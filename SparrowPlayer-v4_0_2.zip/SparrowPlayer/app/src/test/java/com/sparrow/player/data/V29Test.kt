package com.sparrow.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V29Test {
    @Test fun vodHideRoundTrip() {
        val h = VodHide()
        h.addItems(listOf("1:m:5", "ep:77")); h.addGroup("genre:comedies"); h.addRow(VodHide.rowKey("movie", "Top Rated"))
        val back = VodHide.parse(h.serialize())
        assertTrue(back.hasItem("ep:77")); assertTrue("genre:comedies" in back.groups()); assertTrue("movie|Top Rated" in back.rows())
        back.removeItems(listOf("ep:77")); assertFalse(back.hasItem("ep:77"))
        assertEquals(0, VodHide.parse("").items().size)
    }

    @Test fun errorLogRedactsLogins() {
        val r = ErrorLog.redact("failed http://host.tv:8080/movie/user/secret/123.mkv?token=abc and https://x.org/a")
        assertFalse(r.contains("secret")); assertFalse(r.contains("user")); assertTrue(r.contains("host.tv:8080")); assertTrue(r.contains(".mkv"))
    }

    @Test fun errorLogTrimKeepsNewestLines() {
        val t = (1..100).joinToString("\n") { "line$it" }
        val c = ErrorLog.trim(t, 60)
        assertTrue(c.endsWith("line100")); assertFalse(c.startsWith("ine"))
    }

    @Test fun fallbackCountriesOnlyWhenUsCanadaEmpty() {
        fun rd(cc: String, cert: String) = mapOf("iso_3166_1" to cc, "release_dates" to listOf<Any?>(mapOf("certification" to cert)))
        assertEquals("PG-13", Tmdb.movieCertFrom(mapOf("results" to listOf<Any?>(rd("GB", "12A")))))
        assertEquals("PG", Tmdb.movieCertFrom(mapOf("results" to listOf<Any?>(rd("GB", "18"), rd("US", "PG")))))
        assertEquals("", Tmdb.movieCertFrom(mapOf("results" to listOf<Any?>(rd("FR", "12")))))
    }

    @Test fun looseTitleMatch() {
        val res = mapOf("results" to listOf<Any?>(mapOf("id" to "9", "title" to "London Assurance", "original_title" to "London Assurance", "release_date" to "2010-05-01")))
        assertEquals(0, Tmdb.pickId(res, "National Theatre Live London Assurance", 2010, false))
        assertEquals(9, Tmdb.pickIdLoose(res, "National Theatre Live London Assurance", 2010, false))
    }
}
