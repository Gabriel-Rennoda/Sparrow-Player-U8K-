package com.sparrow.player.ui.widget

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyboardCapsTest {
    @Test fun emptyTextIsCapital() { assertTrue(KeyboardCaps.atCaret("", 0)); assertTrue(KeyboardCaps.atCaret(null, 0)) }
    @Test fun renameCaretAtEndIsNotCapital() { assertFalse(KeyboardCaps.atCaret("xyz", 3)) }
    @Test fun backspacedToTheStartIsCapital() { assertTrue(KeyboardCaps.atCaret("", 0)); assertTrue(KeyboardCaps.atCaret("xyz", 0)) }
    @Test fun afterASpaceIsCapital() { assertTrue(KeyboardCaps.atCaret("my ", 3)); assertFalse(KeyboardCaps.atCaret("my g", 4)) }
    @Test fun noCaretMeansEnd() { assertFalse(KeyboardCaps.atCaret("xyz", -1)); assertTrue(KeyboardCaps.atCaret("xyz ", -1)) }
}
