package com.sparrow.player.sports

import org.junit.Assert.*
import org.junit.Test

class SportsChannelMatcherTest {
    private val game = SportsGame("1", "NHL", 0L, GameState.LIVE, SportsTeam("Maple Leafs", "TOR", 3), SportsTeam("Canadiens", "MTL", 2))
    private fun ch(vararg names: String) = names.mapIndexed { i, n -> ChannelRef("1:$i", n) }

    @Test fun teamNamesAndBroadcastersRankChannels() {
        val m = SportsChannelMatcher.match(game, ch("CA: SPORTSNET ONTARIO HD", "NHL: Toronto Maple Leafs vs Montreal Canadiens", "Cartoon Network", "TSN 1"))
        assertEquals("NHL: Toronto Maple Leafs vs Montreal Canadiens", m[0].channel.name); assertEquals("Likely", m[0].label)
        assertEquals(setOf("CA: SPORTSNET ONTARIO HD", "TSN 1"), m.drop(1).map { it.channel.name }.toSet())        // broadcaster only: "Possible"
        assertTrue(m.drop(1).all { it.label == "Possible" })
        assertTrue(m.none { it.channel.name == "Cartoon Network" })                                                   // no evidence, not offered
    }

    @Test fun replaysHighlightsAndTalkAreNeverTheLiveGame() {
        val m = SportsChannelMatcher.match(game, ch("Leafs Highlights HD", "Leafs Lunch Talk Show", "TOR Maple Leafs Live"))
        assertEquals(MatchKind.REPLAY, m.first { it.channel.name.contains("Highlights") }.kind)
        assertEquals(MatchKind.SHOW, m.first { it.channel.name.contains("Talk") }.kind)
        assertEquals(MatchKind.LIVE, m.first { it.channel.name.contains("Live") }.kind)
    }

    @Test fun codesMatchOnlyAsWholeWordsAndAccentsAreIgnored() {
        val m = SportsChannelMatcher.match(game, ch("Stormtrooper TV", "Canadiens de Montréal", "TOR 04"))
        assertTrue(m.none { it.channel.name == "Stormtrooper TV" })                                                  // "tor" inside a word is not TOR
        assertTrue(m.any { it.channel.name == "TOR 04" })
        assertTrue(m.any { it.channel.name == "Canadiens de Montréal" })
    }

    private val start = 1_800_000_000_000L
    private val g2 = game.copy(startMs = start)
    private val h = 3_600_000L

    @Test fun theGuideTellsWhichChannelCarriesTheGame() {
        val chans = ch("Sportsnet Ontario", "TSN 2", "ESPN")
        val progs = listOf(
            ProgrammeRef("1:0", "NHL Hockey: Canadiens at Maple Leafs", start - 10 * 60_000L, start + 3 * h),           // on air in the game window
            ProgrammeRef("1:1", "Curling", start, start + 2 * h),
            ProgrammeRef("1:2", "NHL Tonight", start - 2 * h, start - h))                                                // before the game: not this game
        val m = SportsChannelMatcher.match(g2, chans, progs)
        assertEquals("Sportsnet Ontario", m[0].channel.name); assertEquals(MatchKind.LIVE, m[0].kind); assertEquals("Likely", m[0].label)
        assertNotNull(m[0].programme)
        assertTrue(m.none { it.channel.name == "TSN 2" && it.kind == MatchKind.LIVE && it.score >= 40 })                // curling says nothing
    }

    @Test fun highlightsAndNewsComeFromTheGuideToo() {
        val chans = ch("Sportsnet 360", "TSN 3")
        val progs = listOf(
            ProgrammeRef("1:0", "Leafs Highlights: Canadiens at Maple Leafs", start + 4 * h, start + 5 * h),
            ProgrammeRef("1:1", "Hockey Central: Maple Leafs Post-game Show", start + 4 * h, start + 5 * h),
            ProgrammeRef("1:0", "Maple Leafs vs Canadiens", start + 24 * h, start + 27 * h))                             // tomorrow: a replay, not live
        val m = SportsChannelMatcher.match(g2, chans, progs)
        assertTrue(m.none { it.kind == MatchKind.LIVE && it.score >= 70 })
        assertEquals(MatchKind.REPLAY, m.first { it.channel.name == "Sportsnet 360" }.kind)
        assertEquals(MatchKind.SHOW, m.first { it.channel.name == "TSN 3" }.kind)
    }

    @Test fun searchWordsAreTeamNamesAndLeagueWords() {
        val p = SportsChannelMatcher.searchPatterns(g2)
        assertTrue("maple leafs" in p && "canadiens" in p && "toronto" in p && "nhl" in p); assertTrue("tor" !in p)
    }
}
