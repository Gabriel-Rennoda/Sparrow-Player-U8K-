package com.sparrow.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LanTransferTest {
    @Test fun sealedTextOpensWithTheSameCode() {
        val text = "{\"profiles\":[\"Dad\",\"Kids\"],\"pass\":\"s3cret – ünï\"}".repeat(200)
        val blob = LanTransfer.sealText("4821", text)
        assertEquals(text, LanTransfer.openText("4821", blob))
        assertTrue("passwords must not be readable in what crosses the network", !String(blob, Charsets.ISO_8859_1).contains("s3cret"))
    }

    @Test fun aWrongCodeOrDamagedDataDoesNotOpen() {
        val blob = LanTransfer.sealText("0042", "hello")
        assertNull(LanTransfer.openText("0043", blob))
        blob[blob.size - 1] = (blob[blob.size - 1].toInt() xor 1).toByte()
        assertNull(LanTransfer.openText("0042", blob))
        assertNull(LanTransfer.openText("0042", ByteArray(5)))
    }

    @Test fun codesAreFourDigits() {
        repeat(50) { assertTrue(Regex("[0-9]{4}").matches(LanTransfer.newCode())) }
        assertNotNull(LanTransfer.sealText("0000", ""))
    }
}
