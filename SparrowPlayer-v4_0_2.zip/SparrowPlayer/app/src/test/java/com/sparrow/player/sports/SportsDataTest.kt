package com.sparrow.player.sports

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class SportsDataTest {
    // field names as the sources document them (checked against a real answer on the first run: see SportsDiagnostics)
    private val nhl = mapOf("games" to listOf(
        mapOf("id" to "2026020301", "startTimeUTC" to "2026-11-27T00:30:00Z", "gameState" to "LIVE", "periodDescriptor" to mapOf("number" to "2"),
            "homeTeam" to mapOf("abbrev" to "TOR", "commonName" to mapOf("default" to "Maple Leafs"), "score" to "3"),
            "awayTeam" to mapOf("abbrev" to "MTL", "commonName" to mapOf("default" to "Canadiens"), "score" to "2")),
        mapOf("id" to "2026020250", "startTimeUTC" to "2026-11-20T00:00:00Z", "gameState" to "OFF",
            "homeTeam" to mapOf("abbrev" to "OTT", "placeName" to mapOf("default" to "Ottawa"), "score" to "1"),
            "awayTeam" to mapOf("abbrev" to "TOR", "commonName" to mapOf("default" to "Maple Leafs"), "score" to "4"))))

    @Test fun nhlGamesAreReadAndSortedByTime() {
        val g = NhlParser.parse(nhl)
        assertEquals(listOf("2026020250", "2026020301"), g.map { it.id })
        assertEquals(GameState.FINAL, g[0].state); assertEquals(GameState.LIVE, g[1].state)
        assertEquals("Maple Leafs", g[1].home.name); assertEquals(3, g[1].home.score); assertEquals("Period 2", g[1].status)
        assertEquals("Ottawa", g[0].home.name)                                          // no commonName: the place name
        assertTrue(g[1].startMs > g[0].startMs)
    }

    @Test fun nhlWeekFormatIsReadToo() {
        val week = mapOf("gameWeek" to listOf(mapOf("games" to listOf(mapOf("id" to "9", "startTimeUTC" to "2026-12-01T00:00:00Z", "gameState" to "FUT",
            "homeTeam" to mapOf("abbrev" to "TOR"), "awayTeam" to mapOf("abbrev" to "BOS"))))))
        val g = NhlParser.parse(week); assertEquals(1, g.size); assertEquals(GameState.UPCOMING, g[0].state); assertEquals("TOR", g[0].home.name)
    }

    @Test fun theSportsDbEventsAreRead() {
        val e = mapOf("events" to listOf(
            mapOf("idEvent" to "1", "strLeague" to "NBA", "strHomeTeam" to "Toronto Raptors", "strAwayTeam" to "Boston Celtics", "strStatus" to "Not Started",
                "strTimestamp" to "2026-12-02T00:00:00"),
            mapOf("idEvent" to "2", "strLeague" to "NBA", "strHomeTeam" to "A", "strAwayTeam" to "B", "intHomeScore" to "101", "intAwayScore" to "99",
                "strStatus" to "Match Finished", "dateEvent" to "2026-11-25", "strTime" to "00:00:00")))
        val g = TheSportsDbParser.parse(e)
        assertEquals(listOf("2", "1"), g.map { it.id }); assertEquals(GameState.FINAL, g[0].state); assertEquals(101, g[0].home.score)
        assertEquals(GameState.UPCOMING, g[1].state); assertTrue(g[0].startMs > 0)
        assertTrue(TheSportsDbParser.parse(mapOf("events" to null)).isEmpty())              // the free key answers "null" for an empty list
    }

    @Test fun cacheKeepsCopiesAndSaysHowOld() {
        val dir = java.nio.file.Files.createTempDirectory("sc").toFile()
        val c = SportsCache(dir); c.put("k", "body", 1000L)
        assertEquals("body", c.fresh("k", 500, 1400)); assertNull(c.fresh("k", 500, 2000))
        val again = SportsCache(dir)                                                           // a new process still has the copy (offline use)
        assertEquals(1000L to "body", again.stale("k"))
    }

    @Test fun favouriteClubsToggleInOrderWithoutRepeats() {
        assertEquals("TOR,MTL", NhlTeams.toggle("TOR", "mtl")); assertEquals("TOR", NhlTeams.toggle("TOR,MTL", "MTL"))
        assertEquals("", NhlTeams.toggle("TOR", "TOR")); assertEquals("Toronto Maple Leafs", NhlTeams.nameOf("tor")); assertEquals("BOS", NhlTeams.nameOf("bos"))
    }

    @Test fun rateLimiterAllowsTheQuotaThenWaits() {
        val r = RateLimiter(2)
        assertEquals(0L, r.waitMs(0)); r.record(0); r.record(10_000)
        assertEquals(50_000L, r.waitMs(10_000)); assertEquals(0L, r.waitMs(60_001))
    }

    @Test fun serviceUsesCacheThenFallsBackWhenOffline() = runBlocking {
        var calls = 0; var online = true; var clock = 0L
        val http = SportsHttp { calls++; if (online) "NHL" else null }
        val s = SportsService(http, SportsCache(null), RateLimiter(30), { NhlParserTestHelper.nhl }, { clock })
        val a = s.nhlSeason("TOR"); assertEquals(2, a.games.size); assertFalse(a.fromCache); assertEquals(1, calls)
        clock = 60_000; s.nhlSeason("TOR"); assertEquals(1, calls)                          // fresh copy: no new request
        clock = 3_600_000; online = false
        val off = s.nhlSeason("TOR"); assertTrue(off.fromCache); assertEquals(2, off.games.size); assertEquals(0L, off.updatedMs)   // saved at t = 0
        assertTrue(off.error.isNotEmpty())
    }

    @Test fun serviceSaysSoWhenThereIsNothingSavedAndNoConnection() = runBlocking {
        val s = SportsService({ null }, SportsCache(null), RateLimiter(30), { emptyMap() })
        val r = s.lastEvents("133604"); assertTrue(r.games.isEmpty()); assertTrue(r.fromCache); assertTrue(r.error.isNotEmpty())
    }

    @Test fun serviceStopsAtTheRateLimitAndShowsTheLastCopy() = runBlocking {
        var calls = 0
        val s = SportsService({ calls++; "x" }, SportsCache(null), RateLimiter(1), { emptyMap() }, { 0L })
        s.nextEvents("1"); val second = s.nextEvents("2")
        assertEquals(1, calls); assertTrue(second.fromCache); assertTrue(second.error.contains("Too many"))
    }
}

object NhlParserTestHelper {
    val nhl = mapOf("games" to listOf(
        mapOf("id" to "1", "startTimeUTC" to "2026-11-27T00:30:00Z", "gameState" to "FUT", "homeTeam" to mapOf("abbrev" to "TOR"), "awayTeam" to mapOf("abbrev" to "MTL")),
        mapOf("id" to "2", "startTimeUTC" to "2026-11-20T00:00:00Z", "gameState" to "OFF", "homeTeam" to mapOf("abbrev" to "OTT"), "awayTeam" to mapOf("abbrev" to "TOR"))))
}
