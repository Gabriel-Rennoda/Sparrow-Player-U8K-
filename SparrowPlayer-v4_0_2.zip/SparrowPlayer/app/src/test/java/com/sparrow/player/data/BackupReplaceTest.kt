package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

/** v3.6.8 Live Sync: the Clone becomes a carbon copy of the Source - nothing doubled, nothing left over. */
class BackupReplaceTest {
    private fun e(v: String) = Backup.Entry("s", v)

    private val source = mapOf(
        "profiles" to e("2\tMum\ticon\t\t0\t0\t\t0\n5\tKids\ticon\t\t0\t1\tTV-PG\t0\n"),
        "p5_myList" to e("1:10\n1:11"),
        "cust_1" to e("groups"),
        "active" to e("9"), "lastCh" to e("1:99"), "syncCounts_1" to e("x")
    )
    private val clone = mapOf<String, Any?>(
        "profiles" to "1\tMum\ticon\t\t0\t0\t\t0\n2\tDad\ticon\t\t0\t0\t\t0\n",
        "myList" to "3:7", "p2_myList" to "3:8", "cust_3" to "old", "active" to 3L, "profileActive" to "2",
        "lastCh" to "3:1", "syncCounts_3" to "y", "syncAfterRestart" to true
    )

    @Test fun cloneHoldsExactlyWhatTheSourceHolds() {
        val keep = Backup.replaceWrites(source).map { it.key }.toSet()
        val gone = Backup.replaceRemovals(clone, source).toSet()
        val after = (clone.keys - gone) + keep
        assertEquals(setOf("profiles", "p5_myList", "cust_1", "active", "profileActive", "syncAfterRestart"), after)
    }

    @Test fun profilesAreTheSourcesAloneNoMerge() {
        val w = Backup.replaceWrites(source).first { it.key == "profiles" }
        assertEquals(source["profiles"]!!.v, w.new.v)
        assertEquals(2, w.new.v.lines().filter { it.isNotBlank() }.size)
    }

    @Test fun deviceKeysNeverCrossButStaleOnesGo() {
        val w = Backup.replaceWrites(source).map { it.key }
        assertFalse("lastCh" in w); assertFalse("syncCounts_1" in w); assertFalse("active" in w)
        val gone = Backup.replaceRemovals(clone, source)
        assertTrue("lastCh" in gone); assertTrue("syncCounts_3" in gone)
        assertFalse("active" in gone); assertFalse("profileActive" in gone); assertFalse("syncAfterRestart" in gone)
    }

    @Test fun startsOnTheFirstCopiedProfile() {
        assertEquals("2", Backup.firstProfileId(source))
        assertEquals("1", Backup.firstProfileId(emptyMap()))
    }
}
