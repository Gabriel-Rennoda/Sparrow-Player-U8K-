package com.sparrow.player.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LegacyKeysTest {
    @Test fun retiredKeysAreRecognised() {
        assertTrue(Prefs.isLegacyKey("splitDec"))
        assertTrue(Prefs.isLegacyKey("heroBanner"))
        assertTrue(Prefs.isLegacyKey("p2_splitDec"))
        assertTrue(Prefs.isLegacyKey("p12_heroBanner"))
    }

    @Test fun otherKeysAreKept() {
        assertFalse(Prefs.isLegacyKey("profileActive"))
        assertFalse(Prefs.isLegacyKey("myList"))
        assertFalse(Prefs.isLegacyKey("p2_myList"))
        assertFalse(Prefs.isLegacyKey("splitDecX"))
        assertFalse(Prefs.isLegacyKey("xheroBanner"))
        assertFalse(Prefs.isLegacyKey("pa_heroBanner"))
    }
}
