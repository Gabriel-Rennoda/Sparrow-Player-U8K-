package com.sparrow.player.ui.widget

import org.junit.Assert.*
import org.junit.Test

class KeyboardNavTest {
    private fun nav() = KeyboardNav(KeyboardLayouts.letters(), hasNumberRow = true)

    @Test fun startsOnTheTopLetterRowAndNumbersAreHidden() {
        val n = nav(); assertEquals(1, n.r); assertFalse(n.numbersOpen); assertEquals("q", n.key().label)
    }

    @Test fun tappingUpOnTheTopLetterRowNeverLeavesIt() {
        val n = nav()
        repeat(10) { assertFalse(n.up()) }
        assertEquals(1, n.r); assertFalse(n.numbersOpen)
    }

    @Test fun heldUpOnTheTopRowOpensTheNumberRowAndDownClosesIt() {
        val n = nav(); n.right(); n.right()                      // on "e"
        assertTrue(n.revealNumbers()); assertEquals(0, n.r); assertEquals("3", n.key().label)
        assertFalse(n.up())                                      // nothing above the numbers
        assertTrue(n.down()); assertEquals(1, n.r); assertFalse(n.numbersOpen)
        assertFalse(n.up())                                      // and a tap no longer reaches them
    }

    @Test fun downStopsOnTheBottomRowAndSideKeysStopAtTheEnds() {
        val n = nav()
        repeat(10) { n.down() }
        assertEquals(KeyboardLayouts.letters().lastIndex, n.r)
        assertFalse(n.down())
        repeat(20) { n.right() }; assertEquals("Done", n.key().label); assertFalse(n.right())
        repeat(20) { n.left() }; assertEquals(0, n.c); assertFalse(n.left())
    }

    @Test fun verticalMovesLandUnderTheKeyTheyLeft() {
        val n = nav(); repeat(5) { n.right() }                  // "y"
        n.down(); n.down()                                       // row 3: shift z x c v b n m back -> under y is "b" or "n"
        assertTrue(n.key().label in listOf("v", "b", "n"))
    }

    @Test fun numericBoxesHaveNoNumberRow() {
        val n = KeyboardNav(KeyboardLayouts.numeric(), hasNumberRow = false)
        assertEquals(0, n.r); assertFalse(n.revealNumbers()); assertFalse(n.up())
    }

    @Test fun symbolsLayerAlwaysHasTheNumbersZeroToNine() {
        val rows = KeyboardLayouts.symbols()
        assertEquals("1234567890", rows[0].joinToString("") { it.label })
        val n = KeyboardNav(rows, hasNumberRow = false)
        assertEquals(0, n.r); assertEquals("1", n.key().label); assertFalse(n.up())
    }

    @Test fun topRowLettersCarryTheirNumberAsTheSmallKey() {
        val top = KeyboardLayouts.letters()[1]
        assertEquals("1234567890", top.joinToString("") { it.alt ?: "?" })
        assertEquals("@", KeyboardLayouts.letters()[2][0].alt)
    }
}

