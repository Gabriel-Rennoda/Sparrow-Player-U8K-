package com.sparrow.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TmdbIdTest {
    @Test fun cleansPanelValues() {
        assertEquals("603", TmdbId.clean("603"))
        assertEquals("603", TmdbId.clean(" 603.0 "))
        assertEquals("", TmdbId.clean("0"))
        assertEquals("", TmdbId.clean(""))
        assertEquals("", TmdbId.clean("null"))
        assertEquals("", TmdbId.clean("tt0133093"))
        assertEquals("", TmdbId.clean("12345678901"))
    }

    /** The schema moves 1 -> 2 by adding ONE column with a default: no table is dropped, so every provider login survives. */
    @Test fun migrationOnlyAddsAColumn() {
        val m = Migrations.MIGRATION_1_2
        assertEquals(1, m.startVersion); assertEquals(2, m.endVersion)
        val sql = Migrations.SQL_1_2.uppercase()
        assertTrue(sql.startsWith("ALTER TABLE VOD ADD COLUMN TMDBID"))
        assertTrue(sql.contains("DEFAULT"))
        assertTrue(!sql.contains("DROP") && !sql.contains("DELETE"))
        assertEquals(1, Migrations.ALL.size)
    }
}
