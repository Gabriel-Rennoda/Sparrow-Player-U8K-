package com.sparrow.player.data

import android.content.Context
import android.net.wifi.WifiManager
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketAddress
import java.net.SocketTimeoutException
import java.security.SecureRandom
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import kotlin.concurrent.thread

/**
 * Send / Receive my setup between two devices on the same home network (Settings -> Data, Backup & About).
 *
 *  Sender   : makes the normal backup text, packs (gzip) and seals it (AES-256-GCM, key from a random 4-digit code) and waits.
 *             It answers a UDP broadcast "SPARROW?" (so the other device finds it without typing an address) and hands the sealed blob to
 *             the first device that asks over TCP. It stops by itself after one successful hand-over (or when the person closes it).
 *  Receiver : broadcasts, asks every device that answers for the blob, opens it with the typed code (a wrong code simply does not open),
 *             then the text goes through the normal Restore review (Use Backup / Keep Mine) - nothing is overwritten unasked.
 *
 * Only a sealed blob ever crosses the network, so passwords inside the backup are not readable on the way. A 4-digit code is short: this is
 * meant for a home network, for the minute the Send screen is open.
 */
object LanTransfer {
    const val UDP_PORT = 48557
    const val TCP_PORT = 48558
    private const val ASK = "SPARROW?"
    private const val ANSWER = "SPARROW!"

    fun newCode(): String = SecureRandom().nextInt(10000).toString().padStart(4, '0')

    // ---- sealing ------------------------------------------------------------------------------------------------------------------
    private fun key(code: String, salt: ByteArray): SecretKeySpec {
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(PBEKeySpec(code.toCharArray(), salt, 20000, 256)).encoded
        return SecretKeySpec(raw, "AES")
    }

    private fun gzip(b: ByteArray): ByteArray { val o = ByteArrayOutputStream(); GZIPOutputStream(o).use { it.write(b) }; return o.toByteArray() }
    private fun gunzip(b: ByteArray): ByteArray = GZIPInputStream(ByteArrayInputStream(b)).use { it.readBytes() }

    /** salt(16) + iv(12) + AES-GCM(gzip(text)). */
    fun sealText(code: String, text: String): ByteArray {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(code, salt), GCMParameterSpec(128, iv))
        return salt + iv + c.doFinal(gzip(text.toByteArray(Charsets.UTF_8)))
    }

    /** null = the code is wrong (or the data is damaged). */
    fun openText(code: String, blob: ByteArray): String? {
        if (blob.size < 16 + 12 + 16) return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(code, blob.copyOfRange(0, 16)), GCMParameterSpec(128, blob.copyOfRange(16, 28)))
            String(gunzip(c.doFinal(blob, 28, blob.size - 28)), Charsets.UTF_8)
        } catch (e: Exception) { null }
    }

    // ---- the sending side ---------------------------------------------------------------------------------------------------------
    class Sender(private val ctx: Context, private val blob: ByteArray, private val deviceName: String) {
        @Volatile private var stopped = false
        private var tcp: ServerSocket? = null
        private var udp: DatagramSocket? = null
        private var lock: WifiManager.MulticastLock? = null

        /** Blocks until one device has taken the data (true), [stop] was called, or the network failed (false). Call on a background thread. */
        fun run(): Boolean {
            try {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                lock = try { wm?.createMulticastLock("sparrow")?.also { it.setReferenceCounted(false); it.acquire() } } catch (e: Exception) { null }
                val ss = ServerSocket().also { it.reuseAddress = true; it.bind(InetSocketAddress(TCP_PORT)); tcp = it }
                val ds = DatagramSocket(null as SocketAddress?).also { it.reuseAddress = true; it.bind(InetSocketAddress(UDP_PORT)); it.broadcast = true; udp = it }
                thread(isDaemon = true) { answer(ds) }
                var sent = false
                while (!stopped && !sent) {
                    val c = try { ss.accept() } catch (e: Exception) { break }
                    try { c.use { sent = serve(it) } } catch (e: Exception) { }
                }
                return sent
            } catch (e: Exception) {
                return false
            } finally {
                stop()
            }
        }

        fun stop() {
            stopped = true
            try { tcp?.close() } catch (e: Exception) { }
            try { udp?.close() } catch (e: Exception) { }
            try { lock?.release() } catch (e: Exception) { }
            lock = null
        }

        private fun answer(ds: DatagramSocket) {
            val buf = ByteArray(64)
            while (!stopped && !ds.isClosed) {
                try {
                    val p = DatagramPacket(buf, buf.size)
                    ds.receive(p)
                    if (String(p.data, 0, p.length) == ASK) {
                        val reply = "$ANSWER $deviceName".toByteArray()
                        ds.send(DatagramPacket(reply, reply.size, p.address, p.port))
                    }
                } catch (e: Exception) { if (stopped || ds.isClosed) return }
            }
        }

        private fun serve(c: Socket): Boolean {
            c.soTimeout = 10000
            val line = c.getInputStream().bufferedReader().readLine()
            if (line != "GET") return false
            val out = DataOutputStream(c.getOutputStream().buffered())
            out.writeInt(blob.size); out.write(blob); out.flush()
            return true
        }
    }

    // ---- the receiving side -------------------------------------------------------------------------------------------------------
    sealed class Result {
        class Ok(val text: String) : Result()
        object NoDevice : Result()
        object WrongCode : Result()
        object Failed : Result()
    }

    /** Looks for a sender for about 3.5 s, then asks each one for its data and tries [code]. Call on a background thread. */
    fun receive(ctx: Context, code: String): Result {
        val hosts = find(ctx)
        if (hosts.isEmpty()) return Result.NoDevice
        var opened = false
        for (h in hosts) {
            val blob = try { fetch(h) } catch (e: Exception) { null } ?: continue
            opened = true
            val text = openText(code, blob)
            if (text != null) return Result.Ok(text)
        }
        return if (opened) Result.WrongCode else Result.Failed
    }

    @Suppress("DEPRECATION")
    private fun broadcastTargets(ctx: Context): List<InetAddress> {
        val out = ArrayList<InetAddress>()
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val d = wm?.dhcpInfo
            if (d != null && d.ipAddress != 0 && d.netmask != 0) {
                val b = (d.ipAddress and d.netmask) or d.netmask.inv()
                out += InetAddress.getByAddress(byteArrayOf((b and 0xff).toByte(), (b shr 8 and 0xff).toByte(), (b shr 16 and 0xff).toByte(), (b shr 24 and 0xff).toByte()))
            }
        } catch (e: Exception) { }
        try { out += InetAddress.getByName("255.255.255.255") } catch (e: Exception) { }
        return out
    }

    private fun find(ctx: Context): List<String> {
        val found = LinkedHashSet<String>()
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val lock = try { wm?.createMulticastLock("sparrow")?.also { it.setReferenceCounted(false); it.acquire() } } catch (e: Exception) { null }
        val ds = DatagramSocket().also { it.broadcast = true; it.soTimeout = 500 }
        try {
            val msg = ASK.toByteArray()
            val targets = broadcastTargets(ctx)
            val end = System.currentTimeMillis() + 3500
            var lastSend = 0L
            while (System.currentTimeMillis() < end) {
                if (System.currentTimeMillis() - lastSend > 1000) {
                    for (t in targets) try { ds.send(DatagramPacket(msg, msg.size, t, UDP_PORT)) } catch (e: Exception) { }
                    lastSend = System.currentTimeMillis()
                }
                try {
                    val p = DatagramPacket(ByteArray(128), 128)
                    ds.receive(p)
                    if (String(p.data, 0, p.length).startsWith(ANSWER)) p.address.hostAddress?.let { found += it }
                } catch (e: SocketTimeoutException) { }
            }
        } finally {
            ds.close()
            try { lock?.release() } catch (e: Exception) { }
        }
        return found.toList()
    }

    private fun fetch(host: String): ByteArray? {
        return Socket().use { s ->
            s.connect(InetSocketAddress(host, TCP_PORT), 4000)
            s.soTimeout = 20000
            s.getOutputStream().apply { write("GET\n".toByteArray()); flush() }
            val inp = DataInputStream(s.getInputStream().buffered())
            val n = inp.readInt()
            if (n !in 1..50_000_000) null else ByteArray(n).also { inp.readFully(it) }
        }
    }
}
