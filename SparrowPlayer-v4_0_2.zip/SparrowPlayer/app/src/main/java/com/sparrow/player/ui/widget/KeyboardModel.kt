package com.sparrow.player.ui.widget

/** What a key does when it is not a plain character. */
enum class Fn { SHIFT, SYMBOLS, LETTERS, BACKSPACE, DONE, SPACE }

/** One key: [label] on the cap, [out] = the text it types (null for a function key), [w] = relative width (a normal key is 2), [alt] = what HOLDING OK on it types instead (drawn small at the top right of the cap, v3.4.0). */
class Key(val label: String, val out: String? = null, val fn: Fn? = null, val w: Int = 2, val alt: String? = null)

/** The key layers of Sparrow's own keyboard (v3.3.0). Pure Kotlin so the navigation can be unit-tested. */
object KeyboardLayouts {
    private fun chars(s: String): List<Key> = s.map { Key(it.toString(), it.toString()) }
    /** Keys with a hold-OK alternate: [alts] has one character per key of [s] (a space = none). */
    private fun charsAlt(s: String, alts: String): List<Key> = s.mapIndexed { i, ch ->
        val a = alts.getOrNull(i)?.takeIf { it != ' ' }?.toString()
        Key(ch.toString(), ch.toString(), alt = a)
    }

    /** Row 0 of the letter layer is the NUMBER row: hidden until Up is pressed and HELD on the top letter row. */
    fun letters(): List<List<Key>> = listOf(
        chars("1234567890"),
        charsAlt("qwertyuiop", "1234567890"),
        charsAlt("asdfghjkl-", "@#$%&-+()_"),
        listOf(Key("⇧", fn = Fn.SHIFT, w = 3)) + charsAlt("zxcvbnm", "*\"':;!?") + Key("⌫", fn = Fn.BACKSPACE, w = 3),
        listOf(Key("123 #", fn = Fn.SYMBOLS, w = 3), Key("@", "@", alt = "_"), Key(".", ".", alt = ","), Key(":", ":", alt = ";"), Key("space", " ", Fn.SPACE, 6), Key("/", "/", alt = "?"), Key("Done", fn = Fn.DONE, w = 3))
    )

    /** The 123 # layer: its number row (0-9) is ALWAYS visible (v3.4.0: it used to be hidden like the letters' number row). */
    fun symbols(): List<List<Key>> = listOf(
        chars("1234567890"),
        chars("!@#$%^&*()"),
        chars("-_=+/:;'\"?"),
        listOf(Key("<", "<", w = 3)) + chars(",.~\\|{}") + Key("⌫", fn = Fn.BACKSPACE, w = 3),
        listOf(Key("ABC", fn = Fn.LETTERS, w = 3), Key(">", ">"), Key("space", " ", Fn.SPACE, 12), Key("Done", fn = Fn.DONE, w = 3))
    )

    /** Number-only boxes (PIN, port ...): no number row to reveal. */
    fun numeric(): List<List<Key>> = listOf(
        chars("123"), chars("456"), chars("789"),
        listOf(Key("⌫", fn = Fn.BACKSPACE), Key("0", "0"), Key("Done", fn = Fn.DONE))
    )
}

/**
 * The selector of the keyboard. Left / Right stop at the ends of a row; Down on the bottom row stays; Up on the top LETTER row stays
 * (the number row above it is only reached by [revealNumbers], which the keyboard calls when Up is HELD). Rows have different key widths, so a vertical move
 * lands on the key under the middle of the key it left.
 */
class KeyboardNav(val rows: List<List<Key>>, val hasNumberRow: Boolean) {
    var r = if (hasNumberRow) 1 else 0
    var c = 0
    /** true while the number row (row 0) can be reached. */
    var numbersOpen = false
        private set
    private val top get() = if (hasNumberRow && !numbersOpen) 1 else 0

    fun key(): Key = rows[r][c]

    private fun center(row: Int, col: Int): Int { var x = 0; for (i in 0 until col) x += rows[row][i].w; return x * 2 + rows[row][col].w }
    private fun colAt(row: Int, mid2: Int): Int {
        var x = 0
        for (i in rows[row].indices) { x += rows[row][i].w * 2; if (mid2 < x) return i }
        return rows[row].lastIndex
    }

    fun left(): Boolean { if (c == 0) return false; c--; return true }
    fun right(): Boolean { if (c >= rows[r].lastIndex) return false; c++; return true }

    fun down(): Boolean {
        if (r >= rows.lastIndex) return false
        val m = center(r, c); r++; c = colAt(r, m)
        if (numbersOpen && r == 1) numbersOpen = false          // back on the letters: the number row tucks away again
        return true
    }

    /** A plain (tapped) Up: never reaches the number row. */
    fun up(): Boolean {
        if (r <= top) return false
        val m = center(r, c); r--; c = colAt(r, m)
        return true
    }

    /** Up HELD on the top letter row: opens the number row and moves onto it. */
    fun revealNumbers(): Boolean {
        if (!hasNumberRow || r != 1 || numbersOpen) return false
        val m = center(r, c); numbersOpen = true; r = 0; c = colAt(0, m)
        return true
    }
}

/** v3.5.0: when does the next typed letter get a capital (names)? At the start of the text or right after a space. Pure, so it can be unit-tested. */
object KeyboardCaps {
    fun atCaret(text: String?, caret: Int): Boolean {
        if (text == null) return true
        var a = caret; if (a < 0) a = text.length
        if (a > text.length) a = text.length
        return a == 0 || text[a - 1].isWhitespace()
    }
}
