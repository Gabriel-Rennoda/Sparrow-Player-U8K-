package com.sparrow.player.sports

import java.io.File

/** Saved copies of answers: fresh ones avoid a request, stale ones are what the Sports tab shows when the network is down ("last updated ..."). */
class SportsCache(private val dir: File?) {
    private val mem = HashMap<String, Pair<Long, String>>()

    private fun file(key: String) = dir?.let { File(it, Integer.toHexString(key.hashCode()) + ".json") }

    @Synchronized fun put(key: String, body: String, now: Long) {
        mem[key] = now to body
        try { file(key)?.let { it.parentFile?.mkdirs(); it.writeText("$now\n$body") } } catch (e: Exception) { }
    }

    /** The saved copy and when it was saved, whatever its age; null when there is none. */
    @Synchronized fun stale(key: String): Pair<Long, String>? {
        mem[key]?.let { return it }
        return try {
            val t = file(key)?.takeIf { it.exists() }?.readText() ?: return null
            val at = t.substringBefore('\n').toLongOrNull() ?: return null
            (at to t.substringAfter('\n')).also { mem[key] = it }
        } catch (e: Exception) { null }
    }

    /** The saved copy only if it is younger than [maxAgeMs]. */
    fun fresh(key: String, maxAgeMs: Long, now: Long): String? = stale(key)?.takeIf { now - it.first in 0..maxAgeMs }?.second
}

/** At most [perMinute] requests in any 60 seconds (TheSportsDB's free key allows about 30). */
class RateLimiter(private val perMinute: Int) {
    private val times = ArrayDeque<Long>()

    /** 0 = go ahead; otherwise how many milliseconds to wait. Call [record] when the request is made. */
    @Synchronized fun waitMs(now: Long): Long {
        while (times.isNotEmpty() && now - times.first() >= 60_000L) times.removeFirst()
        return if (times.size < perMinute) 0L else 60_000L - (now - times.first())
    }
    @Synchronized fun record(now: Long) { times.addLast(now) }
}
