package com.sparrow.player.sports

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/** The real network for [SportsService]: the app's OkHttp client; any failure is simply "no answer" (the cache then speaks). */
class OkSportsHttp(private val client: OkHttpClient) : SportsHttp {
    override suspend fun get(url: String): String? = withContext(Dispatchers.IO) {
        try {
            client.newCall(Request.Builder().url(url).header("User-Agent", "SparrowPlayer").build()).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
        } catch (e: Exception) { null }
    }
}
