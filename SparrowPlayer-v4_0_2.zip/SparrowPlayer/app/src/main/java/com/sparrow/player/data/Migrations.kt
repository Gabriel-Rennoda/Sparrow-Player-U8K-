package com.sparrow.player.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Room migrations, oldest first. Version 1 is the schema shipped since v1.0.
 * When an @Entity changes: bump AppDb.version, add a Migration here (ALTER TABLE ... ADD COLUMN ..., keeping every existing row, especially `providers`),
 * and add it to ALL. A new column needs a DEFAULT in the SQL and the same default in the entity's @ColumnInfo(defaultValue = ...) or Room refuses to open the file.
 */
object Migrations {
    /** v3.1.0: the TMDB id of every movie / series (read from the panel's lists). Existing rows get '' until the next sync fills them in. */
    const val SQL_1_2 = "ALTER TABLE vod ADD COLUMN tmdbId TEXT NOT NULL DEFAULT ''"

    val MIGRATION_1_2: Migration = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) { db.execSQL(SQL_1_2) }
    }

    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2)
}
