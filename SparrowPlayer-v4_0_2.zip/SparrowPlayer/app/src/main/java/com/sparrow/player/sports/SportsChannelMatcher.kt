package com.sparrow.player.sports

data class ChannelRef(val uid: String, val name: String)

enum class MatchKind { LIVE, REPLAY, SHOW }

/** What the guide says a channel airs: the programme title and its times (milliseconds). */
data class ProgrammeRef(val channelUid: String, val title: String, val startMs: Long, val stopMs: Long)

data class ChannelMatch(val channel: ChannelRef, val score: Int, val kind: MatchKind, val reasons: List<String>, val programme: ProgrammeRef? = null) {
    /** "Likely" / "Good" / "Possible": shown next to the channel so a weak match is never presented as a sure one. */
    val label: String get() = when { score >= 70 -> "Likely"; score >= 40 -> "Good"; else -> "Possible" }
}

/**
 * Which channels of the playlist may carry a game. Evidence only: a team's name, city or 3-letter code as a whole word in the channel name (+40 each,
 * +30 when both teams are named), a league word (+10) or a broadcaster that carries the sport (+20). Channels that say replay / highlights / recap are
 * REPLAY, news and talk are SHOW: never offered as the live game. Below 20 points a channel is not offered at all (no guessing).
 */
object SportsChannelMatcher {
    private val REPLAY = Regex("\\b(replay|replays|re air|rerun|highlights?|recap|condensed|classic|archive|encore)\\b")
    private val SHOW = Regex("\\b(news|talk|show|tonight|insider|analysis|podcast|radio)\\b")
    private val LEAGUE = listOf("nhl", "hockey")
    private val BROADCASTERS = listOf("sportsnet", "sn1", "sn360", "tsn", "cbc", "hockey night", "rds", "tva sports", "nhl network", "center ice", "espn")

    fun normalize(s: String): String {
        val d = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return " " + d.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim() + " "
    }

    private fun has(text: String, word: String): Boolean = word.isNotBlank() && text.contains(" " + word.trim() + " ")

    private fun aliases(t: SportsTeam): List<String> {
        if (t.name.isBlank() && t.abbrev.isBlank()) return emptyList()
        val full = NhlTeams.nameOf(t.abbrev).takeIf { t.abbrev.isNotBlank() && it != t.abbrev.uppercase() } ?: ""
        val common = normalize(t.name).trim()
        val city = if (full.isNotBlank() && common.isNotBlank()) normalize(full).trim().removeSuffix(common).trim() else ""
        val last = common.substringAfterLast(' ').takeIf { it.length >= 5 } ?: ""          // "leafs" for "maple leafs"
        return listOf(common, last, normalize(full).trim(), city, t.abbrev.lowercase()).filter { it.length >= 3 }.distinct()
    }

    /** Words to look for in guide titles (lower case): the teams' names and cities (not the 3-letter codes) and the league words. */
    fun searchPatterns(game: SportsGame): List<String> =
        (aliases(game.home) + aliases(game.away)).filter { it.length >= 4 }.map { it.trim() }.distinct() + LEAGUE

    private class Prog(val score: Int, val kind: MatchKind, val p: ProgrammeRef, val reason: String)

    /** One guide entry against the game: team names in the title, a league word, and whether it airs while the game is on (15 min before to 3.5 h after the start). */
    private fun scoreProgramme(game: SportsGame, home: List<String>, away: List<String>, p: ProgrammeRef): Prog? {
        val t = normalize(p.title)
        val h = home.any { has(t, it) }; val a = away.any { has(t, it) }
        val inWindow = p.stopMs > game.startMs - 15 * 60_000L && p.startMs < game.startMs + 210 * 60_000L
        val league = LEAGUE.any { has(t, it) }
        var s = 0
        if (h) s += 40
        if (a) s += 40
        if (h && a) s += 30
        if (s == 0 && !(league && inWindow)) return null
        if (league && inWindow) s += 25
        if (inWindow) s += 20
        var kind = when { REPLAY.containsMatchIn(t) -> MatchKind.REPLAY; SHOW.containsMatchIn(t) -> MatchKind.SHOW; else -> MatchKind.LIVE }
        if (!inWindow && kind == MatchKind.LIVE) kind = MatchKind.REPLAY            // a later airing of the same game is a replay
        return Prog(s, kind, p, if (inWindow) "guide: on air in the game window" else "guide: other airing")
    }

    fun match(game: SportsGame, channels: List<ChannelRef>, programmes: List<ProgrammeRef> = emptyList()): List<ChannelMatch> {
        val home = aliases(game.home); val away = aliases(game.away)
        val byChannel = programmes.groupBy { it.channelUid }
        return channels.mapNotNull { c ->
            val n = normalize(c.name)
            val reasons = ArrayList<String>(); var score = 0
            val h = home.any { has(n, it) }; val a = away.any { has(n, it) }
            if (h) { score += 40; reasons += "names ${game.home.name.ifBlank { game.home.abbrev }}" }
            if (a) { score += 40; reasons += "names ${game.away.name.ifBlank { game.away.abbrev }}" }
            if (h && a) { score += 30; reasons += "both teams" }
            if (LEAGUE.any { has(n, it) }) { score += 10; reasons += "league" }
            if (BROADCASTERS.any { has(n, it) }) { score += 20; reasons += "broadcaster" }
            val best = byChannel[c.uid]?.mapNotNull { scoreProgramme(game, home, away, it) }
                ?.maxWithOrNull(compareBy<Prog> { it.score }.thenBy { if (it.kind == MatchKind.LIVE) 1 else 0 })
            if (best != null) { score += best.score; reasons += best.reason }
            if (score < 20) null else {
                val kind = best?.kind ?: when { REPLAY.containsMatchIn(n) -> MatchKind.REPLAY; SHOW.containsMatchIn(n) -> MatchKind.SHOW; else -> MatchKind.LIVE }
                ChannelMatch(c, score, kind, reasons, best?.p)
            }
        }.sortedWith(compareByDescending<ChannelMatch> { it.score }.thenBy { it.channel.name })
    }
}
