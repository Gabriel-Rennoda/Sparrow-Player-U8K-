package com.sparrow.player.ui.menus

import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Repository
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * The pop-up that opens when OK is held on a channel in the guide: every option for that one channel.
 *
 *  Add To / Remove From Favourites · Unhide (only for a hidden channel) · Hide Channels · Copy Channels · Move Channels (asks Yes / No first)
 *  · Delete Channels (out of the group being viewed, own groups only) · Set As Opening Channel · Edit Channel Name · Restore Original Name
 *
 * Hide / Copy / Move / Delete Channels open the guide's tick-box mode with this channel already ticked; Settings -> General -> Hidden brings hidden
 * channels back. All edits are saved per provider (see Customize) and survive syncs.
 */
object ChannelMenu {
    class Hooks(
        val toggleFavorite: (Channel) -> Unit,
        /** The channel was hidden / unhidden. A hidden one is taken out of the list at once. */
        val hiddenChanged: (Channel, Boolean) -> Unit,
        /** The channel got another name. */
        val renamed: (Channel) -> Unit,
        /** The channel now belongs to other groups (copy / move / remove): reload the list around it. */
        val membershipChanged: (Channel) -> Unit,
        /** "Copy Channels": the guide goes into tick-box mode with this channel ticked (see EpgView.startSelecting). */
        val startCopySelect: (Channel) -> Unit,
        /** "Hide Channels": the same tick-box mode, opened for hiding. */
        val startHideSelect: (Channel) -> Unit,
        /** "Move Channels" (only while viewing a group of the user's own): the same tick-box mode. */
        val startMoveSelect: (Channel) -> Unit,
        /** "Delete Channels" (only while viewing a group of the user's own): the same tick-box mode, opened for removing from the group. */
        val startDeleteSelect: (Channel) -> Unit
    )

    fun show(a: FragmentActivity, c: Channel, scope: String, h: Hooks) {
        val repo = a.applicationContext.repo
        val pid = c.providerId
        val cu = repo.custom(pid)
        val inGroup = scope != Repository.SCOPE_ALL && scope != Repository.SCOPE_FAV
        val inMine = cu.customGroups.containsKey(scope)                       // provider groups are never changed: Move / Remove only inside my own groups
        val hidden = cu.isHidden(c.uid)
        val renamed = cu.renamed.containsKey(c.uid)

        val p = Popup(a, c.name, "Channel Options")
        p.row(if (c.isFavorite) "Remove From Favourites" else "Add To Favourites") { h.toggleFavorite(c) }
        if (hidden) p.row("Unhide Channel") {
            cu.setHidden(c.uid, false); repo.saveCustom(pid)
            h.hiddenChanged(c, false)
            toast(a, "Channel unhidden")
        }
        p.row("Hide Channels") { h.startHideSelect(c) }
        p.row("Copy Channels") { h.startCopySelect(c) }
        if (inMine) p.row("Move Channels") { h.startMoveSelect(c) }
        if (inMine) p.row("Delete Channels") { h.startDeleteSelect(c) }
        val isOpening = repo.prefs.openChannel == c.uid
        p.row(if (isOpening) "Clear Opening Channel" else "Set As Opening Channel") {
            repo.prefs.openChannel = if (isOpening) "" else c.uid
            toast(a, if (isOpening) "Opening channel cleared – the app opens on the last channel" else "${c.name} is now the opening channel")
        }
        p.row("Edit Channel Name…") {
            a.lifecycleScope.launch {
                val original = repo.dao.channel(c.uid)?.name ?: c.name
                Popup.ask(a, "Edit Channel Name", "Channel name", c.name) { n ->
                    cu.rename(c.uid, n, original); repo.saveCustom(pid)
                    h.renamed(c.copy(name = cu.nameOf(c.uid, original))); toast(a, "Name saved")
                }
            }
        }
        if (renamed) p.row("Restore Original Name") {
            a.lifecycleScope.launch {
                val original = repo.dao.channel(c.uid)?.name ?: c.name
                cu.renamed.remove(c.uid); repo.saveCustom(pid)
                h.renamed(c.copy(name = original)); toast(a, "Original name restored")
            }
        }
        p.show()
    }

    /**
     * The second half of "Copy To Group": [list] = the ticked channels. Choose an existing group, or make a new one (it goes to the top of the groups,
     * just below Favourites) and copy into it. [onDone] runs after a copy so the guide can reload on the same group and channel.
     */
    fun copyMany(a: FragmentActivity, list: List<Channel>, onDone: () -> Unit) {
        if (list.isEmpty()) return
        a.lifecycleScope.launch {
            val repo = a.applicationContext.repo
            val pid = list[0].providerId
            val cu = repo.custom(pid)
            val groups = repo.groups(pid)
            val n = list.size
            val noun = if (n == 1) "1 Channel" else "$n Channels"
            val p = Popup(a, "Copy $noun To…", "Pick a group, or make a new one")
            p.row("＋  New Group…") {
                Popup.ask(a, "New Group", "Group name", "", onCancel = { copyMany(a, list, onDone) }) { name ->
                    val gid = cu.createGroup(name)
                    for (ch in list) cu.copy(ch.uid, gid, ch.categoryId)
                    repo.saveCustom(pid); onDone()
                    toast(a, "$noun copied to new group \"${cu.groupName(gid, name)}\"")
                }
            }
            // a provider group stays as the provider defined it: only groups you created (or a channel's own group) take copies
            val targets = groups.filter { g -> list.all { cu.canReceive(g.id, it.categoryId) } && list.any { !cu.isMember(g.id, it.uid, it.categoryId) } }
            for (g in targets) p.row(g.name + if (g.hidden) "  (Hidden)" else "") {
                var added = 0
                for (ch in list) if (!cu.isMember(g.id, ch.uid, ch.categoryId)) { cu.copy(ch.uid, g.id, ch.categoryId); added++ }
                repo.saveCustom(pid); onDone()
                toast(a, (if (added == 1) "1 channel" else "$added channels") + " copied to ${g.name}")
            }
            p.note("Groups from your provider keep exactly their own channels. Make a new group above to collect channels.")
            p.show()
        }
    }

    /**
     * Hide the ticked channels after one Yes / No (with "Do Not Show This Again"); when Settings -> Ask Before Hiding is off they are hidden at once.
     * [onDone] lets the guide reload on the same group.
     */
    fun hideMany(a: FragmentActivity, list: List<Channel>, onDone: () -> Unit) {
        if (list.isEmpty()) return
        val repo = a.applicationContext.repo
        val noun = if (list.size == 1) "1 channel" else "${list.size} channels"
        fun doHide() {
            val pid = list[0].providerId
            val cu = repo.custom(pid)
            for (ch in list) cu.setHidden(ch.uid, true)
            repo.saveCustom(pid); onDone()
            toast(a, "$noun hidden")
        }
        if (!repo.prefs.askBeforeHide) { doHide(); return }
        var dontAsk = false
        val p = Popup(a, "Hide $noun?")
        p.note("They leave the guide at once. Settings → General → Hidden brings them back.")
        p.row("No") { }
        p.row("Do Not Show This Again", "☐", keepOpen = true) { r -> dontAsk = !dontAsk; r.setValue(if (dontAsk) "☑" else "☐") }
        p.row("Yes, Hide") { if (dontAsk) repo.prefs.askBeforeHide = false; doHide() }
        p.show()
    }

    /** Take the ticked channels out of the group being viewed ([from], one of the user's own) after one Yes / No. They stay in All Channels and other groups. */
    fun deleteMany(a: FragmentActivity, list: List<Channel>, from: String, onDone: () -> Unit) {
        if (list.isEmpty()) return
        val repo = a.applicationContext.repo
        val noun = if (list.size == 1) "1 channel" else "${list.size} channels"
        Popup.confirm(a, "Remove $noun From Group?", "They leave this group only. They stay in All Channels and in their other groups.", "Yes, Remove") {
            val pid = list[0].providerId
            val cu = repo.custom(pid)
            for (ch in list) cu.removeFrom(from, ch.uid, ch.categoryId)
            repo.saveCustom(pid); onDone()
            toast(a, "$noun removed from group")
        }
    }

    /**
     * The second half of "Move To Group": only inside groups YOU made (a provider group is never changed). [from] = the group being viewed.
     * Asks Yes / No, then the ticked channels leave [from] and appear in the target (an existing group of yours or a new one).
     */
    fun moveMany(a: FragmentActivity, list: List<Channel>, from: String, onDone: () -> Unit) {
        if (list.isEmpty()) return
        a.lifecycleScope.launch {
            val repo = a.applicationContext.repo
            val pid = list[0].providerId
            val cu = repo.custom(pid)
            val groups = repo.groups(pid)
            val fromName = groups.firstOrNull { it.id == from }?.name ?: "this group"
            val noun = if (list.size == 1) "1 Channel" else "${list.size} Channels"
            fun go(toName: String, target: () -> String) {
                Popup.confirm(a, "Move $noun?", "Move $noun from $fromName to $toName? They are removed from $fromName.", "Yes, Move") {
                    val to = target()
                    for (ch in list) cu.move(ch.uid, from, to, ch.categoryId)
                    repo.saveCustom(pid); onDone()
                    toast(a, "$noun moved to $toName")
                }
            }
            val p = Popup(a, "Move $noun To…", "Out of $fromName")
            p.row("＋  New Group…") {
                Popup.ask(a, "New Group", "Group name", "", onCancel = { moveMany(a, list, from, onDone) }) { name ->
                    go(name.trim().ifEmpty { "New Group" }) { cu.createGroup(name) }
                }
            }
            for (g in groups.filter { it.id != from && cu.customGroups.containsKey(it.id) }) p.row(g.name + if (g.hidden) "  (Hidden)" else "") { go(g.name) { g.id } }
            p.show()
        }
    }

    private fun toast(a: FragmentActivity, msg: String) = Toast.makeText(a, msg, Toast.LENGTH_SHORT).show()
}
