package com.sparrow.player.sports

/**
 * Gets games from the two sources through the cache: a fresh saved copy is used first; otherwise one request; if that fails (offline, rate limit),
 * the saved copy of ANY age is returned with fromCache = true so the screen can say "last updated ...".
 */
class SportsService(
    private val http: SportsHttp,
    private val cache: SportsCache,
    private val limiter: RateLimiter,
    private val parseJson: (String) -> Map<String, Any?>,
    private val now: () -> Long = { System.currentTimeMillis() }
) {
    companion object {
        const val SCHEDULE_TTL = 15 * 60_000L       // a team's season schedule
        const val LIVE_TTL = 30_000L                // the NHL scoreboard while games are on
        const val EVENTS_TTL = 10 * 60_000L         // TheSportsDB last / next events
    }

    private suspend fun load(url: String, ttl: Long, limited: Boolean, parse: (Map<String, Any?>) -> List<SportsGame>): SportsResult {
        val t = now()
        cache.fresh(url, ttl, t)?.let { body -> return SportsResult(parseSafe(url, body, parse), false, cache.stale(url)?.first ?: t) }
        if (limited && limiter.waitMs(t) > 0) return fallback(url, parse, "Too many requests, showing the last copy")
        if (limited) limiter.record(t)
        val body = try { http.get(url) } catch (e: Exception) { null }
        if (body.isNullOrBlank()) return fallback(url, parse, "No connection, showing the last copy")
        SportsDiagnostics.add("GET $url -> ${body.length} chars: ${body.take(200)}")
        val games = parseSafe(url, body, parse)
        cache.put(url, body, t)
        return SportsResult(games, false, t)
    }

    private fun parseSafe(url: String, body: String, parse: (Map<String, Any?>) -> List<SportsGame>): List<SportsGame> =
        try { parse(parseJson(body)) } catch (e: Exception) { SportsDiagnostics.add("PARSE FAILED $url: ${e.message}"); emptyList() }

    private fun fallback(url: String, parse: (Map<String, Any?>) -> List<SportsGame>, why: String): SportsResult {
        val old = cache.stale(url) ?: return SportsResult(emptyList(), true, 0L, why)
        return SportsResult(parseSafe(url, old.second, parse), true, old.first, why)
    }

    /** A team's whole NHL season (past results and coming games). abbrev = "TOR". */
    suspend fun nhlSeason(abbrev: String) = load(NhlParser.teamSeasonUrl(abbrev), SCHEDULE_TTL, false, NhlParser::parse)

    /** Today's NHL scoreboard (live scores). */
    suspend fun nhlScores() = load(NhlParser.scoresUrl(), LIVE_TTL, false, NhlParser::parse)

    suspend fun nextEvents(teamId: String) = load(TheSportsDbParser.nextUrl(teamId), EVENTS_TTL, true, TheSportsDbParser::parse)
    suspend fun lastEvents(teamId: String) = load(TheSportsDbParser.lastUrl(teamId), EVENTS_TTL, true, TheSportsDbParser::parse)
}
