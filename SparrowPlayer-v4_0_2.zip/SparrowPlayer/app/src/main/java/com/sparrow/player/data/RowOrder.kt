package com.sparrow.player.data

/**
 * v3.6.11: the order of the rows on the All Movies / All Series page. The first ten rows are LOCKED, in this order:
 *  1 Top Picks for <profile>   2 Top 10 ... Today in <country>   3 Trending Now   4 Continue Watching for <profile>   5 My List
 *  6 <year> Releases   7 Recently Added   8 Top Rated   9 Top 10 Kids Titles Today   10 Watch It Again
 * then every "Because You Watched / Loved / Liked / Added ..." row (11), then all other rows (12) in the order they were built.
 * A row with nothing in it is never made, so it simply is not there until it has titles. Pure Kotlin, unit tested.
 */
object RowOrder {
    const val BECAUSE = 11
    const val OTHER = 12

    fun rank(title: String, profile: String, year: Int): Int = when {
        title == "Top Picks for $profile" -> 1
        title.startsWith("Top 10 ") && title.contains(" Today in ") -> 2
        title == "Trending Now" -> 3
        title == "Continue Watching for $profile" -> 4
        title == "My List" -> 5
        title == "$year Releases" -> 6
        title == "${year - 1} Releases" -> 6
        title == "Recently Added" -> 7
        title == "Top Rated" -> 8
        title == "Top 10 Kids Titles Today" -> 9
        title == "Watch It Again" -> 10
        title.startsWith("Because You ") -> BECAUSE
        else -> OTHER
    }

    /** Stable: rows of the same rank keep the order they were built in. */
    fun <T> arrange(items: List<T>, profile: String, year: Int, titleOf: (T) -> String): List<T> =
        items.withIndex().sortedWith(compareBy<IndexedValue<T>>({ rank(titleOf(it.value), profile, year) }, { it.index })).map { it.value }

    /**
     * Where a row that arrives LATE (the heavy named carousels) goes among the rows already on screen: after the last row of the same or a lower rank
     * (locked and "Because" rows), or at [regionEnd] (the end of the arranged rows, before the provider's own categories) for any other row.
     */
    fun insertIndex(existing: List<String>, regionEnd: Int, title: String, profile: String, year: Int): Int {
        val r = rank(title, profile, year)
        val end = minOf(regionEnd, existing.size)
        if (r == OTHER) return end
        var pos = 0
        for (i in 0 until end) if (rank(existing[i], profile, year) <= r) pos = i + 1
        return pos
    }
}
