package com.sparrow.player.data

/**
 * What a profile hid in Movies / Series (v2.9.0), kept in one preference string per profile ([Prefs.vodHiddenRaw]) - no database change, so no playlist login is at risk
 * (docs/UPGRADE_SAFETY.md). Three kinds of entry, one per line ("u" / "g" / "r", a tab, the value):
 *  - u: a title uid, or "ep:<episode id>" for one episode of a series;
 *  - g: a group of the Movies / Series groups list (its scope id, e.g. "genre:comedies");
 *  - r: a carousel, "<movie|series>|<carousel title>".
 * Pure Kotlin, unit tested.
 */
class VodHide {
    private val items = LinkedHashSet<String>()
    private val groups = LinkedHashSet<String>()
    private val rows = LinkedHashSet<String>()

    fun items(): Set<String> = items
    fun groups(): Set<String> = groups
    fun rows(): Set<String> = rows

    fun hasItem(uid: String) = uid in items
    fun addItems(l: Collection<String>) { items.addAll(l.filter { it.isNotBlank() }) }
    fun removeItems(l: Collection<String>) { items.removeAll(l.toSet()) }
    fun addGroup(id: String) { if (id.isNotBlank()) groups += id }
    fun removeGroup(id: String) { groups -= id }
    fun addRow(key: String) { if (key.isNotBlank()) rows += key }
    fun removeRow(key: String) { rows -= key }

    fun serialize(): String =
        (items.map { "u\t$it" } + groups.map { "g\t$it" } + rows.map { "r\t$it" }).joinToString("\n")

    companion object {
        fun rowKey(type: String, title: String) = "$type|$title"

        fun parse(s: String?): VodHide = VodHide().also { h ->
            for (line in (s ?: "").split('\n')) {
                if (line.length < 3 || line[1] != '\t') continue
                val v = line.substring(2)
                when (line[0]) { 'u' -> h.items += v; 'g' -> h.groups += v; 'r' -> h.rows += v }
            }
        }
    }
}
