package com.sparrow.player.data

/** The TMDB id a panel lists for a title (\"tmdb\" in get_vod_streams / get_series): digits only; \"\", \"0\", \"null\" and anything else mean \"none\". */
object TmdbId {
    fun clean(raw: String): String {
        val t = raw.trim().substringBefore('.')          // numbers can arrive as 603.0
        if (t.isEmpty() || t.length > 9 || !t.all { it.isDigit() }) return ""
        return if (t.trimStart('0').isEmpty()) "" else t.trimStart('0')
    }
}
