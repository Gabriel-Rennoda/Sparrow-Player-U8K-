package com.sparrow.player.sports

/** The NHL's web data (api-web.nhle.com, unofficial). Reads the `games` list of club-schedule-season / score, and `gameWeek[].games` of schedule. */
object NhlParser {
    const val BASE = "https://api-web.nhle.com/v1/"
    fun teamSeasonUrl(abbrev: String) = BASE + "club-schedule-season/" + abbrev.uppercase() + "/now"
    fun scoresUrl() = BASE + "score/now"
    fun weekUrl() = BASE + "schedule/now"

    @Suppress("UNCHECKED_CAST")
    private fun m(v: Any?): Map<String, Any?>? = v as? Map<String, Any?>
    private fun list(v: Any?): List<Map<String, Any?>> = (v as? List<*>)?.mapNotNull { m(it) } ?: emptyList()
    private fun text(v: Any?): String = when (v) { is String -> v; is Map<*, *> -> (v["default"] as? String) ?: ""; else -> "" }

    fun parse(root: Map<String, Any?>): List<SportsGame> {
        val raw = ArrayList<Map<String, Any?>>()
        raw += list(root["games"])
        for (day in list(root["gameWeek"])) raw += list(day["games"])
        return raw.mapNotNull { game(it) }.sortedBy { it.startMs }
    }

    private fun team(t: Map<String, Any?>?): SportsTeam {
        if (t == null) return SportsTeam("")
        val abbrev = (t["abbrev"] as? String) ?: ""
        val name = text(t["commonName"]).ifBlank { text(t["name"]) }.ifBlank { text(t["placeName"]) }.ifBlank { abbrev }
        return SportsTeam(name, abbrev, (t["score"] as? String)?.toIntOrNull())
    }

    private fun game(g: Map<String, Any?>): SportsGame? {
        val id = g["id"]?.toString()?.takeIf { it.isNotBlank() } ?: return null
        val raw = (g["gameState"] as? String) ?: ""
        val state = when (raw.uppercase()) { "LIVE", "CRIT" -> GameState.LIVE; "FINAL", "OFF" -> GameState.FINAL; else -> GameState.UPCOMING }
        val period = m(g["periodDescriptor"])?.get("number")?.toString() ?: ""
        val status = if (state == GameState.LIVE && period.isNotBlank()) "Period $period" else raw
        return SportsGame(id, "NHL", Iso.parseMs((g["startTimeUTC"] as? String) ?: ""), state, team(m(g["homeTeam"])), team(m(g["awayTeam"])), status, "nhl")
    }
}
