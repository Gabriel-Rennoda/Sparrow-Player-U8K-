package com.sparrow.player.sports

/** TheSportsDB v1 (free key 123): eventsnext / eventslast / lookupevent answer with an `events` (or `results`) list. Timestamps are UTC. */
object TheSportsDbParser {
    const val BASE = "https://www.thesportsdb.com/api/v1/json/123/"
    fun nextUrl(teamId: String) = BASE + "eventsnext.php?id=" + teamId
    fun lastUrl(teamId: String) = BASE + "eventslast.php?id=" + teamId
    fun leaguesUrl() = BASE + "all_leagues.php"

    @Suppress("UNCHECKED_CAST")
    fun parse(root: Map<String, Any?>): List<SportsGame> {
        val list = ((root["events"] ?: root["results"]) as? List<*>) ?: return emptyList()
        return list.mapNotNull { (it as? Map<String, Any?>)?.let { e -> event(e) } }.sortedBy { it.startMs }
    }

    private fun event(e: Map<String, Any?>): SportsGame? {
        val id = (e["idEvent"] as? String)?.takeIf { it.isNotBlank() } ?: return null
        val hs = (e["intHomeScore"] as? String)?.toIntOrNull(); val aS = (e["intAwayScore"] as? String)?.toIntOrNull()
        val status = ((e["strStatus"] as? String) ?: "").trim()
        val s = status.lowercase()
        val state = when {
            s.contains("finish") || s == "ft" || s == "aot" || s == "pen" || s.contains("final") -> GameState.FINAL
            s == "1h" || s == "2h" || s == "ht" || s.contains("live") || s.contains("progress") || s.contains("period") -> GameState.LIVE
            else -> GameState.UPCOMING
        }
        val start = Iso.parseMs((e["strTimestamp"] as? String) ?: "").takeIf { it > 0 }
            ?: Iso.parseMs(((e["dateEvent"] as? String) ?: "") + "T" + (((e["strTime"] as? String) ?: "00:00:00").take(8).padEnd(8, '0')))
        return SportsGame(id, (e["strLeague"] as? String) ?: "", start, state,
            SportsTeam((e["strHomeTeam"] as? String) ?: "", "", hs), SportsTeam((e["strAwayTeam"] as? String) ?: "", "", aS), status, "thesportsdb")
    }
}
