package com.sparrow.player.data

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The app's own error log (v2.9.0): playback errors (which title, which error code, what the player was doing, which codecs) and crashes are written to ONE small text
 * file in the app folder, so a movie that stops after 1:12 can be looked into afterwards. Settings -> Data, Backup & About -> Error Log saves it to
 * Documents/SparrowPlayer (for a USB stick / file manager) or sends it by e-mail. Passwords never go into it: [redact] cuts every web address down to host + file type.
 * Pure Kotlin apart from the file; unit tested ([redact], [trim]).
 */
object ErrorLog {
    const val SUPPORT_EMAIL = "sparrowmediaplayer@gmail.com"
    private const val MAX_BYTES = 200_000          // older lines are dropped when the file grows past this
    private const val KEEP_BYTES = 120_000
    @Volatile private var file: File? = null
    @Volatile var header: String = ""              // app version + device, put at the top of every export

    fun init(dir: File, head: String) {
        file = File(dir, "sparrow-error-log.txt")
        header = head
    }

    private val URL = Regex("(?i)\\b(https?|rtsp|rtmp)://([^/\\s:?#]+)(:\\d+)?(/[^\\s]*)?")

    /** "http://host:8080/movie/user/pass/123.mkv?token=x" -> "http://host:8080/…/123.mkv": no login, no path, no query. */
    fun redact(text: String): String = URL.replace(text) { m ->
        val path = m.groupValues[4]
        val last = path.substringBefore('?').substringAfterLast('/')
        val ext = if (last.contains('.')) "." + last.substringAfterLast('.').take(5) else ""
        m.groupValues[1] + "://" + m.groupValues[2] + m.groupValues[3] + (if (path.isNotEmpty()) "/…/*" + ext else "")
    }

    /** The newest part of [text] that fits [max] characters, starting on a line boundary. */
    fun trim(text: String, max: Int): String {
        if (text.length <= max) return text
        val cut = text.length - max
        val nl = text.indexOf('\n', cut)
        return if (nl < 0) text.takeLast(max) else text.substring(nl + 1)
    }

    private fun stamp(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    @Synchronized fun add(kind: String, text: String) {
        val f = file ?: return
        try {
            val line = "[" + stamp() + "] " + kind + ": " + redact(text).replace("\r", "") + "\n"
            f.appendText(line)
            if (f.length() > MAX_BYTES) f.writeText(trim(f.readText(), KEEP_BYTES))
        } catch (e: Exception) { }
    }

    fun addThrowable(kind: String, t: Throwable, extra: String = "") {
        val sb = StringBuilder()
        if (extra.isNotBlank()) sb.append(extra).append(" | ")
        var c: Throwable? = t; var depth = 0
        while (c != null && depth < 4) {
            sb.append(if (depth == 0) "" else " <- caused by ").append(c.javaClass.name).append(": ").append(c.message ?: "")
            c = c.cause; depth++
        }
        val top = t.stackTrace.take(8).joinToString(" / ") { it.className.substringAfterLast('.') + "." + it.methodName + ":" + it.lineNumber }
        if (top.isNotEmpty()) sb.append(" | at ").append(top)
        add(kind, sb.toString())
    }

    @Synchronized fun read(): String = try { file?.takeIf { it.exists() }?.readText() ?: "" } catch (e: Exception) { "" }

    /** The whole log with the version / device header, ready to save or send. */
    fun export(): String {
        val body = read()
        return header + "\n" + (if (body.isBlank()) "(no errors recorded yet)\n" else body)
    }

    @Synchronized fun clear() { try { file?.delete() } catch (e: Exception) { } }

    fun isEmpty(): Boolean = read().isBlank()
}
