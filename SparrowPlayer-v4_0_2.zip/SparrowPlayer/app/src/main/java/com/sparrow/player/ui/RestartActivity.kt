package com.sparrow.player.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Process

/**
 * v3.2.0: runs in its own process (":restart", see the manifest). It ends the main app process, then opens the app again, so the restart is a real
 * close-and-reopen (every setting read afresh) and not just a screen refresh.
 */
class RestartActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pid = intent.getIntExtra(EXTRA_PID, -1)
        val next = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        if (pid > 0 && pid != Process.myPid()) Process.killProcess(pid)
        startActivity(next)
        finish()
        Runtime.getRuntime().exit(0)
    }

    companion object { const val EXTRA_PID = "pid" }
}
