package com.sparrow.player.sports

/** v3.6.19 Sports, stage 1 (data only, no screens yet). Pure Kotlin so it is unit tested; the field names of the two sources are ASSUMED from their public
 *  documentation and are checked against a real response on the first run: every response is kept in [SportsDiagnostics]. */
enum class GameState { UPCOMING, LIVE, FINAL }

data class SportsTeam(val name: String, val abbrev: String = "", val score: Int? = null)

data class SportsGame(
    val id: String, val league: String, val startMs: Long, val state: GameState,
    val home: SportsTeam, val away: SportsTeam, val status: String = "", val source: String = ""
)

/** What a screen gets: the games, whether they came from the saved copy (offline / too many requests) and when they were fetched. */
data class SportsResult(val games: List<SportsGame>, val fromCache: Boolean, val updatedMs: Long, val error: String = "")

/** The network, pluggable so tests need none. null = no answer (offline, error). */
fun interface SportsHttp { suspend fun get(url: String): String? }

object Iso {
    /** "2026-11-27T00:30:00Z" / "2026-11-27T00:30:00" / "...00.000Z" -> UTC milliseconds; 0 when it cannot be read. */
    fun parseMs(s: String): Long {
        if (s.length < 19) return 0L
        return try {
            val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
            f.timeZone = java.util.TimeZone.getTimeZone("UTC")
            f.parse(s.substring(0, 19))?.time ?: 0L
        } catch (e: Exception) { 0L }
    }
}

/** The last responses (url, size, start of the body) and parse problems, newest last: the way to find a wrong field name without a debugger. */
object SportsDiagnostics {
    private val lines = ArrayList<String>()
    @Synchronized fun add(line: String) { lines += line.take(400); while (lines.size > 40) lines.removeAt(0) }
    @Synchronized fun all(): List<String> = lines.toList()
    @Synchronized fun clear() = lines.clear()
}

/** The NHL clubs offered as favourites (abbreviation -> name). Canadian clubs first; the full list comes with the team pages. */
object NhlTeams {
    val CANADIAN: Map<String, String> = linkedMapOf(
        "TOR" to "Toronto Maple Leafs", "MTL" to "Montreal Canadiens", "OTT" to "Ottawa Senators", "WPG" to "Winnipeg Jets",
        "CGY" to "Calgary Flames", "EDM" to "Edmonton Oilers", "VAN" to "Vancouver Canucks"
    )
    fun nameOf(abbrev: String): String = CANADIAN[abbrev.uppercase()] ?: abbrev.uppercase()

    /** "TOR,MTL" with one club switched on or off; order kept, no repeats. */
    fun toggle(list: String, abbrev: String): String {
        val cur = list.split(',').map { it.trim().uppercase() }.filter { it.isNotEmpty() }
        val a = abbrev.uppercase()
        return (if (a in cur) cur - a else cur + a).joinToString(",")
    }
}
