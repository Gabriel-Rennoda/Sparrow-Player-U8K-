# 2.6.0 - investigation, changes and test report

No Kotlin compiler / Gradle (and no network) on the machine this was written on. Run here: `tools/kt_balance.py` (all balanced), `tools/kt_static_check.py` (same 3 known false positives), a symbol-by-symbol read of the 2.5.0 TMDB code (see 0). **Nothing could be run on the U8K** - see TV_TEST_CHECKLIST_2_6.md.

## 0. 2.5.0 build check
The GitHub log could not be read from here. Instead every symbol the 2.5.0 TMDB code uses was checked in the source: `Map.str` (Json.kt), `TextNorm.prepare`, `Json.readObject(InputStream)`, `VodCatalog.titles / kidsOnly`, `RowTitle.uid / name / year`, `Repository.http / scope / active / catalog`, OkHttp 4.12 `Response.code` / `.body` (properties, as used), `HttpUrl.Builder.addPathSegments`, `Popup.ask` parameter order, `Popup.row/note`, `CancellationException` via `kotlinx.coroutines.*`. No compile error found. If "Build APK" is red anyway, the error text decides: send it.

## Findings -> changes
| # | Cause found | 2.6.0 |
|---|---|---|
| 1 (QR) | A profile is ~50 bytes (name, icon, PIN, child flag, limit); a QR holds up to ~2.9 KB, so profile DEFINITIONS fit. History / resume / My List / playlist logins do not. Receiving needs a camera; the TV has none | Question only - answer in the reply, nothing built |
| C1 | "Copy To Group…" asked for ONE group for ONE channel | Hold OK -> Copy To Group… puts the guide in tick-box mode (EpgView.selecting): every row has a box, the held channel is ticked, OK ticks / unticks, hold OK = Copy N / Select All / Clear / Stop. Left / Right / Up-at-top are swallowed so the list cannot be left; Back stops (asks when 2+ ticks). Copy asks for an existing group or "＋ New Group…" (ChannelMenu.copyMany), then reloads the same group on the same channel |
| C1a | - | Only groups that do not already hold every ticked channel are offered |
| C2 | `createGroup` put the new id LAST in `customGroups`; `arrange()` puts the user's saved order first, so after any manual Move a new group landed at the bottom | `createGroup` puts the id FIRST in `order`: newest group is always right below All Channels / Favourites. Test: `newGroupGoesToTheTopEvenWhenTheUserOrderedGroupsBefore` |
| C3 | TMDB key had to be typed | `Tmdb.BUILT_IN_KEY`; `Prefs.tmdbKey` = built-in unless a value was ever saved (an empty saved value = off). Settings row: Use The Built-In Key / Enter My Own Key… / Turn Off. Note: this is a TMDB key (the request said IMDB; IMDB has no free API and this key is the 32-hex v3 TMDB form) |

## Interpretation notes
* "Go back to the EPG section/group the user was in": the pop-up is opened from the guide, so the guide simply stays on that group; after the copy it reloads on the same group and channel.
* Move To Group is unchanged (one channel, asks Yes / No). Say if it should use tick boxes too.
* The key is plain text inside the APK (and in the GitHub repo). It is a free, revocable key: if the repo is public, regenerate it at themoviedb.org -> Settings -> API if it is ever abused.
