Next update (v3.6.2) - copy / paste this into the next chat

Same rules: investigate and test each item before changing code, apply in stages, test for the 75" U8K remote, then give me the updated zip. If anything is not completed, write a new copy-paste document.

Version 3.6.1 (versionCode 48) is the base (written WITHOUT a compiler). FIRST check the GitHub build log for the 3.6.0 run and fix compile errors before anything else. Check docs/TV_TEST_CHECKLIST_3_6.md (my results are pasted below).

Done in 3.6.0 (untested): split screen STAGE 1 - hold OK on a channel -> Add To Split Screen / Watch Split Screen; 2-4 tiles; sound follows the highlighted tile; OK = full screen; provider connection limit read from the Xtream login (max_connections); 720p (2 tiles) / 540p (3-4) cap; a SPLIT line in the Error Log.
NEXT: split screen STAGE 2 (pick / change a channel from inside split screen, remember the picks) and STAGE 3 (1 large + 3 small layout) - after the stage 1 results.

STILL OPEN: Kids / Family titles still wrong (My Gay Life, Liszt's Rhapsody, No Holds Bard, Lucille Ball: We Love Lucy, Sinatra: His Way, A Circle in the Fire, more coming).
NOT done: 19 / 20 multiple custom Favourites sections; 12 live sync; loading cache; S3 TMDB keywords for holiday carousels; Copy To for Movies / Series; S2 animation + family tags beyond TMDB genres; bigger watched badges; S0 TMDB logo on About.
Each of these is large: pick ONE per chat.
[paste checklist results here]

3.6.1 changed: split screen decoder fix (tile 1 hardware, others software, flip on failure, 1.2 s stagger, SPLIT decoder lines in the Error Log). Result unknown until TV test (docs/TV_TEST_CHECKLIST_3_6_1.md).
If tiles still fail or stutter: next ideas = all-software with 480p cap, sequential start after previous tile is READY, or a Settings option "Split screen decoding: Auto / Software".
