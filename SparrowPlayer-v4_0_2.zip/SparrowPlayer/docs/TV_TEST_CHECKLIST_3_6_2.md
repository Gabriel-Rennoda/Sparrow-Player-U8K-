Sparrow Player 3.6.2 (versionCode 49) - TV test checklist (75" U8K) - split screen: diagnostics + decoder modes
(Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_6_2.zip. If red, send the error lines. Written WITHOUT a compiler. Install OVER 3.6.1.

What the 3.6.1 logs showed:
 - 1080p (H.264): tile 1 = c2.mtk.avc.decoder (hardware), tile 2 = c2.android.avc.decoder (software). NO decoder errors any more, but the
   software tile shows a still picture. Either the software decoder is too slow (dropped frames) or it is not rendering. 3.6.2 logs which.
 - 4K (HEVC 10-bit): this TV has NO software HEVC decoder (the "software first" tile still got c2.mtk.hevc.decoder). Two HEVC tiles = two
   hardware decoders = each steals the other's (error 4003 ping-pong). Not fixable by decoder choice. 3.6.2: the 2nd HEVC tile steps aside
   with a message so tile 1 keeps playing.
Changes: Settings -> Playback -> Split Screen Decoding (Auto / Software all tiles / Hardware all tiles); tiles start 3 s apart;
 SPLIT log lines: list of all H.264/HEVC decoders on the TV, stream format + size per tile, and a stats line every 5 s for 30 s
 (state, size, decoder, dropped frames).

[ ] 2 x 1080p (Hollywood Suite 80s & 90s + 2000's), mode AUTO: does tile 2 move? Paste the SPLIT lines (stats lines show dropped frames).
[ ] Same, mode SOFTWARE (All Tiles): moving? Paste SPLIT lines.
[ ] Same, mode HARDWARE (All Tiles): moving? Paste SPLIT lines.
[ ] 4K: Sportsnet ONE + 4K: Sportsnet, mode AUTO: does tile 1 keep playing and tile 2 show the "only one 4K / HEVC channel" message?
[ ] One 4K + one 1080p channel (mixed): both moving?
[ ] Normal live TV / movies unchanged.
