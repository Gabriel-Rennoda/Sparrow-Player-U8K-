Sparrow Player 3.6.5 (versionCode 52) - TV test checklist (75" U8K) - CHAT C: mass actions
(Y = works, E = error + WHAT YOU SAW, N = not tested)
Install OVER 3.6.4. Written WITHOUT a compiler: if the Actions run is red, send the error lines.
[ ] 1. Build is green (GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_6_5.zip) and the app starts. About shows 3.6.5.
[ ] 2. Hold OK on a channel inside a group of YOUR OWN: rows include Hide Channels, Copy Channels, Move Channels, Delete Channels. In All Channels / Favourites / a provider group: no Move Channels, no Delete Channels.
[ ] 3. Delete Channels: the guide opens tick boxes, banner "Delete From <group>", the held channel already ticked.
[ ] 4. Tick 3 channels with OK, hold OK: rows = Copy Channels, Move Channels, Delete Channels, Hide Channels, Select All, Clear All, Cancel.
[ ] 5. Delete Channels -> "Remove 3 channels From Group?" -> Yes: the 3 leave THIS group only; they are still in All Channels and in their other groups.
[ ] 6. Same question -> No: nothing changes, ticks stay.
[ ] 7. In a provider group / All Channels / Favourites (tick mode opened with Copy or Hide): the hold-OK menu has NO Move Channels and NO Delete Channels.
[ ] 8. Banner hint reads "OK ticks / unticks  ·  hold OK for the actions  ·  Back cancels"; the toast on entering tick mode says the same.
[ ] 9. Hide Channels with Settings -> Groups & Channels -> Ask Before Hiding ON: asks Hide N channels? with No / Do Not Show This Again / Yes, Hide.
[ ] 10. Tick "Do Not Show This Again" + Yes: channels hide; Ask Before Hiding switch is now OFF.
[ ] 11. With Ask Before Hiding OFF: Hide Channels hides at once, no question. Turn the switch ON again in Settings: the question comes back.
[ ] 12. Copy Channels and Move Channels still work as in 3.6.4 (new group, existing group, Yes/No before a move).
[ ] 13. Settings -> Navigation And Shortcuts: the channel line mentions delete.
[ ] 14. Normal live TV, movies, series, resume, mini player and full screen unchanged.
