# 3.6.4 (Chat A) - what is left for later chats
- Delete Channels is still the single-channel "Remove From Group?" confirm. Multi-select delete needs a new action in EpgFragment.showSelectMenu (+ ChannelMenu.deleteMany) -> Chat C (mass actions).
- Hide Channels (tick boxes) always asks Yes/No: the "Ask Before Hiding" switch no longer affects channels (the one-channel path that used it is gone). Groups and Movies/Series still honour it.
- The tick-box menu (hold OK while ticking) still says "Copy To / Move To / Hide": rename with Chat C.
- TMDB logo is a generated stand-in (res/drawable-nodpi/tmdb_logo.png, TMDB colours). Replace the file (same name) with the official asset from themoviedb.org/about/logos-attribution.
- Prefs keys "splitDec" and "heroBanner" may still sit in old installs' settings; nothing reads them.
