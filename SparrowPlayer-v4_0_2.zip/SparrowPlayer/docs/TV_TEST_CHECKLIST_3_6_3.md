Sparrow Player 3.6.3 (versionCode 50) - TV test checklist (75" U8K) - split screen: honest decoder modes + capability log
(Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_6_3.zip. If red, send the error lines. Written WITHOUT a compiler. Install OVER 3.6.2.
Changes: HARDWARE mode no longer flips to software on an error (that flip made the 3.6.2 hardware test look like it used a software decoder).
In hardware mode, if the TV runs out of hardware decoders the NEWEST tile steps aside with a message. A software tile that drops 200+ frames now
stops with a message instead of a frozen picture. The SPLIT log lists every H.264/HEVC decoder with hwAccel, vendor, max instances, 1080p fps, plus decoders hidden from the normal list.
[ ] FIRST SPLIT LINES (please paste both, they were missing last time): "picked ..., hardware H.264 decoder instances reported by this TV" and "video decoders on this TV".
[ ] 2 x 1080p, mode HARDWARE: expected = tile 1 plays, tile 2 message "no free hardware decoder" (or both play = great news). Paste SPLIT + PLAYBACK lines.
[ ] 2 x 1080p, mode AUTO: tile 2 should now stop with "CPU cannot decode" after ~10 s instead of freezing. Paste SPLIT lines.
[ ] 4K (HEVC) + 1080p (H.264), mode HARDWARE: different codecs, may both run. Paste SPLIT + PLAYBACK lines.
[ ] Normal live TV / movies unchanged.
