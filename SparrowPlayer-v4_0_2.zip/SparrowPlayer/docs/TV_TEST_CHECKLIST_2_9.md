# 2.9.0 on the U8K (Y = works, E = error + what you saw)
FIRST: GitHub Actions "Build APK" - if red, send the error lines.
- [Y] Settings -> Appearance opens the theme page at once
- [Y] The ▼ arrow at the bottom of menus / Settings / See All is clearly visible
- [Y] Movies / Series: title name + year / rating on the top line; rows start at its left edge
- [E] Pick another group / carousel group: always the top row
- [Y] A movie that crashed (Muppets Christmas Carol, Charlie Brown Christmas): note what the screen says; then Settings -> Data -> Error Log -> View / Save To Device and send the file
- [Y] Search: type, press Back (keyboard closes): Right reaches titles, Down reaches filters; OK on the box reopens the keyboard
- [E] Any text box (Add Playlist, rename, search): keyboard comes up by itself
- [E] Left at the left edge: selector on the current tab's icon; Right = groups; Left = labelled list; in Search, Left from the filters = magnifying glass
- [Y] Hold OK on channels -> menu reads Copy To / Hide / Select All / Clear All / Cancel
- [Y] Details page: age badge line, Genre / Director / Cast lines, Play with Watched badge to its right
- [not tested] Hide: details Hide; episode hold OK; See All hold OK (title, several, carousel); group hold OK; Settings -> EPG -> Hidden -> Hidden Movies & Series unhides; Play Next skips a hidden episode
- [not tested] Settings -> EPG -> Hide Side Bar After (default Never)
- [not tested] Titles from your list 10 / 11: Kids clean; ratings appear after the page opens


(Result on the U8K: Y = works, E = error, not tested = carried over to the 3.0.0 checklist. For the three E items the screen was not described - see TV_TEST_CHECKLIST_3_0.md.)
