# 3.6.5 (Chat C) - what is left
TMDB logo is still a generated stand-in (res/drawable-nodpi/tmdb_logo.png): replace with the official asset (same file name).
Prefs keys "splitDec" and "heroBanner" may still sit in old installs; nothing reads them.
Delete Channels is now multi-select (EpgFragment.showSelectMenu + ChannelMenu.deleteMany). Ask Before Hiding applies to channels again (ChannelMenu.hideMany).
