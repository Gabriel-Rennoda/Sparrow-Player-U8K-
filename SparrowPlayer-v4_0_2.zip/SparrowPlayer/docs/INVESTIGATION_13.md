# 2.7.0 - investigation, changes and test report
No compiler / Gradle / network where this was written. Run: tools/kt_balance.py (all balanced), tools/kt_static_check.py (same 3 known false positives), guide_logic_test, upgrade_check (no preference key removed or renamed). Unit tests added: Customize.canReceive, copy leaves source group alone. Nothing run on the U8K.
| # | Finding | Change |
|---|---|---|
| 1 | Backup file holds profiles, history, resume, ratings, My List, edits, playlist logins. QR holds ~2.9 KB; TV has no camera; cleartext LAN traffic already allowed in the manifest | Answer only (options in chat). Recommended for 2.8.0: Send / Receive over Wi-Fi with a 4-digit code |
| 2 | Channel tick mode existed (2.6.0) for Copy only | Same mode now offers Hide; groups panel gets tick boxes (GroupAdapter ticks, MainActivity handleTickKey / showGroupTickMenu) |
| 3 | A provider group accepted copies / moves from anywhere, so it stopped being "its original channels" | Customize.canReceive: only your own groups (or a channel's own home group) take Copy / Move. Existing foreign channels already stored in provider groups are NOT removed |
| 4 | Details page: 5 button rows + plot in a fixed-height column; Android clips children to the padded area, so rows were cut ~56 dp above the screen edge | clipChildren / clipToPadding off, bottom padding 56 -> 20 dp, plot 5 -> 4 lines. Best diagnosis without a photo |
| 5 | Movie info awaited a fresh get_vod_info on every open (no cache, 120 s timeout) | 200-entry cache, 20 s timeout; credits line (age rating, director, cast, watched) from the panel's fields + the TMDB rating already cached |
| 5 watched | Episodes already show ✓ and resume; no movie / series level mark | "✓ Watched" for a movie; "N of M watched" / "✓ Watched" for a series, updated on return from the player |
| 5b | XMLTV uses the Android pull parser (streaming); JSON uses JsonReader (streaming); OkHttp sends gzip itself; no brotli, no pooling | No change (ELI5 in chat) |
| 7 | Audio / Subtitles / Video Quality pop-up exists (Menu key, 2nd OK, subtitle button) | No change |
| 8 | Focus memory exists for panels / tabs (contentFocus, groupsFocus) and the VOD rows | No change; TV test decides |
