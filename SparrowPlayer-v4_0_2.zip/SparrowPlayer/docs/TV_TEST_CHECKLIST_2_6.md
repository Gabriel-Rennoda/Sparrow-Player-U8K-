# 2.6.0 - run on the Hisense U8K (Y = works, E = error + what you saw)
Nothing in 2.6.0 could be compiled or run where it was written (no Gradle / Kotlin there): FIRST look at the GitHub Actions log. If "Build APK" is red, send me the error lines.

## Copy To Group (bulk) - Live TV, Guide and Favourites tabs
- [ ] Hold OK on a channel -> "Copy To Group…" (with its one-line explanation under it) -> the pop-up closes and you are still in the SAME group, on the SAME channel
- [ ] Every channel row now has a tick box on the left; the clock/time header is replaced by an accent banner "Copy To Group: 1 selected" + the key hints; the channel you held is already ticked
- [ ] OK on a row ticks / unticks it (banner count follows); Up / Down move through the list; Page / CH+ / CH- jump a page
- [ ] While ticking: Left, Right and Up on the first row do nothing (no side panels, no jump to the player, no time browsing)
- [ ] Hold OK (while ticking) -> "Copy N Ticked Channels To…", "Select All (M)", "Clear All Ticks", "Stop Selecting". Select All ticks the whole group. Back inside this pop-up only closes the pop-up
- [ ] "Copy N Ticked Channels To…" -> list begins with "＋ New Group…", then the groups. Pick a group -> toast "N channels copied to X", ticks are gone, you are back on the same group and channel, the channels are in X
- [ ] "＋ New Group…" -> name -> the group is created and filled; Cancel on the name box returns to the group list
- [ ] Back while ticking: 0-1 ticks stops at once; 2+ ticks asks "Stop Selecting?" (Yes, Stop / No)
- [ ] Same thing from the Favourites tab
- [ ] A group that already contains all the ticked channels is not offered as a target

## New groups at the top
- [ ] Groups panel: All Channels, Favourites, then your newest group, then older custom groups, then the provider's groups. Works also after you moved groups by hand earlier; Group Options -> Create New Group… too
- [ ] Moving a group (Group Options -> Move) still works and keeps its new place

## TMDB key built in
- [ ] Fresh install / no key ever typed: Settings -> Data, Backup & About -> TMDB Ratings (Child Safety) shows "On (built-in key)" and after a few minutes "TMDB: N titles checked"
- [ ] The row opens: Use The Built-In Key / Enter My Own Key… / Turn Off. Turn Off -> "Off" and the count stops growing; Use The Built-In Key -> "On" again
- [ ] If you had typed your own key in 2.5.0 it is kept (shows "On (my key)")
- [ ] (still from 2.5.0) R titles such as Cinderella Man / Madagascar Skin gone from Kids / Child profile - send me names of any still wrong + the rating TMDB should give
