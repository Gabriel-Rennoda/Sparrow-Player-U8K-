# 2.9.0 - investigation, changes and test report
No compiler / Gradle / network where this was written (the 2.8.0 build and TV run worked: all Y). Run: tools/kt_balance.py (all balanced), tools/kt_static_check.py (known false positives: BackupMenus, SettingsFragment, PosterCard, ErrorLog - a "//" inside a string / emoji). New unit tests: data/V29Test.kt. Nothing run on the U8K.
| # | Change |
|---|---|
| 1 | Settings -> Appearance opens the Appearance page directly (no pop-up) |
| 2 | "More below" arrow: bigger (28 sp bold, solid triangle), opaque dark pill with white outline (res/drawable/more_arrow_bg.xml, Popup, See All, main screen) |
| 3 | Movies / Series: the selected title's name + year / rating on the slim top line (as in See All) |
| 4 | New page (tab / group) always on the top row: any other row the grid lands on in the first seconds is put back (VodFragment.topLockUntil) |
| 5 | Playback errors are logged (code, cause chain, position, codecs, shortened address). Movies: retry keeps the place; from the 3rd try a damaged spot is jumped (4 s, 8 s ...); decoder / audio failures retry with stereo, then 1080p. Message names the kind of failure. Crashes are logged too |
| 5b | Settings -> Data, Backup & About -> Error Log: Save To Device (Documents/SparrowPlayer), Send By E-mail (sparrowmediaplayer@gmail.com, file attached), View, Clear |
| 6, 9 | TvEditText (all text boxes): keyboard opens by itself on selecting a box / OK; after the keyboard is closed the arrows move on (right to the titles, down to the filters). Year boxes open the keyboard on OK only |
| 7 | First Left from the left edge = the icon bar, on the current tab's icon (Search window: magnifying glass). Right = groups (or content), Left = labelled tab list |
| 8 | Selected Channels menu: Copy To, (Move To in my own groups), Hide, Select All, Clear All, Cancel |
| 10 | The five reported titles are kept out of Kids / Family (Maturity.ADULT_TITLES) |
| 11 | TMDB: age rating also pulled when the information page opens; looser title matching; GB / AU / DE ratings when US / CA have none; one more try for every title without a rating |
| 12 | Hide in Movies / Series: details page "Hide"; episodes (hold OK: episode / season); See All (hold OK: title, several with tick boxes, whole carousel); groups (hold OK on a group). Settings -> EPG -> Hidden -> Hidden Movies & Series unhides. Per profile, in backups. Play Next skips hidden episodes |
| 13-15 | Watched and age rating as off-white rounded badges, thin accent outline, bold accent text; Watched right of Play; age rating on its own line above Genre / Director / Cast, each on its own lines with a larger bold bullet and bold label |
| 16 | Groups panel 250 -> 226 dp (the tab list over it shrinks with it) |
| 17 | Rows are shifted at run time so their left edge equals the left edge of the slim title line (measured on the screen) |
| 18 | Settings -> EPG -> Hide Side Bar After (Never / 2 / 3 / 5 / 10 s), default Never (fixed) |
| 19 | Genre: provider first, TMDB only fills a blank (kept; reasons in the chat) |
