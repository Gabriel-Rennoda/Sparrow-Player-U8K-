Sparrow Player 3.5.0 (versionCode 46) - TV test checklist (75" U8K)
(Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_5_0.zip. If red, send the error lines.
Written WITHOUT a compiler (like 3.0.0 - 3.4.1). No database change: install OVER 3.4.1.

Keyboard
[ ] Rename a group that has a name ("xyz"): backspace everything -> the key shows the capital (a one-shot shift) and the first letter typed is a capital. Also: backspace back to just after a space -> capital again.
[ ] Backspace with the air-mouse remote still redraws the line above the keys at once.
[ ] ENTER key of the air mouse (the Enter key, NOT the round OK button) = Done: closes the keyboard and submits the text box, whatever key the selector is on.
[ ] The round OK button still types the key the selector is on; hold OK still types the small character.
    - If the air mouse's OK button ALSO closes the keyboard (it sends Enter), tell me: then I add a setting.
Add Playlist
[ ] The "more below" arrow is there when the page opens, every time (try 5 times: open, leave, open again). It fades away 1 s after the bottom is reached and returns 1 s after scrolling up.
Kids / Family (needs the TMDB lookups from 3.4.1 to have finished - Settings -> Data, Backup & About -> TMDB status line)
[ ] TV films (Romance / Crime / Documentary / TV Movie only) are gone from Kids and Family. Inception too.
[ ] Flowers & Honey ("Rated G", TV Movie, Romance) is not in Kids.
[ ] "EN - Frozen" style names are recognised.
Send: any title still wrong AFTER the lookups finished: exact title + page + genre line from its details page.
