Sparrow Player 3.4.0 - TV test checklist (75" U8K)
(Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_4_0.zip (versionCode 44). If red, send the error lines.
Written WITHOUT a compiler (like 3.0.0 - 3.3.0). No database change (schema stays 2): install OVER 3.3.0.
Keyboard
[ ] Rename a group that already has a name (e.g. "xyz"): the keyboard opens with the capital (shift) already on; the first letter you type is a capital.
[ ] AIR-mouse remote: Backspace now shows at once in the line above the keys (no need to move to another key first). Try it several times in a row.
[ ] Small characters at the TOP RIGHT of keys (q=1 ... p=0, a=@ s=# d=$ f=% g=& h=- j=+ k=( l=) -=_  z=* x=" c=' v=: b=; n=! m=?  @=_  .=,  :=;  /=?). Keys are the same size and shape as before.
[ ] HOLD OK on any key with a small character: it types the small character instead (the letter is replaced).
[ ] 123 # layer: the number row 1 2 3 4 5 6 7 8 9 0 is on screen all the time. ABC goes back to the letters.
[ ] Double-click Shift: the key shows CAPS and capitals stay on; click Shift once more to turn it off. One click = one capital only.
Add Playlist
[ ] The "more below" arrow is there as soon as the page opens (no need to scroll to the bottom and back).
Kids
[ ] Inception (genre text "Action, Science Fiction, Adventure") is out of Kids / Family / Child profiles.
[ ] STILL NEEDED from you: Frozen in Family but not Kids - send Frozen's details page: the title as written, its Category, and its Genre line. Also any other grown-up title still in Kids: exact title + category + genre.

3.4.1 additions (versionCode 45) - TMDB genres for Kids / Family
ROOT CAUSE found: the panel's MOVIE list carries no genre (Repository: "Movies carry no genre in the panel's list"), so "TV Movie, Romance", "Animation, Family, Adventure" etc. were only ever visible on the details page. Every genre screen of Kids / Family therefore saw nothing for movies.
Now the existing background TMDB lookup (Settings -> Data, Backup & About -> TMDB) also keeps each title's genres (same number of calls: it asks /movie/{id} with the certifications appended). Titles looked up before are looked up ONCE more (retry version 3), kids titles first - this takes a while (hours on a big library). Leave the app open / come back; the status line in that settings page shows progress.
[ ] After the lookups have run: Frozen (TMDB: Animation, Family, Adventure) is in Kids as well as Family. Other Animation + Family films follow.
[ ] After the lookups have run: the TV films from the screenshots (Romance / Crime / Documentary / TV Movie only ...) are gone from Kids and Family. Inception too.
[ ] A G / PG rating from TMDB no longer lets a title in when its genres / title words are grown-up (Flowers & Honey says "Rated G" but is TV Movie, Romance).
[ ] Titles whose name starts with a tag ("EN - Frozen") are recognised as well-known children's titles.
Send: any title still wrong AFTER the lookups finished: exact title + which page (Kids / Family) + the genre line from its details page.
