3.2.0 on the U8K (Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_2_0.zip (versionCode 42). If red, send the error lines.
This build was written WITHOUT a compiler (like 3.0.0 / 3.1.0). No database change (schema stays 2): install OVER 3.1.0.

Restart
[ ] Backup restore -> Apply Restore -> "Yes, Restart": the app really CLOSES and opens again (3.1.0 only refreshed because Android had no launch intent for a TV-only app). Start-on-wake-up / opening channel apply afterwards.
Keyboard
[ ] Open a keyboard (Add Playlist, group rename, New Group). Up on the top row opens the number row; Down from the number row / Down on the bottom row stays in the keyboard (the menu behind never takes the selector). Back closes it, then the arrows move on.
"More below" arrow
[ ] Open Movies / Series / a long settings page: the arrow is there right away when there is more below (no 1 s wait on the first load).
[ ] Scroll to the bottom: solid 1 s, then gone. Scroll up: waits 1 s, fades in.
[ ] Add Playlist page: the arrow shows while there is more below (e.g. with the Restore buttons off-screen) and goes at the bottom.
Groups (speed)
[ ] Movies / Series -> a big genre group: the first carousels appear sooner; the remaining carousels (genre carousels) are added below a moment later while you browse. The selector stays where it is.
Details page
[ ] Loved / Liked / Disliked are icons only (heart, thumb up, thumb down) right of Play. The chosen one keeps a light-blue outline. Press again to remove.
[ ] Series: ONE button "Season 1 v" under the buttons (no pop-up). OK opens the list in place (the episodes hide while it is open), choosing a season fills the episodes, Back closes the list. The first season is chosen by itself.
[ ] Movies: no season button.
Kids
[ ] Frozen (and the other well-known children's films: Mulan, Cars 2, Sing 2 ...) now show in Kids (Movies). Titles whose DESCRIPTION says "for kids / preschoolers / toddlers" also join Kids.
[ ] The grown-up TV movies from your photos are still NOT in Kids / Family / Child profiles.
Navigation
[ ] From the Groups panel press Left: the icon list opens with the selector on the tab you are in (Movies on Movies, Series on Series). The Search icon is only where you chose Search.
