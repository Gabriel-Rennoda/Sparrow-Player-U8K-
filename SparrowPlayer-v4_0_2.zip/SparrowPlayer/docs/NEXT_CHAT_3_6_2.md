Next update (v3.6.3) - copy / paste this into the next chat
Same rules: investigate and test each item before changing code, apply in stages, test for the 75" U8K remote, then give me the updated zip.
Base: 3.6.2 (versionCode 49), written WITHOUT a compiler. FIRST check the GitHub build log and fix compile errors.
Split screen facts so far: TV (MediaTek c2.mtk decoders) runs ~1 hardware decoder per format at a time; no software HEVC decoder (4K = 1 tile max);
H.264 hardware + software tile starts without errors, but the software tile was frozen in 3.6.1 (3.6.2 logs dropped frames to tell why).
Decide from the 3.6.2 SPLIT log lines: if software drops most frames -> cap tiles to HD only / lower fps / ask provider for lower-res variant;
if hardware-all works -> make it the default; then STAGE 2 (pick / change a channel inside split screen) and STAGE 3 (1 large + 3 small).
STILL OPEN: Kids / Family titles wrong; 19/20 custom Favourites sections; 12 live sync; loading cache; S3 TMDB keywords; Copy To for Movies / Series;
S2 animation + family tags; bigger watched badges; S0 TMDB logo on About. One large item per chat.
[paste checklist results here]
