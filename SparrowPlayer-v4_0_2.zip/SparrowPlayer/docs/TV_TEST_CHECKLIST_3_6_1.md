Sparrow Player 3.6.1 (versionCode 48) - TV test checklist (75" U8K) - split screen decoder fix
(Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_6_1.zip. If red, send the error lines. Written WITHOUT a compiler. Install OVER 3.6.0.
Cause found in 3.6.0: error 4003 (decoding failed) on every tile, tiles playing 1 second each in turn = the TV runs only ~1 hardware video decoder at once
(it reports 16, but each new tile steals the previous one).
Fix: tile 1 starts on a hardware decoder, the other tiles on SOFTWARE decoders; a failed tile is rebuilt with the other decoder type (up to 4 tries); tiles start 1.2 s apart.
[ ] 3 tiles: do all three play at the same time and keep playing for 10 minutes?
[ ] Which tiles stutter / freeze (software decoding of a 1080p source is heavy)? Say which channels.
[ ] Error Log: paste every line starting  SPLIT  tile ... video decoder:  and any  PLAYBACK split-screen tile ...  lines (now include the cause and decoder name).
[ ] 2 tiles and 4 tiles (if your account allows 4): same test.
[ ] Normal live TV / movies unchanged.
