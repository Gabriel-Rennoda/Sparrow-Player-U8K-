# 2.8.0 - run on the Hisense U8K (Y = works, E = error + what you saw)
FIRST: look at the GitHub Actions log. 2.6.0, 2.7.0 and 2.8.0 were all written without a compiler: if "Build APK" is red, send me the error lines.

## Send / Receive over Wi-Fi (needs two devices on the same network, both running 2.8.0)
- [ ] Device A: Settings -> Data, Backup & About -> "Send My Setup To Another Device…" -> a window titled "Code: NNNN" appears (waiting)
- [ ] Device B: "Receive Setup From Another Device…" -> type the code -> "Looking for the other device…" -> the normal Restore review opens (Use Backup / Keep Mine, approve all) -> approve -> profiles, history, My List, playlists are there
- [ ] Device A shows "Sent. Approve it on the other device." and the Send window closes by itself
- [ ] Wrong code -> "Wrong code". Sender not started -> "No device found…". Back / Stop Sending on A -> sending stops
- [ ] If B never finds A although both are on Wi-Fi: tell me the router / network type (guest Wi-Fi and "AP isolation" block this) - the file route below still works
- [ ] Fall back still works: Backup Now -> copy the file by USB -> Restore From Backup on the other device

## Copy / Move / Hide in the group you are viewing
- [ ] Hold OK on a channel: Copy To Group…, Hide Several Channels…, and (only inside a group YOU made) Move To Group… and Remove From This Group…; in a provider group there is no Move / Remove
- [ ] Banner names the group: "Copy From Sports: 3 selected". Only that group's channels are listed. Hold OK -> Copy N To… / Move N To… (my groups only) / Hide N… / Select All / Clear / Stop
- [ ] Copy targets = "＋ New Group…" + my own groups only. A provider group is never changed (nothing added, nothing removed); the only way to change what it shows is Hide

## Permanent icon bar
- [ ] The slim icon bar on the far left stays on screen on Live TV, Guide, Movies, Series, Favourites - it never hides itself; the current tab's icon is highlighted
- [ ] Left from the left edge still opens Groups, Left again expands the tab list over it (labels appear), Right closes one level, Back as before
- [ ] Settings -> EPG no longer has "Hide Side Bar After"

## Movie / series information page
- [ ] Line under the plot also shows "Genre:" (only when the provider gave none), "Director:" / "Creator:" and "Cast:" - filled a moment later from TMDB when the panel has none
- [ ] Rest the selector ~1 second on a poster, then open it: the page is already complete (plot, cast). Series open instantly the 2nd time
- [ ] Rows at the bottom of the page are no longer cut off (checked in 2.7.0 too)
- [ ] Tell me which titles still show no director / cast / genre (names)
