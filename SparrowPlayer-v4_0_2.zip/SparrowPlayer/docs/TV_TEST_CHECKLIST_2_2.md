# 2.2.0 - run on the Hisense U8K (Y = works, E = error + what you saw)
- [ ] Movies / Series: no title / year / star text above the rows any more; the row's own name never changes while moving Right / Down / Up; star ratings still on the posters; top line shows only "Hold OK = See All"
- [ ] See All still shows names / two rows exactly as in 2.1.1 (untouched)
- [ ] Live Guide: with more than 6 channels the "▾" shows at the bottom; Down to the end -> it disappears; Up -> it returns
- [ ] Settings -> General -> Hero Banner (Off by default): On -> Movies, Series, a genre, Holidays, My Holiday Favourites show a banner (name, year / rating / genre, 2-line description) above the rows; posters one size smaller, two rows still readable; Off -> banner gone, posters big again
- [ ] Settings -> General -> Profiles -> Add Profile: after the name, "Content Preferences" asks Adult / Child, then the limit. Same from the picker's "＋ Add Profile" (Who's Watching?)
- [ ] Child profile: Movies / Series / groups / Holidays / Random Pick / Search show nothing rated above PG-13 (open a few titles first so ratings are remembered); Adult "No Limit" profile unchanged
- [ ] Profile window -> Content Preferences… changes it (asks the PIN first on a locked profile)
- [ ] Settings -> Data, Backup & About -> Backup Now: file name shown. Restore From Backup…: lists it; restoring on the same device shows "No conflicts"; Approve All / per-conflict toggles work with the D-pad
- [ ] Settings -> General -> Location Canada: The Holidays list has Victoria Day (Mon before 25 May), Canada Day, Remembrance Day; United States: they are not listed
