Sparrow Player 3.6.4 (versionCode 51) - TV test checklist (75" U8K) - CHAT A: cleanup release (removals, renames, text only)
(Y = works, E = error + WHAT YOU SAW, N = not tested)
Install OVER 3.6.3. 3.6.3 compiled on GitHub (its APK carries the 3.6.3 code). 3.6.4 was again written WITHOUT a compiler: if the Actions run is red, send the error lines.

[ ] 1. Build is green (GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_6_4.zip) and the app starts.
[ ] 2. Split screen is gone: hold OK on a channel -> no Play Channel, no Add To / Watch / Clear Split Screen. Settings -> Playback -> no "Split Screen Decoding".
[ ] 3. Settings -> General: Open On Device Start-Up / Wake-Up and Sparrow Keyboard have no text under them. Location says "Influences Movies and Series recommendations." Hero Banner is gone.
[ ] 4. Settings -> Playback: "Resume Where I Stopped" (no text), Playback Quality, Audio Quality, Subtitles have no text under them (the note at the bottom is gone too).
[ ] 5. Settings -> Groups & Channels: Channel Numbers and Ask Before Hiding have no text.
[ ] 6. Settings -> Network and Buffering: Buffer Profile and Auto-Reconnect have no text; "Test & Optimise My Connection" (still runs the check).
[ ] 7. Settings -> EPG: Sync Now has no text; "Holiday Episodes Only (Lite)" is the LAST row.
[ ] 8. Settings -> Data, Backup & About: order = About, Navigation And Shortcuts, Clear Cache & Reload, Clear Watch History, Error Log, Backup Now, Restore From Backup, Live Sync Setup (Source) [one short line], Live Sync Setup (Clone), TMDB Ratings (Child Safety) LAST. No text under the others.
[ ] 9. About shows the TMDB logo + the "not endorsed or certified by TMDB" line. (The logo is a stand-in in TMDB colours: see notes.)
[ ] 10. Hero banner: Movies / Series show the slim title line at the top as before; posters are the normal (bigger) size.
[ ] 11. Hold OK on a channel: no explanation text; rows = Add/Remove Favourites, Hide Channels, Copy Channels, Move Channels (own groups only), Delete Channels (own groups only), Set As Opening Channel, Edit Channel Name, (Restore Original Name).
[ ] 12. Hide Channels / Copy Channels / Move Channels: the guide opens the tick boxes with the held channel ALREADY ticked.
[ ] 13. Delete Channels (inside a group of your own): asks "Remove From Group?" for THAT ONE channel (not multi-select yet: Chat C).
[ ] 14. Live Sync Setup (Source) / (Clone) still show / accept the 4-digit code.
[ ] 15. Normal live TV, movies, series, resume, mini player and full screen unchanged.
