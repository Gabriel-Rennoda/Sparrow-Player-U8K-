# Sparrow Player 3.3.0 - TV test checklist (75" U8K)
(Y = works, E = error + WHAT YOU SAW, N = not tested)

FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_3_0.zip (versionCode 43). If red, send the error lines.
This build was written WITHOUT a compiler (like 3.0.0 - 3.2.0). No database change (schema stays 2): install OVER 3.2.0.

## Keyboard (Sparrow's own keyboard, Settings -> General -> Sparrow Keyboard, On by default)
[ ] Add Playlist / group rename / New Group / Search: OK on a box opens the docked keyboard (the text shows in a line above the keys).
[ ] Up on the top letter row (q w e ...) NEVER moves: tap it many times, nothing leaves the letters, the menu behind never takes the selector.
[ ] PRESS AND HOLD Up on the top letter row: the number row (1 2 3 ...) opens above. Down goes back to the letters and the number row tucks away.
[ ] Hold OK on a top-row letter (q w e ...): the letter becomes its number (q -> 1 ... p -> 0).
[ ] Left / Right stop at the ends of a row; Down on the bottom row stays. Shift (one letter at a time), 123 # / ABC layers, space, backspace, Done.
[ ] Done runs the box's action (Add Playlist: Next moves to the next box). Back closes the keyboard, then the arrows move on.
[ ] PIN / number-only boxes: a small number pad opens by itself.
[ ] Names (group rename, profile name) start with a capital; a password box shows dots in the line above the keys.
[ ] Settings -> General -> Sparrow Keyboard Off: the TV's own keyboard comes back (as in 3.2.0).

## Restart
[ ] Backup restore -> Apply Restore -> "Yes, Restart": the app closes and opens again, AND the playlist syncs by itself (status at the top right).

## Add Playlist
[ ] The "more below" arrow shows while the page can scroll (it re-checks after the page settles and whenever the selector moves). If it still does not show: is anything of the page actually cut off at the bottom of the screen? (the page may simply fit)

## Kids
[ ] Frozen, Mulan, Cars 2, Sing 2 ... show in Kids (Movies).
[ ] The grown-up TV movies are out of Kids / Family / Child profiles. Channel words (Hallmark / Lifetime / "Romance Movies" category) and murder / affair style words in the TITLE keep a film out. If one is still in: send its exact title + the category it sits in.

## Movies / Series
[ ] My List carousel: posters show NO Sparrow rating (the provider's star rating stays).
[ ] Details page: the title sits higher, and can take two lines, with more room below it.
