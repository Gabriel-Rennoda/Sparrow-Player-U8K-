# 3.0.0 on the U8K (Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for the 3.0.0 zip (named SparrowPlayer-v3_0_0.zip, versionCode 40). Red "Delete ...zip" runs are normal. If the build is red, send the error lines.

## Navigation (reverted / new)
- [ ] Left at the left edge (first poster of a row, first channel, See All first column): the GROUPS panel opens first, over the icon bar. A second Left opens the icon (tab) list. Right closes one level at a time.
- [ ] Screens without groups (Settings, Favourites): Left at the edge opens the icon list directly.
- [ ] Two quick, deliberate Left presses ANYWHERE (guide, a carousel, a title list) open the groups panel. A single Left only moves one step.
- [ ] Back walks back: Movies > group > another group > a holiday page > Back x N returns through them to All Movies / All Series (same in Live TV to All Channels).
- [ ] Back once at All Movies / All Series opens the groups panel, Back again the icon list.
- [ ] At the icon list: Back (hint) then Back again = "Exit Sparrow Player?". Two QUICK Back presses on any main screen = the exit message at once.
- [ ] Back from See All / Search / the information page still goes straight back one screen (the double-Back exit only works on the main screen).

## Keyboard
- [ ] Add Playlist: Up / Down glides through every box with only an outline, no keyboard. OK on a box opens the keyboard; Back closes it and the arrows move on again.
- [ ] Search: opens on the box without a keyboard; OK on the box opens it.
- [ ] Rename dialogs (group, profile, channel): the box is outlined; OK opens the keyboard.
- [ ] Numeric-only boxes bring up the numeric keyboard when selected (the Search YEAR boxes are kept on OK-only on purpose: they sit in the middle of the filter list; say if you want them automatic too).

## "More below" arrow
- [ ] No arrow in the TV Guide (Live TV / Favourites) and none over the icon list.
- [ ] Movies / Series / Settings / See All / menus: smaller (3/4), dark smoke-grey pill, black edge, white arrow.
- [ ] While scrolling it is see-through; at rest with more below it is solid; when the bottom comes into view it is solid for 1 second, then fades out completely; scroll up again and it returns.

## Speed
- [ ] Hover a title for about a quarter of a second, press OK: the information page shows poster, plot, rating at once (no pop-in of the plot / backdrop). A 0.17 s fade runs from the list to the page. Tell me if it feels slower or faster than 2.9.0.
- [ ] Same from a See All grid.

## Selector
- [ ] Movies: pick a group, then another group, then a carousel group, several times (also right after the app starts, while ratings are still loading): always the first poster of the top row. Series likewise.

## Still open from 2.9.0
- [ ] Hide: details Hide; episode hold OK; See All hold OK (title, several, carousel); group hold OK; Settings -> EPG -> Hidden -> Hidden Movies & Series unhides; Play Next skips a hidden episode
- [ ] Settings -> EPG -> Hide Side Bar After (default Never)
- [ ] Titles from your list 10 / 11: Kids clean; ratings appear after the page opens
- [ ] Android 7-9 only: Backup Now / Error Log -> Save To Device asks for storage access once
