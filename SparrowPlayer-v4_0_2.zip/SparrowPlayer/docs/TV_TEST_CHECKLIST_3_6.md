Sparrow Player 3.6.0 (versionCode 47) - TV test checklist (75" U8K) - STAGE 1 of the four-channel split screen
(Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_6_0.zip. If red, send the error lines.
Written WITHOUT a compiler (like 3.0.0 - 3.5.0). No database change: install OVER 3.5.0.

Split screen
[ ] Live guide: hold OK on a channel -> "Add To Split Screen" is the 2nd row. Press it: toast "Added - 1 of 4 picked". The row's grey text shows the count.
[ ] Hold OK on a second channel: "Watch Split Screen (2)" appears. Open it: two channels side by side, each with its name top-left.
[ ] The highlighted tile has an accent frame and a note sign before its name; ONLY that tile has sound. Left / Right moves the frame and the sound follows.
[ ] With 3 channels: 2 on top, the third across the bottom. With 4: a 2 x 2 grid. Up / Down / Left / Right move correctly (no jump to a missing tile).
[ ] OK (tap) on a tile: that channel opens full screen (normal player). Back from there returns to the guide.
[ ] Back in split screen leaves it. Home / sleep and return: the tiles restart.
[ ] Quality: 2 tiles up to 720p, 3 or 4 tiles up to 540p (look sharp enough on 75"? tell me if you want it higher).
[ ] Provider limit: Settings -> Data, Backup & About -> Error Log: find the line  SPLIT  picked N, provider connection limit X, showing Y, hardware H.264 decoder instances ...  PASTE THAT LINE HERE.
[ ] If your account allows fewer connections than tiles: only that many tiles open and a toast says why. A tile the provider refuses says so (not a black box).
[ ] Do the 4 streams stay smooth for 10 minutes? (note any tile that stutters / freezes / goes black, and which channels)
[ ] Does normal live TV / movies still play exactly as before?

NOT yet in Stage 1 (Stage 2 / 3): choosing a channel from inside split screen, remembering the picks after the app closes, 1 large + 3 small layout.

Still open from 3.5.0 (Kids / Family): TV titles that still show: "My Gay Life", "Liszt's Rhapsody", "No Holds Bard", "Lucille Ball: We Love Lucy", "Sinatra: His Way", "A Circle in the Fire" (+ more to come). Send each with its page + details-page genre line.
