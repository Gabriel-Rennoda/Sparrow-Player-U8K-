# 3.0.0 - investigation, changes and test report
No compiler / Gradle / device where this was written. GitHub Actions: the 2.9.0 build (run #104, Nov 16) was GREEN, so there were no compile errors to fix. The red runs are the "Delete ...zip" commits (no zip left to build = expected). A SparrowPlayer-v2_9_1.zip appeared in the repository at runs #105-#106; it was not available here, so 3.0.0 is based on 2.9.0 (versionCode 40 so it wins the "highest versionCode" pick in build.yml).
Run here: tools/kt_balance.py (all balanced), tools/kt_static_check.py (only the 4 known false positives: ErrorLog, BackupMenus, SettingsFragment, PosterCard - a "//" inside a string). AndroidManifest parsed as XML. Nothing compiled or run on the U8K.

## The three 2.9.0 failures (the checklist said "E" without describing the screen)
| Item | Cause found in the code | Change |
|---|---|---|
| Group / carousel group not on the top row | the 2.9.0 fix only worked inside a fixed 5 s / 0.7 s window; a slow page (rows added in batches, late carousels) outlived it | VodFragment.topLocked: set when a page starts, cleared when the user presses Up / Down (MainActivity.dispatchKeyEvent -> userMovedVertically); the row-0 correction holds until then (90 s cap, 4 s after the last row is added) |
| Keyboard not coming up by itself | showSoftInput was called from onFocusChanged, i.e. while a dialog / screen was still opening and its window had no input focus yet: Android ignores that call and nothing retried | TvEditText: up to 8 retries (150 ms steps) until accepted; asks again in onWindowFocusChanged; remembers a keyboard closed with Back / Done so it does not pop up again; Popup.ask dialog SOFT_INPUT_STATE_VISIBLE; Add Playlist / Search stateVisible |
| Left edge / icon bar | NOT reproduced: onLeft / enterRail / railLeft / railRight read correctly, and a geometry test would be wrong (Leanback keeps the selected card at a fixed spot) | unchanged; sub-step checklist (3.0 section A) to find the failing line |

## Other
| Change | |
|---|---|
| Android 7-9 | WRITE_EXTERNAL_STORAGE (maxSdkVersion 28) + BackupMenus.askStorage: first Backup Now / Save To Device asks, second press saves; refused = app folder as before |
| Version | 3.0.0 (code 40) |
| Not done | the big items in NEXT_UPDATE_REQUEST.md (schema change, split screen, etc.) - not safe to write blind |

## Round 2 (your test notes)
| Request | Change |
|---|---|
| Left at the edge = groups first, second Left = icon list | the 2.9.0 "icon bar first" step is gone: MainActivity.onLeft -> openContentPanels (PanelState.left). The See All / Search "Left" returns open the groups panel / the icon list with Search selected |
| Two quick Left presses = groups panel anywhere | within 420 ms, first press of the key (a held key does not count) |
| Back walks back through groups / pages to the tab's first screen | scopeHist + backOneScope (Movies, Series, Live TV); then groups panel, then icon list |
| Two quick Back = exit message | 500 ms, main screen; Back at the icon list keeps hint + second Back |
| Keyboard only on OK | TvEditText.autoKeyboard default null: OK opens; numeric-only boxes open by themselves. The PIN is a keypad (PinDialog), not a text box, so it was never affected. Popup.ask and both manifest entries are stateHidden; Search no longer opens the keyboard at start |
| Arrow | new MoreArrow (ui/widget): see-through while scrolling, solid at rest, solid 1 s then gone at the bottom, back when scrolled up; 21 sp / 22 dp padding (3/4), #3C3C3C pill, black edge, white arrow. Not shown on Live TV / Favourites (the guide and its groups list) or over the tab list. Used in Movies / Series / Settings, See All, menus |
| Information page speed | already local-database fast; the wait was the panel's info call when OK came before the background fetch finished. Prefetch delay 350 -> 140 ms (also from See All), plus a 170 ms fade (res/anim) hiding the load. Not measured on the TV |
| Movies not returning to the top row (Series did) | cause: a background refresh (TMDB ratings arriving - Movies has far more titles) cancelled the unfinished page load before its "top row" step and re-applied the old page's row. loadRows now hands the pending reset on (resetPending) and keeps row 0 until Up / Down |
