Sparrow Player 3.6.7 (versionCode 54) - TV test checklist (75" U8K) - first slice of Chats B-H
(Y = works, E = error + WHAT YOU SAW, N = not tested). Written WITHOUT a compiler: if the Actions run is red, send the error lines.
[ ] 1. Build is green for SparrowPlayer-v3_6_7.zip; About shows 3.6.7.
[ ] 2. Open a movie you watched about 3 %: only Play. Watch past 7 %: back on details = "Play" + "Restart" (Restart right of Play).
[ ] 3. Restart starts at 0:00 and does not resume; Play continues 30 s before where you stopped.
[ ] 4. Series: the episode that would continue shows "Play S1 E3" + Restart once more than 7 % of THAT episode is watched.
[ ] 5. Kids page (Movies and Series): titles that are unrated and sit only in a "Family" category are gone (My Gay Life, Liszt's Rhapsody, No Holds Bard, Lucille Ball: We Love Lucy, Sinatra: His Way, A Circle in the Fire). Send any that remain: title + Category + Genre.
[ ] 6. Frozen, Bluey, Paw Patrol and the provider's own Kids category still show in Kids. The Family page is unchanged.
[ ] 7. Child profiles (age limits) behave as in 3.6.6.
