# 2.7.0 - run on the Hisense U8K (Y = works, E = error + what you saw)
Nothing in 2.6.0 or 2.7.0 could be compiled or run where it was written: FIRST look at the GitHub Actions log. If "Build APK" is red, send me the error lines.

## Bulk hide - channels (Live TV / Guide / Favourites)
- [ ] Hold OK on a channel -> new row "Hide Several Channels…" -> tick boxes appear, banner says "Hide Channels: 1 selected"
- [ ] OK ticks / unticks; hold OK -> "Copy N Ticked To…", "Hide N Ticked Channels…", Select All, Clear All Ticks, Stop Selecting
- [ ] Hide N -> Yes / No question -> the channels leave the guide, you stay in the same group on the same row; Settings -> General -> Hidden lists them and can bring them back
## Bulk hide - groups (groups panel)
- [ ] Hold OK on a group -> "Hide Several Groups…" -> every group (not All Channels / Favourites) shows ☐ in front; the one you held shows ☑ (if you see an empty square box instead of ☐ / ☑, tell me)
- [ ] OK ticks / unticks; Up / Down move; Left / Right do nothing; hold OK -> Hide N Ticked Groups… / Select All / Clear / Stop; Back stops (asks first with 2+ ticks)
- [ ] Hide -> Yes / No -> the groups leave the list, the selector lands on the next group, hidden groups are in Settings -> General -> Hidden
## Copy / Move targets
- [ ] Copy To Group… -> hold OK -> Copy N To…: the list shows "＋ New Group…" and only YOUR groups (provider groups such as "USA Sports" are no longer offered; a note says so). Provider groups keep exactly their own channels
- [ ] Move To Group lists only your groups (and the channel's own provider group, to put it back)
- [ ] New group made by Copy holds ONLY the ticked channels; the group you copied from is unchanged
## Details screen (item 4)
- [ ] Movie and Series information page: all rows (Play, Sparrow Rating, My List, Holiday, Love / Like / Dislike) are visible down to the bottom of the TV; nothing is cut ~1/5 up the screen. If something is still cut: tell me WHICH screen (photo please)
## VOD speed and facts (item 5)
- [ ] Open a movie: year / rating / genre appear at once, plot + backdrop follow; open the same movie again: plot appears instantly. A slow panel gives up after 20 s instead of 2 minutes
- [ ] Line under the plot: "✓ Watched • Rated PG-13 • Director: … • Cast: …" (each part only when known). Watch a movie to the end -> back on its page shows ✓ Watched; a series shows "3 of 10 watched" and "✓ Watched" when every episode is finished
- [ ] Tell me which titles show no age rating / director / cast (name) so the next step (TMDB credits) is aimed right
