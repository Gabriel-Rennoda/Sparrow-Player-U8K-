# 2.1.0 - run on the Hisense U8K
- [ ] Guide: no gap between the side bar / groups list and the guide. Movies: posters, row names and top title line start at the same distance from the bar
- [ ] Movies: first poster of a row shows its name on top, row name above the row. Move Right: row name becomes the poster's title (bold, centred over it); Down: new row shows its carousel name
- [ ] Left x2 from content: the tab list slides over the groups list and fully hides it; Right: groups list returns
- [ ] Enter Movies / Series / any group / holiday See All tile: always the top row
- [ ] Hold OK -> See All: two big rows, title area never covered, Up at the top row / Down at the bottom row shifts one row, Left on first column -> side panels open
- [ ] Settings: heading list, every pop-up, "▾" shows when there is more below; descriptions under toggles
- [ ] Live channel playing -> Settings: picture keeps playing in the header. -> Search: sound keeps playing. -> open a title: it stops
- [ ] Exit app (Back, Back, Yes), reopen: Who's Watching? shows. Profile with start-up On + PIN: device wake -> plays, first button -> PIN overlay
- [ ] Random Pick at the top of the Movie / Series groups; absent on Live
- [ ] Network: Optimise For My Connection; kill the network briefly on a live channel -> "Reconnecting…"

## 2.1.1 re-test
- [ ] Guide touches the right screen edge
- [ ] Movies: Right along a row - the row's name above it becomes the poster title (bold, centred); Down: new row shows its own name; Up/Down back: name returns
- [ ] Title page: long about text shows 5 lines; if cut, Up from Play focuses it, OK shows all of it
- [ ] See All: two rows of posters visible, title area clear, Left on column 1 -> side panels
- [ ] Who's Watching: Add Profile shows a person silhouette
