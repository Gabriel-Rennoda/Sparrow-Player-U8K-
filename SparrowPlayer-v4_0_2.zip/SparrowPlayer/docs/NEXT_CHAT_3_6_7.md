# 3.6.7 - what is done / what is left of Chats B-H
DONE (untested, no compiler): G part - Play + Restart once >7 % watched (Resume.RESTART_PERCENT / showRestart, restartBtn, PlayerActivity "fromStart" extra).
DONE (untested): H part - Kids gate for UNRATED titles (Maturity.kidsEvidence, used in Catalog build + Picker.accept for the Kids page only).
OPEN QUESTION for H: may the user's Sparrow Rating override the Kids gate? Not decided; nothing reads it.
NOT STARTED: B keyboard / caret / air mouse | C reorder mode + Copy To Movies/Series + custom Favourites sections (delete multi-select already exists since 3.6.5)
| D search upgrades | E per-group channel order A-Z / Z-A / custom | F mini player -> full screen without reload | G 2-line channel/guide rows, bigger watched badges
| H live sync, loading cache, S2/S3 tags. Each is large: ONE per chat, tests first.
