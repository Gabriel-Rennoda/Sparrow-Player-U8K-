# 3.1.0 on the U8K (Y = works, E = error + WHAT YOU SAW, N = not tested)
FIRST: GitHub Actions "Build Sparrow Player" for SparrowPlayer-v3_1_0.zip (versionCode 41). If red, send the error lines.
This build was written WITHOUT a compiler (like 3.0.0). The database moves from schema 1 to 2: install OVER 3.0.0 and check that the playlist login is still there.

## Database (S0 first)
- [ ] Install over 3.0.0: the app opens, the playlist is still there (no "Add Playlist" page), Movies / Series load.
- [ ] After the next sync nothing is lost (My List, ratings, history all still there).

## Navigation
- [ ] A SINGLE Left press only moves one step (guide, carousel, title list). HOLDING Left (about half a second) opens the groups panel.
- [ ] Left at the left edge: groups panel first, second Left = icon list (unchanged).
- [ ] Live TV: Back after choosing another group asks "Go Back?" - Back again or OK on Go Back returns; Cancel stays.
- [ ] Movies / Series: Back still walks back with no question.
- [ ] Two quick Back presses on a main screen do NOT show the exit message any more. Icon list: Back (hint), Back again = "Exit Sparrow Player?".

## Keyboard
- [ ] Open a keyboard (Add Playlist, group rename, "New Group"): Up on the top row / Down on the bottom row stays inside the keyboard. Back closes it, then the arrows move on.

## "More below" arrow
- [ ] Scroll to the bottom: arrow solid 1 s then gone. Scroll up: the arrow waits 1 s, then fades in.

## Speed / fade
- [ ] The fade into the information page is 0.25 s (list, See All).

## Groups
- [ ] Movies / Series: choose another group - the old posters disappear at once, "Loading..." shows, the new page fades in with the first poster selected.

## Details page (movies and series)
- [ ] The age rating badge is on the same line as the date; the star rating no longer repeats in that line.
- [ ] Play button and age badge: grey, white text, light-blue outline. Play gets a brighter/thicker outline when selected.

## Kids
- [ ] The titles from your photos (She Said No, The Dating Game Killer, Kate's Secret, My Gay Life, Diagnosis Delicious, Every Other Holiday, I Will Survive, Flowers & Honey, Sinatra, Lucille Ball, Liszt ...) are no longer in Kids / Family pages or Child profiles.
- [ ] Real kids titles still show (Bluey, Frozen, Despicable Me ...).

## Search
- [ ] The chooser opens with the focus on the kind of the screen you came from (Movies > Movies, Series > Series, else Live).
- [ ] A new search opens with an empty box and an empty result list ("Type To Search"). Clearing the box clears the results.

## Backup / restore
- [ ] Restore brings back start-on-wake-up and the Opening (custom) channel. (Backups made by 3.0.0 did not include them: make a NEW backup in 3.1.0.)
- [ ] After "Apply Restore" a question offers "Yes, Restart".
- [ ] Add Playlist page has "Restore From Backup File..." and "Connect To Other Device To Restore...".

## Settings
- [ ] Hide Side Bar After shows "Never" (no brackets). About shows the TMDB notice.
