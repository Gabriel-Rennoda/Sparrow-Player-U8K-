package com.sparrow.player.data

/**
 * Everything the user changed about the channel list of ONE provider: hidden channels, renamed channels, groups they created,
 * renamed / hidden / re-ordered groups, and which channels were copied or moved between groups.
 *
 * Pure Kotlin (JUnit-testable). It lives in a preference string (see [Prefs.custom]) and NOT in the Room database on purpose:
 * a schema change would put every provider login at risk (docs/UPGRADE_SAFETY.md), and a provider sync deletes and re-inserts
 * every channel row - these edits are keyed by the stable channel uid / category id, so they survive every sync.
 *
 * Group ids: a provider category uses its own remote id, a group the user created uses "c:<something>".
 */
class Customize {
    val hidden = LinkedHashSet<String>()                                   // channel uids
    val renamed = LinkedHashMap<String, String>()                          // channel uid -> name
    val customGroups = LinkedHashMap<String, String>()                     // group id -> name (groups the user created)
    val groupNames = LinkedHashMap<String, String>()                       // group id -> name chosen by the user
    val hiddenGroups = LinkedHashSet<String>()
    val added = LinkedHashMap<String, LinkedHashSet<String>>()             // group id -> uids put there by Copy / Move
    val removed = LinkedHashMap<String, LinkedHashSet<String>>()           // provider group id -> uids taken out by Move / Remove
    val order = ArrayList<String>()                                        // user's group order (ids not listed keep their natural place after these)

    // ---- channels ---------------------------------------------------------------------------------------------------
    fun isHidden(uid: String) = uid in hidden

    fun setHidden(uid: String, hide: Boolean) { if (hide) hidden += uid else hidden -= uid }

    fun nameOf(uid: String, original: String): String = renamed[uid] ?: original

    /** A blank name (or the original one) removes the rename. */
    fun rename(uid: String, name: String, original: String) {
        val n = name.trim()
        if (n.isEmpty() || n == original) renamed.remove(uid) else renamed[uid] = n
    }

    fun hasChannelEdits(uid: String) = uid in hidden || uid in renamed

    /** Hidden + renamed state of one channel back to the provider's. (Group membership is separate.) */
    fun resetChannel(uid: String) { hidden -= uid; renamed.remove(uid) }

    // ---- groups -----------------------------------------------------------------------------------------------------
    fun isCustom(gid: String) = gid in customGroups

    fun createGroup(name: String, id: String = "c:" + java.lang.Long.toString(System.nanoTime(), 36)): String {
        customGroups[id] = name.trim().ifEmpty { "New Group" }
        return id
    }

    fun groupName(gid: String, original: String): String = groupNames[gid] ?: customGroups[gid] ?: original

    fun renameGroup(gid: String, name: String, original: String) {
        val n = name.trim()
        if (n.isEmpty() || n == original) groupNames.remove(gid) else groupNames[gid] = n
        if (gid in customGroups && n.isNotEmpty()) { customGroups[gid] = n; groupNames.remove(gid) }
    }

    fun isGroupHidden(gid: String) = gid in hiddenGroups

    fun setGroupHidden(gid: String, hide: Boolean) { if (hide) hiddenGroups += gid else hiddenGroups -= gid }

    /** Only groups the user created can be deleted; their channels stay in the provider's own groups. */
    fun deleteGroup(gid: String) {
        if (customGroups.remove(gid) == null) return
        groupNames.remove(gid); hiddenGroups -= gid; added.remove(gid); removed.remove(gid); order.remove(gid)
    }

    /** Back to the provider's name / visibility / position (a group the user created keeps its name). */
    fun resetGroup(gid: String) { groupNames.remove(gid); hiddenGroups -= gid; order.remove(gid) }

    fun hasGroupEdits(gid: String) = gid in groupNames || gid in hiddenGroups || gid in order

    // ---- membership -------------------------------------------------------------------------------------------------
    /** Is channel [uid] (whose provider category is [homeCat]) shown in group [gid]? */
    fun isMember(gid: String, uid: String, homeCat: String): Boolean =
        if (gid in customGroups) added[gid]?.contains(uid) == true
        else (homeCat == gid && removed[gid]?.contains(uid) != true) || added[gid]?.contains(uid) == true

    fun addTo(gid: String, uid: String, homeCat: String) {
        if (gid !in customGroups && homeCat == gid) { removed[gid]?.remove(uid); return }
        added.getOrPut(gid) { LinkedHashSet() }.add(uid)
    }

    fun removeFrom(gid: String, uid: String, homeCat: String) {
        if (gid !in customGroups && homeCat == gid) removed.getOrPut(gid) { LinkedHashSet() }.add(uid)
        else added[gid]?.remove(uid)
    }

    /** Copy: the channel stays where it is and also appears in [to]. */
    fun copy(uid: String, to: String, homeCat: String) = addTo(to, uid, homeCat)

    /** Move: out of [from], into [to]. */
    fun move(uid: String, from: String, to: String, homeCat: String) {
        if (from == to) return
        removeFrom(from, uid, homeCat); addTo(to, uid, homeCat)
    }

    /** Groups (other than [homeCat]'s) that currently show this channel because of a Copy / Move, or that the user created. */
    fun extraGroupsOf(uid: String): List<String> = added.filter { uid in it.value }.keys.toList()

    // ---- order ------------------------------------------------------------------------------------------------------
    /** [natural] = group ids in their default order. The user's order wins; ids it doesn't mention follow in their natural order. */
    fun arrange(natural: List<String>): List<String> {
        val set = natural.toHashSet()
        val first = order.filter { it in set }.distinct()
        val used = first.toHashSet()
        return first + natural.filter { it !in used }
    }

    /** Move group [gid] one place up (delta -1) or down (+1) inside [natural]. Returns false if it is already at that end. */
    fun moveGroup(natural: List<String>, gid: String, delta: Int): Boolean {
        val list = arrange(natural).toMutableList()
        val i = list.indexOf(gid)
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) return false
        list[i] = list[j].also { list[j] = list[i] }
        order.clear(); order.addAll(list)
        return true
    }

    fun isEmpty() = hidden.isEmpty() && renamed.isEmpty() && customGroups.isEmpty() && groupNames.isEmpty() &&
        hiddenGroups.isEmpty() && added.isEmpty() && removed.isEmpty() && order.isEmpty()

    // ---- storage ----------------------------------------------------------------------------------------------------
    /** One record per line, fields separated by TAB; TAB / newline / backslash inside a name are escaped. */
    fun serialize(): String {
        val sb = StringBuilder()
        fun line(vararg f: String) { sb.append(f.joinToString("\t") { esc(it) }).append('\n') }
        hidden.forEach { line("H", it) }
        renamed.forEach { (k, v) -> line("N", k, v) }
        customGroups.forEach { (k, v) -> line("G", k, v) }
        groupNames.forEach { (k, v) -> line("GN", k, v) }
        hiddenGroups.forEach { line("GH", it) }
        added.forEach { (g, set) -> set.forEach { line("A", g, it) } }
        removed.forEach { (g, set) -> set.forEach { line("R", g, it) } }
        order.forEach { line("O", it) }
        return sb.toString()
    }

    companion object {
        fun parse(s: String?): Customize {
            val c = Customize()
            if (s.isNullOrBlank()) return c
            for (raw in s.split('\n')) {
                if (raw.isEmpty()) continue
                val f = raw.split('\t').map { unesc(it) }
                when (f[0]) {
                    "H" -> if (f.size >= 2) c.hidden += f[1]
                    "N" -> if (f.size >= 3) c.renamed[f[1]] = f[2]
                    "G" -> if (f.size >= 3) c.customGroups[f[1]] = f[2]
                    "GN" -> if (f.size >= 3) c.groupNames[f[1]] = f[2]
                    "GH" -> if (f.size >= 2) c.hiddenGroups += f[1]
                    "A" -> if (f.size >= 3) c.added.getOrPut(f[1]) { LinkedHashSet() }.add(f[2])
                    "R" -> if (f.size >= 3) c.removed.getOrPut(f[1]) { LinkedHashSet() }.add(f[2])
                    "O" -> if (f.size >= 2) c.order += f[1]
                }
            }
            return c
        }

        private fun esc(s: String): String {
            val sb = StringBuilder(s.length + 4)
            for (ch in s) when (ch) {
                '\\' -> sb.append("\\\\")
                '\t' -> sb.append("\\t")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                else -> sb.append(ch)
            }
            return sb.toString()
        }

        private fun unesc(s: String): String {
            if (s.indexOf('\\') < 0) return s
            val sb = StringBuilder(s.length)
            var i = 0
            while (i < s.length) {
                val ch = s[i]
                if (ch == '\\' && i + 1 < s.length) {
                    when (s[i + 1]) { 't' -> sb.append('\t'); 'n' -> sb.append('\n'); 'r' -> sb.append('\r'); else -> sb.append(s[i + 1]) }
                    i += 2
                } else { sb.append(ch); i++ }
            }
            return sb.toString()
        }
    }
}
