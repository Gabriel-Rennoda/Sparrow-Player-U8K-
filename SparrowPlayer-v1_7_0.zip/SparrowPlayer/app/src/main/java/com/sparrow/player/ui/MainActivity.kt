package com.sparrow.player.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.doOnLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.sparrow.player.R
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Programme
import com.sparrow.player.data.Genres
import com.sparrow.player.data.Repository
import com.sparrow.player.data.SearchKind
import com.sparrow.player.databinding.ActivityMainBinding
import com.sparrow.player.ui.epg.EpgFragment
import com.sparrow.player.ui.menus.GroupMenu
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.search.SearchActivity
import com.sparrow.player.ui.nav.Panel
import com.sparrow.player.ui.nav.PanelState
import com.sparrow.player.ui.player.PlaybackSignal
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.ui.player.PlayerFactory
import com.sparrow.player.ui.settings.AddProviderActivity
import com.sparrow.player.ui.settings.SettingsFragment
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.ui.vod.VodFragment
import com.sparrow.player.util.fmtTime
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Shell of the app.
 *
 *  - Left: minimized icon bar (always visible). LEFT from the left edge of the content opens the channel groups
 *    (Live TV / Guide) and LEFT again expands the tab list. BACK / RIGHT close one level at a time and put the
 *    selector back where the user was.  (State machine: [PanelState])
 *  - Live TV / Guide / Favourites share one header: the player (top-left, always the channel being watched)
 *    and an info pane that follows whatever is being browsed.
 */
class MainActivity : FragmentActivity() {
    private lateinit var b: ActivityMainBinding
    private var viewsBuilt = false

    private val names = listOf("Live TV", "Movies", "Series", "Favourites", "Settings")
    private val icons = listOf(
        R.drawable.ic_nav_live, R.drawable.ic_nav_movies, R.drawable.ic_nav_series,
        R.drawable.ic_nav_fav, R.drawable.ic_nav_settings
    )
    private val navItems = ArrayList<View>()
    private lateinit var searchNav: View
    private val panels = PanelState()
    private var current = -1

    // Focus memory so BACK can put the selector back one level at a time
    private var contentFocus: View? = null
    private var groupsFocus: View? = null
    private var pendingFocus = false

    // Channel groups
    private lateinit var groupAdapter: GroupAdapter
    /** The group shown on the current screen. Live TV / Favourites, Movies and Series each remember their own. */
    private val scopes = HashMap<Int, String>()
    private fun scopeKey() = if (current == TAB_MOVIES || current == TAB_SERIES) current else TAB_LIVE
    var groupScope: String
        get() = scopes[scopeKey()] ?: Repository.SCOPE_ALL
        private set(v) { scopes[scopeKey()] = v }

    // Top-left player
    private var player: ExoPlayer? = null
    var playing: Channel? = null
        private set
    private var playingScope: String = Repository.SCOPE_ALL
    private var liveJob: Job? = null
    private var infoJob: Job? = null

    private val tabContent: TabContent? get() = supportFragmentManager.findFragmentById(R.id.content) as? TabContent

    /** Keeps the TV's screensaver away for as long as the mini player is playing (also while the guide / lists are browsed). */
    private val awake by lazy { PlaybackSignal(this) }

    private fun updateAwake() {
        val p = player
        val active = p != null && p.playWhenReady &&
            (p.playbackState == Player.STATE_READY || p.playbackState == Player.STATE_BUFFERING)
        awake.set(active, playing?.name ?: "")
    }

    private val playerListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            b.playerMsg.text = "Channel unavailable"; b.playerMsg.visibility = View.VISIBLE
            updateAwake()
        }
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) b.playerMsg.visibility = View.GONE
            updateAwake()
        }
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = updateAwake()
        override fun onIsPlayingChanged(isPlaying: Boolean) = updateAwake()
    }

    // ---- Lifecycle ------------------------------------------------------------------------------
    /** True until the first live channel of a fresh launch has been chosen: that one is the Opening Channel (Settings -> EPG). */
    private var openPending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openPending = savedInstanceState == null
        // "Who's Watching?": once per launch, when there is more than one profile
        val launchRepo = applicationContext.repo
        if (savedInstanceState == null && !launchRepo.profileConfirmed) {
            if (launchRepo.profileStore().profiles.size > 1) {
                startActivity(Intent(this, com.sparrow.player.ui.profiles.ProfilePickerActivity::class.java)); finish(); return
            }
            launchRepo.profileConfirmed = true
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        viewsBuilt = true
        themeSeen = Theme.version
        Theme.applyAll(this, b.root)
        val repo = applicationContext.repo

        buildNav()
        groupAdapter = GroupAdapter({ pickGroup(it.id) }, { onGroupFocused(it.id) }, { showGroupMenu(it) })
        b.groupList.layoutManager = LinearLayoutManager(this)
        b.groupList.adapter = groupAdapter
        b.groupList.itemAnimator = null
        b.playerBox.setOnFocusChangeListener { _, f -> if (f) showNowPlaying() }
        b.playerBox.setOnClickListener { fullscreen() }
        b.groupsSearch.setOnClickListener { showSearchChooser() }
        b.groupsSearch.nextFocusUpId = R.id.groupsSearch          // nothing above it
        b.searchBtn.setOnClickListener { showSearchChooser() }
        b.randomBtn.setOnClickListener { startActivity(SearchActivity.random(this, if (current == TAB_MOVIES) SearchKind.MOVIE else SearchKind.SERIES)) }
        applyPanels()

        select(savedInstanceState?.getInt("tab") ?: TAB_LIVE)
        refreshGroups()

        lifecycleScope.launch {
            if (repo.activeProvider() == null) startActivity(Intent(this@MainActivity, AddProviderActivity::class.java))
        }
        lifecycleScope.launch {
            repo.status.collect {
                b.status.text = it
                b.status.visibility = if (it.isEmpty()) View.GONE else View.VISIBLE
            }
        }
        lifecycleScope.launch {
            var firstEpg = true
            repo.epgVersion.collect { if (firstEpg) firstEpg = false else tabContent?.onGuideUpdated() }
        }
        lifecycleScope.launch {
            var firstTick = true
            // The user edited groups / channels (rename, hide, copy ...): the group list is rebuilt; open lists reload via their own hooks.
            repo.dataTick.collect { if (firstTick) firstTick = false else refreshGroups() }
        }
        lifecycleScope.launch {
            var first = true
            repo.dataVersion.collect {
                if (first) {
                    first = false
                } else {
                    // Refresh IN PLACE. (The old code replaced the visible fragment here, which destroyed the
                    // focused view and bounced the selector back to the first tab.)
                    refreshGroups()
                    if (current != TAB_SETTINGS) tabContent?.reload()
                    if (isLiveTab()) ensureLivePlaying()
                }
            }
        }
    }

    private var themeSeen = 0

    override fun onResume() {
        super.onResume()
        // The theme was changed on the theme screen: rebuild so every view, row and the window pick it up.
        if (themeSeen != Theme.version) recreate()
    }

    override fun onStart() {
        super.onStart()
        if (isLiveTab()) ensureLivePlaying()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()          // frees the decoder for the full-screen player and stops audio in the background
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", current)
    }

    // ---- Tabs -----------------------------------------------------------------------------------
    private fun buildNav() {
        // Search sits at the top of the tab list (it opens the Live Channels / Movies / Series chooser)
        searchNav = layoutInflater.inflate(R.layout.item_nav, b.tabs, false).also { v ->
            v.id = View.generateViewId()
            v.findViewById<ImageView>(R.id.navIcon).setImageResource(R.drawable.ic_search)
            v.findViewById<TextView>(R.id.navLabel).text = "Search"
            v.setOnClickListener { if (panels.panel == Panel.NAV) showSearchChooser() }
            v.nextFocusUpId = v.id                       // the top of the list: Up stops here
            Theme.applyTree(v)
            v.isFocusable = false
            b.tabs.addView(v)
        }
        names.forEachIndexed { i, n ->
            val v = layoutInflater.inflate(R.layout.item_nav, b.tabs, false)
            v.id = View.generateViewId()
            v.findViewById<ImageView>(R.id.navIcon).setImageResource(icons[i])
            v.findViewById<TextView>(R.id.navLabel).text = n
            v.setOnClickListener { onNavPicked(i) }
            Theme.applyTree(v)
            v.isFocusable = false          // only focusable while the tab list is expanded
            b.tabs.addView(v); navItems += v
        }
        // The bottom of the list: Down stops on Settings instead of jumping into the channel groups beside it
        navItems.last().let { it.nextFocusDownId = it.id }
    }

    /** Search: choose Live Channels, Movies or Series, then the search window opens with that kind's filters. */
    fun showSearchChooser() {
        val p = Popup(this, "Search", "What Do You Want To Search?")
        val kinds = listOf(SearchKind.LIVE, SearchKind.MOVIE, SearchKind.SERIES)
        kinds.forEach { k -> p.row(k.label) { startActivity(SearchActivity.intent(this, k)) } }
        p.show()
    }

    private fun isLiveTab() = current == TAB_LIVE || current == TAB_FAVS
    private fun isVodTab() = current == TAB_MOVIES || current == TAB_SERIES
    private fun tabHasGroups() = current == TAB_LIVE || isVodTab()

    private fun select(i: Int) {
        if (i == current) return
        current = i
        navItems.forEachIndexed { j, v -> v.isSelected = j == i }
        val f: Fragment = when (i) {
            TAB_LIVE -> EpgFragment.newInstance(false)
            TAB_MOVIES -> VodFragment.newInstance("movie")
            TAB_SERIES -> VodFragment.newInstance("series")
            TAB_FAVS -> EpgFragment.newInstance(true)
            else -> SettingsFragment()
        }
        val live = isLiveTab()
        b.liveHeader.visibility = if (live) View.VISIBLE else View.GONE
        if (i != TAB_MOVIES && i != TAB_SERIES) hideHero()
        b.searchBar.visibility = if (isVodTab()) View.VISIBLE else View.GONE
        refreshGroups()
        pendingFocus = true
        supportFragmentManager.beginTransaction().replace(R.id.content, f).commitAllowingStateLoss()
        if (live) ensureLivePlaying() else releasePlayer()
    }

    private fun onNavPicked(i: Int) {
        if (panels.panel != Panel.NAV) return
        panels.reset()
        if (i == current) {                       // same tab: just close and go back to where we were
            restoreContent(); applyPanels(); return
        }
        contentFocus = null; groupsFocus = null
        applyPanels()
        select(i)                                 // pendingFocus => the new tab takes focus once it has loaded
    }

    /** Called by a tab body when its data is on screen. Takes focus if a tab / group was just chosen. */
    fun contentReady() {
        if (pendingFocus && panels.panel == Panel.NONE) {
            if (tabContent?.focusContent() == true) pendingFocus = false
            else if (isLiveTab() && b.playerBox.requestFocus()) pendingFocus = false   // empty list: park on the player
        }
    }

    /** A body that refreshed in place and had focus asks for focus back once it's reloaded. */
    fun wantFocus() { pendingFocus = true }

    // ---- Panels / D-pad -------------------------------------------------------------------------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> if (onLeft(e)) return true
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (onRight(e)) return true
                KeyEvent.KEYCODE_DPAD_UP -> if (panels.panel == Panel.NONE && isVodTab() && currentFocus !== b.searchBtn && currentFocus !== b.randomBtn && tabContent?.isAtTop() == true) {
                    b.searchBtn.requestFocus(); return true            // Up from the first row reaches Search
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> if (panels.panel == Panel.NONE && (currentFocus === b.searchBtn || currentFocus === b.randomBtn)) {
                    tabContent?.focusContent(); return true
                }
                KeyEvent.KEYCODE_SEARCH -> { showSearchChooser(); return true }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    /**
     * BACK walks the side panels open: content -> Channel Groups (Live TV only) -> Tab List (Live TV, Movies, Series, Favourites,
     * Settings). With the tab list open, Back starts the exit prompt. (RIGHT still closes one level.) The guide's own
     * "snap back to now" after browsing ahead is tried first.
     */
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (panels.panel == Panel.NONE && tabContent?.handleBack() == true) return
        // inside one holiday's page, Back goes up to The Holidays list first
        if (panels.panel == Panel.NONE && isVodTab() && groupScope.startsWith("holiday:")) { openGroup(Repository.SCOPE_HOLIDAYS); return }
        openNextPanel()
    }

    private fun openNextPanel() {
        when (panels.panel) {
            Panel.NONE -> {
                contentFocus = currentFocus
                panels.hasGroups = tabHasGroups()
                panels.backPress(); applyPanels()
                if (panels.panel == Panel.GROUPS) focusGroups() else focusNav()
            }
            Panel.GROUPS -> { groupsFocus = currentFocus; panels.backPress(); applyPanels(); focusNav() }
            Panel.NAV -> backToExit()
        }
    }

    /** Back on the main screen: 1st press = hint, 2nd press (within 2.5 s) = "Exit?  Yes / No". */
    private var lastBack = 0L
    private fun backToExit() {
        val now = SystemClock.uptimeMillis()
        if (lastBack != 0L && now - lastBack <= 2500) {
            lastBack = 0L
            AlertDialog.Builder(this)
                .setTitle("Exit Sparrow Player?")
                .setPositiveButton("Yes") { _, _ -> finishAffinity() }
                .setNegativeButton("No", null)
                .show()
        } else {
            lastBack = now
            Toast.makeText(this, "Press Back again to exit (Right closes the menu)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onLeft(e: KeyEvent): Boolean {
        val first = e.repeatCount == 0        // a held key must not race through all the levels
        return when (panels.panel) {
            Panel.NAV -> true
            Panel.GROUPS -> {
                if (first) { groupsFocus = currentFocus; panels.left(false); applyPanels(); focusNav() }
                true
            }
            Panel.NONE -> {
                // No focus at all (e.g. an empty group) counts as the edge, so the user can never get stuck.
                if (currentFocus != null && !atLeftEdge()) {
                    false
                } else {
                    if (first) {
                        contentFocus = currentFocus
                        panels.hasGroups = tabHasGroups()
                        panels.left(true)
                        applyPanels()
                        if (panels.panel == Panel.GROUPS) focusGroups() else focusNav()
                    }
                    true
                }
            }
        }
    }

    private fun onRight(e: KeyEvent): Boolean {
        if (panels.panel == Panel.NONE) return false
        if (e.repeatCount == 0) closeTopPanel()
        return true
    }

    private fun atLeftEdge(): Boolean {
        val f = currentFocus ?: return false
        if (b.liveHeader.visibility == View.VISIBLE && f === b.playerBox) return true
        if (f === b.randomBtn) return true                          // the left-most button of the Search / Random Pick pair
        return tabContent?.isAtLeftEdge() ?: false
    }

    /** BACK / RIGHT: close one level, move the selector back to the user's last selection there. */
    private fun closeTopPanel() {
        when (panels.panel) {
            Panel.NAV -> {
                panels.back()
                if (panels.panel == Panel.GROUPS) { if (!restore(groupsFocus)) focusGroups() } else restoreContent()
            }
            Panel.GROUPS -> {
                flushGroupPreview(); groupAdapter.setActive(groupScope); panels.back(); restoreContent()
                if (justHiddenGroups.isNotEmpty()) { justHiddenGroups.clear(); refreshGroups() }   // groups hidden a moment ago now leave the list
            }
            Panel.NONE -> return
        }
        applyPanels()
    }

    private fun restore(v: View?): Boolean =
        v != null && v.isAttachedToWindow && v.isShown && v.isFocusable && v.requestFocus()

    private fun restoreContent() { if (!restore(contentFocus)) tabContent?.focusContent() }

    private fun focusGroups() {
        val pos = groupAdapter.positionOf(groupScope).coerceAtLeast(0)
        val rv = b.groupList
        rv.scrollToPosition(pos)
        rv.doOnLayout { (rv.findViewHolderForAdapterPosition(pos)?.itemView ?: rv.getChildAt(0))?.requestFocus() }
    }

    private fun focusNav() {
        navItems.getOrNull(current.coerceAtLeast(0))?.let { it.isFocusable = true; it.requestFocus() }
    }

    /** Make the views match [panels]. Always move focus BEFORE calling this when closing a panel. */
    private fun applyPanels() {
        val nav = panels.navOpen
        b.groupsPanel.visibility = if (panels.groupsOpen) View.VISIBLE else View.GONE
        b.navRail.layoutParams = b.navRail.layoutParams.apply {
            width = resources.getDimensionPixelSize(if (nav) R.dimen.rail_expanded else R.dimen.rail_collapsed)
        }
        b.navTitle.visibility = if (nav) View.VISIBLE else View.GONE
        (navItems + searchNav).forEach { v ->
            v.isFocusable = nav
            v.findViewById<View>(R.id.navLabel).visibility = if (nav) View.VISIBLE else View.GONE
        }
    }

    // ---- Channel groups -------------------------------------------------------------------------
    private val handler = Handler(Looper.getMainLooper())
    private var previewPending = false
    private val previewRun = Runnable { previewPending = false; tabContent?.onGroupChanged() }

    /** Focus moved to a group in the side menu: the guide shows that group right away (OK commits, Back keeps it). */
    private fun onGroupFocused(id: String) {
        if (panels.panel != Panel.GROUPS || id == groupScope || isVodTab()) return     // Movies / Series switch when OK is pressed
        groupScope = id
        groupAdapter.setActiveQuiet(id)             // no notifyDataSetChanged: that would drop focus
        previewPending = true
        handler.removeCallbacks(previewRun); handler.postDelayed(previewRun, 250)   // debounce fast scrolling
    }

    private fun flushGroupPreview() {
        if (!previewPending) return
        handler.removeCallbacks(previewRun); previewPending = false
        tabContent?.onGroupChanged()
    }

    /** Open a group by id without the groups panel (the "See All" tile of a holiday). */
    fun openGroup(id: String) {
        groupScope = id
        groupAdapter.setActive(if (id.startsWith("holiday:")) Repository.SCOPE_HOLIDAYS else id)
        pendingFocus = true
        tabContent?.onGroupChanged()
    }

    private fun pickGroup(id: String) {
        if (panels.panel != Panel.GROUPS) return
        handler.removeCallbacks(previewRun); previewPending = false
        groupScope = id
        groupAdapter.setActive(id)
        panels.reset()
        contentFocus = null; groupsFocus = null
        pendingFocus = true
        applyPanels()
        tabContent?.onGroupChanged()
    }

    /** Groups hidden during this visit to the panel stay listed (marked) until it closes, so a mistaken Hide can be undone. */
    private val justHiddenGroups = HashSet<String>()

    private fun showGroupMenu(g: GroupItem) {
        if (isVodTab()) { Toast.makeText(this, "These groups are built in", Toast.LENGTH_SHORT).show(); return }
        lifecycleScope.launch {
            val pid = applicationContext.repo.activeProvider()?.id ?: return@launch
            GroupMenu.show(this@MainActivity, g, pid, GroupMenu.Hooks(
                hiddenChanged = { id, hide -> if (hide) justHiddenGroups.add(id) else justHiddenGroups.remove(id) },
                changed = { focusId -> refreshGroups(focusId) }
            ))
        }
    }

    /** Rebuild the group list from the provider + the user's edits. [focusId]: put the selector on that group afterwards. */
    fun refreshGroups(focusId: String? = null) {
        lifecycleScope.launch {
            val repo = applicationContext.repo
            val p = repo.activeProvider()
            val list = ArrayList<GroupItem>()
            if (isVodTab()) {
                // Movies / Series: everything, The Holidays (rows per holiday) and the genre tabs
                b.groupsTitle.text = if (current == TAB_MOVIES) "Movie Groups" else "Series Groups"
                list += GroupItem(Repository.SCOPE_ALL, if (current == TAB_MOVIES) "All Movies" else "All Series", pinned = true)
                list += GroupItem(Repository.SCOPE_HOLIDAYS, "The Holidays", pinned = true)
                // the genre tabs: MAIN genres only (Action & Adventure, Comedies, Horror ...); their sub-genres are rows inside
                val tab = current
                val mains = if (p == null) emptyList() else repo.genreMains(p.id, if (tab == TAB_MOVIES) "movie" else "series")
                if (current != tab) return@launch                            // the user switched tab while this was loading
                mains.forEach { list += GroupItem(Genres.SCOPE_PREFIX + it.id, it.name, pinned = true) }
                val inHoliday = groupScope.startsWith("holiday:")
                if (!inHoliday && list.none { it.id == groupScope }) groupScope = Repository.SCOPE_ALL
                groupAdapter.submit(list, if (inHoliday) Repository.SCOPE_HOLIDAYS else groupScope)
                return@launch
            }
            b.groupsTitle.text = "Channel Groups"
            val groups = if (p == null) emptyList() else repo.groups(p.id)
            list += GroupItem(Repository.SCOPE_ALL, "All Channels", pinned = true)
            list += GroupItem(Repository.SCOPE_FAV, "★  Favourites", pinned = true)
            groups.filter { !it.hidden || it.id in justHiddenGroups }
                .forEach { list += GroupItem(it.id, it.name, custom = it.custom, hidden = it.hidden, original = it.original) }
            // the row that has the selector now (its list is about to be rebuilt, which would drop the focus)
            val keepId = focusId ?: b.groupList.focusedChild?.let { v -> groupAdapter.idAt(b.groupList.getChildAdapterPosition(v)) }
            val old = groupScope
            if (list.none { it.id == groupScope }) groupScope = Repository.SCOPE_ALL
            groupAdapter.submit(list, groupScope)
            if (groupScope != old) tabContent?.onGroupChanged()           // the group being viewed was hidden / deleted
            if (keepId != null && panels.panel != Panel.NONE) {
                val pos = groupAdapter.positionOf(keepId)
                if (pos >= 0) b.groupList.let { rv ->
                    rv.scrollToPosition(pos)
                    rv.doOnLayout { rv.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
                }
            }
        }
    }

    // ---- Top-left player ------------------------------------------------------------------------
    private fun ensurePlayer(): ExoPlayer = player ?: PlayerFactory.create(this).also {
        it.addListener(playerListener); b.playerView.player = it; player = it
    }

    private fun releasePlayer() {
        liveJob?.cancel()
        if (viewsBuilt) b.playerView.player = null                   // (not yet built when the launch went to "Who's Watching?")
        player?.release(); player = null
        awake.release()
    }

    /** Make sure the top-left player is playing the channel the user was last watching. */
    private fun ensureLivePlaying() {
        liveJob?.cancel()
        liveJob = lifecycleScope.launch {
            val repo = applicationContext.repo
            val p = repo.activeProvider() ?: run { showNoProvider(); return@launch }
            // a fresh launch starts on the Opening Channel if one is set; otherwise (and afterwards) on the last channel watched
            val open = if (openPending) repo.prefs.openChannel else ""
            openPending = false
            val last = repo.prefs.lastChannel
            val c = (if (open.isNotBlank()) repo.channel(open)?.takeIf { it.providerId == p.id } else null)
                ?: (if (last.isNotBlank()) repo.channel(last)?.takeIf { it.providerId == p.id } else null)
                ?: repo.firstChannel(p.id)
                ?: return@launch
            if (player != null && playing?.uid == c.uid) { if (infoUid.isEmpty()) showNowPlaying(); return@launch }
            tune(c, if (playing?.uid == c.uid) playingScope else Repository.SCOPE_ALL)
        }
    }

    /** Switch the top-left player to [c]. */
    fun tune(c: Channel, scope: String) {
        val infoWasPlaying = infoPlaying
        playing = c; playingScope = scope
        applicationContext.repo.prefs.lastChannel = c.uid
        val p = ensurePlayer()
        b.playerMsg.visibility = View.GONE
        p.setMediaItem(MediaItem.fromUri(applicationContext.repo.liveUrl(c)))
        p.prepare(); p.playWhenReady = true
        updateAwake()
        tabContent?.onPlayingChanged()
        when {
            infoUid.isEmpty() || infoUid == c.uid || infoWasPlaying -> render(c)   // pane should now describe the playing channel
            else -> { infoPlaying = false; b.infoTag.text = "Browsing" }          // pane shows another channel
        }
    }

    /** OK on a channel: tune it; OK on the channel that is already playing: full screen. */
    fun onChannelClicked(c: Channel, scope: String) {
        if (playing?.uid == c.uid && player != null) fullscreen() else tune(c, scope)
    }

    private fun fullscreen() {
        val c = playing ?: return
        startActivity(PlayerActivity.live(this, c.uid, playingScope))
    }

    fun onFavoriteChanged(c: Channel) {
        if (playing?.uid == c.uid) playing = c
    }

    /** A channel was renamed in the guide: keep the player's channel and the info pane in step. */
    fun onChannelRenamed(c: Channel) {
        if (playing?.uid == c.uid) playing = c
        if (infoUid == c.uid) setHeader(c)
    }

    // ---- Info pane (follows what is browsed; the player keeps playing) ---------------------------
    private var infoUid = ""            // channel the info pane currently describes
    private var infoPlaying = false     // ... and whether that is the channel in the player

    private fun showNoProvider() {
        b.infoTag.text = ""; b.chName.text = "No Playlist Yet"
        b.nowTitle.text = "Open Settings → General → Add Or Switch Playlist"
        b.nowTime.text = ""; b.nowDesc.text = ""; b.nextTitle.text = ""
    }

    fun showNowPlaying() {
        val c = playing ?: return
        render(c)
    }

    /** A list row got focus: show its now / next while the player carries on. */
    fun browseChannel(c: Channel) = render(c)

    /** A guide cell got focus: show that programme (and the one after it). */
    fun browseProgramme(c: Channel, p: Programme?, next: Programme?) {
        infoJob?.cancel()
        setHeader(c)
        fill(p, next)
    }

    private fun setHeader(c: Channel) {
        val isPlaying = c.uid == playing?.uid
        infoUid = c.uid; infoPlaying = isPlaying
        b.infoTag.text = if (isPlaying) "Now Playing" else "Browsing"
        val num = if (applicationContext.repo.prefs.showNumbers) "${c.number}  " else ""
        b.chName.text = (if (c.isFavorite) "★ " else "") + num + c.name
    }

    private fun render(c: Channel) {
        setHeader(c)
        infoJob?.cancel()
        infoJob = lifecycleScope.launch {
            val now = System.currentTimeMillis()
            val l: List<Programme> = if (c.epgId.isBlank()) emptyList() else applicationContext.repo.dao.nowNext(c.providerId, c.epgId, now)
            val cur = l.firstOrNull()?.takeIf { it.start <= now }
            val next = if (cur != null) l.getOrNull(1) else l.firstOrNull()
            fill(cur, next)
        }
    }

    private fun fill(p: Programme?, next: Programme?) {
        val now = System.currentTimeMillis()
        b.nowTitle.text = p?.title ?: "No program information"
        b.nowTime.text = p?.let { "${fmtTime(it.start)} – ${fmtTime(it.stop)}" } ?: ""
        b.nowDesc.text = p?.descr ?: ""
        b.nextTitle.text = next?.let { "Next  ${fmtTime(it.start)}  ${it.title}" } ?: ""
    }

    // ---- Movies / Series hero -------------------------------------------------------------------
    fun showHero(title: String, meta: String, plot: String, percent: Int = 0) {
        b.hero.visibility = View.VISIBLE
        b.heroTitle.text = title; b.heroMeta.text = meta; b.heroPlot.text = plot
        b.heroProgress.visibility = if (percent > 0) View.VISIBLE else View.GONE
        b.heroProgress.progress = percent
    }

    fun hideHero() { b.hero.visibility = View.GONE }

    companion object {
        const val TAB_LIVE = 0
        const val TAB_MOVIES = 1
        const val TAB_SERIES = 2
        const val TAB_FAVS = 3
        const val TAB_SETTINGS = 4
    }
}
