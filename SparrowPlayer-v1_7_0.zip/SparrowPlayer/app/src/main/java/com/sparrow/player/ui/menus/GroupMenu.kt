package com.sparrow.player.ui.menus

import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.ui.GroupItem
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * Pop-up for a channel group (OK held on it in the groups panel): Rename, Move Up / Down, Hide / Unhide, Delete (own groups only),
 * Restore Original (name, position, visibility) and Create New Group. All Channels and Favourites are built in: only
 * "Create New Group" is offered there.
 */
object GroupMenu {
    class Hooks(
        /** A group was hidden / unhidden: the panel keeps showing it (marked) until it closes. */
        val hiddenChanged: (String, Boolean) -> Unit,
        /** The list changed (rename / move / delete / new): rebuild it and put the selector on [focusId]. */
        val changed: (focusId: String?) -> Unit
    )

    fun show(a: FragmentActivity, g: GroupItem, pid: Long, h: Hooks) {
        val repo = a.applicationContext.repo
        val cu = repo.custom(pid)
        val p = Popup(a, g.name, "Group Options")
        if (g.pinned) {
            p.note("All Channels and Favourites are built in and can't be edited.")
        } else {
            p.row("Rename Group…") {
                Popup.ask(a, "Rename Group", "Group name", g.name) { n ->
                    cu.renameGroup(g.id, n, g.original); repo.saveCustom(pid); h.changed(g.id); toast(a, "Name saved")
                }
            }
            p.row("Move Up") { move(a, pid, g, -1, h) }
            p.row("Move Down") { move(a, pid, g, +1, h) }
            p.row(if (g.hidden) "Unhide Group" else "Hide Group") {
                cu.setGroupHidden(g.id, !g.hidden); repo.saveCustom(pid)
                h.hiddenChanged(g.id, !g.hidden)
                toast(a, if (g.hidden) "Group unhidden" else "Group hidden – open this menu again to unhide it")
            }
            if (g.custom) p.row("Delete Group…") {
                Popup.confirm(a, "Delete Group?", "Delete \"${g.name}\"? Its channels stay in All Channels and in their own groups.", "Yes, Delete") {
                    cu.deleteGroup(g.id); repo.saveCustom(pid); h.changed(null); toast(a, "Group deleted")
                }
            } else if (cu.hasGroupEdits(g.id)) p.row("Restore Original Name And Position") {
                cu.resetGroup(g.id); repo.saveCustom(pid); h.changed(g.id); toast(a, "Group restored")
            }
        }
        p.row("Create New Group…") {
            Popup.ask(a, "New Group", "Group name", "") { n ->
                val id = cu.createGroup(n); repo.saveCustom(pid); h.changed(id); toast(a, "Group created – copy channels into it from the guide")
            }
        }
        p.show()
    }

    private fun move(a: FragmentActivity, pid: Long, g: GroupItem, delta: Int, h: Hooks) {
        a.lifecycleScope.launch {
            val repo = a.applicationContext.repo
            val ids = repo.groups(pid).map { it.id }
            if (repo.custom(pid).moveGroup(ids, g.id, delta)) { repo.saveCustom(pid); h.changed(g.id) }
            else toast(a, if (delta < 0) "Already at the top" else "Already at the bottom")
        }
    }

    private fun toast(a: FragmentActivity, msg: String) = Toast.makeText(a, msg, Toast.LENGTH_SHORT).show()
}
