package com.sparrow.player.data

/**
 * Finds film series ("collections") from titles alone: Toy Story / Toy Story 2 / Toy Story 3, The Lord of the Rings: The Two Towers ...
 * Pure Kotlin. A title's key is its first two words (three after "of / and / the ..."), ignoring a leading "The", years, brackets,
 * tags in front ("EN | ") and a trailing sequel number. It is a heuristic: a group needs at least 3 titles to count.
 */
object Franchises {
    class Franchise(val key: String, val name: String, val uids: List<String>)

    private val STOP = setOf("of", "and", "the", "in", "on", "for", "to", "a", "an", "at", "with")

    private fun tokens(name: String): List<String> {
        var s = name.lowercase()
        s = s.replace(Regex("[(\\[][^)\\]]*[)\\]]"), " ")                  // (2019) [4K]
        s = s.replace(Regex("^\\s*[a-z]{2,3}\\s*[|:]\\s*"), "")            // "EN | Title"
        val t = ArrayList(TextNorm.prepare(s).trim().split(' ').filter { it.isNotEmpty() })
        while (t.size > 1 && (t.last().all { it.isDigit() } || t.last() in ROMAN)) t.removeAt(t.size - 1)   // sequel number
        if (t.firstOrNull() in setOf("the", "a", "an") && t.size > 2) t.removeAt(0)
        return t
    }

    private val ROMAN = setOf("ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x")

    fun keyOf(name: String): String {
        val t = tokens(name)
        if (t.size < 2) return ""
        val n = if (t[1] in STOP && t.size >= 3) 3 else 2
        val key = t.take(n).joinToString(" ")
        return if (key.length >= 7) key else ""
    }

    /** Groups of at least [minSize] titles, largest first. [titles]: (uid, name) in any order. */
    fun detect(titles: List<Pair<String, String>>, minSize: Int = 3): List<Franchise> {
        val groups = LinkedHashMap<String, MutableList<Pair<String, String>>>()
        for (t in titles) { val k = keyOf(t.second); if (k.isNotEmpty()) groups.getOrPut(k) { ArrayList() }.add(t) }
        return groups.filter { it.value.size >= minSize }.map { (k, v) ->
            Franchise(k, displayName(k, v.map { it.second }), v.sortedBy { it.second.lowercase() }.map { it.first })
        }.sortedWith(compareByDescending<Franchise> { it.uids.size }.thenBy { it.name })
    }

    /** The longest shared start of the titles ("The Lord of the Rings"), else the key title-cased. */
    private fun displayName(key: String, names: List<String>): String {
        val cleaned = names.map { it.replace(Regex("[(\\[][^)\\]]*[)\\]]"), "").replace(Regex("^\\s*[A-Za-z]{2,3}\\s*[|:]\\s*"), "").trim() }
        var p = cleaned.first()
        for (n in cleaned.drop(1)) { var i = 0; while (i < p.length && i < n.length && p[i].equals(n[i], ignoreCase = true)) i++; p = p.substring(0, i) }
        val words = p.substringBefore(':').trim().split(' ').filter { it.isNotEmpty() }.toMutableList()
        while (words.size > 1 && (words.last().lowercase() in STOP || words.last().all { it.isDigit() } || words.last().lowercase() in ROMAN || words.last() == "-")) words.removeAt(words.size - 1)
        val lcp = words.joinToString(" ")
        if (lcp.length >= key.length) return lcp                              // the titles' own spelling, e.g. "The Lord of the Rings"
        return key.split(' ').filter { it.isNotEmpty() }.joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }
    }
}
