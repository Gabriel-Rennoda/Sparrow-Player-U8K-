package com.sparrow.player.ui.profiles

import android.app.Activity
import android.app.Dialog
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView
import com.sparrow.player.data.Profile
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp

/**
 * A 4-digit PIN pad for the remote: move over the keys and press OK, or just press the number keys on the remote.
 * [onEntered] receives the 4 digits; Cancel / Back closes without calling it.
 */
object PinDialog {
    fun show(a: Activity, title: String, subtitle: String = "", onEntered: (String) -> Unit) {
        if (a.isFinishing) return
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val pin = StringBuilder()
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(a.dp(28), a.dp(22), a.dp(28), a.dp(22)) }
        col.addView(TextView(a).apply { text = title; textSize = 24f; tag = "t:text"; setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER })
        if (subtitle.isNotBlank()) col.addView(TextView(a).apply { text = subtitle; textSize = 15f; tag = "t:dim"; gravity = Gravity.CENTER })
        val dots = TextView(a).apply { textSize = 38f; tag = "t:accent"; gravity = Gravity.CENTER; letterSpacing = 0.3f; setPadding(0, a.dp(8), 0, a.dp(10)) }
        col.addView(dots)
        fun refresh() { dots.text = (0 until Profile.PIN_LENGTH).joinToString(" ") { if (it < pin.length) "●" else "○" } }
        refresh()

        fun digit(n: Int) {
            if (pin.length >= Profile.PIN_LENGTH) return
            pin.append(n); refresh()
            if (pin.length == Profile.PIN_LENGTH) Handler(Looper.getMainLooper()).postDelayed({ d.dismiss(); onEntered(pin.toString()) }, 160)
        }
        fun back() { if (pin.isNotEmpty()) { pin.deleteCharAt(pin.length - 1); refresh() } }

        fun key(label: String, go: () -> Unit) = TextView(a).apply {
            text = label; textSize = 24f; tag = "t:item;bg:item"; gravity = Gravity.CENTER
            isFocusable = true; isClickable = true; minWidth = a.dp(84); minHeight = a.dp(58)
            setOnClickListener { go() }
        }
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "Cancel"))
        var first: TextView? = null
        for (r in rows) {
            val line = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            for (l in r) {
                val k = key(l) { when (l) { "⌫" -> back(); "Cancel" -> d.dismiss(); else -> digit(l.toInt()) } }
                if (first == null && l == "5") first = k
                line.addView(k, LinearLayout.LayoutParams(a.dp(96), ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(a.dp(4), a.dp(4), a.dp(4), a.dp(4)) })
            }
            col.addView(line)
        }
        Theme.applyTree(col)
        d.setContentView(col)
        d.setOnKeyListener { _, code, ev ->
            if (ev.action != KeyEvent.ACTION_DOWN) false
            else when (code) {
                in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> { digit(code - KeyEvent.KEYCODE_0); true }
                in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> { digit(code - KeyEvent.KEYCODE_NUMPAD_0); true }
                KeyEvent.KEYCODE_DEL -> { back(); true }
                else -> false
            }
        }
        d.show()
        d.window?.apply {
            setBackgroundDrawable(GradientDrawable().apply { setColor(Theme.surface); cornerRadius = a.dp(16).toFloat() })
            setLayout(a.dp(380), ViewGroup.LayoutParams.WRAP_CONTENT); setDimAmount(0.7f)
        }
        first?.requestFocus()
    }
}
