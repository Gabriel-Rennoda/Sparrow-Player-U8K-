package com.sparrow.player.ui.widget

import android.content.Context
import android.graphics.Rect
import android.text.InputType
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText

/**
 * Every text box of the app, made for a remote (v3.0.0):
 *  - the on-screen keyboard comes up when OK is pressed on the box (numeric-only boxes: when selected); moving over a box never opens it;
 *  - once the keyboard was closed (Back / Done) the arrow keys move on to the next control again (right to the titles, down to the filters), instead of
 *    being swallowed by a keyboard that is no longer on screen. OK on the box brings the keyboard back.
 * While the keyboard is open the arrow keys belong to it, as usual.
 */
class TvEditText @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : EditText(context, attrs) {
    private var kbUp = false
    private var closedByUser = false          // the keyboard was closed with Back / Done: it must not pop up again until OK or a new focus
    private var tries = 0
    /**
     * v3.0.0: null (default) = text boxes open the keyboard only when OK is pressed on them (so the selector glides through a page of boxes); a box that takes
     * numbers only (inputType number) brings up its numeric keyboard by itself when selected. true / false forces one way.
     */
    var autoKeyboard: Boolean? = null
    private fun auto(): Boolean = autoKeyboard ?: ((inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER)

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        if (gainFocus) { closedByUser = false; if (auto()) showKeyboard() } else kbUp = false
    }

    /**
     * v3.0.0: a box that gets focus while its window is still opening (a dialog, a new screen) asked for the keyboard too early and Android ignored the
     * request - on the U8K nothing came up by itself. Now the request is repeated until it is accepted, and it is made again when the window gets
     * focus.
     */
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus && auto() && isFocused && !closedByUser && !kbUp) showKeyboard()
    }

    fun showKeyboard() {
        kbUp = true; closedByUser = false
        tries = 0
        attempt(0L)
    }

    private fun attempt(delayMs: Long) {
        postDelayed({
            if (!isAttachedToWindow || !hasFocus() || closedByUser) return@postDelayed
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val ok = hasWindowFocus() && imm.showSoftInput(this, 0)
            tries++
            // not accepted yet (window not focused / IME not bound): try again a few times, then give up quietly (OK on the box asks again)
            if (!ok && tries < 8) attempt(150L * tries)
        }, delayMs)
    }

    fun hideKeyboard() {
        kbUp = false; closedByUser = true
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

    override fun onKeyPreIme(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) { kbUp = false; closedByUser = true }            // the keyboard closes itself on this Back
            return super.onKeyPreIme(keyCode, event)
        }
        if (!kbUp && event.action == KeyEvent.ACTION_DOWN) {
            val dir = when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> View.FOCUS_UP
                KeyEvent.KEYCODE_DPAD_DOWN -> View.FOCUS_DOWN
                KeyEvent.KEYCODE_DPAD_LEFT -> View.FOCUS_LEFT
                KeyEvent.KEYCODE_DPAD_RIGHT -> View.FOCUS_RIGHT
                else -> 0
            }
            if (dir != 0) {
                val next = focusSearch(dir)
                if (next != null && next !== this) { next.requestFocus(dir); return true }
            }
            if ((keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) && event.repeatCount == 0) { showKeyboard(); return true }
        }
        return super.onKeyPreIme(keyCode, event)
    }
}
