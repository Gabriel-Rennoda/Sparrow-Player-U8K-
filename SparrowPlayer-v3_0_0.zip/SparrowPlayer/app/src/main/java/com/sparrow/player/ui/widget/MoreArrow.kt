package com.sparrow.player.ui.widget

import android.os.Handler
import android.os.Looper
import android.view.View

/**
 * The "more below" arrow (v3.0.0). It never hides anything for long:
 *  - while the list / page scrolls it is translucent (the content shows through);
 *  - at rest with more below it is solid (a hint that there is more);
 *  - when the bottom comes into view it goes solid for 1 second and then fades away completely (= the end);
 *  - when the bottom goes out of view again it returns.
 * [canScroll] answers "is there more below right now?". Call [scrolled] on every scroll / key move and [layoutChanged] when the size or content changed.
 */
class MoreArrow(private val v: View, private val canScroll: () -> Boolean) {
    private val h = Handler(Looper.getMainLooper())
    private var moving = false
    private var ending = false
    private val idle = Runnable { moving = false; eval() }
    private val endFade = Runnable {
        v.animate().alpha(0f).setDuration(350).withEndAction { if (ending) { ending = false; v.visibility = View.GONE } }.start()
    }

    fun scrolled() { moving = true; eval(); h.removeCallbacks(idle); h.postDelayed(idle, 300) }

    fun layoutChanged() = eval()

    fun hide() { h.removeCallbacks(endFade); h.removeCallbacks(idle); v.animate().cancel(); ending = false; v.visibility = View.GONE }

    private fun eval() {
        if (canScroll()) {
            if (ending) { ending = false; h.removeCallbacks(endFade); v.animate().cancel() }
            if (v.visibility != View.VISIBLE) { v.alpha = 0f; v.visibility = View.VISIBLE }
            v.animate().alpha(if (moving) 0.35f else 1f).setDuration(150).start()
        } else if (v.visibility == View.VISIBLE && !ending) {
            ending = true
            v.animate().cancel(); v.alpha = 1f
            h.removeCallbacks(endFade); h.postDelayed(endFade, 1000)
        }
    }
}
