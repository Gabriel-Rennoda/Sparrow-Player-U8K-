Next update (v3.1.0) - same rules: investigate and test each item before changing code, apply in stages, test for the 75" U8K remote, then give me the updated zip. If anything is not completed, write a new copy-paste document.

Version 3.0.0 is the base; it was written WITHOUT a compiler (as 2.9.0 was; 2.9.0 built green, run #104). FIRST check the GitHub build log for the 3.0.0 run; fix compile errors before anything else. Check docs/TV_TEST_CHECKLIST_3_0.md (my results are pasted below).

Carried over from the 3.0.0 request, NOT done in 3.0.0 (no compiler / device here, and each one changes the database or adds a big screen, so each needs its own build + TV test):
1. S0 tmdb ids from get_vod_streams: Room schema change + Migration (add tmdbId to the vod table; keep every playlist login). Do this FIRST, alone, with a migration unit test.
2. S2 TMDB genres + animation + family tags for genre groups / carousels (needs the tmdb genres stored per title: depends on 1).
3. S3 TMDB keywords for holiday carousels + holiday pre-menu (23) (depends on 1).
4. S0 TMDB logo on Settings / About (TMDB's terms need their logo + the notice "This product uses the TMDB API but is not endorsed or certified by TMDB"). Send me the logo file or allow it to be downloaded in the build; the notice text can be added now.
5. 19 / 20 multiple custom Favourites sections; Copy To for Movies / Series.
6. 12 live sync.
7. 3 / 6 four-channel split screen.
8. "Bigger watched badges on posters": posters currently have NO watched badge (only the progress bar; the Watched badge is on the details page). Tell me what you want on the poster (a tick on finished titles?) and I will add it.

Done in 3.0.0: keyboard retry + window-focus request + dialog / manifest soft-input state; top-row lock held until Up / Down; Android 7-9 storage permission for Backup Now / Save To Device. Left-edge: logic unchanged, needs the sub-step results from checklist section A.
