package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class LibraryStatsTest {
    private fun vod(id: String, type: String = "movie") = VodItem(id, 1, id, type, "T", "", "", "1", "", "", "", 0, "", "", "")

    @Test fun syncCountsRoundTripAndRepeatedIds() {
        val l = listOf(vod("1:m:1"), vod("1:m:1"), vod("1:m:2"), vod("1:s:9", "series"))
        val c = SyncCounts.of(l, 120, 7, 3, 55L)
        assertEquals(3, c.movieSent); assertEquals(2, c.movieUnique); assertEquals(1, c.seriesSent); assertEquals(1, c.seriesUnique)
        val back = SyncCounts.parse(c.serialize())!!
        assertEquals(120, back.liveSent); assertEquals(7, back.movieCategories); assertEquals(3, back.seriesCategories); assertEquals(55L, back.at)
        assertEquals(3, back.movieSent); assertEquals(2, back.movieUnique)
    }

    @Test fun nothingRecordedGivesNull() { assertNull(SyncCounts.parse("")); assertNull(SyncCounts.parse("1,2,x,4,5,6,7,8")) }

    @Test fun reportCountsTitlesNotRows() {
        fun v(i: Int, name: String, cat: String, genre: String = "", poster: String = "http://p", year: String = "2015", rating: String = "7") =
            VodLite("1:m:$i", cat, name, poster, rating, year, i.toLong(), genre)
        val items = listOf(
            v(1, "Same Film", "1", "Action"), v(2, "Same Film", "2", "Comedy"),         // one film listed in two categories
            v(3, "Quiet Drama", "1", "Drama"), v(4, "Mystery Box", "3"),                // no genre anywhere
            v(5, "No Poster", "1", "Action", poster = "", year = "", rating = "")
        )
        val c = VodCatalog.build(1, "movie", items, mapOf("1" to "Movies", "2" to "More Movies", "3" to "Misc"))
        val r = LibraryStats.of(c, emptyMap())
        assertEquals(5, r.stored); assertEquals(4, r.unique)
        assertEquals(1, r.noPoster); assertEquals(1, r.noRating); assertEquals(1, r.noYear)
        assertTrue(r.inGenreGroup >= 3)                                              // Same Film (Action + Comedy), Quiet Drama, No Poster
        assertEquals(r.unique, r.inGenreGroup + r.inNoGenreGroup)
        assertEquals(3, r.perCategory.size); assertEquals("Movies", r.perCategory.first().first)
        assertTrue(r.perGenre.any { it.first == "Action & Adventure" })
    }
}
