package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class HolidayMaskTest {
    private val texts = listOf(
        "A Christmas Story (1983)", "EN | Home for XMAS", "Eastern Promises", "The Polar Express", "Santa Claus Is Comin To Town", "x mas movie",
        "Thanksgiving Day Parade", "Plain Title", "Easter Parade Halloween Hocus Pocus", "North Pole Express", "Jingle All The Way", "My Valentine", "", "   ", "Chrismas Eve"
    )

    @Test fun maskAgreesWithTheKeywordSearchForEveryHoliday() {
        for (t in texts) {
            val p = TextNorm.prepare(t); val mask = Holidays.maskOf(p)
            for (h in Holidays.ALL) assertEquals(t + " / " + h.id, Holidays.matchesPrepared(h, p), mask and Holidays.bit(h) != 0)
        }
    }

    @Test fun descriptionsIgnoreAmbiguousWords() {
        val p = TextNorm.prepare("He orders a pumpkin latte, then Santa Monica. On Christmas Eve ...")
        assertEquals(Holidays.bit(Holidays.CHRISTMAS), Holidays.maskOf(p, plot = true))
        assertTrue(Holidays.maskOf(p) and Holidays.bit(Holidays.HALLOWEEN) != 0)                    // in a title the same word counts
    }

    @Test fun christmasKeywordsNowCatchHolidayCategoriesAndClassics() {
        for (t in listOf("The Holiday", "Home Alone", "It's A Wonderful Life", "Miracle on 34th Street", "Love Actually"))
            assertTrue(t, Holidays.maskOf(TextNorm.prepare(t)) and Holidays.bit(Holidays.CHRISTMAS) != 0)
        // "Holiday Movies" is a CATEGORY word: it counts in a category, not in a title
        assertTrue(Holidays.maskOfCategory(TextNorm.prepare("Holiday Movies")) and Holidays.bit(Holidays.CHRISTMAS) != 0)
        assertEquals(0, Holidays.maskOf(TextNorm.prepare("Holiday Movies")) and Holidays.bit(Holidays.CHRISTMAS))
    }

    private fun screen(name: String, category: String = "", genre: String = ""): Int {
        val prep = RowTitle.Prep.of(category, genre)
        return Holidays.screen(prep.holidays, TextNorm.prepare(name), prep.adult)
    }
    private fun has(mask: Int, h: Holidays.Holiday) = mask and Holidays.bit(h) != 0

    @Test fun excludeListsScreenFalseMatchesOut() {
        for (t in listOf("Roman Holiday", "Santa Fe", "Santa Barbara", "Santa Clarita Diet", "Easter Island", "Elf Quest"))
            assertEquals(t, 0, screen(t) and (Holidays.bit(Holidays.CHRISTMAS) or Holidays.bit(Holidays.EASTER)))
        // ... even when the CATEGORY says holiday: the name's screen-out list wins
        assertFalse(has(screen("Roman Holiday", category = "Holiday Movies"), Holidays.CHRISTMAS))
        assertTrue(has(screen("Holiday Inn"), Holidays.CHRISTMAS)); assertTrue(has(screen("The Santa Clause"), Holidays.CHRISTMAS))
    }

    @Test fun adultCategoriesAndTitlesNeverShow() {
        assertEquals(0, screen("Merry Christmas Darling", category = "Adult Movies"))
        assertEquals(0, screen("Naughty Christmas XXX"))
        assertEquals(0, screen("Christmas Night", category = "18+ Movies"))
        assertTrue(has(screen("Christmas Night", category = "Holiday Movies"), Holidays.CHRISTMAS))
    }

    @Test fun plotsAreScreenedToo() {
        val p = TextNorm.prepare("On Christmas Eve a family gathers")
        assertTrue(has(Holidays.withPlot(0, TextNorm.prepare("Quiet Show"), false, p), Holidays.CHRISTMAS))
        assertEquals(0, Holidays.withPlot(0, TextNorm.prepare("Quiet Show"), true, p))                                   // adult category
        assertEquals(0, Holidays.withPlot(0, TextNorm.prepare("Roman Holiday"), false, TextNorm.prepare("Christmas Eve")) and Holidays.bit(Holidays.CHRISTMAS))
    }
}
