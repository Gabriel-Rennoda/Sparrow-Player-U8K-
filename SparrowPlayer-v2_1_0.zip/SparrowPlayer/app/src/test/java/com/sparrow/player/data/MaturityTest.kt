package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class MaturityTest {
    private fun ok(name: String, cat: String = "", genre: String = "", known: String = "", series: Boolean = false) =
        Maturity.familyOk(known, name, cat, TextNorm.prepare(name), TextNorm.prepare("$genre $cat"), series)

    @Test fun knownRatingsDecide() {
        for (r in listOf("TV-Y", "TV-G", "G", "TV-PG", "PG", "PG-13")) assertTrue(r, ok("X", known = r))
        for (r in listOf("TV-14", "TV-MA", "R", "NC-17")) assertFalse(r, ok("X", "Kids", "Kids", known = r))
    }

    @Test fun ageNumbersAndTextNormalise() {
        assertEquals("TV-MA", Maturity.normalize("18+")); assertEquals("R", Maturity.normalize("16")); assertEquals("TV-14", Maturity.normalize("14"))
        assertEquals("PG-13", Maturity.normalize("13")); assertEquals("TV-PG", Maturity.normalize("10")); assertEquals("", Maturity.normalize("0"))
        assertEquals("PG-13", Maturity.normalize("Rated PG-13")); assertEquals("", Maturity.normalize("Not Rated")); assertEquals("", Maturity.normalize(""))
    }

    @Test fun adultCartoonsAreOutKidsShowsAreIn() {
        assertFalse(ok("Rick And Morty", "Animation", "Animation, Comedy", series = true))
        assertFalse(ok("Rick & Morty (2013)", "Kids", "Kids"))                                      // listed even when misfiled under Kids
        assertFalse(ok("BoJack Horseman", "Animation", "Animation, Drama", series = true))
        assertFalse(ok("Beavis And Butt-Head", "Animation", "Animation", series = true))
        assertFalse(ok("Anything [TV-MA]", "Kids", "Kids"))
        assertFalse(ok("Scary Toons", "Kids", "Animation, Horror"))
        assertTrue(ok("Bluey", "Kids", "Animation, Kids", series = true))
        assertTrue(ok("Paw Patrol", "Children", "", series = true))
        assertTrue(ok("Frozen", "Animation Movies", ""))                                            // film, only "animation": allowed
        assertFalse(ok("Unknown Cartoon", "Animation", "Animation, Comedy", series = true))         // series, only "animation": waits for a rating
    }

    @Test fun crimeNextToFamilyIsFineCrimeAloneIsNot() {
        assertTrue(ok("Despicable Me", "Kids", "Animation, Family, Comedy, Crime"))
        assertFalse(ok("Heat Wave", "Animation", "Animation, Crime"))
        assertFalse(ok("Dark Toon", "Kids", "Kids, Horror"))                                          // horror never
    }

    @Test fun knownChildrensTitlesPassEvenAsASeriesWithNoGenre() {
        assertTrue(ok("Bluey", "Animation", "", series = true)); assertTrue(ok("Peppa Pig (2004)", "Cartoons", "", series = true))
        assertFalse(ok("Rick And Morty", "Animation", "", series = true))
        assertTrue(Maturity.isKidsTitle(TextNorm.prepare("PAW Patrol: The Movie"))); assertFalse(Maturity.isKidsTitle(TextNorm.prepare("Up In Smoke")))
    }
}
