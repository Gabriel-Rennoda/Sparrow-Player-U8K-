package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class GenreRulesTest {
    private fun main(id: String) = Genres.mainOf(id)!!
    private fun p(s: String) = TextNorm.prepare(s)

    @Test fun titlePhrasesPutATitleIn() {
        assertEquals(1, GenreRules.verdict(main("horror"), p("The Conjuring 2"), p("")))
        assertEquals(1, GenreRules.verdict(main("action"), p("John Wick: Chapter 4"), p("NEW RELEASES")))
        assertEquals(1, GenreRules.verdict(main("sports"), p("Cinderella Man"), p("")))
        assertEquals(1, GenreRules.verdict(main("romance"), p("Falling In Love Again"), p("")))     // a word set: falling + love
        assertEquals(0, GenreRules.verdict(main("horror"), p("A Quiet Day"), p("")))
    }

    @Test fun screenOutWinsOverEverything() {
        assertEquals(-1, GenreRules.verdict(main("sports"), p("Boxing Day"), p("")))                 // not a sports film
        assertEquals(-1, GenreRules.verdict(main("sports"), p("Rocky Horror Picture Show"), p("")))
        assertEquals(-1, GenreRules.verdict(main("horror"), p("Scary Movie"), p("")))                // comedy
        assertEquals(-1, GenreRules.verdict(main("romance"), p("Love, Death & Robots"), p("")))
        assertEquals(-1, GenreRules.verdict(main("war"), p("Star Wars: A New Hope"), p("")))
        assertEquals(-1, GenreRules.verdict(main("documentaries"), p("Documentary Now"), p("")))
        assertEquals(-1, GenreRules.verdict(main("faith"), p("Christian Bale: Interview"), p("")))
        // the genre / category text can screen out too
        assertEquals(-1, GenreRules.verdict(main("westerns"), p("Some Film"), p("Western Europe")))
    }

    @Test fun theFastIndexGivesTheSameAnswerAsTheSlowReference() {
        val names = listOf("The Conjuring 2", "John Wick", "Cinderella Man", "Boxing Day", "Boxing Day Fight", "Scary Movie 3", "Love Death and Robots", "Star Wars",
            "Falling In Love", "Planet Earth II", "Rocky", "Rocky Horror Picture Show", "Brooklyn Nine-Nine", "Stand Up Guys", "Comedy Special Live", "Plain Title", "Western Front")
        for (n in names) {
            val np = p(n)
            for (m in Genres.MAIN) {
                val bit = GenreRules.indexOf(m.id).let { if (it in 0..30) 1 shl it else 0 }
                val out = (GenreRules.titleOutBits(np) and bit) != 0
                val inn = (GenreRules.titleInBits(np) and bit) != 0
                val fast = if (out) -1 else if (inn) 1 else 0
                assertEquals(n + " / " + m.id, GenreRules.verdict(m, np, ""), fast)
            }
        }
        // the genre / category text part is a separate mask
        val bit = 1 shl GenreRules.indexOf("westerns")
        assertTrue((GenreRules.genreTextOutBits(p("Western Europe")) and bit) != 0)
    }

    @Test fun descriptionSetsPutTitlesIn() {
        val drama = 1 shl GenreRules.indexOf("dramas")
        assertTrue((GenreRules.plotInBits(p("A film based on a true story of courage")) and drama) != 0)
        assertEquals(0, GenreRules.plotInBits(p("A quiet afternoon")))
        val sports = 1 shl GenreRules.indexOf("sports")
        assertTrue((GenreRules.plotOutBits(p("Boxing Day"), p("A cosy family evening")) and sports) != 0)      // outSets: boxing + day (name and description together)
    }

    @Test fun everyRuleIsInTextNormForm() {
        // a phrase with capitals, punctuation or double spaces would never match
        for ((id, r) in GenreRules.RULES) {
            assertNotNull(id, Genres.mainOf(id))
            val all = r.titleIn + r.out + r.titleInSets.flatten() + r.plotInSets.flatten() + r.outSets.flatten()
            for (w in all) assertEquals("$id: '$w'", p(w).trim(), w)
        }
    }

    @Test fun genrePageUsesTheTitleFiltersAndKeepsTheWrongOnesOut() {
        fun v(i: Int, name: String, cat: String = "1", genre: String = "") = VodLite("1:m:$i", cat, name, "http://p/$i.jpg", "7", "2015", i.toLong(), genre)
        val items = listOf(
            v(1, "The Conjuring"),                                   // only the category says nothing: the title phrase puts it in Horror
            v(2, "Scary Movie", genre = "Horror, Comedy"),          // the genre text says Horror, the screen-out says no
            v(3, "A Plain Film"),
            v(4, "Halloween Kills"),
            v(5, "Real Horror", genre = "Horror")
        )
        val c = VodCatalog.build(1, "movie", items, mapOf("1" to "New Releases"))
        val horror = Pages.genrePicks(c, Genres.mainOf("horror")!!, null, emptyMap()).map { it.uid }.toSet()
        assertEquals(setOf("1:m:1", "1:m:4", "1:m:5"), horror)
    }
}
