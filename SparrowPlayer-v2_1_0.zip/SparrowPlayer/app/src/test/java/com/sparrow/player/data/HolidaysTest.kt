package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class HolidaysTest {
    private fun d(y: Int, m: Int, day: Int) = Holidays.epochDay(y, m, day)
    private fun ids(l: List<Holidays.Dated>) = l.map { it.holiday.id }

    @Test fun civilRoundTrip() {
        for (day in listOf(0, 1, -1, 18000, 20000, 25000)) { val c = Holidays.civil(day); assertEquals(day, d(c[0], c[1], c[2])) }
        assertEquals(0, d(1970, 1, 1)); assertEquals(4, Holidays.weekday(0))                       // a Thursday
    }

    @Test fun easterKnownDates() {
        assertEquals(d(2025, 4, 20), Holidays.easter(2025)); assertEquals(d(2026, 4, 5), Holidays.easter(2026))
        assertEquals(d(2027, 3, 28), Holidays.easter(2027)); assertEquals(d(2030, 4, 21), Holidays.easter(2030))
    }

    @Test fun hanukkahKnownDates() {
        assertEquals(d(2024, 12, 26), Holidays.hanukkah(2024)); assertEquals(d(2025, 12, 15), Holidays.hanukkah(2025))
        assertEquals(d(2026, 12, 5), Holidays.hanukkah(2026)); assertEquals(d(2027, 12, 25), Holidays.hanukkah(2027))
        assertEquals(d(2028, 12, 13), Holidays.hanukkah(2028))
    }

    @Test fun movableHolidays() {
        assertEquals(d(2026, 11, 26), Holidays.dateOf(Holidays.THANKSGIVING, 2026))
        assertEquals(d(2026, 10, 12), Holidays.dateOf(Holidays.THANKSGIVING, 2026, canada = true))
        assertEquals(d(2026, 5, 10), Holidays.dateOf(Holidays.MOTHERS, 2026))
        assertEquals(d(2026, 6, 21), Holidays.dateOf(Holidays.FATHERS, 2026))
    }

    @Test fun rollingOrderStartsWithTheNextHoliday() {
        val o = Holidays.order(d(2026, 10, 1))
        assertEquals(listOf("halloween", "thanksgiving", "hanukkah", "christmas", "boxing", "newyear", "valentine", "patrick", "easter", "mothers", "fathers", "independence"), ids(o))
        assertTrue(o.none { it.recentlyPassed })
    }

    @Test fun passedHolidayStaysOneBelowTheNextForSevenDays() {
        // Halloween was 31 October. 7 November = 7 days later: still right below Thanksgiving.
        val o = Holidays.order(d(2026, 11, 7))
        assertEquals(listOf("thanksgiving", "halloween", "hanukkah", "christmas"), ids(o).take(4))
        assertTrue(o[1].recentlyPassed); assertEquals(d(2026, 10, 31), o[1].day)
        // 8 November: back to the normal sequence (a year away, so last)
        val later = Holidays.order(d(2026, 11, 8))
        assertEquals("thanksgiving", later[0].holiday.id); assertEquals("halloween", later.last().holiday.id)
        assertTrue(later.none { it.recentlyPassed })
    }

    @Test fun holidayOnTheDayItselfIsStillUpcomingAndFirst() {
        val o = Holidays.order(d(2026, 10, 31)); assertEquals("halloween", o[0].holiday.id); assertFalse(o[0].recentlyPassed)
        assertEquals(d(2026, 10, 31), o[0].day)
    }

    @Test fun yearWrapAndTwoRecentHolidays() {
        // 2 January 2027: New Year (1 Jan) and Christmas (25 Dec = 8 days ago, so not recent) ...
        val o = Holidays.order(d(2027, 1, 2))
        assertEquals("valentine", o[0].holiday.id); assertEquals("newyear", o[1].holiday.id); assertTrue(o[1].recentlyPassed)
        assertEquals("christmas", o.last().holiday.id)
        // 27 December 2026: Christmas passed 2 days ago, Hanukkah (5 Dec) long gone
        // (Boxing Day, 26 December, passed yesterday and sits right above Christmas)
        val x = Holidays.order(d(2026, 12, 27)); assertEquals(listOf("newyear", "boxing", "christmas"), ids(x).take(3))
    }

    @Test fun keywordMatching() {
        assertTrue(Holidays.matches(Holidays.CHRISTMAS, "A Christmas Story (1983)"))
        assertTrue(Holidays.matches(Holidays.CHRISTMAS, "EN | Home for XMAS"))
        assertTrue(Holidays.matches(Holidays.VALENTINE, "My Bloody Valentine's Day"))
        assertTrue(Holidays.matches(Holidays.PATRICK, "St. Patrick's Day Parade"))
        assertTrue(Holidays.matches(Holidays.MOTHERS, "Mother's Day"))
        assertTrue(Holidays.matches(Holidays.HANUKKAH, "Eight Crazy Nights - Chanukah"))
        assertFalse(Holidays.matches(Holidays.CHRISTMAS, "Chrismas Eve"))
        assertFalse(Holidays.matches(Holidays.EASTER, "Eastern Promises"))                    // whole words only
        assertFalse(Holidays.matches(Holidays.HALLOWEEN, "Caspers Mountain Hike"))
    }

    @Test fun boxingDayIsInButBoxingWithFightIsOut() {
        assertEquals(d(2026, 12, 26), Holidays.dateOf(Holidays.BOXING, 2026))
        val bit = Holidays.bit(Holidays.BOXING)
        fun hit(name: String) = Holidays.screen(0, TextNorm.prepare(name), false) and bit != 0
        assertTrue(hit("Boxing Day"))
        assertTrue(hit("A Boxing Day Surprise"))
        assertFalse(hit("Cinderella Man"))                         // a boxing film, not a Boxing Day one
        assertFalse(hit("Boxing Day Fight Night"))                 // \"boxing\" + \"fight\" = out
        assertFalse(hit("Boxing Day Heavyweight Champion"))
        // the description counts too: the name says Boxing Day, the story is a boxing match
        val withPlot = Holidays.withPlot(Holidays.screen(0, TextNorm.prepare("Boxing Day"), false), TextNorm.prepare("Boxing Day"), false, TextNorm.prepare("A boxing champion fights for the title"))
        assertEquals(0, withPlot and bit)
    }

    @Test fun wordSetsScreenTitlesIn() {
        assertTrue(Holidays.matches(Holidays.CHRISTMAS, "A Holiday Baking Championship"))      // \"holiday\" + \"baking\"
        assertTrue(Holidays.matches(Holidays.CHRISTMAS, "Winter Wonderland Wedding"))
        assertFalse(Holidays.matches(Holidays.CHRISTMAS, "Baking With Friends"))
        assertTrue(Holidays.matches(Holidays.EASTER, "The Great Egg Hunt"))
        // a set never fires on one word alone
        assertFalse(Holidays.matches(Holidays.EASTER, "Egg"))
    }
}
