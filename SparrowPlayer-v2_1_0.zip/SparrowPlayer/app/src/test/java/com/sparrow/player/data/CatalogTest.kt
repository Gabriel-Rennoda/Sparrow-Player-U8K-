package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class CatalogTest {
    private fun v(i: Int, name: String, cat: String = "1", genre: String = "", year: String = "2015", rating: String = "7", added: Long = i.toLong()) =
        VodLite("1:m:$i", cat, name, "http://p/$i.jpg", rating, year, added, genre)

    private val names = mapOf("1" to "Action", "2" to "Kids", "3" to "Animation", "4" to "Christmas Movies")

    private fun cat(items: List<VodLite>, type: String = "movie", plots: List<UidPlot> = emptyList()) = VodCatalog.build(1, type, items, names, plots)

    @Test fun lookupsOrdersAndCardItems() {
        val c = cat((1..50).map { v(it, "Film $it", cat = if (it % 2 == 0) "1" else "2", rating = (it % 10).toString()) })
        assertEquals(50, c.size); assertEquals("Film 7", c.lite("1:m:7")!!.name); assertNull(c.lite("nope"))
        assertEquals("1:m:50", c.recent(3).first().uid)                                        // newest first
        assertEquals(setOf("9"), c.topRated(5).map { it.rating }.toSet())                       // best rated first
        assertEquals(25, c.categorySize("1")); assertTrue(c.inCategory("1", 5).all { it.categoryId == "1" })
        val item = c.item(c.lite("1:m:7")!!)
        assertEquals("movie", item.type); assertEquals("7", item.remoteId); assertEquals("http://p/7.jpg", item.poster); assertEquals(1L, item.providerId)
        assertEquals(listOf("1:m:2", "1:m:3"), c.items(listOf("1:m:2", "x", "1:m:3")).map { it.uid })
    }

    @Test fun holidayTitlesAreFoundInNameCategoryAndDescription() {
        val items = listOf(
            v(1, "Elf", cat = "4"), v(2, "Home Alone"), v(3, "Die Hard"), v(4, "Quiet Show", genre = "Drama"), v(5, "The Santa Clause"), v(6, "Love Actually")
        )
        val c = cat(items, plots = listOf(UidPlot("1:m:4", "On Christmas Eve a family gathers"), UidPlot("1:m:3", "A cop in a tower. Pumpkin spice latte.")))
        val xmas = HomeRows.holidayPool(Holidays.CHRISTMAS, c.titles).map { it.uid }.toSet()
        assertEquals(setOf("1:m:1", "1:m:2", "1:m:4", "1:m:5", "1:m:6"), xmas)                    // category / title / description; Die Hard is not Christmas
        assertTrue(HomeRows.holidayPool(Holidays.HALLOWEEN, c.titles).isEmpty())                  // "pumpkin" alone does not count in a description
    }

    @Test fun seeAllPageHasAllTheHolidayTitles() {
        val items = (1..40).map { v(it, if (it <= 25) "Xmas Story $it" else "Plain $it", rating = (1 + it % 9).toString(), year = if (it % 5 == 0) "1985" else "2012") }
        val c = cat(items)
        val page = HomeRows.holiday(Holidays.CHRISTMAS, c.titles, RowCtx(0L, true, "Canada", "Sam"), emptyList()) { 0.0 }
        assertEquals(25, page.first { it.title == "What's Hot" }.uids.size)
        assertTrue(page.first { it.title == "Top Picks for Sam" }.uids.isNotEmpty())
    }

    @Test fun genrePageAndSubGenres() {
        val items = (1..12).map { v(it, "Fight $it", cat = "1", genre = "", rating = "8") } + (13..20).map { v(it, "Toon $it", cat = "2") }
        val c = cat(items)
        val action = Genres.mainOf("action")!!
        val rows = Pages.genre(c, action, null, emptyMap())
        assertEquals("Top Rated in Action & Adventure", rows[0].title); assertEquals("Recently Added in Action & Adventure", rows[1].title)
        assertTrue(rows.drop(2).none { it.title.startsWith("Action Comedies") })                    // sub-genres are not rows any more
        assertEquals("Action", rows[2].title)                                                       // the provider category inside the genre
        assertEquals(Pages.genreScope("action", 3), "genre:action#3"); assertEquals("action" to 3, Pages.parseGenreScope("genre:action#3")); assertEquals("action" to null, Pages.parseGenreScope("genre:action"))
    }

    @Test fun subGenresAreCarouselsInsideTheGenrePage() {
        val items = (1..5).map { v(it, "Funny Fight $it", cat = "1", genre = "Action Comedy", rating = "7") } +
            (6..9).map { v(it, "Kick $it", cat = "1", genre = "Martial Arts", rating = "6") } + (10..11).map { v(it, "Lonely $it", cat = "1", genre = "Action Thriller") }
        val rows = Pages.genre(cat(items), Genres.mainOf("action")!!, null, emptyMap())
        val titles = rows.map { it.title }
        assertEquals(listOf("Top Rated in Action & Adventure", "Recently Added in Action & Adventure"), titles.take(2))
        assertTrue("Action Comedies" in titles); assertTrue("Martial Arts" in titles)
        assertFalse("Action Thrillers" in titles)                                                  // only 2 titles: under MIN_SUB
        assertEquals(5, rows.first { it.title == "Action Comedies" }.uids.size)
        assertTrue(titles.indexOf("Action Comedies") < titles.indexOf("Martial Arts"))             // the fullest carousel first
    }

    @Test fun kidsAndFamilyAreSeparatePagesAndFamilyFilmsTaggedCrimeStay() {
        val items = (1..4).map { v(it, "Toon Pal $it", cat = "2", genre = "Animation, Family, Comedy, Crime") } +
            (5..8).map { v(it, "Disney Tale $it", cat = "2", genre = "Disney") } + listOf(v(9, "Bluey", cat = "9", genre = ""))
        val c = VodCatalog.build(1, "series", items, names + ("9" to "Misc"), emptyList())
        val fam = Pages.genre(c, Genres.mainOf("family")!!, null, emptyMap())
        val famAll = fam.flatMap { it.uids }.toSet()
        assertTrue((1..8).all { "1:m:$it" in famAll })                                             // "Crime" next to "Family" no longer drops a film
        assertTrue(fam.any { it.title == "Disney" })
        val kids = Pages.genre(c, Genres.mainOf("kids")!!, null, emptyMap()).flatMap { it.uids }.toSet()
        assertTrue("1:m:9" in kids)                                                                // a well-known children's title with no genre text
        assertTrue((1..4).all { "1:m:$it" in kids })                                               // the provider's Kids category
    }

    @Test fun childrensTitlesStayInKidsAndKidsHasItsOwnGenreRows() {
        val items = (1..4).map { v(it, "Toon Pal $it", cat = "2", genre = "Animation, Action, Adventure") } + (5..8).map { v(it, "Spy Guy $it", cat = "1") }
        val c = cat(items)
        val action = Pages.genre(c, Genres.mainOf("action")!!, null, emptyMap()).flatMap { it.uids }.toSet()
        assertTrue((5..8).all { "1:m:$it" in action }); assertTrue((1..4).none { "1:m:$it" in action })   // not in the grown-up Action & Adventure
        val kidsRows = Pages.genre(c, Genres.mainOf("kids")!!, null, emptyMap())
        assertEquals(4, kidsRows.first { it.title == "Action & Adventure" }.uids.size)                      // but Kids has its own Action & Adventure row
    }

    @Test fun aFilmListedInTwoCategoriesIsOneCardInBothGenresAndHasACombinedRow() {
        val nm = mapOf("1" to "Action", "5" to "Comedy")
        val items = (1..3).flatMap { n -> listOf(v(n, "Big Laughs Fight $n", cat = "1"), v(n + 10, "Big Laughs Fight $n", cat = "5")) }
        val c = VodCatalog.build(1, "movie", items, nm, emptyList())
        val action = Pages.genre(c, Genres.mainOf("action")!!, null, emptyMap())
        val comedy = Pages.genre(c, Genres.mainOf("comedies")!!, null, emptyMap())
        assertEquals(3, action.first().uids.size); assertEquals(3, comedy.first().uids.size)              // 6 entries, 3 films, each in BOTH genres
        assertEquals(3, action.first { it.title == "Action Comedies" }.uids.size)
        assertEquals(3, comedy.first { it.title == "Action Comedies" }.uids.size)
    }

    @Test fun standUpComedyIsFoundByNameAndIsAlsoComedy() {
        val items = (1..4).map { v(it, "Dave Live: Stand-Up Special $it", cat = "1", year = "20${10 + it}") }
        val c = cat(items)
        assertEquals(4, Pages.genre(c, Genres.mainOf("standup")!!, null, emptyMap()).first().uids.size)
        assertEquals(4, Pages.genre(c, Genres.mainOf("comedies")!!, null, emptyMap()).first().uids.size)
    }

    @Test fun childrenAndFamilyKeepsAdultCartoonsOut() {
        val kidsCat = (1..4).map { v(it, "Bluey $it", cat = "2", genre = "Animation, Kids") }
        val rick = v(10, "Rick And Morty", cat = "3", genre = "Animation, Comedy, Sci-Fi")
        val adultCat = v(11, "Some Show", cat = "3", genre = "Adult Animation")
        val bojack = v(12, "BoJack Horseman", cat = "2", genre = "Animation, Kids")                 // even misfiled under Kids
        val frozen = v(13, "Frozen", cat = "3", genre = "")
        val tvma = v(14, "Show [TV-MA]", cat = "2", genre = "Kids")
        val family = Genres.mainOf("family")!!
        val series = cat(kidsCat + listOf(rick, adultCat, bojack, tvma), type = "series")
        val s = Pages.genre(series, family, null, emptyMap()).flatMap { it.uids }.toSet()
        assertTrue(s.containsAll(kidsCat.map { it.uid }))
        assertTrue("1:m:10" !in s && "1:m:11" !in s && "1:m:12" !in s && "1:m:14" !in s)
        // a film that is only "animation" is let through, a series that is only "animation" waits for a known rating
        assertTrue("1:m:13" in Pages.genre(cat(listOf(frozen) + kidsCat), family, null, emptyMap()).flatMap { it.uids })
        assertTrue("1:m:10" !in Pages.genre(cat(listOf(rick) + kidsCat, type = "series"), family, null, emptyMap()).flatMap { it.uids })
        val known = mapOf("1:m:10" to "PG")                                                          // the panel said PG: trusted
        assertTrue("1:m:10" in Pages.genre(cat(listOf(rick) + kidsCat, type = "series"), family, null, known).flatMap { it.uids })
        assertTrue("1:m:1" !in Pages.genre(cat(kidsCat), family, null, mapOf("1:m:1" to "TV-14")).flatMap { it.uids })
    }

    @Test fun holidayListSkipsHolidaysWithoutTitles() {
        val c = cat(listOf(v(1, "Merry Christmas Movie"), v(2, "Plain")))
        val today = Holidays.epochDay(2026, 11, 9)
        val l = Pages.holidayList(c, today, false, today * 86_400_000L)
        assertEquals(listOf("christmas"), l.map { it.first.holiday.id }); assertEquals(listOf("1:m:1"), l[0].second)
    }
}
