package com.sparrow.player.ui.player

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import java.util.Locale
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Repository
import com.sparrow.player.data.Resume
import com.sparrow.player.databinding.ActivityPlayerBinding
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.fmtTime
import com.sparrow.player.util.dp
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * Full-screen player.
 *  Live:  Up/Down or CH+/CH- zap, 0-9 jump to channel number, OK = info, hold OK = favourite, Menu = audio/subtitle/video tracks.
 *  VOD:   standard Media3 transport controls, position is remembered and resumed.
 */
class PlayerActivity : FragmentActivity() {
    private lateinit var b: ActivityPlayerBinding
    private lateinit var repo: Repository
    private var player: ExoPlayer? = null
    private var live = false
    private var channels: List<Channel> = emptyList()
    private var index = 0
    private var posKey: String? = null
    private var retries = 0
    private var stopped = false
    private var finished = false
    private var numBuf = ""
    private var vodUid = ""
    private var historyRecorded = false
    private var revealedAt = 0L
    private val gate = FirstPressGate()
    private val awake by lazy { PlaybackSignal(this) }
    private val handler = Handler(Looper.getMainLooper())

    private val hideInfo = Runnable { b.infoBar.visibility = View.GONE; b.gearBtn.visibility = View.GONE }
    private val commitNumber = Runnable {
        val n = numBuf.toIntOrNull(); numBuf = ""; b.numberText.visibility = View.GONE
        val i = channels.indexOfFirst { it.number == n }
        if (i >= 0) playIndex(i) else Toast.makeText(this, "No channel $n", Toast.LENGTH_SHORT).show()
    }
    // ---- Next Episode ---------------------------------------------------------------------------------------------
    private class NextEp(val id: String, val url: String, val title: String)
    private var nextEp: NextEp? = null
    private var nextShown = false
    private val hideNext = Runnable { b.nextBtn.visibility = View.GONE }

    /** The episode after this one (series only). Looked up once, in the background. */
    private fun loadNextEpisode() {
        val key = posKey ?: return
        if (live || !key.startsWith("ep:") || vodUid.isBlank()) return
        lifecycleScope.launch {
            try {
                val series = repo.dao.vod(vodUid) ?: return@launch
                val eps = repo.seriesEpisodes(series).sortedWith(compareBy({ it.season }, { it.num }))
                val i = eps.indexOfFirst { "ep:${it.id}" == key }
                val n = eps.getOrNull(i + 1) ?: return@launch
                nextEp = NextEp(n.id, repo.episodeUrl(n), "${series.name} · S${n.season}E${n.num}  ${n.title}")
            } catch (e: Exception) { /* no next episode button; playback is unaffected */ }
        }
    }

    /**
     * Credits are not marked in the stream, so "the beginning of the credits" is taken as the last 3 % of the runtime (never less than 30 s
     * or more than 2 min). The button shows for 15 seconds, once per episode (again if the viewer seeks well back and returns), and also
     * appears when the episode ends.
     */
    private fun checkNext() {
        val p = player ?: return
        if (live || nextEp == null || p.duration <= 0) return
        val remaining = p.duration - p.currentPosition
        val lead = (p.duration * 0.03).toLong().coerceIn(30_000L, 120_000L)
        if (remaining > lead + 8_000) { nextShown = false; return }                       // seeked back: it may show again later
        if (!nextShown && (remaining <= lead || p.playbackState == Player.STATE_ENDED)) showNext()
    }

    private fun showNext() {
        nextShown = true
        b.nextBtn.visibility = View.VISIBLE
        b.nextBtn.requestFocus()
        handler.removeCallbacks(hideNext); handler.postDelayed(hideNext, 15_000)
    }

    private fun playNext() {
        val n = nextEp ?: return
        handler.removeCallbacks(hideNext); b.nextBtn.visibility = View.GONE
        posKey?.let { repo.prefs.setPosition(it, Resume.FINISHED) }          // this episode is done
        recordHistory(); finished = true
        repo.prefs.setLastEpisode(vodUid, n.id)
        startActivity(vod(this, n.url, n.title, "ep:${n.id}", vodUid))
        finish()
    }

    /** Media3's own settings / CC buttons (movies and series). Their clicks open OUR menu, so there is only one settings menu. */
    private var builtInGear: View? = null

    /** The gear is on screen exactly while the player controls are, and never longer (focus does not keep it alive). */
    private val gearTick = object : Runnable {
        override fun run() { syncGear(); checkNext(); handler.postDelayed(this, 250) }
    }

    private fun syncGear() {
        val controlsShown = if (live) b.infoBar.visibility == View.VISIBLE else b.playerView.isControllerFullyVisible
        val useOverlay = live || builtInGear == null          // movies / series show Media3's own gear unless it could not be found
        val v = if (controlsShown && useOverlay) View.VISIBLE else View.GONE
        if (b.gearBtn.visibility != v) b.gearBtn.visibility = v
    }

    private fun hookBuiltInButtons() {
        fun find(name: String): View? {
            val id = resources.getIdentifier(name, "id", packageName)
            return if (id != 0) b.playerView.findViewById(id) else null
        }
        builtInGear = find("exo_settings")
        builtInGear?.setOnClickListener { showTrackMenu() }
        find("exo_subtitle")?.setOnClickListener { chooseTrack(C.TRACK_TYPE_TEXT, "Subtitles") }
    }

    private val savePos = object : Runnable {
        override fun run() { savePosition(); handler.postDelayed(this, 5_000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        com.sparrow.player.ui.MainActivity.stopMini()          // the mini player (kept alive behind Search / Settings) must not play under this screen
        super.onCreate(savedInstanceState)
        b = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(b.root)
        Theme.applyTree(b.root)
        repo = applicationContext.repo
        live = intent.getBooleanExtra("live", false)
        b.gearBtn.isFocusable = !live                      // live: a hint only (OK opens the menu); movies / series fallback: reachable with Up
        b.gearBtn.setOnClickListener { showTrackMenu() }
        b.nextBtn.setOnClickListener { playNext() }
        b.infoHint.visibility = if (live) View.VISIBLE else View.GONE
        if (!live) {
            hookBuiltInButtons()
            if (builtInGear == null) (b.gearBtn.layoutParams as FrameLayout.LayoutParams).bottomMargin = dp(120)   // fallback: above Media3's bar
        }
        handler.post(gearTick)

        val p = PlayerFactory.create(this)
        player = p
        b.playerView.player = p
        b.playerView.useController = !live
        b.playerView.controllerShowTimeoutMs = FirstPressGate.SHOW_MS.toInt()   // controls vanish after 3 s without a key
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (retries++ < 5) {
                    showError("Stream error – retrying ($retries/5)…")
                    handler.postDelayed({ if (live) playIndex(index) else player?.prepare() }, 2000)
                } else showError("Channel unavailable (${error.errorCodeName})")
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { awake.set(isPlaying, intent.getStringExtra("title") ?: "") }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { retries = 0; b.errorText.visibility = View.GONE }
                if (state == Player.STATE_ENDED && !live) { finished = true; posKey?.let { repo.prefs.setPosition(it, Resume.FINISHED) }; recordHistory() }
            }
        })

        if (live) {
            lifecycleScope.launch {
                val prov = repo.activeProvider() ?: return@launch finish()
                val uid = intent.getStringExtra("uid")
                channels = repo.channelsFor(prov.id, intent.getStringExtra("scope") ?: Repository.SCOPE_ALL)
                // The channel may not be in the group that was open (e.g. it was tuned in another group): fall back to all.
                if (channels.none { it.uid == uid }) channels = repo.channelsFor(prov.id, Repository.SCOPE_ALL, includeHidden = true)
                index = channels.indexOfFirst { it.uid == uid }.coerceAtLeast(0)
                if (channels.isEmpty()) finish() else playIndex(index)
            }
        } else {
            posKey = intent.getStringExtra("key")
            vodUid = intent.getStringExtra("vodUid") ?: ""
            loadNextEpisode()
            // Resume 30 seconds before where the user stopped last time.
            val start = if (!repo.prefs.resumeEnabled) 0L else Resume.resumeAt(posKey?.let { repo.prefs.position(it) } ?: 0L)
            val item = MediaItem.Builder().setUri(intent.getStringExtra("url")!!)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(intent.getStringExtra("title")).build()).build()
            p.setMediaItem(item, if (start > 0) start else C.TIME_UNSET)
            p.prepare(); p.playWhenReady = true
            handler.postDelayed(savePos, 5_000)
        }
    }

    // ---- Live ------------------------------------------------------------------------------
    private fun playIndex(i: Int) {
        if (channels.isEmpty()) return
        index = (i + channels.size) % channels.size
        val c = channels[index]
        repo.prefs.lastChannel = c.uid
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(repo.liveUrl(c)))
        p.prepare(); p.playWhenReady = true
        showInfo()
    }

    private fun zap(delta: Int) { retries = 0; b.errorText.visibility = View.GONE; playIndex(index + delta) }

    private fun showInfo() {
        if (!live || channels.isEmpty()) return
        val c = channels[index]
        b.infoChannel.text = (if (c.isFavorite) "★ " else "") + (if (repo.prefs.showNumbers) "${c.number}  " else "") + c.name
        b.infoNow.text = ""; b.infoNext.text = ""; b.infoProgress.progress = 0
        b.infoBar.visibility = View.VISIBLE
        syncGear()
        handler.removeCallbacks(hideInfo); handler.postDelayed(hideInfo, FirstPressGate.SHOW_MS)
        if (c.epgId.isBlank()) return
        lifecycleScope.launch {
            val now = System.currentTimeMillis()
            val l = repo.dao.nowNext(c.providerId, c.epgId, now)
            val cur = l.firstOrNull()?.takeIf { it.start <= now }
            val next = if (cur != null) l.getOrNull(1) else l.firstOrNull()
            if (channels.getOrNull(index)?.uid != c.uid) return@launch
            b.infoNow.text = cur?.let { "${fmtTime(it.start)}–${fmtTime(it.stop)}  ${it.title}" } ?: ""
            b.infoProgress.progress = cur?.let { ((now - it.start) * 100 / (it.stop - it.start).coerceAtLeast(1)).toInt() } ?: 0
            b.infoNext.text = next?.let { "Next ${fmtTime(it.start)}  ${it.title}" } ?: ""
        }
    }

    private fun toggleFavorite() {
        val c = channels.getOrNull(index) ?: return
        lifecycleScope.launch {
            val nv = !c.isFavorite
            repo.dao.setFavorite(c.uid, nv)
            channels = channels.toMutableList().also { it[index] = c.copy(isFavorite = nv) }
            Toast.makeText(this@PlayerActivity, if (nv) "Added to favourites" else "Removed from favourites", Toast.LENGTH_SHORT).show()
            showInfo()
        }
    }

    private fun digit(d: Int) {
        if (numBuf.length >= 5) numBuf = ""
        numBuf += d
        b.numberText.text = numBuf; b.numberText.visibility = View.VISIBLE
        handler.removeCallbacks(commitNumber); handler.postDelayed(commitNumber, 1800)
    }

    private fun showError(msg: String) { b.errorText.text = msg; b.errorText.visibility = View.VISIBLE }

    // ---- Keys ------------------------------------------------------------------------------
    /** Live: the info bar. Movies / series: the Media3 transport controls. */
    private fun controlsVisible(): Boolean =
        if (live) b.infoBar.visibility == View.VISIBLE
        else b.playerView.isControllerFullyVisible || SystemClock.uptimeMillis() - revealedAt < 600

    private fun revealControls() {
        revealedAt = SystemClock.uptimeMillis()
        if (live) showInfo() else b.playerView.showController()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        // while "Next Episode" is on screen, OK / Enter presses it (no waking-the-controls first press)
        if (b.nextBtn.visibility == View.VISIBLE && (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER)) {
            if (event.action == KeyEvent.ACTION_UP) playNext()
            return true
        }
        if (FirstPressGate.isGated(code) && (event.action == KeyEvent.ACTION_DOWN || event.action == KeyEvent.ACTION_UP)) {
            val down = event.action == KeyEvent.ACTION_DOWN
            if (gate.swallow(code, down, event.repeatCount, controlsVisible())) {
                if (down && event.repeatCount == 0) revealControls()     // 1st press: only wake the controls
                return true
            }
        }
        if (!live && !b.gearBtn.hasFocus() && b.playerView.dispatchKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (live) when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(+1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> { event.startTracking(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_INFO -> { showInfo(); return true }
            KeyEvent.KEYCODE_MENU -> { showTrackMenu(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { player?.let { it.playWhenReady = !it.playWhenReady }; return true }
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> { digit(keyCode - KeyEvent.KEYCODE_0); return true }
        } else if (keyCode == KeyEvent.KEYCODE_MENU) { showTrackMenu(); return true }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (live && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) &&
            event.isTracking && !event.isCanceled) { showTrackMenu(); return true }     // 2nd OK (bar showing): audio / subtitles
        return super.onKeyUp(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (live && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) { toggleFavorite(); return true }
        return super.onKeyLongPress(keyCode, event)
    }

    // ---- Tracks (own pop-up: Media3's TrackSelectionDialogBuilder needs an AppCompat theme) ---
    private fun showTrackMenu() {
        val p = player ?: return
        fun current(type: Int): String {
            val g = p.currentTracks.groups.firstOrNull { it.type == type && it.isSelected } ?: return if (type == C.TRACK_TYPE_TEXT) "Off" else "Automatic"
            for (i in 0 until g.length) if (g.isTrackSelected(i)) return describe(g.getTrackFormat(i), type)
            return "Automatic"
        }
        val pop = Popup(this, "Audio And Subtitles", intent.getStringExtra("title") ?: "")
        pop.row("Audio", current(C.TRACK_TYPE_AUDIO)) { chooseTrack(C.TRACK_TYPE_AUDIO, "Audio") }
        pop.row("Subtitles", current(C.TRACK_TYPE_TEXT)) { chooseTrack(C.TRACK_TYPE_TEXT, "Subtitles") }
        pop.row("Video Quality") { chooseTrack(C.TRACK_TYPE_VIDEO, "Video Quality") }
        pop.show()
    }

    private fun langName(code: String?): String? {
        if (code.isNullOrBlank() || code == "und") return null
        val n = Locale.forLanguageTag(code).getDisplayLanguage(Locale.ENGLISH)
        return if (n.isBlank()) code.uppercase() else n
    }

    private fun describe(f: Format, type: Int): String {
        val parts = ArrayList<String>()
        val lang = langName(f.language)
        f.label?.takeIf { it.isNotBlank() }?.let { parts += it }
        if (lang != null && parts.none { it.contains(lang, ignoreCase = true) }) parts += lang
        when (type) {
            C.TRACK_TYPE_AUDIO -> {
                when (f.channelCount) { -1, 0 -> Unit; 1 -> parts += "Mono"; 2 -> parts += "Stereo"; 6 -> parts += "5.1"; 8 -> parts += "7.1"; else -> parts += "${f.channelCount}ch" }
                f.sampleMimeType?.substringAfter('/')?.uppercase()?.let { parts += it }
            }
            C.TRACK_TYPE_VIDEO -> if (f.height > 0) parts += "${f.height}p"
        }
        return parts.joinToString(" · ").ifBlank { "Track" }
    }

    private fun chooseTrack(type: Int, title: String) {
        val p = player ?: return
        val entries = ArrayList<Pair<Tracks.Group, Int>>()
        p.currentTracks.groups.filter { it.type == type }.forEach { g ->
            for (i in 0 until g.length) if (g.isTrackSupported(i)) entries += g to i
        }
        if (entries.isEmpty()) { Toast.makeText(this, "No ${title.lowercase()} tracks in this stream", Toast.LENGTH_SHORT).show(); return }
        val params0 = p.trackSelectionParameters
        val overridden = params0.overrides.keys.any { it.type == type }
        val pop = Popup(this, title, if (entries.size > 1) "${entries.size} Available" else "Only One Available")
        // Off (subtitles) / Automatic (audio, video): hand the choice back to the player
        val autoSelected = if (type == C.TRACK_TYPE_TEXT) false else !overridden
        if (type == C.TRACK_TYPE_TEXT) pop.row("Off", if (params0.disabledTrackTypes.contains(type)) "✓" else "") {
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(type, true).build()
        } else pop.row("Automatic", if (autoSelected) "✓" else "") {
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().clearOverridesOfType(type).build()
        }
        for ((g, i) in entries) {
            val on = g.isTrackSelected(i) && !params0.disabledTrackTypes.contains(type) && (type == C.TRACK_TYPE_TEXT || overridden)
            pop.row(describe(g.getTrackFormat(i), type), if (on) "✓" else "") {
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(type, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
            }
        }
        pop.show()
    }

    // ---- Lifecycle -------------------------------------------------------------------------
    /** Counts as "watched" (history / recommendations) once 40 % was played or the end was reached (see Resume.countsAsWatched). */
    private fun recordHistory() {
        if (historyRecorded || live || vodUid.isBlank()) return
        historyRecorded = true
        repo.prefs.recordWatch(vodUid)
    }

    private fun savePosition() {
        val p = player ?: return; val k = posKey ?: return
        if (live || finished || p.duration <= 0 || p.playbackState == Player.STATE_IDLE) return
        if (Resume.countsAsWatched(p.currentPosition, p.duration)) recordHistory()
        repo.prefs.setDuration(k, p.duration)
        repo.prefs.setPosition(k, Resume.toStore(p.currentPosition, p.duration))
    }

    override fun onStop() {
        super.onStop()
        stopped = true
        savePosition()
        player?.pause()
    }

    override fun onStart() {
        super.onStart()
        if (stopped) {
            stopped = false
            if (live) playIndex(index) else player?.play()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        savePosition()
        b.playerView.player = null
        player?.release(); player = null
        awake.release()
        super.onDestroy()
    }

    companion object {
        fun live(ctx: Context, uid: String, scope: String) = Intent(ctx, PlayerActivity::class.java)
            .putExtra("live", true).putExtra("uid", uid).putExtra("scope", scope)

        fun vod(ctx: Context, url: String, title: String, key: String, vodUid: String = "") = Intent(ctx, PlayerActivity::class.java)
            .putExtra("live", false).putExtra("url", url).putExtra("title", title).putExtra("key", key).putExtra("vodUid", vodUid)
    }
}
