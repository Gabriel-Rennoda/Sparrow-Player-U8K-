package com.sparrow.player.data

/**
 * "The Holidays" group of Movies and Series: which holidays exist, when they fall, in which order their rows are shown and which
 * titles belong to each. Pure Kotlin (no java.time: the app supports Android 7), unit tested against known dates
 * (Easter 2026 = 5 April, Hanukkah 2026 = 5 December, US Thanksgiving 2026 = 26 November ...).
 *
 * Dates are "epoch days" (days since 1970-01-01), so they are easy to compare and subtract.
 */
object Holidays {
    /**
     * One holiday and the word lists that screen titles IN and OUT (all in [TextNorm] form: lower case, punctuation = one space):
     *  - [keywords]      screen IN: whole words / phrases that put a title here when they are in its NAME, its category / genre, or (series,
     *                    remembered plots) its description. Ambiguous ones listed in [AMBIGUOUS_IN_PLOT] are ignored in descriptions.
     *  - [categoryWords] screen IN, but only from the category / genre text ("Holiday Movies", "Seasonal"): too general to trust in a name.
     *  - [exclude]       screen OUT: if the NAME contains one of these the title is NOT this holiday's, whatever else matched
     *                    ("Roman Holiday", "Santa Fe", "Easter Island").
     *  - [keywordSets]   screen IN by SETS of words: a title / category / description that has ALL the words of one set (in any order, not
     *                    necessarily next to each other) belongs here ("holiday" + "baking").
     *  - [excludeSets]   screen OUT by SETS of words: if the name (or the description) has ALL the words of one set the title is NOT this holiday's.
     *                    "boxing day" is in, but "boxing" together with "fight" is out (Cinderella Man is a boxing film, not a Boxing Day one).
     * Words that screen a title out of EVERY holiday (adult material) are in [ADULT_CATEGORY] / [ADULT_ANYWHERE].
     */
    class Holiday(val id: String, val name: String, val keywords: List<String>, val categoryWords: List<String> = emptyList(), val exclude: List<String> = emptyList(),
                  val keywordSets: List<List<String>> = emptyList(), val excludeSets: List<List<String>> = emptyList())

    /** [day] = the date this holiday is next on (or, for [recentlyPassed], the date it was on a few days ago). */
    class Dated(val holiday: Holiday, val day: Int, val recentlyPassed: Boolean)

    val NEW_YEAR = Holiday("newyear", "New Year's Day",
        keywords = listOf("new year", "new years", "new year s", "new years eve", "new year s eve", "new year s day", "happy new year", "nye", "auld lang syne"),
        categoryWords = listOf("new year"),
        exclude = listOf("new year s evil"),
        keywordSets = listOf(listOf("countdown", "midnight")))
    val VALENTINE = Holiday("valentine", "Valentine's Day",
        keywords = listOf("valentine", "valentines", "valentine s", "galentine", "galentines", "galentine s", "cupid", "be my valentine"),
        categoryWords = listOf("valentine"),
        exclude = listOf("valentine road"))
    val PATRICK = Holiday("patrick", "St. Patrick's Day",
        keywords = listOf("st patrick", "st patricks", "st patrick s", "saint patrick", "saint patricks", "saint patrick s", "patricks day", "patrick s day", "leprechaun", "shamrock", "luck of the irish"),
        exclude = listOf("leprechaun origins", "leprechaun returns", "leprechaun in the hood", "leprechaun back 2 tha hood"))
    val EASTER = Holiday("easter", "Easter",
        keywords = listOf("easter", "peter cottontail", "easter bunny", "easter parade", "easter egg hunt"),
        exclude = listOf("easter island", "easter rising", "easter eggs", "easter sunday"),
        keywordSets = listOf(listOf("egg", "hunt"), listOf("bunny", "basket")))
    val MOTHERS = Holiday("mothers", "Mother's Day",
        keywords = listOf("mothers day", "mother s day", "happy mother s day"))
    val FATHERS = Holiday("fathers", "Father's Day",
        keywords = listOf("fathers day", "father s day", "happy father s day"))
    val INDEPENDENCE = Holiday("independence", "Independence Day",
        keywords = listOf("independence day", "fourth of july", "4th of july", "july 4th", "july fourth", "yankee doodle dandy"),
        keywordSets = listOf(listOf("july", "4th"), listOf("fourth", "july")))
    val HALLOWEEN = Holiday("halloween", "Halloween",
        keywords = listOf("halloween", "halloweentown", "trick or treat", "trick r treat", "hocus pocus", "pumpkin", "spooky", "haunted house", "addams family", "casper", "goosebumps",
            "nightmare before christmas", "monster house", "great pumpkin", "beetlejuice", "coraline", "paranorman", "hotel transylvania"),
        categoryWords = listOf("spooky season", "fright night"),
        exclude = listOf("pumpkin pie", "casper wyoming", "casper meadow"),
        keywordSets = listOf(listOf("spooky", "night"), listOf("monster", "mash")))
    val THANKSGIVING = Holiday("thanksgiving", "Thanksgiving",
        keywords = listOf("thanksgiving", "turkey day", "friendsgiving", "planes trains and automobiles"),
        categoryWords = listOf("thanksgiving"),
        keywordSets = listOf(listOf("turkey", "dinner")))
    val HANUKKAH = Holiday("hanukkah", "Hanukkah",
        keywords = listOf("hanukkah", "chanukah", "festival of lights", "menorah", "eight crazy nights", "8 crazy nights", "hebrew hammer", "dreidel"))
    val CHRISTMAS = Holiday("christmas", "Christmas",
        keywords = listOf("christmas", "christmases", "christmastime", "xmas", "x mas", "santa", "santa claus", "santa clause", "santa s", "noel", "grinch", "north pole", "nutcracker", "rudolph", "jingle",
            "frosty", "polar express", "krampus", "scrooge", "yule", "yuletide", "reindeer", "mistletoe", "snowman", "sleigh", "tinsel", "home alone", "wonderful life", "34th street", "love actually",
            "elf on the shelf", "elf", "the holiday", "holiday inn", "holiday in", "holiday special", "holiday season", "holiday spirit", "holiday heist", "white christmas", "bad santa", "fred claus",
            "arthur christmas", "klaus", "nativity", "carol of the bells", "deck the halls", "holidate", "festive"),
        categoryWords = listOf("holiday", "holidays", "seasonal", "winter holidays", "holiday movies", "holiday specials"),
        exclude = listOf("roman holiday", "holiday camp", "holiday road trip", "holidays in the sun", "santa fe", "santa barbara", "santa monica", "santa cruz", "santa clarita", "santa clara",
            "santa ana", "santa maria", "santa rosa", "santa paula", "santa rita", "santa sangre", "santa muerte", "santa ines", "santa marta", "santa lucia", "klaus kinski", "elf quest"),
        keywordSets = listOf(listOf("holiday", "romance"), listOf("holiday", "baking"), listOf("holiday", "cheer"), listOf("holiday", "wedding"), listOf("holiday", "reunion"), listOf("winter", "wonderland")))

    val BOXING = Holiday("boxing", "Boxing Day",
        keywords = listOf("boxing day", "boxing day sale", "boxing day sales"),
        excludeSets = listOf(listOf("boxing", "fight"), listOf("boxing", "fighter"), listOf("boxing", "champion"), listOf("boxing", "ring"), listOf("boxing", "heavyweight"),
            listOf("boxing", "knockout"), listOf("boxing", "match"), listOf("boxing", "gym"), listOf("cinderella", "man")))

    val ALL: List<Holiday> = listOf(NEW_YEAR, VALENTINE, PATRICK, EASTER, MOTHERS, FATHERS, INDEPENDENCE, HALLOWEEN, THANKSGIVING, HANUKKAH, CHRISTMAS, BOXING)

    /** Days a holiday that has just passed stays directly below the next upcoming one. */
    const val LINGER_DAYS = 7

    // ---- calendar maths ---------------------------------------------------------------------------------------------
    fun epochDay(y: Int, m: Int, d: Int): Int {
        val yy = if (m <= 2) y - 1 else y
        val era = (if (yy >= 0) yy else yy - 399) / 400
        val yoe = yy - era * 400
        val doy = (153 * (m + (if (m > 2) -3 else 9)) + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097 + doe - 719468
    }

    /** (year, month, day) of an epoch day. */
    fun civil(day: Int): IntArray {
        val z = day + 719468
        val era = (if (z >= 0) z else z - 146096) / 146097
        val doe = z - era * 146097
        val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
        val y = yoe + era * 400
        val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
        val mp = (5 * doy + 2) / 153
        val d = doy - (153 * mp + 2) / 5 + 1
        val m = mp + (if (mp < 10) 3 else -9)
        return intArrayOf(if (m <= 2) y + 1 else y, m, d)
    }

    /** 0 = Sunday ... 6 = Saturday. */
    fun weekday(day: Int): Int = Math.floorMod(day + 4, 7)

    /** The [n]-th (1 = first) [wd] (0 = Sunday) of month [m]. */
    fun nthWeekday(y: Int, m: Int, wd: Int, n: Int): Int {
        val first = epochDay(y, m, 1)
        return first + Math.floorMod(wd - weekday(first), 7) + 7 * (n - 1)
    }

    fun easter(y: Int): Int {
        val a = y % 19; val b = y / 100; val c = y % 100
        val d = b / 4; val e = b % 4; val f = (b + 8) / 25; val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4; val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = (h + l - 7 * m + 114) % 31 + 1
        return epochDay(y, month, day)
    }

    // Hebrew calendar (Dershowitz & Reingold): only needed for Hanukkah = 25 Kislev.
    private const val HEBREW_EPOCH_RD = -1373427
    private const val UNIX_EPOCH_RD = 719163

    private fun hebrewElapsed(y: Int): Int {
        val months = (235 * y - 234) / 19
        val parts = 12084 + 13753 * months
        val days = 29 * months + parts / 25920
        return if ((3 * (days + 1)) % 7 < 3) days + 1 else days
    }

    private fun hebrewNewYearRd(y: Int): Int {
        val n0 = hebrewElapsed(y - 1); val n1 = hebrewElapsed(y); val n2 = hebrewElapsed(y + 1)
        val corr = if (n2 - n1 == 356) 2 else if (n1 - n0 == 382) 1 else 0
        return HEBREW_EPOCH_RD + n1 + corr
    }

    /** First day of Hanukkah (25 Kislev) in Gregorian year [gy]. (The candles are lit the evening before.) */
    fun hanukkah(gy: Int): Int {
        val hy = gy + 3761
        val ny = hebrewNewYearRd(hy)
        val len = hebrewNewYearRd(hy + 1) - ny
        val heshvan = if (len % 10 == 5) 30 else 29
        return ny + 30 + heshvan + 24 - UNIX_EPOCH_RD
    }

    /** Date of [h] in year [y]. [canada]: Thanksgiving is the 2nd Monday of October there (4th Thursday of November elsewhere). */
    fun dateOf(h: Holiday, y: Int, canada: Boolean = false): Int = when (h.id) {
        "newyear" -> epochDay(y, 1, 1)
        "valentine" -> epochDay(y, 2, 14)
        "patrick" -> epochDay(y, 3, 17)
        "easter" -> easter(y)
        "mothers" -> nthWeekday(y, 5, 0, 2)
        "fathers" -> nthWeekday(y, 6, 0, 3)
        "independence" -> epochDay(y, 7, 4)
        "halloween" -> epochDay(y, 10, 31)
        "thanksgiving" -> if (canada) nthWeekday(y, 10, 1, 2) else nthWeekday(y, 11, 4, 4)
        "hanukkah" -> hanukkah(y)
        "boxing" -> epochDay(y, 12, 26)
        else -> epochDay(y, 12, 25)                      // christmas
    }

    // ---- row order --------------------------------------------------------------------------------------------------
    /**
     * Rows in the order they are shown on [today]: the holidays follow each other through the calendar year starting with the next
     * one coming up (a rolling Jan-Dec calendar). A holiday that passed within the last [LINGER_DAYS] days sits directly below the
     * next upcoming one (most recently passed first); after that it drops back to its normal place in the sequence (about a year away).
     */
    fun order(today: Int, canada: Boolean = false): List<Dated> {
        val y = civil(today)[0]
        val upcoming = ArrayList<Dated>(); val recent = ArrayList<Dated>()
        for (h in ALL) {
            val dates = (y - 1..y + 1).map { dateOf(h, it, canada) }.sorted()
            val next = dates.first { it >= today }
            val last = dates.last { it < today }
            if (today - last in 1..LINGER_DAYS) recent += Dated(h, last, true)
            else upcoming += Dated(h, next, false)
        }
        upcoming.sortBy { it.day }
        recent.sortByDescending { it.day }
        if (upcoming.isEmpty()) return recent
        return listOf(upcoming[0]) + recent + upcoming.drop(1)
    }

    // ---- which title belongs to which holiday -------------------------------------------------------------------------
    private fun norm(s: String): String = TextNorm.prepare(s)

    /** Text prepared for [matchesPrepared]: normalise each title once, then test it against every holiday. */
    fun prepare(text: String): String = norm(text)

    fun matchesPrepared(h: Holiday, prepared: String): Boolean =
        h.keywords.any { prepared.contains(" $it ") } || h.keywordSets.any { set -> hasAll(prepared, set) }

    /** Does the text have EVERY word of [words] (each as a whole word, in any order)? */
    private fun hasAll(prepared: String, words: List<String>) = words.isNotEmpty() && words.all { prepared.contains(" $it ") }

    /** Bit of [h] in the masks below (bit i = [ALL][i]). */
    fun bit(h: Holiday): Int = 1 shl ALL.indexOf(h)

    /** Words too common in a story description (or too general) to mean "this is a holiday title" (they still count in a title or a category). */
    private val AMBIGUOUS_IN_PLOT = setOf("noel", "pumpkin", "spooky", "casper", "cupid", "jingle", "yule", "reindeer", "nye", "new year", "new years",
        "festive", "snowman", "sleigh", "tinsel", "santa", "turkey day", "menorah", "shamrock", "elf", "klaus", "nativity", "coraline", "beetlejuice", "dreidel")

    /** Screen OUT of every holiday: adult material named by the category / genre ("Adult Movies", "18+", "XXX") ... */
    private val ADULT_CATEGORY = listOf("adult", "adults", "18", "xxx", "porn", "porno", "erotic", "erotica", "nsfw", "hentai", "after dark")
    /** ... or named anywhere, the title included. */
    private val ADULT_ANYWHERE = listOf("xxx", "porn", "porno", "erotic", "erotica", "nsfw", "hentai")

    private fun hasWord(prepared: String, words: List<String>) = words.any { prepared.contains(" $it ") }

    /** Is this category / genre text (already [TextNorm]ed) an adult one? Nothing in it is shown in The Holidays. */
    fun adultCategory(prepared: String): Boolean = hasWord(prepared, ADULT_CATEGORY)

    /** Does this title (already [TextNorm]ed) name adult material? */
    fun adultTitle(prepared: String): Boolean = hasWord(prepared, ADULT_ANYWHERE)

    /** first word -> (" keyword ", bit): finds every holiday word of a text in one pass instead of ~100 substring searches. */
    private class Index(val m: Map<String, List<Pair<String, Int>>>)

    private fun buildIndex(words: (Holiday) -> List<String>, skipAmbiguous: Boolean): Index {
        val m = HashMap<String, MutableList<Pair<String, Int>>>()
        ALL.forEachIndexed { i, h ->
            for (kw in words(h)) {
                if (skipAmbiguous && kw in AMBIGUOUS_IN_PLOT) continue
                m.getOrPut(kw.substringBefore(' ')) { ArrayList() }.add(" $kw " to (1 shl i))
            }
        }
        return Index(m)
    }

    private val titleIndex: Index by lazy { buildIndex({ it.keywords }, false) }
    private val plotIndex: Index by lazy { buildIndex({ it.keywords }, true) }
    private val categoryIndex: Index by lazy { buildIndex({ it.keywords + it.categoryWords }, false) }
    private val excludeIndex: Index by lazy { buildIndex({ it.exclude }, false) }

    /** One set of words of one holiday (bit i = [ALL][i]). */
    private class SetRule(val bit: Int, val words: List<String>)

    private val inSets: List<SetRule> by lazy { ALL.flatMapIndexed { i, h -> h.keywordSets.map { SetRule(1 shl i, it) } } }
    private val outSets: List<SetRule> by lazy { ALL.flatMapIndexed { i, h -> h.excludeSets.map { SetRule(1 shl i, it) } } }

    private fun setBits(prepared: String, rules: List<SetRule>): Int {
        var m = 0
        for (r in rules) if (hasAll(prepared, r.words)) m = m or r.bit
        return m
    }

    private fun scan(prepared: String, index: Index): Int {
        var mask = 0
        val n = prepared.length
        var i = 0
        while (i < n) {
            if (prepared[i] == ' ' && i + 1 < n && prepared[i + 1] != ' ') {
                var j = i + 1
                while (j < n && prepared[j] != ' ') j++
                val cands = index.m[prepared.substring(i + 1, j)]
                if (cands != null) for (c in cands) if (prepared.startsWith(c.first, i)) mask = mask or c.second
                i = j
            } else i++
        }
        return mask
    }

    /**
     * Which holidays a prepared text ([TextNorm.prepare]) mentions, as a bit mask. Same answer as [matchesPrepared] for every holiday
     * (unit tested). [plot] = the text is a story description: the ambiguous words are ignored there.
     */
    fun maskOf(prepared: String, plot: Boolean = false): Int = scan(prepared, if (plot) plotIndex else titleIndex) or setBits(prepared, inSets)

    /** Holidays a category / genre text names: the keywords plus the category-only words ("Holiday Movies"). No exclusions or adult screening yet. */
    fun maskOfCategory(prepared: String): Int = scan(prepared, categoryIndex) or setBits(prepared, inSets)

    /** Holidays whose screen-OUT list matches this title (already [TextNorm]ed). */
    fun excludedBits(prepared: String): Int = scan(prepared, excludeIndex) or setBits(prepared, outSets)

    /**
     * The final answer for one title: [catBits] (from [maskOfCategory]) or what its name says, minus what its name screens out; nothing at all
     * when the category / genre ([adultCat]) or the name is adult material.
     */
    fun screen(catBits: Int, namePrepared: String, adultCat: Boolean): Int {
        if (adultCat || adultTitle(namePrepared)) return 0
        return (catBits or maskOf(namePrepared)) and excludedBits(namePrepared).inv()
    }

    /** Add what a story description says to [bits], with the same screening-out of the title ([namePrepared]). */
    fun withPlot(bits: Int, namePrepared: String, adultCat: Boolean, plotPrepared: String): Int {
        if (adultCat || adultTitle(namePrepared)) return 0
        // the screen-out word sets look at the name AND the description together ("boxing" in the name, "fight" in the story)
        return (bits or maskOf(plotPrepared, plot = true)) and excludedBits(namePrepared).inv() and setBits(namePrepared + plotPrepared, outSets).inv()
    }

    /** Whole-word / whole-phrase match of any keyword in [text] (a title, plus the category and genre text). */
    fun matches(h: Holiday, text: String): Boolean = matchesPrepared(h, norm(text))

    private val MONTHS = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    /** "Dec 25". */
    fun label(day: Int): String { val c = civil(day); return "${MONTHS[c[1] - 1]} ${c[2]}" }
}
