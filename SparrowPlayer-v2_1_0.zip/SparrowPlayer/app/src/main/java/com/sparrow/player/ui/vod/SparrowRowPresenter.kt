package com.sparrow.player.ui.vod

import android.view.ViewGroup
import android.widget.TextView
import androidx.leanback.widget.FocusHighlight
import androidx.leanback.widget.ListRowPresenter
import androidx.leanback.widget.Presenter
import androidx.leanback.widget.RowHeaderPresenter
import androidx.leanback.widget.RowPresenter
import com.sparrow.player.ui.theme.Theme

/**
 * Rows of posters. Zoom is LARGE (the selected card is clearly wider and taller than its neighbours); the grid draws the
 * focused card last and does not clip, so it overlaps both neighbours and its shadow / halo can fall on them. A few extra
 * cached views per row keep fast scrolling from re-binding posters.
 */
class SparrowRowPresenter : ListRowPresenter(FocusHighlight.ZOOM_FACTOR_LARGE) {
    init {
        shadowEnabled = false
        headerPresenter = ThemedHeader()
    }

    override fun initializeRowViewHolder(holder: RowPresenter.ViewHolder) {
        super.initializeRowViewHolder(holder)
        (holder.view as? ViewGroup)?.apply { clipChildren = false; clipToPadding = false }
        val grid = (holder as ListRowPresenter.ViewHolder).gridView
        grid.clipChildren = false
        grid.clipToPadding = false
        grid.setPadding(0, grid.paddingTop, 0, grid.paddingBottom)      // posters start at the same distance from the side bars as the title line (the card's own padding gives the rest)
        grid.setFocusDrawingOrderEnabled(true)
        grid.setItemViewCacheSize(14)
    }
}

/** Row titles in the theme's text colour (the stock Leanback header is always white - unreadable on a light theme). */
class ThemedHeader : RowHeaderPresenter() {
    override fun onBindViewHolder(viewHolder: Presenter.ViewHolder, item: Any?) {
        super.onBindViewHolder(viewHolder, item)
        (viewHolder.view as? TextView)?.apply {
            setTextColor(Theme.text)
            textSize = 16f                                           // slimmer row titles and no air above / below them: two rows fit on screen
            val d = resources.displayMetrics.density
            setPadding((14 * d).toInt(), 0, 0, 0)                    // = the poster card's inner side padding: header, title line and posters share one left edge
        }
    }
}
