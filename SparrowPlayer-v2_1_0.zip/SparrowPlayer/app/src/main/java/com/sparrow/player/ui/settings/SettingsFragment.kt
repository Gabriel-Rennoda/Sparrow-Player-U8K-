package com.sparrow.player.ui.settings

import android.content.Intent
import android.os.Bundle
import android.text.format.DateUtils
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.R
import com.sparrow.player.data.Langs
import com.sparrow.player.data.LibraryReport
import com.sparrow.player.data.SyncCounts
import com.sparrow.player.data.Provider
import com.sparrow.player.databinding.FragmentSettingsBinding
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.TabContent
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.profiles.ProfileMenus
import com.sparrow.player.ui.search.SearchActivity
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.ui.theme.ThemeActivity
import com.sparrow.player.util.StartupLauncher
import com.sparrow.player.util.TimeFmt
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * Settings (v2.1): General, Playback, Playlists, Groups & Channels, Appearance, Network and Buffering, EPG, Data / Backup & About.
 * Each opens a pop-up window with its options; a few options (Hidden) appear under every heading they belong to.
 */
class SettingsFragment : Fragment(R.layout.fragment_settings), TabContent {
    private var b: FragmentSettingsBinding? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val bind = FragmentSettingsBinding.bind(view)
        b = bind
        Theme.applyTree(view)
        val repo = requireContext().repo
        val scope = viewLifecycleOwner.lifecycleScope

        fun refresh() = scope.launch {
            val p = repo.activeProvider()
            bind.info.text = if (p == null) "No Playlist Configured" else
                "Active Playlist: ${p.name} (${p.type})   •   Last Sync: " +
                    if (p.lastSync == 0L) "Never" else DateUtils.getRelativeTimeSpanString(p.lastSync)
        }
        refresh()
        bind.generalBtn.setOnClickListener { general() }
        bind.playbackBtn.setOnClickListener { playback() }
        bind.playlistsBtn.setOnClickListener { playlistsMenu { refresh() } }
        bind.groupsBtn.setOnClickListener { groupsAndChannels() }
        bind.appearanceBtn.setOnClickListener { appearance() }
        bind.networkBtn.setOnClickListener { network() }
        bind.epgBtn.setOnClickListener { epg() }
        bind.dataBtn.setOnClickListener { dataMenu() }
        scope.launch { repo.status.collect { if (it == "Ready") refresh() } }
        (activity as? MainActivity)?.contentReady()
    }

    override fun onDestroyView() { b = null; super.onDestroyView() }

    private fun on(v: Boolean) = if (v) "On" else "Off"
    private fun toast(m: String) = Toast.makeText(requireContext(), m, Toast.LENGTH_SHORT).show()

    // ---- General ------------------------------------------------------------------------------------------------------
    private fun general() {
        val repo = requireContext().repo
        val me = repo.activeProfile()
        val p = Popup(requireActivity(), "General")
        p.row("Profiles", me.name) { ProfileMenus.show(requireActivity()) { id -> chooseIcon(id) } }
        fun bootLabel() = if (repo.prefs.bootProfile == me.id) "Yes" else "No"
        p.row("Open On Device Start-Up / Wake-Up", bootLabel(), keepOpen = true,
            desc = "Yes = this profile opens by itself when the TV starts or wakes, and Who's Watching? is skipped. If the profile has a lock, the Opening Channel plays and the PIN is asked on the first button press. Only one profile can have this on.") { r ->
            val wasOn = repo.prefs.bootProfile == me.id
            repo.prefs.bootProfile = if (wasOn) "" else me.id
            r.setValue(bootLabel())
            if (!wasOn) { toast("${me.name} opens on device start-up"); StartupLauncher.explainPermission(requireActivity()) }
        }
        fun countryLabel() = if (repo.prefs.isCanada) "Canada" else "United States"
        p.row("Location", countryLabel() + "  ▾", keepOpen = true,
            desc = "Sets the holiday calendar (Canadian Thanksgiving, Victoria Day ...) and the country shown in carousel names such as Top 10 in Canada.") { r ->
            Popup.choose(requireActivity(), "Location", listOf("Canada", "United States"), if (repo.prefs.isCanada) 0 else 1) { i ->
                repo.prefs.country = if (i == 0) "CA" else "US"; r.setValue(countryLabel() + "  ▾"); repo.dataVersion.value++
            }
        }
        // "12 Hr Clock" On = 12 hour clock (the default), Off = 24 hour.
        p.row("12 Hr Clock", on(!repo.prefs.clock24), keepOpen = true) { r ->
            repo.prefs.clock24 = !repo.prefs.clock24; TimeFmt.is24h = repo.prefs.clock24; r.setValue(on(!repo.prefs.clock24))
        }
        p.show()
    }

    // ---- Playback -----------------------------------------------------------------------------------------------------
    private fun playback() {
        val repo = requireContext().repo
        val p = Popup(requireActivity(), "Playback")
        p.row("Resume Movies And Episodes Where I Stopped", on(repo.prefs.resumeEnabled), keepOpen = true,
            desc = "Off = a movie or episode always starts from the beginning.") { r ->
            repo.prefs.resumeEnabled = !repo.prefs.resumeEnabled; r.setValue(on(repo.prefs.resumeEnabled))
        }
        val vq = listOf("best" to "Best Available", "2160" to "4K", "1080" to "1080p (Full HD)", "720" to "720p (HD)", "480" to "480p (SD)")
        fun vqLabel() = vq.firstOrNull { it.first == repo.prefs.videoQuality }?.second ?: "Best Available"
        p.row("Playback Quality", vqLabel() + "  ▾", keepOpen = true,
            desc = "The largest picture size to play. Best Available takes the highest the stream offers. A lower size uses less data and buffers less on a slow connection.") { r ->
            Popup.choose(requireActivity(), "Playback Quality", vq.map { it.second }, vq.indexOfFirst { it.first == repo.prefs.videoQuality }) { i ->
                repo.prefs.videoQuality = vq[i].first; r.setValue(vqLabel() + "  ▾")
            }
        }
        val aq = listOf("best" to "Best Available", "6" to "Surround (5.1)", "2" to "Stereo (2.0)")
        fun aqLabel() = aq.firstOrNull { it.first == repo.prefs.audioQuality }?.second ?: "Best Available"
        p.row("Audio Quality", aqLabel() + "  ▾", keepOpen = true,
            desc = "The most audio channels to play. Stereo can help when a TV or soundbar handles surround badly.") { r ->
            Popup.choose(requireActivity(), "Audio Quality", aq.map { it.second }, aq.indexOfFirst { it.first == repo.prefs.audioQuality }) { i ->
                repo.prefs.audioQuality = aq[i].first; r.setValue(aqLabel() + "  ▾")
            }
        }
        p.row("Audio Language", Langs.label(Langs.AUDIO, repo.prefs.audioLang) + "  ▾", keepOpen = true) { r ->
            val idx = Langs.AUDIO.indexOfFirst { it.first == repo.prefs.audioLang }
            Popup.choose(requireActivity(), "Audio Language", Langs.AUDIO.map { it.second }, idx) { i ->
                repo.prefs.audioLang = Langs.AUDIO[i].first; r.setValue(Langs.AUDIO[i].second + "  ▾")
            }
        }
        p.row("Subtitles", Langs.label(Langs.SUBTITLES, repo.prefs.subtitleLang) + "  ▾", keepOpen = true) { r ->
            val idx = Langs.SUBTITLES.indexOfFirst { it.first == repo.prefs.subtitleLang }
            Popup.choose(requireActivity(), "Subtitles", Langs.SUBTITLES.map { it.second }, idx) { i ->
                repo.prefs.subtitleLang = Langs.SUBTITLES[i].first; r.setValue(Langs.SUBTITLES[i].second + "  ▾")
            }
        }
        p.note("Quality, audio and subtitle choices apply to the next thing you play. Audio language and subtitles are used when a stream has that track; you can also change them while watching (OK in full screen).")
        p.show()
    }

    // ---- Playlists ----------------------------------------------------------------------------------------------------
    private fun playlistsMenu(refresh: () -> Unit) {
        val p = Popup(requireActivity(), "Playlists")
        p.row("Switch Playlist") { switchPlaylist(refresh) }
        p.row("Add Playlist") { keepPlayingBehind(); startActivity(Intent(requireContext(), AddProviderActivity::class.java)) }
        p.row("Delete Playlist") { chooseToDelete(refresh) }
        p.row("Library Counts", "IPTV vs Sparrow") { libraryCounts() }
        p.row("Hidden") { hidden() }
        p.note("Library Counts: how many titles your IPTV list has and how many Sparrow shows. Hidden: channels and groups you hid from this playlist.")
        p.show()
    }

    private fun keepPlayingBehind() { (activity as? MainActivity)?.keepPlayingBehind() }

    private fun switchPlaylist(refresh: () -> Unit) {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val all = repo.dao.providers()
            val active = repo.activeProvider()?.id
            val p = Popup(requireActivity(), "Switch Playlist", "Choose The Playlist To Use")
            all.forEach { pr ->
                p.row(pr.name, if (pr.id == active) "Active  ✓" else "") {
                    if (pr.id != active) {
                        repo.prefs.activeProvider = pr.id
                        repo.dataVersion.value++
                        if (pr.lastSync == 0L) repo.syncAsync(pr)
                        refresh(); toast("Switched to ${pr.name}")
                    }
                }
            }
            if (all.isEmpty()) p.note("No playlists yet. Choose Add Playlist to get started.")
            p.show()
        }
    }

    // ---- Groups & Channels --------------------------------------------------------------------------------------------
    private fun groupsAndChannels() {
        val repo = requireContext().repo
        val p = Popup(requireActivity(), "Groups & Channels")
        p.row("Channel Numbers", on(repo.prefs.showNumbers), keepOpen = true, desc = "Show the channel number in front of each channel name.") { r ->
            repo.prefs.showNumbers = !repo.prefs.showNumbers; r.setValue(on(repo.prefs.showNumbers))
        }
        p.row("Hidden") { hidden() }
        p.row("Ask Before Hiding", on(repo.prefs.askBeforeHide), keepOpen = true, desc = "Asks \"Are you sure?\" before a channel or group is hidden.") { r ->
            repo.prefs.askBeforeHide = !repo.prefs.askBeforeHide; r.setValue(on(repo.prefs.askBeforeHide))
        }
        p.show()
    }

    private fun chooseToDelete(refresh: () -> Unit) {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val all = repo.dao.providers()
            val active = repo.activeProvider()?.id
            val p = Popup(requireActivity(), "Delete Playlist", "Choose The Playlist To Delete")
            all.forEach { pr -> p.row(pr.name, if (pr.id == active) "Active" else "") { confirmDelete(pr, refresh) } }
            if (all.isEmpty()) p.note("There are no playlists to delete.")
            p.show()
        }
    }

    private fun confirmDelete(pr: Provider, refresh: () -> Unit) {
        val repo = requireContext().repo
        Popup.confirm(requireActivity(), "Delete ${pr.name}?", "Channels, movies, series and guide data for this playlist will be deleted.", "Yes, Delete") {
            viewLifecycleOwner.lifecycleScope.launch {
                repo.deleteProvider(pr)
                if (repo.activeProvider() == null) startActivity(Intent(requireContext(), AddProviderActivity::class.java))
                refresh(); toast("Playlist deleted")
            }
        }
    }

    private fun hidden() {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val pid = repo.activeProvider()?.id ?: run { toast("No playlist yet"); return@launch }
            val chans = repo.hiddenChannels(pid)
            val groups = repo.groups(pid).filter { it.hidden }
            val p = Popup(requireActivity(), "Hidden", "Channels And Groups You Hid")
            p.row("Hidden Channels", chans.size.toString()) { hiddenChannels(pid) }
            p.row("Hidden Groups", groups.size.toString()) { hiddenGroups(pid) }
            p.show()
        }
    }

    private fun hiddenChannels(pid: Long) {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val chans = repo.hiddenChannels(pid)
            val p = Popup(requireActivity(), "Hidden Channels", "Select A Channel To Unhide It")
            if (chans.isEmpty()) p.note("No hidden channels.")
            else {
                p.row("Unhide All Channels") { repo.custom(pid).hidden.clear(); repo.saveCustom(pid); toast("All channels unhidden") }
                chans.forEach { c ->
                    p.row(c.name, "Unhide") { repo.custom(pid).setHidden(c.uid, false); repo.saveCustom(pid); toast("${c.name} unhidden") }
                }
            }
            p.show()
        }
    }

    private fun hiddenGroups(pid: Long) {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val groups = repo.groups(pid).filter { it.hidden }
            val p = Popup(requireActivity(), "Hidden Groups", "Select A Group To Unhide It")
            if (groups.isEmpty()) p.note("No hidden groups.")
            else {
                p.row("Unhide All Groups") { repo.custom(pid).hiddenGroups.clear(); repo.saveCustom(pid); toast("All groups unhidden") }
                groups.forEach { g ->
                    p.row(g.name, "Unhide") { repo.custom(pid).setGroupHidden(g.id, false); repo.saveCustom(pid); toast("${g.name} unhidden") }
                }
            }
            p.show()
        }
    }

    // ---- Appearance ---------------------------------------------------------------------------------------------------
    private fun appearance() {
        val p = Popup(requireActivity(), "Appearance")
        p.row("Theme", Theme.palette.name) { keepPlayingBehind(); startActivity(Intent(requireContext(), ThemeActivity::class.java)) }
        p.note("Stock themes, solid colours, custom and random. Backgrounds are always dark so text stays easy to read. More appearance options will arrive in future updates.")
        p.show()
    }

    // ---- Network and Buffering ----------------------------------------------------------------------------------------
    private fun network() {
        val repo = requireContext().repo
        val p = Popup(requireActivity(), "Network and Buffering")
        p.row("Live Stream Format", repo.prefs.liveFormat.uppercase(), keepOpen = true,
            desc = "TS starts fastest; HLS (m3u8) can be steadier on weak connections. Xtream playlists only.") { r ->
            repo.prefs.liveFormat = if (repo.prefs.liveFormat == "ts") "m3u8" else "ts"
            r.setValue(repo.prefs.liveFormat.uppercase())
        }
        val modes = listOf("auto" to "Auto (Follows The Connection Check)", "fast" to "Fast Start", "balanced" to "Balanced", "stable" to "Stable", "max" to "Maximum Stability")
        fun modeLabel() = (modes.firstOrNull { it.first == repo.prefs.bufferMode } ?: modes[0]).second.substringBefore(" (")
        p.row("Buffer Profile", modeLabel() + "  ▾", keepOpen = true,
            desc = "A bigger buffer rides out a weak or jumpy connection (it waits a little longer before the picture starts). A smaller one starts faster.") { r ->
            Popup.choose(requireActivity(), "Buffer Profile", modes.map { it.second }, modes.indexOfFirst { it.first == repo.prefs.bufferMode }) { i ->
                repo.prefs.bufferMode = modes[i].first; r.setValue(modeLabel() + "  ▾")
            }
        }
        fun connLabel() = when (repo.prefs.connectionClass) { 1 -> "Very Steady"; 2 -> "Steady"; 3 -> "Unsteady"; 4 -> "Poor"; else -> "Not Checked" }
        p.row("Optimise For My Connection", connLabel(), keepOpen = true,
            desc = "Opens a live stream for a few seconds and watches how steadily it arrives, then Auto picks the buffer size that suits it. Run it again if your connection changes.") { r ->
            r.setValue("Checking…")
            viewLifecycleOwner.lifecycleScope.launch {
                val c = measureConnection()
                if (c == 0) { r.setValue(connLabel()); toast("Could not check: add a playlist with a live channel first, or check the connection") }
                else {
                    repo.prefs.connectionClass = c; repo.prefs.bufferMode = "auto"
                    r.setValue(connLabel()); toast("Connection: " + connLabel() + " - buffer set to Auto")
                }
            }
        }
        p.row("Auto-Reconnect Dropped Streams", on(repo.prefs.autoRetry), keepOpen = true,
            desc = "When a live channel drops, Sparrow tries it again a few times by itself instead of showing an error.") { r ->
            repo.prefs.autoRetry = !repo.prefs.autoRetry; r.setValue(on(repo.prefs.autoRetry))
        }
        p.note("For the steadiest picture on a slow connection also lower Playback Quality (Settings → Playback). Quality choices never go above what the stream offers.")
        p.show()
    }

    /** 1 = very steady ... 4 = poor, 0 = could not be checked. Reads a live stream for up to 6 s: time to first data and the longest pause in between. */
    private suspend fun measureConnection(): Int = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val repo = requireContext().repo
        val pr = repo.activeProvider() ?: return@withContext 0
        val ch = repo.firstChannel(pr.id) ?: return@withContext 0
        try {
            val req = okhttp3.Request.Builder().url(repo.liveUrl(ch)).header("User-Agent", com.sparrow.player.data.Prefs.UA).build()
            val t0 = System.nanoTime()
            var first = -1L; var last = t0; var maxGap = 0L
            repo.http.newCall(req).execute().use { resp ->
                val stream = resp.body?.byteStream() ?: return@withContext 0
                val buf = ByteArray(32 * 1024)
                while (System.nanoTime() - t0 < 6_000_000_000L) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    val now = System.nanoTime()
                    if (first < 0) first = now - t0 else maxGap = maxOf(maxGap, now - last)
                    last = now
                }
            }
            if (first < 0) return@withContext 4
            val ttfbMs = first / 1_000_000; val gapMs = maxGap / 1_000_000
            when {
                ttfbMs > 3000 || gapMs > 1500 -> 4
                ttfbMs > 1500 || gapMs > 800 -> 3
                ttfbMs > 600 || gapMs > 400 -> 2
                else -> 1
            }
        } catch (e: Exception) { 0 }
    }

    // ---- EPG ----------------------------------------------------------------------------------------------------------
    private var iconTarget = ""
    private val pickIcon = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        ProfileMenus.saveFromUri(requireActivity(), iconTarget, uri)
    }

    private fun chooseIcon(id: String) {
        iconTarget = id
        try { pickIcon.launch("image/*") }
        catch (e: Exception) {
            toast("This TV has no file chooser – use Icon From A Web Address instead")
            ProfileMenus.saveFromUri(requireActivity(), id, null)            // back to the profile's window
        }
    }

    private var pickRow: Popup.Row? = null
    private val pickChannel = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { res ->
        val uid = res.data?.getStringExtra("uid")
        if (res.resultCode == android.app.Activity.RESULT_OK && !uid.isNullOrBlank()) {
            requireContext().repo.prefs.openChannel = uid
            pickRow?.setValue(customLabel(res.data?.getStringExtra("name")))        // the EPG window now reads "Custom: <channel>"
            toast("Opening channel set to " + (res.data?.getStringExtra("name") ?: "the chosen channel"))
        }
    }

    /** What the Opening Channel row of the EPG window shows: "Last Watched" or "Custom: <channel name>". */
    private fun customLabel(name: String?) = "Custom: " + (name ?: "Unavailable")

    private fun epg() {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val open = repo.prefs.openChannel
            epgPopup(if (open.isBlank()) "Last Watched" else customLabel(repo.channel(open)?.name))
        }
    }

    private fun epgPopup(openName: String) {
        val repo = requireContext().repo
        val hours = listOf(24, 12, 6, 3, 2)
        fun label(h: Int) = "$h Hours"
        val p = Popup(requireActivity(), "EPG")
        // 1. getting the guide
        p.row("EPG Sync", label(repo.prefs.epgHours) + "  ▾", keepOpen = true) { r ->
            Popup.choose(requireActivity(), "EPG Sync Every", hours.map { label(it) }, hours.indexOf(repo.prefs.epgHours)) { i ->
                repo.prefs.epgHours = hours[i]; r.setValue(label(hours[i]) + "  ▾")
            }
        }
        p.row("Sync EPG On App Start", on(repo.prefs.epgOnStart), keepOpen = true) { r ->
            repo.prefs.epgOnStart = !repo.prefs.epgOnStart; r.setValue(on(repo.prefs.epgOnStart))
        }
        p.row("Sync Now", desc = "Refreshes channels, movies, series and the TV guide. Automatic syncs update the guide only.") {
            viewLifecycleOwner.lifecycleScope.launch {
                val pr = repo.activeProvider()
                if (pr == null) toast("Add a playlist first") else { repo.syncAsync(pr); toast("Sync started") }
            }
        }
        // 2. how the guide opens and looks
        p.row("Opening Channel", openName, keepOpen = true) { r ->
            viewLifecycleOwner.lifecycleScope.launch {
                val open = repo.prefs.openChannel
                val custom = open.isNotBlank()
                val name = if (custom) repo.channel(open)?.name else null
                val m = Popup(requireActivity(), "Opening Channel", "The Channel Sparrow Player Starts On Every Time It Opens")
                m.row("Last Watched (Default)", if (!custom) "✓" else "") {
                    repo.prefs.openChannel = ""; r.setValue("Last Watched"); toast("The app opens on the last channel you watched")
                }
                m.row(if (custom) "Custom: " + (name ?: "Unavailable") else "Custom", if (custom) "✓" else "") {
                    pickRow = r; pickChannel.launch(SearchActivity.pickChannel(requireContext()))
                }
                m.note("Custom opens the guide with the mini player (top left) on the channel you choose. You can also hold OK on any channel in the guide and choose Set As Opening Channel.")
                m.show()
            }
        }
        val delays = listOf(0, 2, 3, 5, 10)
        fun delayLabel(v: Int) = if (v == 0) "Never" else "$v Seconds"
        p.row("Hide Side Bar After", delayLabel(repo.prefs.railHideSeconds) + "  ▾", keepOpen = true,
            desc = "The Sparrow icon bar hides after this many seconds. Press Left twice (or Back twice) to bring it back; Search is first in it.") { r ->
            Popup.choose(requireActivity(), "Hide Side Bar After", delays.map { delayLabel(it) }, delays.indexOf(repo.prefs.railHideSeconds)) { i ->
                repo.prefs.railHideSeconds = delays[i]; r.setValue(delayLabel(delays[i]) + "  ▾")
            }
        }
        // 3. holiday programming and hidden items
        p.row("Holiday Episodes Only (Lite)", on(repo.prefs.holidayEpisodesOnly), keepOpen = true,
            desc = "On: a series opened from a holiday page lists only the episodes about that holiday (when it has some). Off: every episode of the series is listed.") { r ->
            repo.prefs.holidayEpisodesOnly = !repo.prefs.holidayEpisodesOnly; r.setValue(on(repo.prefs.holidayEpisodesOnly))
        }
        p.row("Hidden", desc = "Channels and groups you hid from the guide; unhide them here.") { hidden() }
        p.show()
    }

    // ---- Library Counts: the IPTV provider's numbers next to what Sparrow Player shows ---------------------------------------------------------
    private fun n(v: Int): String = String.format("%,d", v)

    private fun libraryCounts() {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val pr = repo.activeProvider() ?: run { toast("No playlist yet"); return@launch }
            toast("Counting titles…")
            val sent = SyncCounts.parse(repo.prefs.syncCounts(pr.id))
            val movies = try { repo.libraryReport(pr.id, "movie") } catch (e: Exception) { null }
            val series = try { repo.libraryReport(pr.id, "series") } catch (e: Exception) { null }
            val live = try { repo.dao.channelCount(pr.id) } catch (e: Exception) { 0 }
            val p = Popup(requireActivity(), "Library Counts", "Your IPTV list vs. what Sparrow Player shows  •  " + pr.name)
            if (sent == null) p.note("This playlist was synced before the counts existed: use Settings → EPG → Sync Now once, then the IPTV numbers show here.")
            else p.note("IPTV = what the panel sent at the last sync (" + DateUtils.getRelativeTimeSpanString(sent.at) + ").")
            p.row("Live Channels", "IPTV " + (sent?.let { n(it.liveSent) } ?: "?") + "   •   Sparrow " + n(live), keepOpen = true) { }
            if (movies != null) section(p, "Movies", movies, sent?.movieSent, sent?.movieUnique, sent?.movieCategories)
            if (series != null) section(p, "Series", series, sent?.seriesSent, sent?.seriesUnique, sent?.seriesCategories)
            if (movies == null && series == null) p.note("The catalogue is not ready yet. Try again in a moment.")
            p.row("Close") { }
            p.show()
        }
    }

    private fun section(p: Popup, label: String, r: LibraryReport, sent: Int?, sentUnique: Int?, cats: Int?) {
        val kind = if (r.type == "movie") "Movies" else "Series"
        p.note(label.uppercase())
        p.row("IPTV List Sent", sent?.let { n(it) } ?: "Sync Needed", keepOpen = true) { }
        p.row("Saved In Sparrow", n(r.stored) + (if (sentUnique != null && sentUnique != r.stored) "   (IPTV unique ids: " + n(sentUnique) + ")" else ""), keepOpen = true) { }
        if (sent != null && sentUnique != null && sent > sentUnique) p.row("Repeated Ids In IPTV List", n(sent - sentUnique), keepOpen = true) { }
        p.row("Different Titles", n(r.unique) + "   (a title in several categories counts once)", keepOpen = true) { }
        p.row("In A Genre Group", n(r.inGenreGroup), keepOpen = true) { }
        p.row("Only In All $kind", n(r.inNoGenreGroup) + "   (no genre found)", keepOpen = true) { }
        p.row("Kids Titles", n(r.kids), keepOpen = true) { }
        p.row("Holiday Titles", n(r.holidays), keepOpen = true) { }
        p.row("Adult (Kept Out Of Holidays)", n(r.adult), keepOpen = true) { }
        p.row("No Poster / Rating / Year", n(r.noPoster) + " / " + n(r.noRating) + " / " + n(r.noYear), keepOpen = true) { }
        if (cats != null) p.row("IPTV Categories", n(cats), keepOpen = true) { }
        p.row("$kind By Genre", r.perGenre.size.toString() + " Genres") { breakdown("$kind By Genre", r.perGenre) }
        p.row("$kind By IPTV Category", r.perCategory.size.toString() + " Categories") { breakdown("$kind By IPTV Category", r.perCategory) }
    }

    private fun breakdown(title: String, l: List<Pair<String, Int>>) {
        val p = Popup(requireActivity(), title, "Titles In Each")
        if (l.isEmpty()) p.note("Nothing to list.")
        l.forEach { (name, c) -> p.row(name, n(c), keepOpen = true) { } }
        p.show()
    }

    // ---- Data, Backup & About -------------------------------------------------------------------------------------------
    private fun dataMenu() {
        val p = Popup(requireActivity(), "Data, Backup & About")
        p.row("About") { about() }
        p.row("Navigation And Shortcuts") { shortcuts() }
        p.row("Clear Cache & Reload", desc = "Clears the saved poster pictures and reloads Movies and Series from your playlist's saved data. Your profiles, history and settings are kept.") { clearCache() }
        p.row("Clear Watch History", desc = "Clears watch history and resume points of the current profile (" + requireContext().repo.activeProfile().name + ") only. Other profiles are not touched.") {
            Popup.confirm(requireActivity(), "Clear Watch History?", "This clears what " + requireContext().repo.activeProfile().name + " has watched, resume points and Continue Watching. It cannot be undone.", "Yes, Clear") {
                val r = requireContext().repo
                r.prefs.clearWatchHistory(); r.dataVersion.value++; toast("Watch history cleared")
            }
        }
        p.note("Backup, Restore and Update / Sync Profiles arrive in the next update.")
        p.show()
    }

    private fun clearCache() {
        val ctx = requireContext()
        val loader = coil.Coil.imageLoader(ctx)
        loader.memoryCache?.clear()
        try { loader.diskCache?.clear() } catch (e: Exception) { }
        ctx.repo.dataVersion.value++
        toast("Cache cleared - reloading")
    }

    private fun about() {
        val ver = try { requireContext().packageManager.getPackageInfo(requireContext().packageName, 0).versionName } catch (e: Exception) { "?" }
        val p = Popup(requireActivity(), "About", "Sparrow Player $ver")
        p.note("IPTV player for Android TV / Google TV, built and tuned for the Hisense U8K.")
        p.note("Built with Media3 / ExoPlayer, Leanback, Room, OkHttp and Coil.")
        p.note("Your profiles, history and settings stay on this device. Sparrow Player does not supply any channels or titles: they come from the playlist you add.")
        p.row("Close") { }
        p.show()
    }

    private fun shortcuts() {
        val p = Popup(requireActivity(), "Navigation And Shortcuts")
        p.note("SIDE BARS")
        p.note("Left at the left edge opens Channel / Movie Groups. Left again opens the Tab List (it covers the groups). Right or Back closes one level. Back on the Tab List twice asks to exit.")
        p.note("GUIDE (LIVE TV)")
        p.note("OK tunes the channel; OK on the playing channel = full screen. Hold OK on a channel = options (favourite, hide, copy, move, rename, set as opening channel). Up from the first channel reaches the player box.")
        p.note("MOVIES AND SERIES")
        p.note("OK opens a title. Hold OK (or Menu / Info) on a poster = See All of that row. In See All: Left on the first column returns with the side panels open; Back returns to the row.")
        p.note("Once you scroll along a row, the title's name appears above the row where the carousel's name was.")
        p.note("GROUPS")
        p.note("Hold OK on a group = rename, move, hide, delete. Random Pick is at the top of the Movie / Series groups.")
        p.note("FULL SCREEN")
        p.note("Live: Up / Down or CH+/- = zap, 0-9 = channel number, OK = info bar, OK again = audio, subtitles, quality. Movies: standard player bar; the gear (Up from the bar) has audio, subtitles and quality.")
        p.note("SEARCH")
        p.note("Search is first in the Tab List and the groups panel, or press the remote's search key.")
        p.row("Close") { }
        p.show()
    }

    // ---- TabContent: a single column of buttons, so every row is on the left edge ---------------
    override fun focusContent(): Boolean = view?.findViewById<View>(R.id.generalBtn)?.requestFocus() ?: false
    override fun scrollView(): View? = view
    override fun isAtLeftEdge() = true
}
