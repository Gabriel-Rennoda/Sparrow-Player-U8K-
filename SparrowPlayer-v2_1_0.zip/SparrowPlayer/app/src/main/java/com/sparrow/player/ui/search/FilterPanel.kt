package com.sparrow.player.ui.search

import android.app.Activity
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.sparrow.player.data.Langs
import com.sparrow.player.data.MediaTags
import com.sparrow.player.data.SearchFilters
import com.sparrow.player.data.SearchKind
import com.sparrow.player.data.SortBy
import com.sparrow.player.data.UserRatings
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.TitleCase
import com.sparrow.player.util.dp

/**
 * The filters, ON the search page (no pop-up): Live / Movie / Series buttons at the top (the chosen one is outlined), then drop-downs and
 * toggle buttons. A drop-down has no heading: it shows its own name until something is chosen, then the choice. Yes / no filters are toggle buttons.
 * Every change applies at once. Fields that do not belong to the chosen type are not shown.
 *
 * Stateless: the current filters / kind are read through [filters] / [kind], changes are reported through [onFilters] / [onKind];
 * the page calls [refresh] after every change so the boxes show the current values.
 */
class FilterPanel(
    private val a: Activity,
    private val host: LinearLayout,
    private val kind: () -> SearchKind,
    private val filters: () -> SearchFilters,
    private val genreOptions: () -> List<String>,
    private val typeLocked: Boolean,
    private val onFilters: (SearchFilters) -> Unit,
    private val onKind: (SearchKind) -> Unit
) {
    private val updaters = ArrayList<() -> Unit>()
    private val w: SearchFilters get() = filters()

    fun refresh() = updaters.forEach { it() }
    fun clear() = updaters.clear()

    // ---- the top: type buttons + the filters ------------------------------------------------------------------------------
    fun buildTop() {
        val live = kind() == SearchKind.LIVE
        if (!typeLocked) typeButtons()
        if (!live) {
            val stars = listOf("Any") + (1..10).map { it.toString() }
            row(
                drop("Min. Star Rating", { if (w.minStars <= 0) "" else "Min. Star Rating: " + w.minStars.toInt() }) {
                    Popup.choose(a, "Min. Star Rating", stars, if (w.minStars <= 0) 0 else w.minStars.toInt().coerceIn(1, 10)) { i -> onFilters(w.copy(minStars = i.toDouble())) }
                },
                drop("Min. Sparrow Rating", { if (w.minSparrow <= 0) "" else "Min. Sparrow Rating: " + w.minSparrow.toInt() }) {
                    Popup.choose(a, "Min. Sparrow Rating", stars, if (w.minSparrow <= 0) 0 else w.minSparrow.toInt().coerceIn(1, 10)) { i -> onFilters(w.copy(minSparrow = i.toDouble())) }
                }
            )
            row(
                drop("Genre", { summarize(w.genres) { TitleCase.of(it) } }) {
                    val opts = genreOptions()
                    if (opts.isNotEmpty()) Popup.multi(a, "Genre", opts.map { it to TitleCase.of(it) }, w.genres) { s, _ -> onFilters(w.copy(genres = s)) }
                },
                drop("Quality", { summarize(w.qualities) { it } }) {
                    Popup.multi(a, "Quality", MediaTags.QUALITIES.map { it to it }, w.qualities) { s, _ -> onFilters(w.copy(qualities = s)) }
                }
            )
        } else {
            row(
                drop("Channel Type", { summarize(w.channelTypes) { it } }) {
                    Popup.multi(a, "Channel Type", MediaTags.CHANNEL_TYPES.map { it to it }, w.channelTypes) { s, _ -> onFilters(w.copy(channelTypes = s)) }
                },
                drop("Quality", { summarize(w.qualities) { it } }) {
                    Popup.multi(a, "Quality", MediaTags.QUALITIES.map { it to it }, w.qualities) { s, _ -> onFilters(w.copy(qualities = s)) }
                }
            )
        }
        val langOptions = Langs.ALL + (MediaTags.UNKNOWN_LANGUAGE to MediaTags.UNKNOWN_LANGUAGE)
        val language = drop("Language", {
            if (w.languages.isEmpty()) "" else summarize(w.languages) { c -> Langs.label(langOptions, c) }.let { if (w.languagesOut) "Hide: $it" else it }
        }) {
            Popup.multi(a, "Language", langOptions, w.languages, "Show only selected", "Hide selected", w.languagesOut) { s, out -> onFilters(w.copy(languages = s, languagesOut = out)) }
        }
        if (!live) {
            row(language, toggle("Unwatched Only", { w.unwatchedOnly }) { onFilters(w.copy(unwatchedOnly = !w.unwatchedOnly)) })
            row(chips(listOf(UserRatings.LOVED to "❤️ Loved", UserRatings.LIKED to "👍 Liked", UserRatings.DISLIKED to "👎 Disliked"), 15f,
                { it in w.myRatings && !w.myRatingsOut },
                { code ->
                    val s = LinkedHashSet(w.myRatings); if (!s.add(code)) s.remove(code)
                    onFilters(w.copy(myRatings = s, myRatingsOut = false, hideRatings = w.hideRatings - code))
                }), null)
            row(chips(listOf(UserRatings.LOVED to "Hide ❤️", UserRatings.LIKED to "Hide 👍", UserRatings.DISLIKED to "Hide 👎"), 15f,
                { it in w.hideRatings },
                { code ->
                    val s = LinkedHashSet(w.hideRatings); if (!s.add(code)) s.remove(code)
                    onFilters(w.copy(hideRatings = s, myRatings = w.myRatings - code))
                }), null)
            row(toggle("Search Descriptions", { w.inDescription }) { onFilters(w.copy(inDescription = !w.inDescription)) }, null)
        } else {
            row(language, toggle("Search Descriptions", { w.inDescription }) { onFilters(w.copy(inDescription = !w.inDescription)) })
            row(
                toggle("Skip Hidden Channels", { !w.showHiddenChannels }) { onFilters(w.copy(showHiddenChannels = !w.showHiddenChannels)) },
                toggle("Skip Hidden Groups", { !w.showHiddenGroups }) { onFilters(w.copy(showHiddenGroups = !w.showHiddenGroups)) }
            )
        }
    }

    // ---- the bottom: sort ---------------------------------------------------------------------------------------------------
    fun buildSort() {
        val vod = kind() != SearchKind.LIVE
        val sorts = SortBy.forKind(kind())
        row(
            drop("Sort By", { "Sort By: " + (if (w.sortBy in sorts) w.sortBy else SortBy.NAME).label }) {
                Popup.choose(a, "Sort By", sorts.map { it.label }, sorts.indexOf(w.sortBy)) { i -> onFilters(w.copy(sortBy = sorts[i])) }
            },
            toggle("", { false }, { if (w.descending) "Descending" else "Ascending" }) { onFilters(w.copy(descending = !w.descending)) }
        )
        if (vod) row(drop("❤️ 👍 👎 First, Then By", { w.ratingsFirst?.let { "Then By: " + it.label } ?: "" }) {
            Popup.choose(a, "Ratings First, Then By", listOf("Same As Sort By") + sorts.map { it.label }, (w.ratingsFirst?.let { sorts.indexOf(it) + 1 } ?: 0)) { i ->
                onFilters(w.copy(ratingsFirst = if (i == 0) null else sorts[i - 1]))
            }
        }, null)
    }

    // ---- pieces -------------------------------------------------------------------------------------------------------------
    private fun summarize(set: Set<String>, label: (String) -> String): String =
        if (set.isEmpty()) "" else if (set.size <= 2) set.joinToString(", ") { label(it) } else "${set.size} Selected"

    private fun shape(fill: Int, stroke: Int, width: Int) = GradientDrawable().apply { setColor(fill); cornerRadius = a.dp(12).toFloat(); setStroke(a.dp(width), stroke) }

    private fun row(left: View, right: View?) {
        val line = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        line.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = if (right != null) a.dp(10) else 0 })
        if (right != null) line.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        host.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = a.dp(8) })
    }

    /** Live / Movie / Series: three buttons side by side, the chosen one outlined. */
    private fun typeButtons() {
        val items = listOf(SearchKind.LIVE to "Live", SearchKind.MOVIE to "Movie", SearchKind.SERIES to "Series")
        val line = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEachIndexed { i, (k, text) ->
            val b = TextView(a).apply {
                this.text = text; textSize = 18f; gravity = Gravity.CENTER; isFocusable = true; isClickable = true; setSingleLine(true)
                setTypeface(typeface, Typeface.BOLD)
                background = StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_focused, android.R.attr.state_selected), shape(Theme.surface2, Theme.text, 4))
                    addState(intArrayOf(android.R.attr.state_focused), shape(Theme.bg, Theme.text, 3))
                    addState(intArrayOf(android.R.attr.state_selected), shape(Theme.surface2, Theme.accent, 4))
                    addState(intArrayOf(), shape(Theme.bg, Theme.surface2, 2))
                }
                setOnClickListener { if (kind() != k) onKind(k) }
                updaters += { isSelected = kind() == k; setTextColor(if (kind() == k) Theme.text else Theme.textDim) }
            }
            line.addView(b, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { if (i > 0) marginStart = a.dp(8) })
        }
        host.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = a.dp(10) })
    }

    /** A drop-down box: its own name (dimmed) until something is chosen, then the choice. */
    private fun drop(placeholder: String, value: () -> String, onClick: () -> Unit): View {
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(a.dp(12), a.dp(6), a.dp(10), a.dp(6)); minimumHeight = a.dp(48)
            isFocusable = true; isClickable = true
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_focused), shape(Theme.bg, Theme.text, 3))
                addState(intArrayOf(), shape(Theme.bg, Theme.accent, 2))
            }
        }
        val v = TextView(a).apply { textSize = 16f; setSingleLine(true); ellipsize = TextUtils.TruncateAt.END }
        box.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(TextView(a).apply { text = "⌄"; textSize = 20f; setTextColor(Theme.textDim) })
        updaters += { val s = value(); v.text = s.ifEmpty { placeholder }; v.setTextColor(if (s.isEmpty()) Theme.textDim else Theme.text) }
        box.setOnClickListener { onClick() }
        return box
    }

    /** A yes / no filter as a toggle button: filled when on, outlined when off. [text] may change with the state ([label] overrides it). */
    private fun toggle(text: String, on: () -> Boolean, label: (() -> String)? = null, flip: () -> Unit): View {
        val b = TextView(a).apply {
            this.text = text; textSize = 16f; gravity = Gravity.CENTER; isFocusable = true; isClickable = true; setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END; setPadding(a.dp(8), 0, a.dp(8), 0)
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_focused, android.R.attr.state_selected), shape(Theme.accent, Theme.text, 3))
                addState(intArrayOf(android.R.attr.state_focused), shape(Theme.bg, Theme.text, 3))
                addState(intArrayOf(android.R.attr.state_selected), shape(Theme.accent, Theme.accent, 2))
                addState(intArrayOf(), shape(Theme.bg, Theme.accent, 2))
            }
            setOnClickListener { flip() }
            updaters += { isSelected = on(); setTextColor(if (on()) Theme.onAccent else Theme.text); label?.let { l -> this.text = l() } }
        }
        val frame = LinearLayout(a)
        frame.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, a.dp(48)))
        return frame
    }

    /** A row of toggle buttons that share the width. */
    private fun chips(items: List<Pair<String, String>>, size: Float, isOn: (String) -> Boolean, flip: (String) -> Unit): View {
        val line = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEachIndexed { i, (id, text) ->
            val chip = TextView(a).apply {
                this.text = text; textSize = size; gravity = Gravity.CENTER; isFocusable = true; isClickable = true; setSingleLine(true)
                background = StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_focused, android.R.attr.state_selected), shape(Theme.accent, Theme.text, 3))
                    addState(intArrayOf(android.R.attr.state_focused), shape(Theme.bg, Theme.text, 3))
                    addState(intArrayOf(android.R.attr.state_selected), shape(Theme.accent, Theme.accent, 2))
                    addState(intArrayOf(), shape(Theme.bg, Theme.accent, 2))
                }
                setOnClickListener { flip(id) }
                updaters += { isSelected = isOn(id); setTextColor(if (isOn(id)) Theme.onAccent else Theme.text) }
            }
            line.addView(chip, LinearLayout.LayoutParams(0, a.dp(46), 1f).apply { if (i > 0) marginStart = a.dp(6) })
        }
        return line
    }
}
