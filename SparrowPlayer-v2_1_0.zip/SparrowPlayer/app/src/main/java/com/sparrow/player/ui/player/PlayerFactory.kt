package com.sparrow.player.ui.player

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import com.sparrow.player.data.Prefs
import com.sparrow.player.util.repo

/** One place to tune ExoPlayer for IPTV (raw MPEG-TS, HLS, VOD containers) on TV hardware. */
@OptIn(UnstableApi::class)
object PlayerFactory {
    fun create(ctx: Context): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(Prefs.UA)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true)

        val extractors = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                    DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
            )

        val mediaSources = DefaultMediaSourceFactory(ctx, extractors)
            .setDataSourceFactory(DefaultDataSource.Factory(ctx, http))

        val renderers = DefaultRenderersFactory(ctx)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)

        val prefsForBuffer = ctx.repo.prefs
        val b = bufferFor(prefsForBuffer.bufferMode, prefsForBuffer.connectionClass)
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(b[0], b[1], b[2], b[3])
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val player = ExoPlayer.Builder(ctx, renderers)
            .setMediaSourceFactory(mediaSources)
            .setLoadControl(load)
            .setHandleAudioBecomingNoisy(true)
            .build()

        // Preferred audio language / subtitles from Settings -> General (used whenever a stream offers that track).
        val prefs = ctx.repo.prefs
        val tp = player.trackSelectionParameters.buildUpon()
        if (prefs.audioLang.isNotBlank()) tp.setPreferredAudioLanguage(prefs.audioLang)
        when (val sub = prefs.subtitleLang) {
            "" -> Unit
            "off" -> tp.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            else -> tp.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setPreferredTextLanguage(sub)
        }
        // Playback quality / audio quality (Settings -> Playback): caps only, "best" leaves the player free to take the highest it can
        when (prefs.videoQuality) {
            "2160" -> tp.setMaxVideoSize(3840, 2160)
            "1080" -> tp.setMaxVideoSize(1920, 1080)
            "720" -> tp.setMaxVideoSize(1280, 720)
            "480" -> tp.setMaxVideoSize(854, 480)
            else -> Unit
        }
        prefs.audioQuality.toIntOrNull()?.let { tp.setMaxAudioChannelCount(it) }
        player.trackSelectionParameters = tp.build()
        return player
    }

    /**
     * Buffer sizes in ms: [min buffer, max buffer, start playback after, resume after a stall].
     * "auto" follows the last "Optimise For My Connection" check (class 1 = very steady ... 4 = poor); never measured = balanced.
     */
    fun bufferFor(mode: String, connectionClass: Int): IntArray {
        val m = if (mode == "auto") when (connectionClass) { 1 -> "fast"; 3 -> "stable"; 4 -> "max"; else -> "balanced" } else mode
        return when (m) {
            "fast" -> intArrayOf(8_000, 30_000, 1_500, 3_000)
            "stable" -> intArrayOf(30_000, 90_000, 3_000, 6_000)
            "max" -> intArrayOf(60_000, 150_000, 5_000, 10_000)
            else -> intArrayOf(15_000, 50_000, 2_000, 4_000)
        }
    }
}
