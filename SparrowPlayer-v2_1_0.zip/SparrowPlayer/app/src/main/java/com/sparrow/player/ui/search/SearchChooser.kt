package com.sparrow.player.ui.search

import android.app.Activity
import android.app.Dialog
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.TextView
import com.sparrow.player.data.SearchKind
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp

/**
 * "What would you like to search?" - three big buttons (Live Channels, Movies, Series). The one picked becomes the Type filter of the search
 * window; every other filter stays available there. Live Channels has the focus first; Back closes it.
 */
object SearchChooser {
    fun show(a: Activity, onPick: (SearchKind) -> Unit) {
        if (a.isFinishing) return
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(32), a.dp(28), a.dp(32), a.dp(24)) }
        col.addView(TextView(a).apply {
            text = "What would you like to search?"; textSize = 28f; tag = "t:text"; gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = a.dp(18) })

        fun shape(stroke: Int, width: Int) = GradientDrawable().apply { setColor(Theme.accent); cornerRadius = a.dp(26).toFloat(); if (width > 0) setStroke(a.dp(width), stroke) }
        var first: View? = null
        listOf(SearchKind.LIVE to "📡", SearchKind.MOVIE to "🎬", SearchKind.SERIES to "📺").forEach { (k, icon) ->
            val btn = TextView(a).apply {
                text = "$icon   ${k.label}"; textSize = 26f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
                setTextColor(Theme.onAccent); isFocusable = true; isClickable = true
                background = StateListDrawable().apply {
                    addState(intArrayOf(android.R.attr.state_focused), shape(Theme.text, 4))      // the focus ring
                    addState(intArrayOf(), shape(Theme.accent, 0))
                }
                setOnClickListener { d.dismiss(); onPick(k) }
            }
            if (first == null) first = btn
            col.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, a.dp(76)).apply { bottomMargin = a.dp(12) })
        }
        col.addView(TextView(a).apply {
            text = "Pick one and it fills in the Type filter for you. Every other filter is still available."
            textSize = 16f; tag = "t:dim"; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = a.dp(6) })
        Theme.applyTree(col)
        d.setContentView(col)
        d.show()
        d.window?.apply {
            setBackgroundDrawable(GradientDrawable().apply { setColor(Theme.bg); cornerRadius = a.dp(20).toFloat() })
            setLayout(a.dp(620), ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.7f)
        }
        first?.requestFocus()
    }
}
