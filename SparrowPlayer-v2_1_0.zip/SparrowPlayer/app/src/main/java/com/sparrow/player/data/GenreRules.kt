package com.sparrow.player.data

/**
 * Keyword filters for the genre groups of Movies / Series, on top of the provider's genre / category text ([Genres]).
 *
 * Why: a panel's movie list carries NO genre, only a category name ("NEW RELEASES", "4K"), so a film filed there never reached Action or Horror;
 * and a word list alone lets the wrong titles in (a "boxing" film in a "Boxing Day" list, "Love, Death & Robots" in Romance). Each genre can therefore have:
 *
 *  - [Rules.titleIn]      phrases that put a title IN when they are in its NAME ("john wick", "the conjuring"). Whole words / phrases only, never one common word.
 *  - [Rules.titleInSets]  SETS of words: a title that has ALL of them (any order) is IN ("falling" + "love").
 *  - [Rules.plotInSets]   the same for the DESCRIPTION (series descriptions and the plots remembered from details pages).
 *  - [Rules.out]          phrases that keep a title OUT when they are in its name or its genre / category text ("rocky horror" is not a sports film).
 *  - [Rules.outSets]      SETS of words that keep a title OUT when the name has all of them ("boxing" + "day").
 *
 * OUT always wins over IN. All words are in [TextNorm] form (lower case, every punctuation mark = one space: "ocean s eleven").
 * Pure Kotlin, unit tested ([GenreRulesTest]) and mirrored by tools/v20_model_test.py.
 */
object GenreRules {
    class Rules(
        val titleIn: List<String> = emptyList(),
        val titleInSets: List<List<String>> = emptyList(),
        val plotInSets: List<List<String>> = emptyList(),
        val out: List<String> = emptyList(),
        val outSets: List<List<String>> = emptyList()
    )

    private fun hasAll(prepared: String, words: List<String>) = words.isNotEmpty() && words.all { prepared.contains(" $it ") }
    private fun anySet(prepared: String, sets: List<List<String>>) = sets.any { hasAll(prepared, it) }

    val RULES: Map<String, Rules> = mapOf(
        "action" to Rules(
            titleIn = listOf("mission impossible", "fast and furious", "fast furious", "die hard", "john wick", "mad max", "jason bourne", "bourne identity", "bourne supremacy", "bourne ultimatum",
                "lethal weapon", "rambo", "the expendables", "kill bill", "james bond", "casino royale", "skyfall", "top gun", "bad boys", "rush hour", "the equalizer", "terminator", "predator",
                "robocop", "the raid", "ip man", "crouching tiger", "transformers", "pirates of the caribbean", "indiana jones", "the mummy", "the fugitive", "speed racer", "the bourne"),
            out = listOf("adventure time", "adventures in babysitting", "adventures of rocky and bullwinkle")
        ),
        "anime" to Rules(
            titleIn = listOf("dragon ball", "naruto", "one piece", "attack on titan", "demon slayer", "jujutsu kaisen", "my hero academia", "sailor moon", "cowboy bebop", "fullmetal alchemist",
                "spirited away", "studio ghibli", "death note", "hunter x hunter", "one punch man", "neon genesis evangelion", "pokemon", "digimon", "yu gi oh", "sword art online")
        ),
        "family" to Rules(
            titleIn = listOf("pixar", "dreamworks", "muppet", "muppets", "paddington", "stuart little", "charlotte s web", "homeward bound", "free willy", "the parent trap", "home alone"),
            outSets = listOf(listOf("horror", "family"), listOf("family", "guy"), listOf("family", "massacre"))
        ),
        "comedies" to Rules(
            titleIn = listOf("scary movie", "american pie", "meet the parents", "meet the fockers", "the hangover", "dumb and dumber", "anchorman", "step brothers", "superbad", "naked gun",
                "ace ventura", "austin powers", "wayne s world", "ghostbusters", "zoolander", "borat", "blazing saddles", "monty python", "caddyshack", "tropic thunder", "pineapple express",
                "horrible bosses", "bridesmaids", "wedding crashers", "old school", "talladega nights", "coming to america", "police academy", "night at the museum", "johnny english",
                "mr bean", "big daddy", "happy gilmore", "billy madison", "grown ups", "blades of glory", "brooklyn nine nine", "parks and recreation", "parks recreation", "the office", "schitt s creek", "seinfeld",
                "how i met your mother", "big bang theory", "arrested development", "curb your enthusiasm", "modern family", "30 rock"),
            titleInSets = listOf(listOf("stand", "up", "comedian")),
            out = listOf("comedy of errors", "family guy"),
            outSets = listOf(listOf("comedy", "central", "roast", "documentary"))
        ),
        "standup" to Rules(
            titleIn = listOf("stand up", "standup", "live at the apollo", "comedy special", "netflix is a joke", "comedy central presents", "just for laughs", "def comedy jam", "last comic standing"),
            out = listOf("stand up guys", "standup guys", "stand up to cancer", "stand up speak up")
        ),
        "crime" to Rules(
            titleIn = listOf("true crime", "law and order", "law order", "criminal minds", "narcos", "breaking bad", "the sopranos", "peaky blinders", "the godfather", "goodfellas", "scarface", "the wire", "ozark",
                "money heist", "mindhunter", "dexter", "making a murderer", "the untouchables", "donnie brasco", "reservoir dogs", "pulp fiction", "ocean s eleven", "ocean s twelve",
                "ocean s thirteen", "the italian job", "inside man", "dog day afternoon", "american gangster", "better call saul", "boardwalk empire", "the departed"),
            plotInSets = listOf(listOf("organized", "crime"), listOf("crime", "family"), listOf("drug", "cartel"), listOf("bank", "robbery"), listOf("private", "detective")),
            out = listOf("crime and punishment of", "heat wave", "heat of the night")
        ),
        "cult" to Rules(
            titleIn = listOf("rocky horror", "the big lebowski", "donnie darko", "fight club", "evil dead", "mystery science theater", "army of darkness", "repo man", "heathers", "clerks",
                "office space", "napoleon dynamite", "a clockwork orange", "blade runner", "the princess bride", "big trouble in little china", "they live", "re animator")
        ),
        "documentaries" to Rules(
            titleIn = listOf("a documentary", "the documentary", "planet earth", "blue planet", "our planet", "the last dance", "free solo", "my octopus teacher", "life on our planet", "the vietnam war",
                "the civil war", "jim and andy", "won t you be my neighbor", "tiger king", "the staircase", "wild wild country", "the jinx", "seaspiracy", "cowspiracy", "the social dilemma",
                "dirty money", "chef s table", "30 for 30", "frontline", "the true story of"),
            plotInSets = listOf(listOf("documentary", "follows"), listOf("documentary", "explores"), listOf("documentary", "film")),
            out = listOf("mockumentary", "documentary now", "this is spinal tap", "documentary of horror")
        ),
        "dramas" to Rules(
            titleIn = listOf("downton abbey", "the crown", "mad men", "this is us", "succession", "the good doctor", "grey s anatomy", "the handmaid s tale", "house of cards", "the leftovers",
                "six feet under", "friday night lights", "yellowstone", "outlander", "bridgerton", "the queen s gambit", "the good wife", "better call saul"),
            plotInSets = listOf(listOf("based", "true", "story"), listOf("based", "real", "events"), listOf("based", "true", "events")),
            out = listOf("drama queen", "drama club")
        ),
        "faith" to Rules(
            titleIn = listOf("the chosen", "the passion of the christ", "son of god", "god s not dead", "i can only imagine", "fireproof", "courageous", "facing the giants", "the bible",
                "the prince of egypt", "the nativity story", "gospel", "jesus christ", "bible", "christian movie"),
            plotInSets = listOf(listOf("jesus", "christ"), listOf("bible", "story"), listOf("faith", "god"), listOf("church", "pastor")),
            out = listOf("christian grey", "christian slater", "christian bale", "jesus camp", "jesus and mary chain", "bible black")
        ),
        "horror" to Rules(
            titleIn = listOf("nightmare on elm street", "friday the 13th", "texas chainsaw", "texas chain saw", "the conjuring", "annabelle", "paranormal activity", "the exorcist", "final destination",
                "evil dead", "hellraiser", "the purge", "insidious", "sinister", "the grudge", "resident evil", "silent hill", "a quiet place", "pet sematary", "child s play", "the nun",
                "poltergeist", "night of the living dead", "dawn of the dead", "the walking dead", "halloween kills", "halloween ends", "the haunting of", "american horror story", "scream"),
            titleInSets = listOf(listOf("haunted", "house"), listOf("night", "living", "dead")),
            plotInSets = listOf(listOf("haunted", "house"), listOf("demonic", "possession"), listOf("evil", "spirit")),
            out = listOf("scary movie", "horror of the deep", "little shop of horrors", "scream queens")
        ),
        "music" to Rules(
            titleIn = listOf("live in concert", "in concert", "unplugged", "the sound of music", "bohemian rhapsody", "rocketman", "mamma mia", "les miserables", "phantom of the opera", "grease",
                "dirty dancing", "la la land", "the greatest showman", "hamilton", "west side story", "footloose", "pitch perfect", "high school musical", "sing street", "walk the line",
                "a star is born", "the blues brothers", "moulin rouge", "hairspray"),
            titleInSets = listOf(listOf("live", "tour"), listOf("world", "tour")),
            out = listOf("music of the heart", "music box killer")
        ),
        "mysteries" to Rules(
            titleIn = listOf("murder she wrote", "agatha christie", "sherlock", "poirot", "miss marple", "knives out", "glass onion", "murder on the orient express", "death on the nile",
                "midsomer murders", "father brown", "columbo", "the girl with the dragon tattoo", "true detective", "broadchurch", "twin peaks", "endeavour"),
            out = listOf("mystery science theater")
        ),
        "reality" to Rules(
            titleIn = listOf("the bachelor", "the bachelorette", "love island", "big brother", "the amazing race", "the voice", "american idol", "america s got talent",
                "dancing with the stars", "keeping up with the kardashians", "real housewives", "masterchef", "hell s kitchen", "kitchen nightmares", "top chef", "drag race", "queer eye",
                "say yes to the dress", "love is blind", "too hot to handle", "selling sunset", "below deck", "naked and afraid", "storage wars", "pawn stars", "american pickers", "shark tank",
                "dragons den", "great british bake off", "bake off", "jersey shore", "90 day fiance", "project runway", "fear factor", "jeopardy", "wheel of fortune", "family feud",
                "the price is right", "who wants to be a millionaire", "deal or no deal", "saturday night live", "the daily show", "dr phil"),
            outSets = listOf(listOf("reality", "bites"))
        ),
        // note: "&" disappears when a title is normalised ("Love, Death & Robots" = "love death robots"), so rules are written without it where a title may use it
        "romance" to Rules(
            titleIn = listOf("love actually", "the notebook", "pride and prejudice", "pretty woman", "when harry met sally", "sleepless in seattle", "you ve got mail", "notting hill", "the proposal",
                "crazy rich asians", "to all the boys", "about time", "a walk to remember", "dear john", "the vow", "titanic", "10 things i hate about you", "how to lose a guy in 10 days",
                "sweet home alabama", "romeo and juliet", "love story"),
            titleInSets = listOf(listOf("falling", "love"), listOf("wedding", "planner"), listOf("marry", "me")),
            out = listOf("love death and robots", "love death robots")
        ),
        "scifi" to Rules(
            titleIn = listOf("star wars", "star trek", "the matrix", "blade runner", "back to the future", "jurassic park", "jurassic world", "alien vs predator", "avatar", "dune", "interstellar",
                "inception", "total recall", "minority report", "ready player one", "guardians of the galaxy", "doctor who", "the mandalorian", "stranger things", "black mirror", "westworld",
                "the expanse", "the twilight zone", "battlestar galactica", "firefly", "the x files", "stargate", "lost in space", "altered carbon", "severance", "ex machina", "the martian", "edge of tomorrow",
                "district 9", "the hunger games", "divergent", "the maze runner", "planet of the apes", "war of the worlds", "terminator", "robocop"),
            plotInSets = listOf(listOf("outer", "space"), listOf("alien", "invasion"), listOf("time", "travel"), listOf("post", "apocalyptic"), listOf("artificial", "intelligence"), listOf("distant", "planet")),
            out = listOf("sci fi channel original comedy")
        ),
        "sports" to Rules(
            titleIn = listOf("rocky", "creed", "raging bull", "cinderella man", "million dollar baby", "the fighter", "moneyball", "remember the titans", "friday night lights", "hoosiers", "rudy",
                "field of dreams", "the blind side", "coach carter", "space jam", "the mighty ducks", "the sandlot", "major league", "bull durham", "cobra kai", "ted lasso", "drive to survive",
                "formula 1", "the last dance", "hard knocks", "30 for 30", "wrestlemania", "ufc", "wwe", "nba", "nfl", "nhl", "mlb", "premier league", "champions league", "world cup",
                "olympics", "tour de france", "wimbledon", "stanley cup", "super bowl"),
            plotInSets = listOf(listOf("boxing", "champion"), listOf("football", "team"), listOf("basketball", "team"), listOf("hockey", "team"), listOf("baseball", "team")),
            out = listOf("rocky horror", "rocky road", "rocky mountain", "miracle on 34th street", "world cup of cooking"),
            outSets = listOf(listOf("boxing", "day"))
        ),
        "thrillers" to Rules(
            titleIn = listOf("the silence of the lambs", "se7en", "gone girl", "shutter island", "zodiac", "the girl on the train", "gone baby gone", "nightcrawler", "misery", "cape fear",
                "fatal attraction", "basic instinct", "the usual suspects", "memento", "the departed", "no country for old men", "a simple plan", "the fugitive", "enemy of the state",
                "jack ryan", "jack reacher", "the night manager", "killing eve", "mr robot", "the sinner", "the undoing", "sharp objects", "big little lies")
        ),
        "teen" to Rules(
            titleIn = listOf("high school musical", "mean girls", "clueless", "the breakfast club", "pretty little liars", "riverdale", "gossip girl", "13 reasons why", "euphoria", "never have i ever",
                "the vampire diaries", "teen wolf", "glee", "degrassi", "dawson s creek", "one tree hill", "the o c", "90210", "sex education", "heartstopper", "to all the boys",
                "the fault in our stars", "the perks of being a wallflower", "easy a", "booksmart", "lady bird", "twilight", "10 things i hate about you", "she s all that"),
            out = listOf("teen titans", "teenage mutant ninja turtles", "teen mom", "twilight zone")
        ),
        "war" to Rules(
            titleIn = listOf("saving private ryan", "band of brothers", "the pacific", "full metal jacket", "apocalypse now", "platoon", "the thin red line", "dunkirk", "1917", "hacksaw ridge",
                "black hawk down", "we were soldiers", "the hurt locker", "letters from iwo jima", "flags of our fathers", "enemy at the gates", "the bridge on the river kwai", "the great escape",
                "a bridge too far", "where eagles dare", "patton", "tora tora tora", "pearl harbor", "midway", "greyhound", "the longest day", "inglourious basterds",
                "all quiet on the western front", "paths of glory", "das boot"),
            plotInSets = listOf(listOf("world", "war", "ii"), listOf("wwii"), listOf("soldiers", "battlefield"), listOf("platoon", "enemy")),
            out = listOf("star wars", "war of the worlds", "war games", "war of the roses", "world war z", "war for the planet of the apes", "war machine", "star trek", "clone wars")
        ),
        "westerns" to Rules(
            titleIn = listOf("the good the bad and the ugly", "a fistful of dollars", "for a few dollars more", "once upon a time in the west", "unforgiven", "tombstone", "true grit",
                "the searchers", "stagecoach", "rio bravo", "high noon", "django unchained", "the magnificent seven", "butch cassidy", "the outlaw josey wales", "3 10 to yuma", "open range",
                "hell or high water", "dances with wolves", "wyatt earp", "the lone ranger", "bonanza", "gunsmoke", "lonesome dove", "deadwood", "the ballad of buster scruggs",
                "the power of the dog", "the harder they fall", "rawhide", "wagon train"),
            out = listOf("western front", "western europe", "western union", "western digital")
        )
    )

    /** Position of [mainId] in [Genres.MAIN] (the bit used by every mask below); -1 if unknown. */
    fun indexOf(mainId: String): Int = Genres.MAIN.indexOfFirst { it.id == mainId }

    private val bitOf: Map<String, Int> by lazy { HashMap<String, Int>().also { m -> Genres.MAIN.forEachIndexed { i, g -> if (i <= 30) m[g.id] = 1 shl i } } }

    // ---- the reference (slow, plain) answer: what the TITLE and the genre / category text say about ONE genre ----------------------------------------
    /** +1 = put in (a title phrase or word set), -1 = keep out, 0 = nothing. [namePrepared] / [genrePrepared]: [TextNorm.prepare] forms of the title and of "genre + category". */
    fun verdict(m: Genres.Main, namePrepared: String, genrePrepared: String): Int {
        val r = RULES[m.id] ?: return 0
        if (r.out.isNotEmpty() && (TextNorm.hasAny(namePrepared, r.out) || TextNorm.hasAny(genrePrepared, r.out))) return -1
        if (r.outSets.isNotEmpty() && anySet(namePrepared, r.outSets)) return -1
        if (r.titleIn.isNotEmpty() && TextNorm.hasAny(namePrepared, r.titleIn)) return 1
        if (r.titleInSets.isNotEmpty() && anySet(namePrepared, r.titleInSets)) return 1
        return 0
    }

    // ---- the fast answer for ALL genres at once (used while the catalogue is built: one pass over the title, not ~30 phrases x 25 genres) ---------------
    private class Phrase(val text: String, val bit: Int)
    private class Idx(val m: Map<String, List<Phrase>>)
    private class SetRule(val bit: Int, val words: List<String>)

    private fun index(pick: (Rules) -> List<String>): Idx {
        val m = HashMap<String, MutableList<Phrase>>()
        for ((id, r) in RULES) {
            val bit = bitOf[id] ?: continue
            for (w in pick(r)) m.getOrPut(w.substringBefore(' ')) { ArrayList() }.add(Phrase(" $w ", bit))
        }
        return Idx(m)
    }

    private val inIdx: Idx by lazy { index { it.titleIn } }
    private val outIdx: Idx by lazy { index { it.out } }
    private val inSets: List<SetRule> by lazy { RULES.flatMap { (id, r) -> r.titleInSets.map { SetRule(bitOf[id] ?: 0, it) } } }
    private val outSets: List<SetRule> by lazy { RULES.flatMap { (id, r) -> r.outSets.map { SetRule(bitOf[id] ?: 0, it) } } }

    private fun scan(prepared: String, idx: Idx): Int {
        var mask = 0
        val n = prepared.length
        var i = 0
        while (i < n) {
            if (prepared[i] == ' ' && i + 1 < n && prepared[i + 1] != ' ') {
                var j = i + 1
                while (j < n && prepared[j] != ' ') j++
                val cands = idx.m[prepared.substring(i + 1, j)]
                if (cands != null) for (c in cands) if (prepared.startsWith(c.text, i)) mask = mask or c.bit
                i = j
            } else i++
        }
        return mask
    }

    private fun setBits(prepared: String, rules: List<SetRule>): Int {
        var m = 0
        for (r in rules) if (hasAll(prepared, r.words)) m = m or r.bit
        return m
    }

    /** Bit i = the TITLE puts the title IN genre [Genres.MAIN][i]. */
    fun titleInBits(namePrepared: String): Int = scan(namePrepared, inIdx) or setBits(namePrepared, inSets)

    /** Bit i = the TITLE keeps the title OUT of genre [i]. */
    fun titleOutBits(namePrepared: String): Int = scan(namePrepared, outIdx) or setBits(namePrepared, outSets)

    /** Bit i = a screen-out phrase of genre [i] is in this genre / category text (worked out once per distinct text, not per title). */
    fun genreTextOutBits(genrePrepared: String): Int = scan(genrePrepared, outIdx)

    /** Bit i = the DESCRIPTION ([plotPrepared]) puts the title IN genre [i]. */
    fun plotInBits(plotPrepared: String): Int {
        var bits = 0
        for ((id, r) in RULES) if (r.plotInSets.isNotEmpty() && anySet(plotPrepared, r.plotInSets)) bits = bits or (bitOf[id] ?: 0)
        return bits
    }

    /** Bit i = the name and the description TOGETHER have all the words of a screen-out set of genre [i]. */
    fun plotOutBits(namePrepared: String, plotPrepared: String): Int {
        var bits = 0
        val both = namePrepared + plotPrepared
        for ((id, r) in RULES) if (r.outSets.isNotEmpty() && anySet(both, r.outSets)) bits = bits or (bitOf[id] ?: 0)
        return bits
    }
}
