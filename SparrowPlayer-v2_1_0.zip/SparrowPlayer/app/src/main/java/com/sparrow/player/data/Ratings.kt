package com.sparrow.player.data

/**
 * "Loved It / Liked It / Disliked It": a deliberately simple three-step (Likert style) verdict, separate from the 0 - 10 ratings. It is a stronger
 * statement of taste than a number and drives the recommendations (see [Recommender.profile]). Stored in one preference string. Pure Kotlin.
 */
class UserRatings {
    private val map = LinkedHashMap<String, String>()

    fun get(uid: String): String = map[uid] ?: ""

    /** Setting the same verdict again removes it (press "Loved It" twice = not rated). */
    fun toggle(uid: String, code: String) { if (map[uid] == code) map.remove(uid) else map[uid] = code }

    fun clear(uid: String) { map.remove(uid) }

    fun all(): Map<String, String> = map

    fun serialize(): String = map.entries.joinToString("") { "${it.key}\t${it.value}\n" }

    companion object {
        const val LOVED = "loved"
        const val LIKED = "liked"
        const val DISLIKED = "disliked"
        val CODES = listOf(LOVED, LIKED, DISLIKED)
        fun label(code: String) = when (code) { LOVED -> "Loved It"; LIKED -> "Liked It"; DISLIKED -> "Disliked It"; else -> "" }

        fun parse(s: String?): UserRatings {
            val r = UserRatings()
            if (s.isNullOrBlank()) return r
            for (line in s.split('\n')) {
                val f = line.split('\t')
                if (f.size >= 2 && f[1] in CODES) r.map[f[0]] = f[1]
            }
            return r
        }
    }
}

/**
 * The two star ratings shown on every poster, both on the provider's 0 - 10 scale (-1 = unknown):
 *
 *  - Provider rating: what the IPTV provider's metadata says, to one decimal (7.3, 8.7, 9).
 *  - Sparrow Rating: the user's OWN rating of a title, picked from a 0.5 - 10 drop down in half steps (see [SparrowScores]).
 *
 * "Loved It / Liked It / Disliked It" ([UserRatings]) is a separate, simpler three-step scale that tells the recommendations more strongly
 * what the user likes.
 */
object SparrowRating {
    /** The drop down: 0.5, 1, 1.5 ... 10. */
    val STEPS: List<Double> = (1..20).map { it * 0.5 }

    /** Provider score, 0 - 10 with one decimal; -1 when the panel gave none (or 0). */
    fun providerOf(raw: String): Double {
        val v = raw.trim().toDoubleOrNull() ?: return -1.0
        return if (v <= 0.0) -1.0 else Math.round(v.coerceAtMost(10.0) * 10.0) / 10.0
    }

    fun roundHalf(x: Double): Double = Math.round(x * 2.0) / 2.0

    /** "7.3", "8.5", "9" (a whole number never gets ".0"); "" when unknown. */
    fun format(v: Double): String {
        if (v <= 0.0) return ""
        val tenths = Math.round(v * 10.0).toInt()
        return if (tenths % 10 == 0) (tenths / 10).toString() else "${tenths / 10}.${tenths % 10}"
    }
}

/** The user's own Sparrow Ratings (title uid -> 0.5 .. 10 in half steps), kept in one preference string. Pure Kotlin. */
class SparrowScores {
    private val map = LinkedHashMap<String, Double>()

    /** -1 when the user has not rated the title. */
    fun get(uid: String): Double = map[uid] ?: -1.0

    /** uid -> rating, copied. */
    fun all(): Map<String, Double> = LinkedHashMap(map)

    /** A value of 0 or less removes the rating ("Not Rated"); anything else is clamped to 0.5 - 10 and rounded to a half step. */
    fun set(uid: String, value: Double) {
        if (value <= 0.0) map.remove(uid) else map[uid] = SparrowRating.roundHalf(value.coerceIn(0.5, 10.0))
    }

    fun serialize(): String = map.entries.joinToString("") { "${it.key}\t${it.value}\n" }

    companion object {
        fun parse(s: String?): SparrowScores {
            val r = SparrowScores()
            if (s.isNullOrBlank()) return r
            for (line in s.split('\n')) {
                val f = line.split('\t')
                val v = f.getOrNull(1)?.toDoubleOrNull()
                if (f.size >= 2 && v != null && v > 0.0) r.map[f[0]] = SparrowRating.roundHalf(v.coerceIn(0.5, 10.0))
            }
            return r
        }
    }
}

/**
 * What the panel's info call told us about a title (length in minutes, maturity rating, plot), remembered when a details page is
 * opened so search can use it later. One preference string, pure Kotlin.
 */
class MetaCache {
    class Meta(val lengthMin: Int, val maturity: String, val plot: String)

    private val map = LinkedHashMap<String, Meta>()

    fun get(uid: String): Meta? = map[uid]

    fun all(): Map<String, Meta> = LinkedHashMap(map)

    /** uid -> rating text the panel gave, for the titles that have one. */
    fun maturities(): Map<String, String> {
        val out = HashMap<String, String>()
        for ((k, m) in map) if (m.maturity.isNotBlank()) out[k] = m.maturity
        return out
    }

    fun put(uid: String, lengthMin: Int, maturity: String, plot: String) {
        val old = map[uid]
        map[uid] = Meta(
            if (lengthMin >= 0) lengthMin else old?.lengthMin ?: -1,
            maturity.ifBlank { old?.maturity ?: "" },
            plot.take(PLOT_MAX).ifBlank { old?.plot ?: "" }
        )
        while (map.size > MAX_ENTRIES) map.remove(map.keys.first())            // oldest first
    }

    fun serialize(): String = map.entries.joinToString("") { (k, m) -> "$k\t${m.lengthMin}\t${esc(m.maturity)}\t${esc(m.plot)}\n" }

    companion object {
        const val PLOT_MAX = 300
        const val MAX_ENTRIES = 1500

        fun parse(s: String?): MetaCache {
            val c = MetaCache()
            if (s.isNullOrBlank()) return c
            for (line in s.split('\n')) {
                val f = line.split('\t')
                if (f.size >= 4) c.map[f[0]] = Meta(f[1].toIntOrNull() ?: -1, unesc(f[2]), unesc(f[3]))
            }
            return c
        }

        private fun esc(s: String) = s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "")
        private fun unesc(s: String): String {
            val sb = StringBuilder(); var i = 0
            while (i < s.length) {
                val ch = s[i]
                if (ch == '\\' && i + 1 < s.length) { sb.append(when (s[i + 1]) { 't' -> '\t'; 'n' -> '\n'; else -> s[i + 1] }); i += 2 }
                else { sb.append(ch); i++ }
            }
            return sb.toString()
        }

        /** "01:45:30", "105", "1h 45min", "105 min", "1:45" -> minutes (-1 if it is not a length). */
        fun lengthMinutes(raw: String): Int {
            val s = raw.trim().lowercase()
            if (s.isEmpty()) return -1
            Regex("^(\\d{1,2}):(\\d{2}):(\\d{2})$").find(s)?.let { return it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt() }
            Regex("^(\\d{1,2}):(\\d{2})$").find(s)?.let { return it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt() }
            val h = Regex("(\\d+)\\s*h").find(s)?.groupValues?.get(1)?.toInt()
            val m = Regex("(\\d+)\\s*m").find(s)?.groupValues?.get(1)?.toInt()
            if (h != null || m != null) return (h ?: 0) * 60 + (m ?: 0)
            return s.toIntOrNull()?.takeIf { it in 1..1000 } ?: -1
        }
    }
}
