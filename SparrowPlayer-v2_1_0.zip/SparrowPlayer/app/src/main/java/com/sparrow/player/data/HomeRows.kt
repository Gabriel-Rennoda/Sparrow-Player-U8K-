package com.sparrow.player.data

/**
 * The named carousels of the Movies / Series home and of every holiday page. Pure Kotlin (JUnit tested): it only sees [RowTitle]s and a
 * [RowCtx] and returns [RowSpec]s (a heading and the uids to show); the screen turns uids into posters.
 *
 * Honest limits - an IPTV panel's lists carry no viewing statistics, so "Top 10 ... Today" and "Trending Now" are ranked by a transparent
 * proxy: provider rating + how recently the title was added + a small daily shuffle (so the list moves from day to day).
 * Rows built from genres use [Genres] (category / genre text, never the title); a few mood rows also look for words in the title.
 * A row with too few titles is simply not shown.
 */
class RowTitle(
    val uid: String, val name: String, val category: String, val genre: String,
    val year: Int, val rating: Double, val added: Long,
    prep: Prep? = null
) {
    /**
     * What is worked out from a (category, genre) pair: there are only a few hundred different pairs among 100 000 titles, so the catalogue
     * builds each once and every title of the pair shares it (the old code normalised the same text for every single title).
     */
    class Prep(val prepared: String, val categoryNorm: String, val tags: Set<String>, val holidays: Int, val adult: Boolean = false, val genreOut: Int = 0) {
        companion object {
            fun of(category: String, genre: String): Prep {
                val prepared = TextNorm.prepare("$genre $category")
                return Prep(prepared, TextNorm.prepare(category), HomeRows.tagsOf(prepared), Holidays.maskOfCategory(prepared), Holidays.adultCategory(prepared), GenreRules.genreTextOutBits(prepared))
            }

            /** For a title that sits in several provider categories (the same film listed twice): the texts of all of them together, so it carries every genre. */
            fun ofPrepared(prepared: String, categoryNorm: String): Prep =
                Prep(prepared, categoryNorm, HomeRows.tagsOf(prepared), Holidays.maskOfCategory(prepared), Holidays.adultCategory(prepared), GenreRules.genreTextOutBits(prepared))
        }
    }

    var prep: Prep = prep ?: Prep.of(category, genre)
        private set
    /** Index of the first catalogue entry that is the same title (name + year) - copies of one film in several categories share it; -1 = not worked out. */
    var group: Int = -1
    /** Made for children (a Kids category / well-known children's title that passes the age screen): such titles stay in Kids and are left out of the grown-up genre rows. */
    var kidsOnly: Boolean = false
    fun mergePrep(p: Prep) { prep = p }
    fun seedName(n: String) { nameNormV = n }
    /** genre + category text for genre matching */
    val prepared: String get() = prep.prepared
    val categoryNorm: String get() = prep.categoryNorm
    /** the genre tags of [Genres] this title belongs to ("action", "action:Martial Arts" ...) */
    val tags: Set<String> get() = prep.tags

    private var nameNormV: String? = null
    private var fullV: String? = null
    /** the title only; worked out on first use (most rows never need it) */
    val nameNorm: String get() = nameNormV ?: TextNorm.prepare(name).also { nameNormV = it }
    /** title + genre + category, for holiday matching */
    val full: String get() = fullV ?: TextNorm.prepare("$name $genre $category").also { fullV = it }

    /** Holidays named by the title, the category / genre or (series) the description, after the screen-out lists (see [Holidays.Holiday]): bit i = Holidays.ALL[i]. -1 = not worked out yet. */
    var holidays: Int = -1
    /** Genre filters of [GenreRules] for this title: bit i = Genres.MAIN[i] is put IN / kept OUT by its NAME (and, when a description is known, by that). The genre / category text adds [Prep.genreOut]. */
    var genreIn: Int = 0
    var genreOut: Int = 0
    fun holidayBits(): Int { if (holidays == -1) holidays = Holidays.screen(prep.holidays, nameNorm, prep.adult); return holidays }
}

class RowSpec(val title: String, val uids: List<String>)

class RowCtx(
    val nowMs: Long,
    val movies: Boolean,
    val country: String,
    val profile: String,
    val finished: List<String> = emptyList(),               // uids this profile watched to the end
    val myList: List<String> = emptyList(),                 // newest first
    val verdicts: Map<String, String> = emptyMap(),         // uid -> loved / liked / disliked, oldest first
    val maturity: Map<String, String> = emptyMap(),         // uid -> rating the panel gave (only titles whose details were opened)
    val label: String = ""                                  // the group these rows are for ("Comedies"); empty = the whole Movies / Series page
)

object HomeRows {
    const val MIN_ROW = 3
    private const val DAY_MS = 86_400_000L

    /** The most titles a row keeps. A screen shows the first [ROW_CAP] and a "See All" tile; See All opens a grid of the rest. */
    const val FULL = 300
    const val ROW_CAP = 20

    /** A "classic": released 10 or more years ago and rated 6.5 or better by the provider's own star rating (no year / no rating = not a classic). Used on every page, holidays included. */
    const val CLASSIC_YEARS = 10
    const val CLASSIC_RATING = 6.5
    fun isClassic(t: RowTitle, thisYear: Int): Boolean = t.year in 1..(thisYear - CLASSIC_YEARS) && t.rating >= CLASSIC_RATING

    // ---- tagging ----------------------------------------------------------------------------------------------------
    private val tagCache = HashMap<String, Set<String>>()

    /** The genre tags of one prepared genre + category text (cached: a few hundred different texts exist). */
    fun tagsOf(prepared: String): Set<String> = synchronized(tagCache) {
        tagCache.getOrPut(prepared) {
            val out = HashSet<String>()
            for (m in Genres.MAIN) {
                val c = Genres.classify(m, prepared)
                if (c.inMain) out += m.id
                c.subs.forEach { out += m.id + ":" + m.subs[it].name }
            }
            out
        }
    }

    private fun tags(t: RowTitle): Set<String> = t.tags
    private fun has(t: RowTitle, id: String) = id in t.tags
    private fun sub(t: RowTitle, id: String, name: String) = id in t.tags && "$id:$name" in t.tags      // (a sub-genre implies its main genre: the cheap test first)
    private fun nameHas(t: RowTitle, vararg k: String) = k.any { t.nameNorm.contains(" $it ") }
    /** Plain text search in the title WITHOUT normalising it (for rows that test every title of a 100 000 title list). */
    private fun rawHas(t: RowTitle, vararg k: String) = k.any { t.name.contains(it, ignoreCase = true) }
    private fun catHas(t: RowTitle, vararg k: String) = k.any { t.prepared.contains(" $it ") }

    // ---- streaming platforms named in category names ("NETFLIX", "Disney+ Movies" ...) ---------------------------------
    val PLATFORMS: List<Pair<String, List<String>>> = listOf(
        "Netflix" to listOf("netflix"), "Disney+" to listOf("disney plus", "disney"), "Hulu" to listOf("hulu"),
        "Prime Video" to listOf("amazon", "prime video", "prime"), "HBO Max" to listOf("hbo", "hbo max"), "Apple TV+" to listOf("apple tv", "apple"),
        "Paramount+" to listOf("paramount"), "Crave" to listOf("crave"), "Peacock" to listOf("peacock"), "Showtime" to listOf("showtime"),
        "Starz" to listOf("starz"), "Discovery+" to listOf("discovery plus", "discovery")
    )

    fun platformOf(t: RowTitle): String? = PLATFORMS.firstOrNull { (_, kw) -> kw.any { t.categoryNorm.contains(" $it ") } }?.first

    // ---- ranking proxy ----------------------------------------------------------------------------------------------
    fun addedMs(t: RowTitle): Long = if (t.added > 100_000_000_000L) t.added else t.added * 1000L

    fun trendScore(t: RowTitle, nowMs: Long): Double {
        val ageDays = if (t.added > 0) (nowMs - addedMs(t)) / DAY_MS.toDouble() else 99999.0
        val recency = when { ageDays <= 30 -> 3.0; ageDays <= 90 -> 2.0; ageDays <= 365 -> 1.0; else -> 0.0 }
        val daySeed = (nowMs / DAY_MS).toInt()
        val jitter = ((t.uid.hashCode() xor (daySeed * 31)) and 0xFF) / 255.0 * 1.2
        return t.rating + recency + jitter
    }

    private fun byRating(l: List<RowTitle>) = l.sortedByDescending { it.rating }
    /** A number that is the same all day for one title and different tomorrow (rows that should change daily). */
    private fun dayShuffle(t: RowTitle, nowMs: Long): Int = (t.uid.hashCode() xor ((nowMs / DAY_MS).toInt() * 31)) and 0xFFFF
    private fun yearOf(nowMs: Long) = Holidays.civil((nowMs / DAY_MS).toInt())[0]

    private fun similar(seed: RowTitle, all: List<RowTitle>, exclude: Set<String>): List<RowTitle> {
        val seedTags = tags(seed)
        return all.asSequence().filter { it.uid !in exclude }.map { t ->
            var s = 0.0
            if (seed.category.isNotEmpty() && t.category == seed.category) s += 2.0
            s += tags(t).count { it in seedTags }
            t to s
        }.filter { it.second > 0 }.sortedWith(compareByDescending<Pair<RowTitle, Double>> { it.second }.thenByDescending { it.first.rating }).map { it.first }.take(24).toList()
    }

    // ---- Movies / Series home ---------------------------------------------------------------------------------------
    fun build(all: List<RowTitle>, c: RowCtx): List<RowSpec> {
        val out = ArrayList<RowSpec>()
        val by = HashMap<String, RowTitle>(all.size * 2); all.forEach { by[it.uid] = it }
        fun add(title: String, l: List<RowTitle>, min: Int = MIN_ROW, max: Int = FULL) {
            val seen = HashSet<Int>()
            val u = l.filter { it.group < 0 || seen.add(it.group) }.map { it.uid }.distinct().take(max)      // a film listed in several categories is ONE card
            if (u.size >= min) out += RowSpec(title, u)
        }
        val group = c.label.isNotBlank()
        val now = c.nowMs; val year = yearOf(now)
        val grown = all.filter { !it.kidsOnly }                                  // children's titles stay in Kids: the grown-up genre / mood rows do not take them
        val ranked = all.filter { it.rating > 0 }.sortedByDescending { trendScore(it, now) }

        add(if (group) "Top 10 ${c.label} Today in ${c.country}" else if (c.movies) "Top 10 Movies Today in ${c.country}" else "Top 10 TV Shows Today in ${c.country}", ranked.take(10), min = 5, max = 10)
        if (!group) add("Top 10 Kids Titles Today", ranked.filter { (has(it, "kids") || has(it, "family")) && Maturity.familyOk(it, c.maturity[it.uid] ?: "", !c.movies) }.take(10), min = 5, max = 10)

        val mine = c.myList.mapNotNull { by[it] }
        add("My List", mine)
        mine.firstOrNull()?.let { seed -> add("Because You Added ${seed.name} to Your List", similar(seed, all, c.myList.toSet() + seed.uid)) }
        c.verdicts.entries.toList().asReversed().firstOrNull { it.value == UserRatings.LIKED }?.let { by[it.key] }
            ?.let { seed -> add("More Like ${seed.name}", similar(seed, all, setOf(seed.uid))) }

        val loved = c.verdicts.filterValues { it == UserRatings.LOVED }.keys
        add("Watch It Again", (c.finished + loved).distinct().mapNotNull { by[it] })

        add(if (group) "New ${c.label}" else "New Releases", all.filter { it.year >= year - 1 && it.year <= year }.sortedByDescending { addedMs(it) })
        add("Trending Now", all.filter { it.rating >= 6.0 }.sortedByDescending { addedMs(it) })
        add("Coming Soon", all.filter { it.year > year || catHas(it, "coming soon", "upcoming") || rawHas(it, "coming soon") }.sortedBy { it.year })

        // Classics (every page, every group): released 10+ years ago and rated 6.5+; Hidden Gems: well liked, not new, a different set every day
        if (c.label != "Classics") add(if (group) "Classic ${c.label}" else if (c.movies) "Classic Movies" else "Classic TV Shows", byRating(all.filter { isClassic(it, year) }))
        add(if (group) "Hidden Gems in ${c.label}" else "Hidden Gems", all.filter { it.rating >= 7.0 && it.rating < 8.5 && it.year in 1..(year - 2) }.sortedByDescending { dayShuffle(it, now) })

        // Popular on <platform> for the platforms named most in category names, then the rest together
        val onPlatform = all.mapNotNull { t -> platformOf(t)?.let { it to t } }.groupBy({ it.first }, { it.second })
        val top = onPlatform.entries.filter { it.value.size >= 6 }.sortedByDescending { it.value.size }.take(3)
        top.forEach { (name, l) -> add("Popular on $name", byRating(l), min = 6, max = 100) }
        val shown = top.map { it.key }.toSet()
        add("Popular on Other Platforms", byRating(onPlatform.filterKeys { it !in shown }.values.flatten()))

        // pacing & mood
        add("Slow-Burn Psychological Thrillers", byRating(grown.filter { sub(it, "thrillers", "Psychological Thrillers") || (has(it, "thrillers") && catHas(it, "slow burn", "noir")) }))
        add("Feel-Good Romantic Comedies", byRating(grown.filter { sub(it, "romance", "Romantic Comedies") || sub(it, "comedies", "Romantic Comedies") || (has(it, "romance") && has(it, "comedies")) }))
        add("Mind-Bending Sci-Fi", byRating(grown.filter { has(it, "scifi") && (nameHas(it, "mind", "twist", "reality", "dream", "dreams", "time", "paradox", "simulation", "memory", "loop", "inception", "matrix", "source", "code") || sub(it, "scifi", "Sci-Fi Thrillers") || sub(it, "scifi", "Sci-Fi Dramas")) }))
        add("Dark & Gritty Crime Dramas", byRating(grown.filter { sub(it, "crime", "Crime Dramas") || sub(it, "dramas", "Crime Dramas") || (has(it, "crime") && has(it, "dramas")) }))

        // critical acclaim
        if (!c.movies) add("Critically Acclaimed TV Dramas", byRating(grown.filter { has(it, "dramas") && it.rating >= 8.0 }))
        else add("Award-Winning Films", byRating(grown.filter { catHas(it, "oscar", "oscars", "academy award", "academy awards", "award winning", "golden globe", "bafta", "cannes") || it.rating >= 8.3 }))
        add("Academy Award Nominees", byRating(grown.filter { catHas(it, "oscar", "oscars", "academy award", "academy awards", "nominee", "nominees", "nominated") || rawHas(it, "oscar nominee") }))

        // themes & audiences
        add("Female Strong Lead Dramas", byRating(grown.filter { has(it, "dramas") && (nameHas(it, "she", "her", "woman", "women", "girl", "girls", "queen", "lady", "ladies", "mother", "sisters", "wife", "heroine", "princess", "widow", "daughters") || catHas(it, "female lead", "strong women")) }))
        add("Underdog Sports Movies", byRating(grown.filter { has(it, "sports") && (has(it, "dramas") || nameHas(it, "underdog", "rocky", "rookie", "miracle", "comeback", "champion", "coach", "team", "greatest", "glory")) }))
        add("Twisted Mysteries", byRating(grown.filter { has(it, "mysteries") || (has(it, "thrillers") && nameHas(it, "twist", "murder", "secret", "lies", "killer", "missing", "gone", "disappearance")) }))
        add("Ensemble Comedies", byRating(grown.filter { has(it, "comedies") && nameHas(it, "ensemble", "friends", "family", "wedding", "reunion", "crew", "gang", "party", "trip", "club", "brothers", "sisters", "neighbors", "squad", "weekend") }))

        // bingeable (series)
        if (!c.movies) {
            add("Quick Binge TV Shows", byRating(grown.filter { catHas(it, "miniseries", "mini series", "limited series", "limited", "mini") || rawHas(it, "miniseries", "limited series") }))
            add("30-Minute Laughs", byRating(grown.filter { has(it, "comedies") }))
            add("Casual Viewing", byRating(grown.filter { has(it, "reality") || catHas(it, "cooking", "talk show", "game show", "food", "travel", "home", "lifestyle") }))
        }

        add("Cult Followings", byRating(grown.filter { has(it, "cult") }))

        if (c.movies) {
            val fr = Franchises.detect(all.map { it.uid to it.name })
            fr.take(3).forEach { f -> add("The ${f.name.removePrefix("The ").trim()} Collection", f.uids.mapNotNull { by[it] }.sortedBy { it.year }, max = 24) }
            val trilogies = fr.filter { it.uids.size == 3 }.take(6)
            add("Trilogies", trilogies.flatMap { f -> f.uids.mapNotNull { by[it] }.sortedBy { it.year } }, max = 24)
            add("Movie Marathons", fr.filter { it.uids.size >= 4 }.take(4).flatMap { f -> f.uids.mapNotNull { by[it] }.sortedBy { it.year } }, max = 32)
        }
        return out
    }

    // ---- The Holidays -----------------------------------------------------------------------------------------------
    /** Every title that mentions the holiday in its title, its category / genre or its description (the mask is worked out once per title). */
    fun holidayPool(h: Holidays.Holiday, all: List<RowTitle>): List<RowTitle> {
        val bit = Holidays.bit(h)
        return all.filter { it.holidayBits() and bit != 0 }
    }

    /** "Top 10 What's Hot" for one holiday (the row shown in The Holidays group). */
    fun holidayTop10(h: Holidays.Holiday, all: List<RowTitle>, nowMs: Long): List<String> =
        holidayPool(h, all).sortedByDescending { trendScore(it, nowMs) }.take(10).map { it.uid }

    /** Main genres that make a poor "Christmas <genre>" row (they are rows of their own, or about the age of the audience, not the kind of story). */
    private val NOT_FOR_HOLIDAY_ROWS = setOf("kids", "family", "classics", "cult", "standup", "independent", "international", "teen", "anime", "reality")

    /** Made for children: a Kids title, a well-known children's title, or a family animation, and it passes the age screen. */
    private fun holidayKids(t: RowTitle, c: RowCtx): Boolean =
        (t.kidsOnly || has(t, "kids") || Maturity.isKidsTitle(t.nameNorm) || sub(t, "family", "Animation")) && Maturity.familyOk(t, c.maturity[t.uid] ?: "", !c.movies)

    /** For the whole family: tagged Family, passes the age screen, and is not already a children's title. */
    private fun holidayFamily(t: RowTitle, c: RowCtx): Boolean =
        has(t, "family") && !holidayKids(t, c) && Maturity.familyOk(t, c.maturity[t.uid] ?: "", !c.movies)

    /**
     * The page behind a holiday's "See All": every title of that holiday in carousels - Top 10, What's Hot, Continue Watching for [Name]
     * (uids in [inProgress], newest first), Top Picks for [Name] (recommended for you), the holiday for Kids and for the Family (age screened,
     * so Kids and Family titles always have a row of their own), Classics (10+ years old, 6.5+ stars), Newly Added, Critically Acclaimed, up to four
     * genre rows ("Christmas Comedies") and Cult Followings. [pick]: how well a title fits this profile's taste (0 = no taste known); when there
     * is none the best rated titles fill the row, so a row is never empty while the holiday has titles. A row with no title is left out.
     */
    fun holiday(h: Holidays.Holiday, all: List<RowTitle>, c: RowCtx, inProgress: List<String>, pick: (RowTitle) -> Double): List<RowSpec> {
        val pool = holidayPool(h, all)
        val by = pool.associateBy { it.uid }
        val out = ArrayList<RowSpec>()
        val year = yearOf(c.nowMs)
        val n = h.name
        fun add(title: String, l: List<RowTitle>, max: Int = FULL, min: Int = 1) {
            val seen = HashSet<Int>()
            val u = l.filter { it.group < 0 || seen.add(it.group) }.map { it.uid }.distinct().take(max); if (u.size >= min) out += RowSpec(title, u)
        }
        val hot = pool.sortedByDescending { trendScore(it, c.nowMs) }
        add("Top 10 $n Titles", hot, max = 10, min = 5)
        add("What's Hot", hot)
        val cont = inProgress.mapNotNull { by[it] }
        add("Continue Watching for ${c.profile}", cont)
        val taste = pool.map { it to pick(it) }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
        val contUids = cont.map { it.uid }.toSet()
        add("Top Picks for ${c.profile}", if (taste.isNotEmpty()) taste else byRating(pool.filter { it.uid !in contUids }))
        add("$n for Kids", byRating(pool.filter { holidayKids(it, c) }))
        add("$n for the Family", byRating(pool.filter { holidayFamily(it, c) }))
        add("$n Classics", byRating(pool.filter { isClassic(it, year) }))
        add("Newly Added $n Titles", pool.sortedByDescending { addedMs(it) })
        add("Critically Acclaimed $n", byRating(pool.filter { it.rating >= 7.5 }))
        // the genres the holiday's titles are in most (grown-up titles only: the children's ones have their rows above)
        val grown = pool.filter { !holidayKids(it, c) }
        Genres.MAIN.filter { it.id !in NOT_FOR_HOLIDAY_ROWS }
            .map { g -> g to grown.filter { has(it, g.id) } }
            .filter { it.second.size >= 4 }.sortedByDescending { it.second.size }.take(4)
            .forEach { (g, l) -> add("$n ${g.name}", byRating(l)) }
        val cult = pool.filter { has(it, "cult") || catHas(it, "cult") }
        add("Cult Followings", byRating(cult))
        return out
    }
}
