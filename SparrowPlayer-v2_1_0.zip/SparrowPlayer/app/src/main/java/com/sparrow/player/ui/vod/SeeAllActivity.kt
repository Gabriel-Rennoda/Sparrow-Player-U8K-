package com.sparrow.player.ui.vod

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.doOnLayout
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sparrow.player.data.VodItem
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * "See All": every title of one row in a poster grid. Columns are equal in width and the posters sit in the middle of their column, so the horizontal
 * spacing between posters is the same everywhere. The grid stays still while the selector moves inside what is on screen; it only scrolls when the
 * selector leaves the screen (new titles come in). The selected poster gets the white halo and grows a little (and shrinks back when the selector leaves).
 * The title of the selected poster is shown in the bar on top. Back returns to the row it came from, selector where it was.
 *
 * v2.1: only TWO rows of (much bigger) posters are on screen, filling the space under the title area; the selector moves between them and
 * at the top / bottom row the next Up / Down shifts the rows by exactly one. The title area is never drawn over (the grid clips at its top
 * edge). Left on the first column returns to the page with the side panels open.
 */
/** One cell of the See All grid (a class of its own: Kotlin does not allow a class inside an inner class). */
class SeeAllHolder(val cell: FrameLayout, val card: PosterCard) : RecyclerView.ViewHolder(cell)

class SeeAllActivity : FragmentActivity() {
    private lateinit var grid: RecyclerView
    private lateinit var head: TextView          // the carousel's name until the user scrolls, then the selected title (bold)
    private lateinit var selected: TextView      // the first title (large) until the user scrolls, then the carousel's name
    private lateinit var more: TextView
    private var entry: SeeAllStore.Entry? = null
    private var items: List<VodItem> = emptyList()
    private var span = 3
    private var moved = false
    private var firstFocusSeen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val e = SeeAllStore.get(intent.getStringExtra("token") ?: "")
        if (e == null || e.uids.isEmpty()) { finish(); return }          // the list is gone (the app was restarted): nothing to show
        entry = e

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(36), dp(6), dp(36), 0)
        }
        head = TextView(this).apply {
            textSize = 22f; setSingleLine(true); setTypeface(typeface, android.graphics.Typeface.BOLD)
            ellipsize = android.text.TextUtils.TruncateAt.END; tag = "t:text"
        }
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        selected = TextView(this).apply {
            textSize = 28f; setSingleLine(true); setTypeface(typeface, android.graphics.Typeface.BOLD)
            ellipsize = android.text.TextUtils.TruncateAt.END; text = " "; tag = "t:accent"
        }
        root.addView(selected, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(2) })

        grid = RecyclerView(this).apply {
            // clipChildren ON: a selected poster (halo, zoom) can never be drawn over the title area above; the padding leaves it room inside the grid
            clipChildren = true; clipToPadding = false
            setPadding(0, dp(20), 0, dp(8))
            itemAnimator = null
            setItemViewCacheSize(12)
            isFocusable = false
        }
        more = TextView(this).apply {
            text = "▾"; textSize = 22f; setTextColor(0xFFFFFFFF.toInt()); setPadding(dp(16), 0, dp(16), 0)
            setBackgroundResource(com.sparrow.player.R.drawable.more_arrow_bg); visibility = View.GONE; isFocusable = false
        }
        val frame = FrameLayout(this)
        frame.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(more, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.clipChildren = false
        Theme.applyAll(this, root)
        setContentView(root)
        showHeader(null)

        grid.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) { updateMore() }
        })

        lifecycleScope.launch {
            val repo = applicationContext.repo
            val p = repo.activeProvider() ?: run { finish(); return@launch }
            val type = if (e.uids.first().split(':').getOrNull(1) == "s") "series" else "movie"
            val cat = repo.catalog(p.id, type)
            val list = cat.items(e.uids)
            if (list.isEmpty()) { finish(); return@launch }
            items = list
            showHeader(0)
            // the size of the posters comes from the room the grid really has: exactly two rows fill it
            grid.doOnLayout {
                val gridH = grid.height - grid.paddingTop - grid.paddingBottom
                val rowH = gridH / 2
                val posterH = (rowH - dp(12) - dp(6)).coerceAtLeast(dp(120))
                val posterW = posterH * 2 / 3
                val cardW = posterW + dp(28)
                val avail = grid.width
                span = maxOf(3, avail / (cardW + dp(8)))
                grid.layoutManager = GridLayoutManager(this@SeeAllActivity, span)
                grid.adapter = Adapter(list, posterW, posterH, rowH)
                grid.post { grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus(); updateMore() }
            }
        }
    }

    private fun updateMore() { more.visibility = if (grid.canScrollVertically(1)) View.VISIBLE else View.GONE }

    private fun metaOf(v: VodItem): String = listOf(v.year, CardPresenter.ratingText(v)).filter { it.isNotBlank() }.let { if (it.isEmpty()) "" else "   •   " + it.joinToString("   ") }

    /**
     * Before the user scrolls: the carousel's name on top and the first title below it, large. After the first move the selected title (bold) takes the
     * top line, where the carousel's name was, and the carousel's name drops to the small line.
     */
    private fun showHeader(pos: Int?) {
        val e = entry ?: return
        val carousel = e.title + "   •   " + e.uids.size + " Titles"
        val v = if (pos != null) items.getOrNull(pos) else null
        if (!moved) {
            head.text = carousel; head.textSize = 22f; head.setTextColor(Theme.text)
            selected.text = v?.name ?: " "; selected.textSize = 28f; selected.setTextColor(Theme.accent)
        } else if (v != null) {
            head.text = v.name + metaOf(v); head.textSize = 22f; head.setTextColor(Theme.text)
            selected.text = carousel; selected.textSize = 16f; selected.setTextColor(Theme.textDim)
        }
    }

    /** Left on the first column: back to the page with the side panels open (Back keeps returning to the row). */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_DPAD_LEFT && e.action == KeyEvent.ACTION_DOWN && grid.adapter != null) {
            val f = currentFocus
            val cell = if (f != null) grid.findContainingItemView(f) else null
            val pos = if (cell != null) grid.getChildAdapterPosition(cell) else -1
            if (pos >= 0 && pos % span == 0) {
                if (e.repeatCount == 0) { SeeAllStore.panelsRequested = true; finish() }
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private inner class Adapter(val items: List<VodItem>, val posterW: Int, val posterH: Int, val rowH: Int) : RecyclerView.Adapter<SeeAllHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeeAllHolder {
            val ctx = parent.context
            val cell = FrameLayout(ctx).apply { clipChildren = false; clipToPadding = false }
            val card = PosterCard(ctx, posterW, posterH)
            cell.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            cell.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH)
            val z = ctx.dp(10).toFloat()
            card.setOnFocusChangeListener { _, has ->
                // grows a little and is drawn above its neighbours while selected; back to normal size when the selector leaves
                cell.translationZ = if (has) z else 0f
                card.animate().cancel()
                card.animate().scaleX(if (has) 1.06f else 1f).scaleY(if (has) 1.06f else 1f).setDuration(110).start()
                if (has) {
                    val pos = cell.tag as? Int
                    if (pos != null && pos in items.indices) {
                        if (!firstFocusSeen) firstFocusSeen = true else moved = true
                        showHeader(pos)
                    }
                }
            }
            return SeeAllHolder(cell, card)
        }

        override fun onBindViewHolder(h: SeeAllHolder, position: Int) {
            val v = items[position]
            val repo = h.card.context.repo
            h.cell.tag = position
            val poster = v.poster.ifBlank { repo.knownPoster(v.uid) ?: "" }
            h.card.bind(v.name, v.year, poster, repo.prefs.vodPercent(v), repo.providerRatingOf(v), repo.sparrowOf(v), v.uid) { u ->
                repo.fetchPoster(v) { url -> if (url != v.poster) h.card.latePoster(u, url) }
            }
            h.card.setOnClickListener {
                val en = entry
                startActivity(DetailsActivity.intent(this@SeeAllActivity, v.uid, en?.holiday ?: false, en?.holidayId ?: ""))
            }
        }

        override fun onViewRecycled(h: SeeAllHolder) { h.card.animate().cancel(); h.card.scaleX = 1f; h.card.scaleY = 1f; h.cell.translationZ = 0f; h.card.clear() }

        override fun getItemCount() = items.size
    }

    companion object {
        fun intent(ctx: Context, token: String) = Intent(ctx, SeeAllActivity::class.java).putExtra("token", token)
    }
}
