package com.sparrow.player.ui.vod

import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import coil.dispose
import coil.imageLoader
import coil.request.ImageRequest
import coil.size.Scale
import com.sparrow.player.R
import com.sparrow.player.ui.theme.Theme

/** Size of a poster: a share of the screen width, 2:3. Used by the card AND by the prefetcher so cache keys match. */
object PosterSize {
    /** Share of the screen width one poster takes. 0.17 (was 0.125): bigger, sharper posters for the row being browsed (a second row only peeks in); the one number to change to make posters bigger / smaller. */
    const val FRACTION = 0.17f
    fun width(ctx: Context): Int = (ctx.resources.displayMetrics.widthPixels * FRACTION).toInt()
    fun height(ctx: Context): Int = width(ctx) * 3 / 2

    /**
     * Panels write poster addresses in odd ways (protocol-relative "//host/x.jpg", JSON-escaped "http:\/\/host\/x.jpg", stray spaces / line breaks);
     * Coil then fails and the card shows only the Sparrow logo. Tidied here, in the one place every card and the prefetcher go through.
     */
    fun clean(url: String): String {
        var u = url.trim().replace("\\/", "/").replace("\n", "").replace("\r", "")
        if (u.startsWith("//")) u = "https:$u"
        return u.replace(" ", "%20")
    }

    /** The same poster over the other scheme (some hosts only answer on one of them); null when the address has neither. */
    fun otherScheme(url: String): String? = when {
        url.startsWith("https://") -> "http://" + url.removePrefix("https://")
        url.startsWith("http://") -> "https://" + url.removePrefix("http://")
        else -> null
    }

    fun request(ctx: Context, url: String, w: Int = width(ctx), h: Int = height(ctx)): ImageRequest.Builder =
        ImageRequest.Builder(ctx).data(clean(url)).size(w, h).scale(Scale.FILL).crossfade(false)
}

/**
 * Poster only (the title is shown in the slim bar at the top while it is selected). When focused it is drawn like Netflix / Disney+: the card is enlarged by Leanback's zoom
 * (it grows wider AND taller over its neighbours) and this view adds, behind the poster, a soft black shadow that falls on
 * the neighbouring titles, edged by a thin white halo ring - so selection / shadow / titles behind read as three layers.
 */
class PosterCard(ctx: Context, private val posterW: Int = PosterSize.width(ctx), private val posterH: Int = PosterSize.height(ctx)) : LinearLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val radius = 8 * d
    private val spread = 12 * d

    val poster = RatedImageView(ctx)
    private var progress = 0

    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    init {
        orientation = VERTICAL
        isFocusable = true
        isFocusableInTouchMode = true
        clipChildren = false
        clipToPadding = false
        setWillNotDraw(false)
        // no text under the poster any more: little room is kept above / below (the halo may overlap the rows next to it), the sides keep the gap between posters
        setPadding((spread + 2 * d).toInt(), (6 * d).toInt(), (spread + 2 * d).toInt(), (6 * d).toInt())

        poster.scaleType = ImageView.ScaleType.CENTER_CROP
        poster.setBackgroundColor(Theme.surface2)
        poster.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, radius) }
        }
        poster.clipToOutline = true
        addView(poster, LayoutParams(posterW, posterH))
    }

    private var uid = ""
    private var onMissing: ((String) -> Unit)? = null
    private var lateTried = false

    /** [onMissing] (with [uid]) is called once when the poster is empty or cannot be loaded: the caller may look for another address and hand it to [latePoster]. */
    fun bind(name: String, subtitle: String, posterUrl: String?, percent: Int, providerRating: Double = -1.0, sparrowRating: Double = -1.0,
             uid: String = "", onMissing: ((String) -> Unit)? = null) {
        this.uid = uid; this.onMissing = onMissing; lateTried = false
        poster.dispose()                       // a poster still loading for the title this card showed before must not land on this one
        poster.setImageDrawable(null)
        poster.setRatings(providerRating, sparrowRating)
        progress = percent
        setPoster(posterUrl)
        invalidate()
    }

    private fun setPoster(url: String?) {
        if (url.isNullOrBlank()) { fallback(); return }
        poster.scaleType = ImageView.ScaleType.CENTER_CROP
        poster.imageAlpha = 255
        val req = PosterSize.request(context, url, posterW, posterH).target(poster)
            .listener(onError = { _, _ -> retryOtherScheme(url) }).build()
        context.imageLoader.enqueue(req)
    }

    /** First failure: try the same address over the other scheme once; only then the logo. */
    private fun retryOtherScheme(url: String) {
        val alt = PosterSize.otherScheme(PosterSize.clean(url))
        if (alt == null) { fallback(); return }
        val req = PosterSize.request(context, alt, posterW, posterH).target(poster).listener(onError = { _, _ -> fallback() }).build()
        context.imageLoader.enqueue(req)
    }

    private fun fallback() {
        poster.scaleType = ImageView.ScaleType.CENTER_INSIDE
        poster.imageAlpha = 90                       // dims the logo only: the rating badges stay fully visible
        poster.setImageResource(R.drawable.logo_circle)
        if (!lateTried) { lateTried = true; onMissing?.invoke(uid) }
    }

    /** A poster found afterwards: shown only if this card still shows the title it was looked up for. */
    fun latePoster(forUid: String, url: String) {
        if (forUid != uid || url.isBlank()) return
        lateTried = true
        setPoster(url)
    }

    fun clear() { uid = ""; onMissing = null; poster.dispose(); poster.setImageDrawable(null); poster.imageAlpha = 255; poster.setRatings(-1.0, -1.0) }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        invalidate()
    }

    override fun dispatchDraw(c: Canvas) {
        if (isFocused) drawHalo(c)
        super.dispatchDraw(c)
        if (progress in 1..100) {
            val l = poster.left.toFloat(); val r = poster.right.toFloat(); val b = poster.bottom.toFloat()
            val h = 5 * d
            bar.color = 0xAA000000.toInt(); c.drawRect(l, b - h, r, b, bar)
            bar.color = Theme.accent; c.drawRect(l, b - h, l + (r - l) * progress / 100f, b, bar)
        }
    }

    /** Shadow band (darkest next to the poster, fading outward) + a thin white ring at its outer edge. */
    private fun drawHalo(c: Canvas) {
        val l = poster.left.toFloat(); val t = poster.top.toFloat(); val r = poster.right.toFloat(); val b = poster.bottom.toFloat()
        val steps = 8
        shade.color = 0x2A000000          // each layer ~16 %; the innermost area is covered by all of them (~75 %)
        for (i in steps downTo 1) {
            val g = spread * i / steps
            box.set(l - g, t - g, r + g, b + g)
            c.drawRoundRect(box, radius + g, radius + g, shade)
        }
        ring.color = 0xF2FFFFFF.toInt()
        box.set(l - spread, t - spread, r + spread, b + spread)
        c.drawRoundRect(box, radius + spread, radius + spread, ring)
    }
}
