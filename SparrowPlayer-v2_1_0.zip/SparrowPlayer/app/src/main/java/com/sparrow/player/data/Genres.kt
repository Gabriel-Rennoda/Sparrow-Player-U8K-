package com.sparrow.player.data

/**
 * The genre tabs of Movies and Series (next to "The Holidays"): MAIN genres, each with its sub-genres.
 *
 * Built from the Netflix genre list (https://gist.github.com/frankywahl/b7a1f4e1dabb5f1f408393ddd9b94278): the ~270 genre codes are folded into
 * [MAIN] main genres, e.g. "Action Comedies", "Action Thrillers", "Action Sci-Fi & Fantasy" and "Martial Arts Movies" are all sub-genres of
 * "Action & Adventure". Only the MAIN genres are listed as tabs; inside a main genre every sub-genre that has titles is a row.
 *
 * A title is matched from what the provider says about it - its genre text and its category name, never the title - using whole-word
 * keywords written in [TextNorm] form (lower case, "-" and "&" as spaces). A title can belong to several genres. Pure Kotlin, unit tested.
 */
object Genres {
    class Sub(val name: String, val keywords: List<String>)
    class Main(val id: String, val name: String, val keywords: List<String>, val subs: List<Sub>)

    /** [inMain]: the title belongs to this main genre; [subs]: indexes into [Main.subs] of the sub-genres it also matches. */
    class Match(val inMain: Boolean, val subs: List<Int>)

    const val SCOPE_PREFIX = "genre:"

    fun classify(m: Main, prepared: String): Match {
        val subs = m.subs.indices.filter { TextNorm.hasAny(prepared, m.subs[it].keywords) }
        return Match(subs.isNotEmpty() || TextNorm.hasAny(prepared, m.keywords), subs)
    }

    fun mainOf(id: String): Main? = MAIN.firstOrNull { it.id == id }

    /** The main genres that have titles, and for each the indexes of its sub-genres that have titles (what the Movie / Series Groups list shows). */
    class Index(val mains: List<Main>, val subs: Map<String, List<Int>>)

    /** [prepared]: the distinct genre + category texts of a provider ([TextNorm] form). */
    fun index(prepared: Collection<String>): Index {
        val mains = ArrayList<Main>(); val subs = HashMap<String, List<Int>>()
        for (m in MAIN) {
            val found = java.util.TreeSet<Int>(); var any = false
            for (p in prepared) { val c = classify(m, p); if (c.inMain) any = true; found.addAll(c.subs) }
            if (any) { mains += m; subs[m.id] = found.toList() }
        }
        return Index(mains, subs)
    }

    private fun m(id: String, name: String, kw: List<String>, vararg subs: Pair<String, List<String>>) =
        Main(id, name, kw, subs.map { Sub(it.first, it.second) })

    val MAIN: List<Main> = listOf(
        m("action", "Action & Adventure", listOf("action", "action adventure", "adventure", "adventures", "martial arts", "kung fu", "superhero", "superheroes"),
            "Action Comedies" to listOf("action comedy", "action comedies"),
            "Action Sci-Fi & Fantasy" to listOf("action sci fi", "action science fiction", "action fantasy"),
            "Action Thrillers" to listOf("action thriller", "action thrillers"),
            "Adventures" to listOf("adventure", "adventures"),
            "Crime Action & Adventure" to listOf("crime action"),
            "Martial Arts" to listOf("martial arts", "kung fu", "karate"),
            "Spy Action & Adventure" to listOf("spy action", "spy", "spies", "espionage"),
            "Military Action & Adventure" to listOf("military action", "war action"),
            "Comic Book & Superhero" to listOf("superhero", "superheroes", "comic book", "comic books", "marvel", "dc comics"),
            "Classic Action & Adventure" to listOf("classic action"),
            "Asian Action" to listOf("asian action"),
            "Foreign Action & Adventure" to listOf("foreign action"),
            "Independent Action & Adventure" to listOf("independent action"),
            "TV Action & Adventure" to listOf("tv action")
        ),
        m("anime", "Anime", listOf("anime"),
            "Anime Action" to listOf("anime action"),
            "Anime Comedies" to listOf("anime comedy", "anime comedies"),
            "Anime Dramas" to listOf("anime drama", "anime dramas"),
            "Anime Fantasy" to listOf("anime fantasy"),
            "Anime Features" to listOf("anime features", "anime movies", "anime film", "anime films"),
            "Anime Horror" to listOf("anime horror"),
            "Anime Sci-Fi" to listOf("anime sci fi"),
            "Anime Series" to listOf("anime series")
        ),
        // Kids and Family are two groups, as on the providers: Kids = made for children (stays out of the grown-up genres), Family = for everyone (animation, Disney ...)
        m("kids", "Kids", listOf("kids", "kid", "children", "children s", "childrens", "cartoon", "cartoons", "nickelodeon", "nick jr", "cartoon network", "pbs kids", "toddler", "toddlers", "preschool", "baby", "kids movies", "kids series", "kids tv", "junior"),
            "Animal Tales" to listOf("animal tales", "animals"),
            "Education for Kids" to listOf("education for kids", "educational", "learning"),
            "Kids' TV" to listOf("kids tv", "kids shows", "children tv"),
            "Kids' Music" to listOf("kids music"),
            "Based on Children's Books" to listOf("children s books", "kids books", "children books"),
            "TV Cartoons" to listOf("cartoon", "cartoons", "tv cartoons"),
            "For Ages 0 to 4" to listOf("ages 0 to 2", "ages 2 to 4", "toddler", "toddlers", "preschool"),
            "For Ages 5 to 12" to listOf("ages 5 to 7", "ages 8 to 10", "ages 11 to 12")
        ),
        m("family", "Family", listOf("family", "families", "family movies", "animation", "animated", "disney", "pixar", "dreamworks"),
            "Disney" to listOf("disney", "pixar"),
            "Disney Musicals" to listOf("disney musicals"),
            "Family Features" to listOf("family", "families", "family features"),
            "Animation" to listOf("animation", "animated")
        ),
        m("classics", "Classics", listOf("classic", "classics", "silent", "film noir", "golden age"),
            "Classic Action & Adventure" to listOf("classic action"),
            "Classic Comedies" to listOf("classic comedy", "classic comedies"),
            "Classic Dramas" to listOf("classic drama", "classic dramas"),
            "Classic Foreign Movies" to listOf("classic foreign"),
            "Classic Musicals" to listOf("classic musicals", "classic musical"),
            "Classic Romance" to listOf("classic romantic", "classic romance"),
            "Classic Sci-Fi & Fantasy" to listOf("classic sci fi"),
            "Classic Thrillers" to listOf("classic thriller", "classic thrillers"),
            "Classic TV Shows" to listOf("classic tv"),
            "Classic War Movies" to listOf("classic war"),
            "Classic Westerns" to listOf("classic western", "classic westerns"),
            "Silent Movies" to listOf("silent"),
            "Film Noir" to listOf("film noir")
        ),
        m("comedies", "Comedies", listOf("comedy", "comedies", "comedic", "funny", "sitcom", "sitcoms", "stand up", "standup", "humor", "humour"),
            "Action Comedies" to listOf("action comedy", "action comedies"),
            "Adult Animation" to listOf("adult animation"),
            "Classic Comedies" to listOf("classic comedy", "classic comedies"),
            "Cult Comedies" to listOf("cult comedy", "cult comedies"),
            "Dark Comedies" to listOf("dark comedy", "dark comedies", "black comedy"),
            "Foreign Comedies" to listOf("foreign comedy", "foreign comedies"),
            "Horror Comedy" to listOf("horror comedy", "horror comedies"),
            "Independent Comedies" to listOf("independent comedy", "independent comedies"),
            "Late Night Comedies" to listOf("late night"),
            "Political Comedies" to listOf("political comedy", "political comedies"),
            "Romantic Comedies" to listOf("romantic comedy", "romantic comedies", "romcom", "rom com", "rom coms"),
            "Screwball Comedies" to listOf("screwball"),
            "Slapstick Comedies" to listOf("slapstick"),
            "Sports Comedies" to listOf("sports comedy", "sports comedies"),
            "Stand-Up Comedy" to listOf("stand up", "standup"),
            "Teen Comedies" to listOf("teen comedy", "teen comedies"),
            "Mockumentaries" to listOf("mockumentary", "mockumentaries"),
            "Satires & Spoofs" to listOf("satire", "satires", "parody", "spoof"),
            "TV Comedies" to listOf("sitcom", "sitcoms", "tv comedy", "tv comedies")
        ),
        m("standup", "Stand-Up Comedy", listOf("stand up", "standup", "stand up comedy", "comedy special", "comedy specials"),
            "Comedy Specials" to listOf("comedy special", "comedy specials"),
            "Roasts" to listOf("roast", "roasts"),
            "Sketch & Improv" to listOf("sketch", "sketch comedy", "improv")
        ),
        m("crime", "Crime", listOf("crime", "criminal", "gangster", "mafia", "heist", "detective", "true crime"),
            "Crime Action & Adventure" to listOf("crime action"),
            "Crime Documentaries" to listOf("crime documentary", "crime documentaries", "true crime"),
            "Crime Dramas" to listOf("crime drama", "crime dramas"),
            "Crime Thrillers" to listOf("crime thriller", "crime thrillers"),
            "Crime TV Shows" to listOf("crime tv", "crime series"),
            "Gangster Movies" to listOf("gangster", "mafia", "mob"),
            "Courtroom Dramas" to listOf("courtroom", "legal", "lawyer"),
            "Heist Movies" to listOf("heist"),
            "Detective Stories" to listOf("detective", "police", "cop")
        ),
        m("cult", "Cult", listOf("cult", "campy", "camp"),
            "Cult Comedies" to listOf("cult comedy", "cult comedies"),
            "Cult Horror" to listOf("cult horror"),
            "Cult Movies" to listOf("cult movies", "cult classic", "cult classics"),
            "Cult Sci-Fi & Fantasy" to listOf("cult sci fi"),
            "Cult TV Shows" to listOf("cult tv"),
            "Campy Movies" to listOf("campy", "camp"),
            "B-Horror Movies" to listOf("b horror", "b movie", "b movies")
        ),
        m("documentaries", "Documentaries", listOf("documentary", "documentaries", "docuseries"),
            "Biographical Documentaries" to listOf("biographical documentary", "biographical documentaries", "biography", "biographies"),
            "Crime Documentaries" to listOf("crime documentary", "crime documentaries"),
            "Foreign Documentaries" to listOf("foreign documentary", "foreign documentaries"),
            "Historical Documentaries" to listOf("historical documentary", "historical documentaries", "history"),
            "Military Documentaries" to listOf("military documentary", "military documentaries"),
            "Music & Concert Documentaries" to listOf("music documentary", "music documentaries", "concert documentary"),
            "Political Documentaries" to listOf("political documentary", "political documentaries"),
            "Religious & Spiritual Documentaries" to listOf("religious documentary", "religious documentaries", "spiritual documentary", "spiritual documentaries"),
            "Science & Nature" to listOf("science nature", "nature", "science"),
            "Social & Cultural Documentaries" to listOf("social cultural", "social documentary", "social documentaries"),
            "Sports Documentaries" to listOf("sports documentary", "sports documentaries"),
            "Travel & Adventure Documentaries" to listOf("travel", "travel adventure"),
            "TV Documentaries" to listOf("tv documentary", "tv documentaries")
        ),
        m("dramas", "Dramas", listOf("drama", "dramas", "tearjerker", "tearjerkers", "epic", "epics", "period piece", "period pieces", "melodrama"),
            "Biographical Dramas" to listOf("biographical drama", "biographical dramas", "biopic", "biopics"),
            "Classic Dramas" to listOf("classic drama", "classic dramas"),
            "Courtroom Dramas" to listOf("courtroom drama", "courtroom dramas"),
            "Crime Dramas" to listOf("crime drama", "crime dramas"),
            "Dramas Based on Books" to listOf("based on books", "based on a book", "book adaptation"),
            "Dramas Based on Real Life" to listOf("based on real life", "true story", "based on a true story"),
            "Foreign Dramas" to listOf("foreign drama", "foreign dramas"),
            "Gay & Lesbian Dramas" to listOf("gay lesbian", "lgbt", "lgbtq", "queer"),
            "Independent Dramas" to listOf("independent drama", "independent dramas"),
            "Military Dramas" to listOf("military drama", "military dramas", "war drama"),
            "Period Pieces" to listOf("period piece", "period pieces", "period drama"),
            "Political Dramas" to listOf("political drama", "political dramas"),
            "Romantic Dramas" to listOf("romantic drama", "romantic dramas"),
            "Sci-Fi Dramas" to listOf("sci fi drama", "sci fi dramas"),
            "Showbiz Dramas" to listOf("showbiz"),
            "Social Issue Dramas" to listOf("social issue"),
            "Sports Dramas" to listOf("sports drama", "sports dramas"),
            "Teen Dramas" to listOf("teen drama", "teen dramas"),
            "Tearjerkers" to listOf("tearjerker", "tearjerkers"),
            "TV Dramas" to listOf("tv drama", "tv dramas"),
            "Epics" to listOf("epic", "epics")
        ),
        m("faith", "Faith & Spirituality", listOf("faith", "spirituality", "spiritual", "religious", "religion", "christian", "gospel", "bible"),
            "Faith & Spirituality Movies" to listOf("faith spirituality movies", "faith movies", "christian movies"),
            "Religious Documentaries" to listOf("religious documentary", "religious documentaries"),
            "Spiritual Documentaries" to listOf("spiritual documentary", "spiritual documentaries"),
            "Kids' Faith & Spirituality" to listOf("kids faith")
        ),
        m("horror", "Horror", listOf("horror", "scary", "slasher", "zombie", "zombies", "vampire", "vampires", "werewolf", "werewolves", "creature", "monster", "monsters"),
            "B-Horror Movies" to listOf("b horror"),
            "Cult Horror" to listOf("cult horror"),
            "Deep Sea Horror" to listOf("deep sea horror", "shark", "sharks"),
            "Foreign Horror" to listOf("foreign horror"),
            "Horror Comedy" to listOf("horror comedy", "horror comedies"),
            "Sci-Fi Horror" to listOf("sci fi horror"),
            "Slasher & Serial Killer Movies" to listOf("slasher", "serial killer"),
            "Supernatural Horror" to listOf("supernatural horror", "supernatural", "paranormal", "haunted"),
            "Teen Screams" to listOf("teen screams"),
            "TV Horror" to listOf("tv horror"),
            "Vampire Horror" to listOf("vampire", "vampires"),
            "Werewolf Horror" to listOf("werewolf", "werewolves"),
            "Zombie Horror" to listOf("zombie", "zombies"),
            "Creature Features" to listOf("creature features", "creature"),
            "Monster Movies" to listOf("monster", "monsters"),
            "Satanic Stories" to listOf("satanic", "occult", "demonic"),
            "Anime Horror" to listOf("anime horror")
        ),
        m("independent", "Independent", listOf("independent", "indie", "art house", "arthouse", "experimental"),
            "Independent Action & Adventure" to listOf("independent action"),
            "Independent Comedies" to listOf("independent comedy", "independent comedies"),
            "Independent Dramas" to listOf("independent drama", "independent dramas"),
            "Independent Thrillers" to listOf("independent thriller", "independent thrillers"),
            "Independent Movies" to listOf("independent movies", "indie"),
            "Art House Movies" to listOf("art house", "arthouse"),
            "Experimental Movies" to listOf("experimental"),
            "Romantic Independent Movies" to listOf("romantic independent")
        ),
        m("international", "International", listOf("foreign", "international", "world cinema", "african", "asian", "australian", "belgian", "british", "chinese", "dutch", "eastern european", "french", "german", "greek", "indian", "irish", "italian", "japanese", "korean", "latin american", "middle eastern", "new zealand", "russian", "scandinavian", "southeast asian", "spanish", "arabic", "portuguese", "turkish", "polish", "bollywood"),
            "African Movies" to listOf("african"),
            "Asian Movies" to listOf("asian", "southeast asian"),
            "Australian & New Zealand Movies" to listOf("australian", "new zealand"),
            "British Movies & TV" to listOf("british"),
            "Chinese Movies" to listOf("chinese"),
            "Dutch & Belgian Movies" to listOf("dutch", "belgian"),
            "Eastern European Movies" to listOf("eastern european", "polish", "czech", "hungarian", "romanian"),
            "French Movies" to listOf("french"),
            "German Movies" to listOf("german"),
            "Greek Movies" to listOf("greek"),
            "Indian Movies" to listOf("indian", "bollywood", "hindi", "tamil", "telugu"),
            "Irish Movies" to listOf("irish"),
            "Italian Movies" to listOf("italian"),
            "Japanese Movies" to listOf("japanese"),
            "Korean Movies & TV" to listOf("korean"),
            "Latin American Movies" to listOf("latin american", "latino"),
            "Middle Eastern Movies" to listOf("middle eastern", "arabic", "turkish"),
            "Russian Movies" to listOf("russian"),
            "Scandinavian Movies" to listOf("scandinavian", "swedish", "norwegian", "danish", "finnish"),
            "Spanish Movies" to listOf("spanish"),
            "Portuguese Movies" to listOf("portuguese", "brazilian"),
            "Foreign Movies" to listOf("foreign movies", "foreign")
        ),
        m("music", "Music & Musicals", listOf("music", "musical", "musicals", "concert", "concerts", "jazz"),
            "Musicals" to listOf("musical", "musicals"),
            "Concerts" to listOf("concert", "concerts"),
            "Music & Concert Documentaries" to listOf("music documentary", "music documentaries"),
            "Classic Musicals" to listOf("classic musicals", "classic musical"),
            "Disney Musicals" to listOf("disney musicals"),
            "Showbiz Musicals" to listOf("showbiz musicals"),
            "Stage Musicals" to listOf("stage musicals"),
            "Jazz & Easy Listening" to listOf("jazz", "easy listening"),
            "Country & Folk" to listOf("country western", "folk"),
            "Latin Music" to listOf("latin music"),
            "Kids' Music" to listOf("kids music"),
            "Rock & Pop Concerts" to listOf("rock pop", "rock concerts", "pop concerts"),
            "Urban & Dance Concerts" to listOf("urban dance", "hip hop", "dance"),
            "World Music Concerts" to listOf("world music")
        ),
        m("mysteries", "Mysteries", listOf("mystery", "mysteries", "whodunit", "whodunits"),
            "Mysteries" to listOf("mystery", "mysteries"),
            "TV Mysteries" to listOf("tv mystery", "tv mysteries"),
            "Whodunits" to listOf("whodunit", "whodunits")
        ),
        m("reality", "Reality & TV", listOf("reality", "game show", "game shows", "talk show", "talk shows", "competition"),
            "Reality TV" to listOf("reality"),
            "Reality Competitions" to listOf("competition", "reality competition"),
            "Food & Travel TV" to listOf("food travel", "cooking", "travel"),
            "Lifestyle & Home" to listOf("lifestyle", "makeover", "home"),
            "Game Shows" to listOf("game show", "game shows"),
            "Talk Shows" to listOf("talk show", "talk shows")
        ),
        m("romance", "Romance", listOf("romance", "romantic", "love story", "rom com"),
            "Classic Romance" to listOf("classic romantic", "classic romance"),
            "Foreign Romance" to listOf("romantic foreign", "foreign romance"),
            "Independent Romance" to listOf("romantic independent"),
            "Quirky Romance" to listOf("quirky romance"),
            "Romantic Comedies" to listOf("romantic comedy", "romantic comedies", "romcom", "rom com"),
            "Romantic Dramas" to listOf("romantic drama", "romantic dramas"),
            "Romantic Favorites" to listOf("romantic favorites", "romantic favourites"),
            "Romantic Movies" to listOf("romantic movies", "romance movies"),
            "Steamy Romance" to listOf("steamy romantic", "steamy romance")
        ),
        m("scifi", "Sci-Fi & Fantasy", listOf("sci fi", "scifi", "science fiction", "fantasy"),
            "Action Sci-Fi & Fantasy" to listOf("action sci fi", "action fantasy"),
            "Alien Sci-Fi" to listOf("alien", "aliens", "ufo"),
            "Classic Sci-Fi & Fantasy" to listOf("classic sci fi"),
            "Cult Sci-Fi & Fantasy" to listOf("cult sci fi"),
            "Fantasy Movies" to listOf("fantasy"),
            "Foreign Sci-Fi & Fantasy" to listOf("foreign sci fi"),
            "Sci-Fi Adventure" to listOf("sci fi adventure"),
            "Sci-Fi Dramas" to listOf("sci fi drama", "sci fi dramas"),
            "Sci-Fi Horror" to listOf("sci fi horror"),
            "Sci-Fi Thrillers" to listOf("sci fi thriller", "sci fi thrillers"),
            "TV Sci-Fi & Fantasy" to listOf("tv sci fi"),
            "Anime Sci-Fi" to listOf("anime sci fi"),
            "Space & Dystopia" to listOf("space", "space opera", "dystopian", "post apocalyptic")
        ),
        m("sports", "Sports", listOf("sport", "sports", "baseball", "basketball", "boxing", "football", "soccer", "wrestling", "fitness", "golf", "hockey", "racing"),
            "Baseball Movies" to listOf("baseball"),
            "Basketball Movies" to listOf("basketball"),
            "Boxing Movies" to listOf("boxing"),
            "Football Movies" to listOf("football"),
            "Soccer Movies" to listOf("soccer"),
            "Hockey Movies" to listOf("hockey"),
            "Martial Arts, Boxing & Wrestling" to listOf("wrestling", "mma", "ufc", "martial arts boxing"),
            "Sports & Fitness" to listOf("fitness", "workout", "sports fitness"),
            "Sports Comedies" to listOf("sports comedy", "sports comedies"),
            "Sports Documentaries" to listOf("sports documentary", "sports documentaries"),
            "Sports Dramas" to listOf("sports drama", "sports dramas"),
            "Sports Movies" to listOf("sports movies", "sports movie")
        ),
        m("thrillers", "Thrillers", listOf("thriller", "thrillers", "suspense"),
            "Action Thrillers" to listOf("action thriller", "action thrillers"),
            "Classic Thrillers" to listOf("classic thriller", "classic thrillers"),
            "Crime Thrillers" to listOf("crime thriller", "crime thrillers"),
            "Foreign Thrillers" to listOf("foreign thriller", "foreign thrillers"),
            "Independent Thrillers" to listOf("independent thriller", "independent thrillers"),
            "Political Thrillers" to listOf("political thriller", "political thrillers"),
            "Psychological Thrillers" to listOf("psychological thriller", "psychological thrillers", "psychological"),
            "Sci-Fi Thrillers" to listOf("sci fi thriller", "sci fi thrillers"),
            "Spy Thrillers" to listOf("spy thriller", "spy thrillers"),
            "Steamy Thrillers" to listOf("steamy thrillers", "erotic thriller"),
            "Supernatural Thrillers" to listOf("supernatural thriller", "supernatural thrillers")
        ),
        m("teen", "Teen", listOf("teen", "teens", "teenage", "young adult"),
            "Teen Comedies" to listOf("teen comedy", "teen comedies"),
            "Teen Dramas" to listOf("teen drama", "teen dramas"),
            "Teen Screams" to listOf("teen screams"),
            "Teen TV Shows" to listOf("teen tv", "teen shows")
        ),
        m("war", "War & Military", listOf("war", "military", "army", "navy", "wwii", "world war"),
            "Military Action & Adventure" to listOf("military action", "war action"),
            "Military Documentaries" to listOf("military documentary", "military documentaries"),
            "Military Dramas" to listOf("military drama", "military dramas", "war drama"),
            "Military TV Shows" to listOf("military tv"),
            "Classic War Movies" to listOf("classic war"),
            "World War II" to listOf("wwii", "ww2", "world war ii", "world war 2"),
            "War Movies" to listOf("war movies", "war")
        ),
        m("westerns", "Westerns", listOf("western", "westerns", "cowboy", "cowboys"),
            "Classic Westerns" to listOf("classic western", "classic westerns"),
            "Spaghetti Westerns" to listOf("spaghetti western"),
            "Cowboy Stories" to listOf("cowboy", "cowboys")
        )
    )
}
