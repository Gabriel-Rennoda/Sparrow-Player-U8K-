package com.sparrow.player.data

/**
 * What the panel SENT at the last sync, kept per playlist so the app can be compared with the IPTV provider's own numbers
 * (Settings -> General -> Library Counts). "sent" = entries in the panel's list, "unique" = distinct stream ids among them. The database keeps ONE row
 * per stream id, so [movieSent] - [movieUnique] entries were repeats of an id already sent (the panel listed the same id twice).
 */
class SyncCounts(
    val movieSent: Int, val movieUnique: Int, val seriesSent: Int, val seriesUnique: Int, val liveSent: Int,
    val movieCategories: Int, val seriesCategories: Int, val at: Long
) {
    fun serialize(): String = listOf(movieSent, movieUnique, seriesSent, seriesUnique, liveSent, movieCategories, seriesCategories).joinToString(",") + "," + at

    companion object {
        /** From the entries of one sync: [vod] = every movie and series entry, [liveSent] = live channels, the categories by kind. */
        fun of(vod: List<VodItem>, liveSent: Int, movieCategories: Int, seriesCategories: Int, at: Long): SyncCounts {
            val movies = vod.filter { it.type == "movie" }
            val series = vod.filter { it.type == "series" }
            return SyncCounts(movies.size, movies.map { it.uid }.toHashSet().size, series.size, series.map { it.uid }.toHashSet().size, liveSent, movieCategories, seriesCategories, at)
        }

        /** null when nothing was recorded yet (a playlist synced before this version: Sync Now records it). */
        fun parse(raw: String): SyncCounts? {
            val p = raw.split(',')
            if (p.size < 8) return null
            val n = p.take(7).map { it.trim().toIntOrNull() ?: return null }
            return SyncCounts(n[0], n[1], n[2], n[3], n[4], n[5], n[6], p[7].trim().toLongOrNull() ?: 0L)
        }
    }
}

/** What the app made of one kind of title (movies or series), worked out from the catalogue. All counts are of TITLES: one film listed in several categories is one title. */
class LibraryReport(
    val type: String,
    /** rows in the database / the in-memory catalogue (one per stream id) */
    val stored: Int,
    /** distinct films / shows (a film in several categories counted once) */
    val unique: Int,
    /** in at least one genre group of the Groups list */
    val inGenreGroup: Int,
    /** in no genre group: they are only in All Movies / All Series and in their provider category */
    val inNoGenreGroup: Int,
    val kids: Int,
    val holidays: Int,
    /** sitting in an adult category / named as adult: never shown in a holiday */
    val adult: Int,
    val noPoster: Int,
    val noRating: Int,
    val noYear: Int,
    val perGenre: List<Pair<String, Int>>,
    val perCategory: List<Pair<String, Int>>
)

object LibraryStats {
    /** Worked out on a background thread (it visits every title once per genre): [known] = ratings the panel gave (the Kids / Family age screen). */
    fun of(cat: VodCatalog, known: Map<String, String>): LibraryReport {
        val n = cat.titles.size
        var unique = 0; var holidays = 0; var adult = 0; var noPoster = 0; var noRating = 0; var noYear = 0; var kids = 0
        val leader = BooleanArray(n)
        for (i in 0 until n) {
            if (cat.group[i] != i) continue
            leader[i] = true; unique++
        }
        for (i in 0 until n) {
            val t = cat.titles[i]
            if (!leader[cat.group[i]]) continue
            if (cat.group[i] != i) continue
            if (t.holidayBits() != 0) holidays++
            if (t.prep.adult) adult++
            if (cat.items[i].poster.isBlank()) noPoster++
            if (t.rating <= 0.0) noRating++
            if (t.year <= 0) noYear++
            if (cat.kidsOnly[i]) kids++
        }
        val inAny = HashSet<Int>()
        val perGenre = ArrayList<Pair<String, Int>>()
        for (m in Genres.MAIN) {
            val picks = Pages.genrePicks(cat, m, null, known)
            if (picks.isEmpty()) continue
            perGenre += m.name to picks.size
            for (t in picks) { val i = cat.indexOf(t.uid); if (i >= 0) inAny += cat.group[i] }
        }
        perGenre.sortByDescending { it.second }
        val perCat = ArrayList<Pair<String, Int>>()
        for ((cid, name) in cat.categoryNames) { val c = cat.categorySize(cid); if (c > 0) perCat += name to c }
        perCat.sortByDescending { it.second }
        return LibraryReport(cat.type, n, unique, inAny.size, unique - inAny.size, kids, holidays, adult, noPoster, noRating, noYear, perGenre, perCat)
    }
}
