#!/usr/bin/env python3
"""Model tests for the 2.0.0 behaviours. No Kotlin compiler on the build box: the word lists are PARSED from the Kotlin sources and the logic mirrored.
Covers: genre / holiday keyword filters (word sets, screen-outs), Classics rule, row cap + See All, grid geometry, 2-row fit on the 75" U8K,
side-bar hide / reappear with the remote (Left x2 / Back x2), Search-first, hold-OK See All, Movies / Series reopen on All.
python3 tools/v20_model_test.py"""
import re, os
D = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "java", "com", "sparrow", "player")
fails = []
def ok(c, m): print(("PASS " if c else "FAIL ") + m); (not c) and fails.append(m)
def prep(t): return " " + re.sub(r"[^0-9a-z]+", " ", t.lower()).strip() + " "
def has(p, ws): return any(" " + w + " " in p for w in ws)
def hasall(p, ws): return all(" " + w + " " in p for w in ws)

# ---------------------------------------------------------------- GenreRules.kt parsed
src = open(os.path.join(D, "data", "GenreRules.kt")).read()
body = src[src.index("val RULES"):src.index("fun indexOf")]
RULES = {}
for m in re.finditer(r'"(\w+)" to Rules\((.*?)\n        \)(?:,|\n)', body, re.S):
    gid, b = m.group(1), m.group(2)
    def lst(name):
        mm = re.search(name + r' = listOf\((.*?)\)(?=,\s*\n\s+\w+ = |\s*$)', b, re.S)
        return re.findall(r'"([^"]*)"', mm.group(1)) if mm else []
    def sets(name):
        mm = re.search(name + r' = listOf\((.*)\)(?=,\s*\n\s+\w+ = |\s*$)', b, re.S)
        if not mm: return []
        return [re.findall(r'"([^"]*)"', x) for x in re.findall(r'listOf\(("[^)]*)\)', mm.group(1))]
    RULES[gid] = dict(tin=lst("titleIn"), tsets=sets("titleInSets"), out=lst("out"), osets=sets("outSets"))
ok(len(RULES) >= 20, "genre rules parsed from GenreRules.kt (%d genres)" % len(RULES))
def verdict(g, name, genre=""):
    r = RULES.get(g)
    if not r: return 0
    n, gp = prep(name), prep(genre)
    if has(n, r["out"]) or has(gp, r["out"]) or any(hasall(n, s) for s in r["osets"]): return -1
    if has(n, r["tin"]) or any(hasall(n, s) for s in r["tsets"]): return 1
    return 0
cases = [("horror", "The Conjuring 2", 1), ("action", "John Wick: Chapter 4", 1), ("sports", "Cinderella Man", 1), ("sports", "Boxing Day", -1),
         ("sports", "Rocky Horror Picture Show", -1), ("horror", "Scary Movie", -1), ("romance", "Love, Death & Robots", -1), ("war", "Star Wars", -1),
         ("documentaries", "Documentary Now", -1), ("westerns", "Django Unchained", 1), ("scifi", "The Twilight Zone", 1), ("teen", "The Twilight Zone", -1),
         ("horror", "A Quiet Day", 0), ("crime", "Law & Order: SVU", 1), ("comedies", "Parks & Recreation", 1), ("comedies", "Brooklyn Nine-Nine", 1)]
for g, n, e in cases: ok(verdict(g, n) == e, "genre %-13s %-28s -> %+d" % (g, n, e))
ok(verdict("westerns", "Some Film", "Western Europe") == -1, "category text 'Western Europe' keeps a title out of Westerns")
# every phrase is already in TextNorm form
bad = [w for g, r in RULES.items() for w in r["tin"] + r["out"] if prep(w).strip() != w]
ok(not bad, "every genre phrase is in normalised form %s" % bad[:3])

# ---------------------------------------------------------------- Holidays.kt: Boxing Day + sets
h = open(os.path.join(D, "data", "Holidays.kt")).read()
ok('"boxing", "Boxing Day"' in h and 'BOXING)' in h, "Boxing Day is a holiday (ALL has BOXING)")
bx = re.search(r'val BOXING = Holiday\((.*?)\n\n', h, re.S).group(1)
kw = re.findall(r'"([^"]*)"', re.search(r'keywords = listOf\((.*?)\)', bx).group(1))
osets = [re.findall(r'"([^"]*)"', x) for x in re.findall(r'listOf\(("[^)]*)\)', re.search(r'excludeSets = listOf\((.*)\)\)', bx, re.S).group(1))]
def boxing(name, plot=""):
    n = prep(name)
    if not has(n, kw): return False
    if any(hasall(n, s) for s in osets): return False
    if plot and any(hasall(n + prep(plot), s) for s in osets): return False
    return True
for n, e in [("Boxing Day", True), ("A Boxing Day Surprise", True), ("Cinderella Man", False), ("Boxing Day Fight Night", False), ("Boxing Day Heavyweight Champion", False)]:
    ok(boxing(n) == e, "Boxing Day filter: %-34s -> %s" % (n, e))
ok(not boxing("Boxing Day", "a boxing champion fights for the title"), "Boxing Day + description 'boxing' + 'champion' -> out")
ok(boxing("Boxing Day", "a family sits down to dinner"), "Boxing Day + ordinary description stays in")

# ---------------------------------------------------------------- classics + caps
YEAR = 2026
def classic(y, r): return 1 <= y <= YEAR - 10 and r >= 6.5
ok(classic(2016, 6.5) and not classic(2017, 9) and not classic(1980, 6.4) and not classic(0, 9), "Classics = 10+ years old AND 6.5+ (edges 2016/6.5 in, 2017 out, 6.4 out, no year out)")
hr = open(os.path.join(D, "data", "HomeRows.kt")).read()
ok("CLASSIC_YEARS = 10" in hr and "CLASSIC_RATING = 6.5" in hr and "ROW_CAP = 20" in hr, "constants in HomeRows.kt: classics 10 years / 6.5, row cap 20")
ok("Classic ${c.label}" in hr and '"$n Classics"' in hr, "Classics rows exist on group pages and on every holiday page")
def row(n, cap=20): return min(n, cap) + (1 if n > cap else 0)
ok(row(10) == 10 and row(20) == 20 and row(21) == 21 and row(300) == 21, "row = first 20 titles + 1 See All tile when there are more (21 items max)")

# ---------------------------------------------------------------- geometry (75" U8K = 3840x2160 px at 640 dpi -> 960 x 540 dp)
W, H = 960.0, 540.0
poster_w = W * 0.125; poster_h = poster_w * 1.5
card_h = poster_h + 12                                  # PosterCard vertical padding 6 + 6, no text
hero = 30; header = 22; top = 4
two_rows = hero + top + 2 * (header + card_h)
ok(two_rows <= H - 40, "two poster rows fit with 40 dp left for the zoom: need %.0f of %.0f dp" % (two_rows, H))
old_card = W * 0.14 * 1.5 + 14 + 2 * 18 + 28 + 4       # 1.9.5: poster + 2 text lines + padding
ok(2 * (header + old_card) + 100 + 14 > H - 40, "1.9.5 layout did NOT fit two rows (%.0f dp)" % (2 * (header + old_card) + 114))
# see-all grid: equal columns, equal gaps
card_w = poster_w + 28
avail = W - 72
span = max(3, int(avail // (card_w + 8)))
col = avail / span
ok(span >= 5 and col >= card_w * 1.08, "See All grid: %d columns of %.0f dp, selected poster (x1.08) fits its column" % (span, col))
rows_vis = (H - 70) / (card_h + 4)
ok(rows_vis >= 2.0, "See All grid shows %.1f rows" % rows_vis)

# ---------------------------------------------------------------- side bar model (MainActivity.updateRail / PanelState)
class Bar:
    def __init__(s, secs=3, groups=True):
        s.secs = secs; s.groups = groups; s.panel = "NONE"; s.nav_from = "NONE"; s.hidden = False; s.timer = None; s.t = 0; s.focus = "content"; s.apply()
    def apply(s):
        nav = s.panel == "NAV"
        if nav or s.secs <= 0: s.hidden = False; s.timer = None
        elif not s.hidden and s.timer is None: s.timer = s.t + s.secs
    def tick(s, sec):
        s.t += sec
        if s.timer is not None and s.t >= s.timer and s.panel != "NAV": s.hidden = True; s.timer = None
    def left(s):
        if s.panel == "NONE": s.nav_from = "NONE"; s.panel = "GROUPS" if s.groups else "NAV"
        elif s.panel == "GROUPS": s.nav_from = "GROUPS"; s.panel = "NAV"
        s.focus = "search" if s.panel == "NAV" else "groups"; s.apply()
    back = left
    def right(s):
        if s.panel == "NAV": s.panel = s.nav_from; s.nav_from = "NONE"
        elif s.panel == "GROUPS": s.panel = "NONE"
        s.focus = "groups" if s.panel == "GROUPS" else "content"; s.apply()
    @property
    def visible(s): return s.panel == "NAV" or not s.hidden
b = Bar(); ok(b.visible, "bar is visible at start"); b.tick(2.9); ok(b.visible, "still visible at 2.9 s"); b.tick(0.2); ok(not b.visible, "bar hides after 3 s")
b.left(); ok(b.panel == "GROUPS" and not b.visible, "Left #1: Movie Groups open, bar stays hidden")
b.left(); ok(b.panel == "NAV" and b.visible and b.focus == "search", "Left #2: bar comes back expanded, selector on Search (first)")
b.right(); ok(b.panel == "GROUPS" and b.visible, "Right closes one level"); b.tick(3.1); ok(not b.visible, "...and it hides again 3 s later")
b = Bar(); b.tick(3.1); b.back(); b.back(); ok(b.panel == "NAV" and b.visible and b.focus == "search", "Back x2 does the same as Left x2")
b = Bar(groups=False); b.tick(3.1); b.left(); ok(b.panel == "NAV" and b.visible, "screen without groups (Settings): first Left shows the bar")
b = Bar(secs=0); b.tick(60); ok(b.visible, "delay 'Never' keeps the bar")
b = Bar(secs=5); b.tick(4.9); ok(b.visible, "delay 5 s honoured"); b.tick(0.2); ok(not b.visible, "...hides at 5 s")
s = open(os.path.join(D, "ui", "settings", "SettingsFragment.kt")).read()
ok('"Hide Side Bar After"' in s and "listOf(0, 2, 3, 5, 10)" in s and "fun epgPopup" in s, "delay is set in Settings -> EPG (Never / 2 / 3 / 5 / 10 s)")
pf = open(os.path.join(D, "data", "Prefs.kt")).read()
ok('getInt("railHideSec", 3)' in pf, "default delay is 3 s")

# ---------------------------------------------------------------- code-level wiring checks
ma = open(os.path.join(D, "ui", "MainActivity.kt")).read()
ok("searchNav.isFocusable = true; searchNav.requestFocus()" in ma, "bar returns with Search focused")
ok("scopes[i] = Repository.SCOPE_ALL" in ma, "Movies / Series tabs reopen on All Movies / All Series")
ok("KEYCODE_MENU" in ma and "repeatCount == 0) okLong = false" in ma and "seeAllSelected()" in ma, "hold OK / Menu = See All of the selected row; key-up swallowed")
ok("startActivity(DetailsActivity.intent(this@MainActivity, uid))" in ma and "SearchActivity.random" not in ma, "dice = instant pick of a title's info page; search = separate icon")
ok("searchBar" not in ma and "randomBtn" not in ma and "searchBtn" not in ma, "top-right Search / Random buttons are gone from MainActivity")
lay = open(os.path.join(D, "..", "..", "..", "..", "res", "layout", "activity_main.xml")).read()
ok("searchBar" not in lay and "randomBtn" not in lay, "top-right Search / Random buttons are gone from the layout")
pc = open(os.path.join(D, "ui", "vod", "PosterCard.kt")).read()
ok("val title = TextView" not in pc and "private val title" not in pc, "no name / year text under posters")
sa = open(os.path.join(D, "ui", "search", "SearchActivity.kt")).read()
ok("collapseFilters()" in sa and "focusFirstResult = true" in sa and "expandFilters(); return true" in sa, "Search: Enter minimizes filters + selector to first title; Left from column 0 restores them")
print("\nRESULT:", "ALL PASSED" if not fails else "%d FAILED" % len(fails))
raise SystemExit(1 if fails else 0)
