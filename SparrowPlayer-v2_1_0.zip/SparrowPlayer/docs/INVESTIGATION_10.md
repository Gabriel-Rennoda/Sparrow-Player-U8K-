# 2.0.0 - investigation, changes and test report

Every item was read in the code first (what the 1.9.5 code really does), then changed in stages. There is no Kotlin compiler / Gradle on the machine this
was written on, so the compile + `testDebugUnitTest` runs in the GitHub Action; what *was* run here: `tools/kt_balance.py`, `tools/kt_static_check.py`
(same 3 known false positives as 1.9.5), `tools/upgrade_check.py` (schema unchanged, upgrade safe) and the new `tools/v20_model_test.py` (all passed).
`genres_check.py` / `v19_model_test.py` fail identically on the untouched 1.9.5 zip (stale checks, not related).

## Findings (before any change) -> what was done
| # | 1.9.5 behaviour | 2.0.0 |
|---|---|---|
| 1 | Each tab remembered its last group, so Movies could open on Comedies | Choosing Movies / Series always opens All Movies / All Series on the top row (also when picked again while a group is open) |
| 1a | Rows held 30-60 titles, no way to see the rest | A row shows its first **20** titles + a "See All (N Titles)" tile. **Hold OK** (or Menu / Info) on any poster opens See All of the row the selector is on |
| 1a-i | - | New See All grid screen: equal columns (equal horizontal gap), still while the selector moves on screen, scrolls only for new rows; selected poster = white halo + slight enlarge, back to normal when left |
| 1b | Group pages had only Top Rated / Recently Added / sub-genres / categories | Every group (and sub-genre) now also gets Continue Watching, Top Picks, Top 10 Today, New, Classic, Hidden Gems, Trending, ... built from that group's own titles |
| 2 | Poster 14 % of width + 2 text lines; 114 dp header; Search/Dice top right | Poster 12.5 %, no text under posters, one slim title line in the top-left corner, no plot header; two rows fit (model: needs ~430 of 540 dp). Search / Dice buttons top-right removed |
| 2-i | Bar always visible | Bar hides after 3 s (Settings -> EPG -> Hide Side Bar After: Never / 2 / 3 / 5 / 10 s); returns on Left x2 / Back x2 |
| 3 | No counts | Settings -> General -> Library Counts (see below) |
| 4 | Holiday page: What's Hot, Continue, Top Picks, Classics, Cult; no Kids / Family rows | Top 10, What's Hot, Continue, Top Picks (recommended), **for Kids**, **for the Family**, Classics, Newly Added, Critically Acclaimed, up to 4 genre rows (e.g. "Christmas Comedies"), Cult |
| 4a | Phrases only | **Word sets** (all words, any order) in / out, applied to title AND description. New holiday: **Boxing Day** (26 Dec). "boxing day" in; "boxing" + "fight" / "champion" / "ring" ... out; Cinderella Man out |
| 4b | **Not implemented as an option.** Only an automatic filter existed (a series opened from a holiday lists the holiday episodes) | Now a setting: Settings -> General -> **Holiday Episodes Only (Lite)** (default On) |
| 4c / 5 | Holiday classics = year <= 2000 or "classic" category | **Classics everywhere** = released 10+ years ago AND rating >= 6.5 (holidays, All, every group) |
| 5 | Genre / category text only; title never used | `GenreRules.kt`: per genre title phrases, word sets, description sets and screen-outs (e.g. "Love, Death & Robots" not Romance, "Rocky Horror" not Sports, "Scary Movie" not Horror). Computed once at catalogue build with a first-word index (fast on 100k titles) |
| 6 | Search / Random lived top-right | Search + dice (Random Pick) are in the left bar under the logo, only reachable when the bar is open. Two separate icons. Dice = instant pick: opens the information page of a random unwatched title at once (movie, or series on the Series tab). Magnifying glass = Search with its filters. Choosing either closes the bar. After **Enter** in Search the filter pane minimizes and the selector lands on the first title (top-left); **Left** from the first column brings the filters back. When the bar returns, the selector is on **Search** |

## Library Counts (item 3)
General -> Library Counts shows, for Live / Movies / Series: what the panel **sent** at the last sync (needs one Sync Now after updating),
how many were **saved** (the database keeps one row per stream id, repeated ids are reported), distinct titles (a film in several categories = 1),
titles in a genre group vs only in All, Kids, Holiday, Adult, no poster / rating / year, plus lists **by genre** and **by IPTV category**.

## Interpretation notes (tell me if you meant otherwise)
* "Remove the large header over the posters" = the big title + plot block. The selected title, year / rating / genre stay in one slim line.
* Row cap 20: about three screens of posters per row; more makes rows slow to scroll on a TV and the See All grid is one press away.
* The side bar hide / reappear applies on every tab (Live TV, Movies, Series, Favourites, Settings).

## Tests added / updated
`GenreRulesTest`, `LibraryStatsTest`, `HolidaysTest` (Boxing Day, word sets, order), `HomeRowsTest` (classics rule, group carousels, kids / family rows, new holiday page), `tools/v20_model_test.py`.

## TV checks to do on the U8K (docs/TV_TEST_CHECKLIST.md has the older ones)
1. Start: bar visible 3 s then gone; Left, Left -> groups then bar with Search highlighted; same with Back, Back.
2. Movies: two rows visible; selected title name top-left; no text under posters. Hold OK on a poster -> See All grid; arrows move the halo, grid stays still until the bottom; Back returns to the row.
3. Pick Comedies, then Left x2 -> Movies: opens All Movies, top row.
4. Dice: filters pop out; Pick A Random Title. Search: type, Enter -> filters hide, first poster selected, Left -> filters back.
5. Settings -> General -> Library Counts (after Sync Now) and compare with your panel.
If posters look too big / small change `PosterSize.FRACTION` (PosterCard.kt).
