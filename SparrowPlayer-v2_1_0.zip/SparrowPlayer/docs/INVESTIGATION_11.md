# 2.1.0 - investigation, changes and test report

No Kotlin compiler / Gradle exists on the machine this was written on, so compile + `testDebugUnitTest` run in the GitHub Action.
Run here: `tools/kt_balance.py` (all balanced), `tools/kt_static_check.py` (same 3 known false positives as 2.0.1), `tools/upgrade_check.py` (schema unchanged, upgrade safe).
**Nothing could be tried on the U8K** - see docs/TV_TEST_CHECKLIST_2_1.md.

## Findings (code read first) -> change
| # | Cause found | 2.1.0 |
|---|---|---|
| 1 | `contentCol` had 28 dp start padding between the side bars and the guide | start padding 0; the live header keeps its own 14 dp inset |
| 2 | 28 dp column padding + Leanback's own 56 dp row padding put posters ~98 dp from the bar, title line at 30 dp | rows, row names, title line and posters share one left edge (14 dp) |
| 2a | Posters 12.5 % of width | 17 % (`PosterSize.FRACTION`): bigger / sharper, second row only peeks in |
| 2b | - | After you scroll along a row, the title (bold) replaces the carousel name above the row, centred over the poster (left-aligned if it would not fit). New row = carousel name again. Top line then shows year / rating / genre only |
| 3 | Tab list (232 dp) left an 82 dp sliver of the groups list showing | Opened over groups the tab list is as wide as bar + groups and covers it completely; 140 ms slide, groups list fades in |
| 4 / 22 / 2a-i | Grid had `clipChildren=false`, so the selected top-row poster drew over the title area; grid size fixed | Grid clips at its top edge; exactly two rows fill the space under the title area, Up/Down at the top/bottom row shifts one row. Title area: carousel name + first title (large) until you scroll, then the title takes the carousel's place (bold) |
| 5 | `profileConfirmed` lives in the app process; after Exit the process stays alive so the picker was skipped. Start-up option was one global switch | Exit resets it, so the next start asks Who's Watching? again. Start-up option is now per profile (one profile owns it): that profile opens at once, no picker. Locked: Opening Channel plays, first key press shows the PIN pad as an overlay |
| 6 | Settings tab and Search both released the mini player | Settings keeps it (header shown); Search / Theme / Add Playlist keep it playing behind; full screen and Details stop it |
| 7-13 | One long General list | New headings: General, Playback, Playlists, Groups & Channels, Appearance, Network and Buffering, EPG, Data/Backup & About. Hidden is under Playlists, Groups & Channels and EPG |
| 14 | Only a TS / HLS switch | Buffer Profile, Optimise For My Connection, Auto-Reconnect. Playback Quality / Audio Quality caps |
| 15 | No cue | "▾" pill when a Settings page, pop-up, groups list, Movies/Series page or See All grid scrolls further. (Not on the Live guide yet) |
| 18 | - | Descriptions under rows (`Popup.row(desc=...)`), incl. Holiday Episodes Only |
| 21 | Leanback re-applies the previous page's row position to a new adapter | New page (tab, group, See All tile) always selects row 0 |
| 24 | See All is its own screen with no side panels | Left on first column returns and opens the side panels |
| 25 | Slider icon | Cog icon |
| 26 | Dice in the tab list | Random Pick at the top of the Movie / Series groups; picks an unwatched title of All Movies / All Series, so a series starts at episode 1 |

## Interpretation notes
* #9: Holiday Episodes Only was put in EPG as written. Say if you meant a Holidays heading.
* #24: Left now returns to the page with the side panels. Back still returns to the row first (second Back opens the groups, as on every page).
* #22: two rows of posters is height limited on a 540 dp screen: posters are ~11 % larger than 2.0.1 in the grid, not 40 %.
* "Optimise For My Connection" reads a live stream and judges how steadily it arrives (live streams are paced, so it is not a speed test).
* Location defaults to Canada (Thanksgiving 2nd Monday of October). Only affects Thanksgiving + carousel country name so far.

## Not done this round - see docs/NEXT_UPDATE_REQUEST.md
16, 17, 19, 20, 23 (pre-menu, keyword research, Canadian holidays beyond Thanksgiving), 12 (Backup, Restore, Update/Sync Profiles), 15 on the Live guide.
