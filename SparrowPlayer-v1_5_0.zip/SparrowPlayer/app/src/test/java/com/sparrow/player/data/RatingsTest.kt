package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class RatingsTest {
    @Test fun userRatingsToggleAndRoundTrip() {
        val r = UserRatings(); r.toggle("u1", UserRatings.LOVED); r.toggle("u2", UserRatings.DISLIKED)
        assertEquals("loved", r.get("u1")); r.toggle("u1", UserRatings.LOVED); assertEquals("", r.get("u1"))
        r.toggle("u2", UserRatings.LIKED); assertEquals("liked", r.get("u2"))
        val d = UserRatings.parse(r.serialize()); assertEquals("liked", d.get("u2")); assertEquals(1, d.all().size)
        assertTrue(UserRatings.parse("junk\nu\tbogus").all().isEmpty())
    }

    @Test fun starsFromProviderScore() {
        assertEquals(4.0, SparrowRating.starsOf("8"), 0.0); assertEquals(3.5, SparrowRating.starsOf("7.2"), 0.0)
        assertEquals(-1.0, SparrowRating.starsOf(""), 0.0); assertEquals(-1.0, SparrowRating.starsOf("0"), 0.0); assertEquals(5.0, SparrowRating.starsOf("11"), 0.0)
    }

    @Test fun sparrowRatingFollowsTaste() {
        val ks = SparrowRating.keys("10", setOf("action"))
        val aff = SparrowRating.affinity(listOf(ks to UserRatings.LOVED, ks to UserRatings.LOVED))
        assertEquals(4.5, SparrowRating.score(3.5, ks, aff, ""), 0.0)                                  // +1 for a loved genre
        val bad = SparrowRating.affinity(listOf(ks to UserRatings.DISLIKED))
        assertEquals(2.5, SparrowRating.score(3.5, ks, bad, ""), 0.0)
        assertEquals(3.5, SparrowRating.score(3.5, setOf("c:99"), aff, ""), 0.0)                       // nothing in common: unchanged
        assertEquals(-1.0, SparrowRating.score(-1.0, ks, aff, ""), 0.0)
        assertEquals(5.0, SparrowRating.score(1.0, ks, bad, UserRatings.LOVED), 0.0)
        assertEquals(1.0, SparrowRating.score(5.0, ks, aff, UserRatings.DISLIKED), 0.0)
        assertEquals(5.0, SparrowRating.score(4.5, ks, aff, ""), 0.0)                                  // clamped
    }

    @Test fun metaCacheRoundTripAndMerge() {
        val c = MetaCache(); c.put("u1", 105, "PG-13", "Plot\twith tab\nand newline")
        c.put("u1", -1, "", "")                                                                         // empty update keeps what we know
        val d = MetaCache.parse(c.serialize()); val m = d.get("u1")!!
        assertEquals(105, m.lengthMin); assertEquals("PG-13", m.maturity); assertEquals("Plot\twith tab\nand newline", m.plot)
        assertNull(d.get("nope"))
    }

    @Test fun lengthParsing() {
        assertEquals(105, MetaCache.lengthMinutes("01:45:30")); assertEquals(105, MetaCache.lengthMinutes("105"))
        assertEquals(105, MetaCache.lengthMinutes("1h 45min")); assertEquals(95, MetaCache.lengthMinutes("95 min"))
        assertEquals(105, MetaCache.lengthMinutes("1:45")); assertEquals(-1, MetaCache.lengthMinutes("")); assertEquals(-1, MetaCache.lengthMinutes("n/a"))
    }
}
