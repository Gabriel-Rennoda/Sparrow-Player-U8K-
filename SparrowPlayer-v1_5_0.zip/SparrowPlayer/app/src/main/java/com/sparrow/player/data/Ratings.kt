package com.sparrow.player.data

/** "Loved It / Liked It / Disliked It": the user's own verdict on a title. Stored in one preference string. Pure Kotlin. */
class UserRatings {
    private val map = LinkedHashMap<String, String>()

    fun get(uid: String): String = map[uid] ?: ""

    /** Setting the same verdict again removes it (press "Loved It" twice = not rated). */
    fun toggle(uid: String, code: String) { if (map[uid] == code) map.remove(uid) else map[uid] = code }

    fun clear(uid: String) { map.remove(uid) }

    fun all(): Map<String, String> = map

    fun serialize(): String = map.entries.joinToString("") { "${it.key}\t${it.value}\n" }

    companion object {
        const val LOVED = "loved"
        const val LIKED = "liked"
        const val DISLIKED = "disliked"
        val CODES = listOf(LOVED, LIKED, DISLIKED)
        fun label(code: String) = when (code) { LOVED -> "Loved It"; LIKED -> "Liked It"; DISLIKED -> "Disliked It"; else -> "" }

        fun parse(s: String?): UserRatings {
            val r = UserRatings()
            if (s.isNullOrBlank()) return r
            for (line in s.split('\n')) {
                val f = line.split('\t')
                if (f.size >= 2 && f[1] in CODES) r.map[f[0]] = f[1]
            }
            return r
        }
    }
}

/**
 * Star rating and the app's own "Sparrow Rating", both 0 - 5 in half steps (-1 = unknown).
 *
 *  - Star rating = the provider's 0 - 10 score halved.
 *  - Sparrow rating = the star rating nudged (at most one star either way) by the user's own taste: every title the user loved /
 *    liked / disliked gives its category and genres a positive or negative weight, and a title sharing those moves up or down.
 *    A title the user rated themselves is simply 5 (loved), 4 (liked) or 1 (disliked).
 */
object SparrowRating {
    fun starsOf(raw: String): Double {
        val v = raw.trim().toDoubleOrNull() ?: return -1.0
        return if (v <= 0.0) -1.0 else roundHalf((v / 2.0).coerceIn(0.0, 5.0))
    }

    fun roundHalf(x: Double): Double = Math.round(x * 2.0) / 2.0

    /** keys of a title: "c:<category id>" and "g:<genre>" for every genre. */
    fun keys(categoryId: String, genres: Set<String>): Set<String> =
        LinkedHashSet<String>().also { out -> if (categoryId.isNotEmpty()) out.add("c:$categoryId"); genres.forEach { g -> out.add("g:$g") } }

    private fun weight(code: String) = when (code) { UserRatings.LOVED -> 1.0; UserRatings.LIKED -> 0.5; UserRatings.DISLIKED -> -1.0; else -> 0.0 }

    /** Average weight (-1..1) per key, from (keys of a rated title, its verdict) pairs. */
    fun affinity(rated: List<Pair<Set<String>, String>>): Map<String, Double> {
        val sum = HashMap<String, Double>(); val n = HashMap<String, Int>()
        for ((ks, code) in rated) for (k in ks) { sum[k] = (sum[k] ?: 0.0) + weight(code); n[k] = (n[k] ?: 0) + 1 }
        return sum.mapValues { (k, v) -> v / n[k]!! }
    }

    fun score(stars: Double, keys: Set<String>, affinity: Map<String, Double>, mine: String): Double {
        when (mine) {
            UserRatings.LOVED -> return 5.0
            UserRatings.LIKED -> return 4.0
            UserRatings.DISLIKED -> return 1.0
        }
        if (stars < 0) return -1.0
        val hits = keys.mapNotNull { affinity[it] }
        val adj = if (hits.isEmpty()) 0.0 else (hits.sum() / hits.size).coerceIn(-1.0, 1.0)
        return roundHalf((stars + adj).coerceIn(0.0, 5.0))
    }
}

/**
 * What the panel's info call told us about a title (length in minutes, maturity rating, plot), remembered when a details page is
 * opened so search can use it later. One preference string, pure Kotlin.
 */
class MetaCache {
    class Meta(val lengthMin: Int, val maturity: String, val plot: String)

    private val map = LinkedHashMap<String, Meta>()

    fun get(uid: String): Meta? = map[uid]

    fun put(uid: String, lengthMin: Int, maturity: String, plot: String) {
        val old = map[uid]
        map[uid] = Meta(
            if (lengthMin >= 0) lengthMin else old?.lengthMin ?: -1,
            maturity.ifBlank { old?.maturity ?: "" },
            plot.take(PLOT_MAX).ifBlank { old?.plot ?: "" }
        )
        while (map.size > MAX_ENTRIES) map.remove(map.keys.first())            // oldest first
    }

    fun serialize(): String = map.entries.joinToString("") { (k, m) -> "$k\t${m.lengthMin}\t${esc(m.maturity)}\t${esc(m.plot)}\n" }

    companion object {
        const val PLOT_MAX = 300
        const val MAX_ENTRIES = 1500

        fun parse(s: String?): MetaCache {
            val c = MetaCache()
            if (s.isNullOrBlank()) return c
            for (line in s.split('\n')) {
                val f = line.split('\t')
                if (f.size >= 4) c.map[f[0]] = Meta(f[1].toIntOrNull() ?: -1, unesc(f[2]), unesc(f[3]))
            }
            return c
        }

        private fun esc(s: String) = s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "")
        private fun unesc(s: String): String {
            val sb = StringBuilder(); var i = 0
            while (i < s.length) {
                val ch = s[i]
                if (ch == '\\' && i + 1 < s.length) { sb.append(when (s[i + 1]) { 't' -> '\t'; 'n' -> '\n'; else -> s[i + 1] }); i += 2 }
                else { sb.append(ch); i++ }
            }
            return sb.toString()
        }

        /** "01:45:30", "105", "1h 45min", "105 min", "1:45" -> minutes (-1 if it is not a length). */
        fun lengthMinutes(raw: String): Int {
            val s = raw.trim().lowercase()
            if (s.isEmpty()) return -1
            Regex("^(\\d{1,2}):(\\d{2}):(\\d{2})$").find(s)?.let { return it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt() }
            Regex("^(\\d{1,2}):(\\d{2})$").find(s)?.let { return it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt() }
            val h = Regex("(\\d+)\\s*h").find(s)?.groupValues?.get(1)?.toInt()
            val m = Regex("(\\d+)\\s*m").find(s)?.groupValues?.get(1)?.toInt()
            if (h != null || m != null) return (h ?: 0) * 60 + (m ?: 0)
            return s.toIntOrNull()?.takeIf { it in 1..1000 } ?: -1
        }
    }
}
