package com.sparrow.player.data

/**
 * "The Holiday's" group of Movies and Series: which holidays exist, when they fall, in which order their rows are shown and which
 * titles belong to each. Pure Kotlin (no java.time: the app supports Android 7), unit tested against known dates
 * (Easter 2026 = 5 April, Hanukkah 2026 = 5 December, US Thanksgiving 2026 = 26 November ...).
 *
 * Dates are "epoch days" (days since 1970-01-01), so they are easy to compare and subtract.
 */
object Holidays {
    class Holiday(val id: String, val name: String, val keywords: List<String>)

    /** [day] = the date this holiday is next on (or, for [recentlyPassed], the date it was on a few days ago). */
    class Dated(val holiday: Holiday, val day: Int, val recentlyPassed: Boolean)

    val NEW_YEAR = Holiday("newyear", "New Year's Day", listOf("new year", "new years", "new years eve", "nye"))
    val VALENTINE = Holiday("valentine", "Valentine's Day", listOf("valentine", "valentines", "galentine", "galentines", "cupid"))
    val PATRICK = Holiday("patrick", "St. Patrick's Day", listOf("st patrick", "st patricks", "saint patrick", "saint patricks", "patricks day", "leprechaun", "shamrock"))
    val EASTER = Holiday("easter", "Easter", listOf("easter", "peter cottontail", "easter bunny"))
    val MOTHERS = Holiday("mothers", "Mother's Day", listOf("mothers day", "mother s day"))
    val FATHERS = Holiday("fathers", "Father's Day", listOf("fathers day", "father s day"))
    val INDEPENDENCE = Holiday("independence", "Independence Day", listOf("independence day", "fourth of july", "4th of july", "july 4th", "july fourth"))
    val HALLOWEEN = Holiday("halloween", "Halloween", listOf("halloween", "trick or treat", "trick r treat", "hocus pocus", "pumpkin", "spooky", "haunted house", "addams family", "casper", "goosebumps"))
    val THANKSGIVING = Holiday("thanksgiving", "Thanksgiving", listOf("thanksgiving", "turkey day", "friendsgiving"))
    val HANUKKAH = Holiday("hanukkah", "Hanukkah", listOf("hanukkah", "chanukah", "festival of lights", "menorah"))
    val CHRISTMAS = Holiday("christmas", "Christmas", listOf("christmas", "xmas", "santa", "santa claus", "noel", "grinch", "north pole", "nutcracker", "rudolph", "jingle", "frosty", "polar express", "krampus", "scrooge", "yule", "reindeer"))

    val ALL: List<Holiday> = listOf(NEW_YEAR, VALENTINE, PATRICK, EASTER, MOTHERS, FATHERS, INDEPENDENCE, HALLOWEEN, THANKSGIVING, HANUKKAH, CHRISTMAS)

    /** Days a holiday that has just passed stays directly below the next upcoming one. */
    const val LINGER_DAYS = 7

    // ---- calendar maths ---------------------------------------------------------------------------------------------
    fun epochDay(y: Int, m: Int, d: Int): Int {
        val yy = if (m <= 2) y - 1 else y
        val era = (if (yy >= 0) yy else yy - 399) / 400
        val yoe = yy - era * 400
        val doy = (153 * (m + (if (m > 2) -3 else 9)) + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097 + doe - 719468
    }

    /** (year, month, day) of an epoch day. */
    fun civil(day: Int): IntArray {
        val z = day + 719468
        val era = (if (z >= 0) z else z - 146096) / 146097
        val doe = z - era * 146097
        val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
        val y = yoe + era * 400
        val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
        val mp = (5 * doy + 2) / 153
        val d = doy - (153 * mp + 2) / 5 + 1
        val m = mp + (if (mp < 10) 3 else -9)
        return intArrayOf(if (m <= 2) y + 1 else y, m, d)
    }

    /** 0 = Sunday ... 6 = Saturday. */
    fun weekday(day: Int): Int = Math.floorMod(day + 4, 7)

    /** The [n]-th (1 = first) [wd] (0 = Sunday) of month [m]. */
    fun nthWeekday(y: Int, m: Int, wd: Int, n: Int): Int {
        val first = epochDay(y, m, 1)
        return first + Math.floorMod(wd - weekday(first), 7) + 7 * (n - 1)
    }

    fun easter(y: Int): Int {
        val a = y % 19; val b = y / 100; val c = y % 100
        val d = b / 4; val e = b % 4; val f = (b + 8) / 25; val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4; val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = (h + l - 7 * m + 114) % 31 + 1
        return epochDay(y, month, day)
    }

    // Hebrew calendar (Dershowitz & Reingold): only needed for Hanukkah = 25 Kislev.
    private const val HEBREW_EPOCH_RD = -1373427
    private const val UNIX_EPOCH_RD = 719163

    private fun hebrewElapsed(y: Int): Int {
        val months = (235 * y - 234) / 19
        val parts = 12084 + 13753 * months
        val days = 29 * months + parts / 25920
        return if ((3 * (days + 1)) % 7 < 3) days + 1 else days
    }

    private fun hebrewNewYearRd(y: Int): Int {
        val n0 = hebrewElapsed(y - 1); val n1 = hebrewElapsed(y); val n2 = hebrewElapsed(y + 1)
        val corr = if (n2 - n1 == 356) 2 else if (n1 - n0 == 382) 1 else 0
        return HEBREW_EPOCH_RD + n1 + corr
    }

    /** First day of Hanukkah (25 Kislev) in Gregorian year [gy]. (The candles are lit the evening before.) */
    fun hanukkah(gy: Int): Int {
        val hy = gy + 3761
        val ny = hebrewNewYearRd(hy)
        val len = hebrewNewYearRd(hy + 1) - ny
        val heshvan = if (len % 10 == 5) 30 else 29
        return ny + 30 + heshvan + 24 - UNIX_EPOCH_RD
    }

    /** Date of [h] in year [y]. [canada]: Thanksgiving is the 2nd Monday of October there (4th Thursday of November elsewhere). */
    fun dateOf(h: Holiday, y: Int, canada: Boolean = false): Int = when (h.id) {
        "newyear" -> epochDay(y, 1, 1)
        "valentine" -> epochDay(y, 2, 14)
        "patrick" -> epochDay(y, 3, 17)
        "easter" -> easter(y)
        "mothers" -> nthWeekday(y, 5, 0, 2)
        "fathers" -> nthWeekday(y, 6, 0, 3)
        "independence" -> epochDay(y, 7, 4)
        "halloween" -> epochDay(y, 10, 31)
        "thanksgiving" -> if (canada) nthWeekday(y, 10, 1, 2) else nthWeekday(y, 11, 4, 4)
        "hanukkah" -> hanukkah(y)
        else -> epochDay(y, 12, 25)                      // christmas
    }

    // ---- row order --------------------------------------------------------------------------------------------------
    /**
     * Rows in the order they are shown on [today]: the holidays follow each other through the calendar year starting with the next
     * one coming up (a rolling Jan-Dec calendar). A holiday that passed within the last [LINGER_DAYS] days sits directly below the
     * next upcoming one (most recently passed first); after that it drops back to its normal place in the sequence (about a year away).
     */
    fun order(today: Int, canada: Boolean = false): List<Dated> {
        val y = civil(today)[0]
        val upcoming = ArrayList<Dated>(); val recent = ArrayList<Dated>()
        for (h in ALL) {
            val dates = (y - 1..y + 1).map { dateOf(h, it, canada) }.sorted()
            val next = dates.first { it >= today }
            val last = dates.last { it < today }
            if (today - last in 1..LINGER_DAYS) recent += Dated(h, last, true)
            else upcoming += Dated(h, next, false)
        }
        upcoming.sortBy { it.day }
        recent.sortByDescending { it.day }
        if (upcoming.isEmpty()) return recent
        return listOf(upcoming[0]) + recent + upcoming.drop(1)
    }

    // ---- which title belongs to which holiday -------------------------------------------------------------------------
    private fun norm(s: String): String {
        val sb = StringBuilder(s.length + 2).append(' ')
        for (ch in s.lowercase()) {
            if (ch == '\'' || ch == '\u2019') { sb.append(' '); continue }       // "mother's" -> "mother s" (both spellings are keywords)
            sb.append(if (ch.isLetterOrDigit()) ch else ' ')
        }
        return sb.append(' ').toString().replace(Regex(" +"), " ")
    }

    /** Text prepared for [matchesPrepared]: normalise each title once, then test it against every holiday. */
    fun prepare(text: String): String = norm(text)

    fun matchesPrepared(h: Holiday, prepared: String): Boolean = h.keywords.any { prepared.contains(" $it ") }

    /** Whole-word / whole-phrase match of any keyword in [text] (a title, plus the category and genre text). */
    fun matches(h: Holiday, text: String): Boolean = matchesPrepared(h, norm(text))

    private val MONTHS = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    /** "Dec 25". */
    fun label(day: Int): String { val c = civil(day); return "${MONTHS[c[1] - 1]} ${c[2]}" }
}
