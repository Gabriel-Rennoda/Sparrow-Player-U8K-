# Round 5 (v1.5.0) - investigated BEFORE changing code

Same limits as before: no Android SDK, Gradle, Kotlin compiler or TV here. Everything was traced through the code, all new logic is pure
Kotlin with JUnit tests, and Python mirrors (`tools/search_check.py`, `customize_check.py`, `nav_model_test.py`, ...) were run. **CI is the first
real compile; then walk the v1.5.0 section of `TV_TEST_CHECKLIST.md` on the U8K.**

| Request | Finding | Change |
|---|---|---|
| Gear icon bottom right, disappears with the controls, one settings menu | The overlay gear was top right and deliberately stayed visible while it had focus; Media3's own gear / CC buttons (bottom right of its bar) still opened Media3's separate menu = two menus. | One gear. Movies / series: Media3's gear and CC buttons are redirected to the Sparrow pop-up (found by resource name at run time). Live: the overlay gear is bottom right, inside the info bar. It is synced with the controls (info bar / `isControllerFullyVisible`), 250 ms poll plus an immediate sync, and never kept alive by focus. |
| Down on the tab list should stop at Settings | Settings is the last tab; with the Channel Groups panel open beside it, the focus search for Down found the group list. | `nextFocusDown` of the last tab and `nextFocusUp` of the first entry point at themselves. |
| Search at the top of Channel Groups and the tab list; easy to reach in Movies / Series | none existed | Search entry at the top of the tab list and of the groups panel; a Search button above the Movies / Series rows (Up from the first row reaches it, Down returns); the remote's SEARCH key works everywhere. |
| Click Search -> choose Live Channels / Movies / Series -> window with that kind's filters | - | `showSearchChooser()` -> `SearchActivity(kind)`. "Search In" at the top switches kind. Each kind's last filters are remembered while the app runs. |
| Filters | Bulk panel lists only give name, category, year, rating, added (series: genre, plot). No quality / language / subtitles / maturity / length. | Read from tags in titles and category names (`MediaTags`); **SD when a title says nothing**. Length, maturity and plot are remembered from the panel's info call whenever a details page is opened (`MetaCache`, own preferences file). A title with no data for a filter is not matched by it. DB schema untouched. |
| Loved / Liked / Disliked, Star Rating, Sparrow Rating | not present | Three buttons on the details screen (press again to remove). Star rating = panel score / 2 in half steps. **Sparrow Rating** = star rating nudged up to one star by your taste (loved / liked / disliked titles weight their category and genres); a title you rated yourself is 5 / 4 / 1. |
| The Holiday's group | Movies / Series had no groups panel. | Both now have a groups panel: All Movies / All Series and **The Holiday's**. Rows per holiday in calendar order starting with the next one; a holiday that just passed sits directly below the next one for 7 days, then returns to its place in the sequence. Dates computed in `Holidays` (Easter, Hanukkah, Thanksgiving ... verified against known dates). Titles are matched by whole-word keywords in name / category / genre. |
| Sort | - | Name, Genre, Star Rating, Maturity Rating, Release Date, Date Added, Length (live: Name, Channel Number, Genre) + an Ascending / Descending toggle. Titles with no value for the chosen field always come last. |

## Interpretations (tell me if any is wrong)
* "Channel Type" (live) = Sports, News, Kids, Music, Documentary, Movies, Series, Radio, Entertainment, Local, International, Other, worked out from the group and channel name.
* Star Rating and Sparrow Rating filters are "this rating and up" in half-star steps.
* Maturity / language / my-ratings filters: first row of each pop-up switches "Show Only Selected" / "Hide Selected" (the include / exclude toggle); quality is multi-select.
* "Include Descriptions": titles use the plot (series from the list, movies once opened); live channels search the downloaded guide (programme titles and descriptions).
* The group is spelled **The Holiday's** exactly as in the request (`VodFragment` / `MainActivity`, one string).
* The holiday rolling order starts at the next upcoming holiday (a Jan-Dec calendar that wraps), instead of always starting at January. Thanksgiving follows the device region (Canada = 2nd Monday of October).
* Movies have no genre in most panels, so the category name stands in for the genre.

## Not verified (needs the TV)
Focus paths: Up from the first Movies row to Search; the redirected Media3 gear; the search window's two columns; the holiday rows. If Media3's gear cannot be found by name, the overlay gear appears instead (bottom right above the bar, reachable with Up).
