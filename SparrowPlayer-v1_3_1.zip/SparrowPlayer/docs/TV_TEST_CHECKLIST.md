# Hisense U8K checklist (please run on the TV - these could not be run off-device)

The build (`gradle assembleDebug`) is verified by your GitHub Action. Remote behaviour below needs a real TV.

## Sizing (75", 3840x2160)
- [ ] Live TV: player top-left (16:9, not cut off), info pane to its right fully visible, list below, nothing clipped at any edge
- [ ] Guide: same header; grid rows fully visible; time header visible
- [ ] Movies / Series: hero text on top, posters below, nothing clipped
- [ ] Settings / Add provider / Details readable and inside the screen

## Player + info (#2)
- [ ] App opens with the last channel playing in the top-left box
- [ ] Moving up/down the list or around the guide updates the info pane (tag says BROWSING) while the picture keeps playing
- [ ] Focus on the player box (Up from the first row) -> info returns to the playing channel (tag NOW PLAYING)
- [ ] OK on another channel tunes the player; OK on the playing channel (or on the player box) = full screen; Back returns to the list
- [ ] Hold OK on a channel toggles favourite

## Movies / Series (#3)
- [ ] Tab list -> Movies (OK): selector lands on the first poster and STAYS there
- [ ] Browse rows left/right/up/down for 30+ seconds, including while a sync finishes: selector never jumps to another tab
- [ ] Same for Series

## Panels (#4)
- [ ] Guide, left-most programme, LEFT -> channel groups open, selector on the active group
- [ ] LEFT again -> tab list expands (labels visible)
- [ ] BACK -> groups, selector on the group you were on; BACK -> guide, selector on the programme you left
- [ ] Same starting from the player box and from the Live TV list
- [ ] OK on a group applies it and returns to the list/guide; Back on groups (without OK) changes nothing
- [ ] Movies/Series/Favourites/Settings: LEFT at the first item opens the tab list directly; Back returns

## Language (#5)
- [ ] "Favourites" everywhere (tab, group, toasts), "program" in guide text


# Round 2 (v1.1.0) - run on the TV
## Guide
- [ ] Live TV tab, Guide tab and Favourites tab all show the same grid; channel logos appear; no progress bars under channels
- [ ] Top-left of the guide reads like `Thurs, Nov. 05     -    1:15 am` and changes on the minute
- [ ] Grid starts at the current half hour (4:50 -> 4:30) and shows 2 hours; programs longer than 30 min are one block
- [ ] LEFT/RIGHT highlight programs; the grid does NOT shift. LEFT at the first block opens Channel groups
- [ ] (superseded in v1.3.0, see below) guide time-shifting mode no longer exists
## Navigation
- [ ] In Channel groups, moving ↑/↓ updates the guide to the focused group; OK closes the panel; Back closes and keeps that group
- [ ] Main screen: Back -> hint; Back again -> Exit? Yes / No (No returns to the app)
## Series / Movies
- [ ] Browse episodes up/down for 30 s: selector never jumps to the season row; info on top follows the episode
- [ ] One OK on an episode starts it; stop at 10:00, reopen -> starts at 9:30; Play button says Resume
- [ ] Movies / Series tabs open on the solid colour; backdrop appears when you move to a title; solid again when the tab list opens
## Settings
- [ ] 12 / 24 hour toggle changes guide, info pane and player; channel numbers toggle hides them everywhere

## v1.1.1
- [ ] Tab list: Live TV, Movies, Series, Favourites, Settings (no Guide)
- [ ] Live info pane has no progress bar
- [ ] Movies / Series: highlighted title shows a thin progress bar once partly watched; details + focused episode show it too; bar updates after returning from the player

## v1.2.0 additions (U8K remote)
1. **Backgrounds** - Movies, Series: background stays the solid theme / picture while moving over posters. Open a title: its poster is the backdrop (details only).
2. **Resume time** - watch a movie for 5+ min, Back out, reopen it: right of "Resume" reads `Resumes at m:ss • N min left`. Series: same, for the continue-episode. A fresh title shows nothing.
3. **Player, first press** - movie, series, live (full screen): with the bar hidden press each of Up, Down, Left, Right, OK, Back, CH+, CH-: only the bar appears (live: info bar zaps/acts only on the 2nd press). 2nd press within 3 s acts (Back leaves, CH changes channel). Bar vanishes ~3 s after the last key. Play/Pause, FF/RW, Menu, 0-9 work on the first press. Hold a key: counts as one press.
4. **Selected title** - move Left/Right: selected poster is larger, covers its neighbours, dark shadow on them, thin white ring outside the shadow. Up/Down between rows too; nothing clipped at row edges.
5. **Recommendations** - watch 2+ minutes of 3 different titles, reopen the tab: *Continue watching*, *Because you watched...*, *Recommended for you* appear above the provider rows.
6. **Image loading** - hold Right through a long row, and Down through several rows: posters are already there (no spinner / placeholder flashing). First open after install still loads from the network once.
7. **Themes** (Settings -> Theme) - try every stock theme, a solid colour, Custom background (move each bar), Custom accent, Random x5. Check on each: guide text, hero text, row titles, settings, details screen, player bar. Leafs White is the light one. After Back, the main screen shows the new theme.

## v1.3.0 additions (U8K remote)
1. **Guide browsing** - Live TV guide: hold RIGHT: the grid scrolls into the future in 30 min steps (also on rows with "No information"); hold LEFT: it comes back and STOPS at the current half hour (nothing earlier is ever shown); one more LEFT there opens the side panels. After browsing ahead, Back snaps the grid to now. No "time shifting" pop-up anywhere. OK on a programme tunes the channel (OK on the playing one = full screen); hold OK = favourite.
2. **Clock** - top-left corner cell of the grid (above the channel names/logos, level with the half-hour labels): clock on top, date under it. The old line above the guide is gone. Minute changes update it.
3. **Screensaver** - leave the guide idle (no keys) with a channel playing in the mini player for longer than your TV's screensaver timeout (set it to 5 min to test): no screensaver / dimming. Pause (stop playback) or leave the Live tab: the TV may sleep as normal again. Same in full-screen.
4. **Update over old** - see docs/UPGRADE_SAFETY.md: install this APK over the previous one (no uninstall): providers, favourites, resume positions, theme still there.
5. **Recommendations** - a movie counts as watched at 40 %: watch 39 % -> no "Because you watched" row; reach 40 % -> it appears next time the tab is opened.
