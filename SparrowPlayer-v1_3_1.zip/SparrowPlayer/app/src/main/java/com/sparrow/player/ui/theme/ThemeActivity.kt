package com.sparrow.player.ui.theme

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextPaint
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import com.sparrow.player.util.dp
import java.util.Random

/**
 * Theme picker: stock themes (Leafs jerseys + the three pictures), pre-selected solid colours, custom background /
 * accent colour (hue / saturation / brightness bars) and a Random button. A choice is applied (and saved) at once so the
 * user sees it on this very screen; the main screen re-creates itself when it comes back.
 */
class ThemeActivity : FragmentActivity() {
    private lateinit var root: ScrollView
    private lateinit var current: TextView
    private val tiles = ArrayList<ThemeTile>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(28), dp(56), dp(40))
        }
        root = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; addView(col) }
        setContentView(root)

        col.addView(label("Theme", 30f, "t:text", bold = true))
        current = label("", 16f, "t:dim")
        col.addView(current)

        col.addView(section("Stock themes"))
        rows(col, Palette.STOCK.map { tile(it, 96) }, 4)

        col.addView(section("Solid colours"))
        rows(col, Palette.allSolids().map { tile(it, 64) }, 6)

        col.addView(section("Make your own"))
        val actions = listOf(
            action("🎲  Random theme") { choose(Palette.random(Random())) },
            action("🎨  Custom background colour…") {
                ColourPicker.show(this, "Background colour", Theme.palette.bg, false) { c -> choose(Palette.fromBase("custom", "Custom", c)) }
            },
            action("✦  Custom accent colour…") {
                ColourPicker.show(this, "Accent colour", Theme.palette.accent, true) { c -> choose(Theme.palette.withAccent(c)) }
            }
        )
        rows(col, actions, 3)

        col.addView(label("Text colours are chosen automatically so everything stays easy to read, whatever colour you pick.", 14f, "t:dim").apply {
            setPadding(0, dp(14), 0, 0)
        })
        restyle()
        tiles.firstOrNull { it.pal.id == Theme.palette.id }?.requestFocus() ?: tiles.firstOrNull()?.requestFocus()
    }

    private fun choose(p: Palette) {
        Theme.set(this, p)
        restyle()
    }

    private fun restyle() {
        Theme.applyAll(this, root)
        current.text = "Current: ${Theme.palette.name}"
        tiles.forEach { it.chosen = it.pal.id == Theme.palette.id; it.invalidate() }
    }

    // ---- building blocks ---------------------------------------------------------------------------------------------
    private fun label(t: String, sp: Float, tag: String, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; this.tag = tag
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun section(t: String) = label(t, 18f, "t:accent", bold = true).apply { setPadding(0, dp(22), 0, dp(8)) }

    private fun tile(p: Palette, heightDp: Int): ThemeTile {
        val t = ThemeTile(this, p)
        t.minimumHeight = dp(heightDp)
        t.setOnClickListener { choose(p) }
        tiles += t
        return t
    }

    private fun action(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 17f; tag = "t:item;bg:item"
        gravity = Gravity.CENTER; isFocusable = true; isClickable = true
        setPadding(dp(14), dp(16), dp(14), dp(16))
        setOnClickListener { onClick() }
    }

    /** Lays [items] out [perRow] to a row, sharing the width equally (the last row is padded with empty space). */
    private fun rows(parent: LinearLayout, items: List<View>, perRow: Int) {
        items.chunked(perRow).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until perRow) {
                val v: View = chunk.getOrNull(i) ?: View(this)
                val h = if (v is ThemeTile) maxOf(v.minimumHeight, dp(40)) else ViewGroup.LayoutParams.WRAP_CONTENT
                row.addView(v, LinearLayout.LayoutParams(0, h, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
            }
            parent.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }
}

/** A swatch that previews a palette (background / picture, panel, accent, text) and shows a ring when focused. */
class ThemeTile(ctx: Context, pal0: Palette, focusableTile: Boolean = true) : View(ctx) {
    var pal: Palette = pal0
        set(v) { field = v; crop = null; invalidate() }
    var chosen = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val rect = RectF()
    private var crop: CropDrawable? = null

    init { isFocusable = focusableTile; isClickable = focusableTile }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val pad = 4 * d
        rect.set(pad, pad, width - pad, height - pad)
        if (rect.width() <= 0 || rect.height() <= 0) return
        val r = 10 * d
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)

        c.save()
        c.clipPath(clip)
        val img = Theme.bitmapFor(context, pal.image)
        if (img != null) {
            val cd = crop ?: CropDrawable(img).also { crop = it }
            cd.setBounds(rect.left.toInt(), rect.top.toInt(), rect.right.toInt(), rect.bottom.toInt())
            cd.draw(c)
            paint.color = pal.scrimColor; c.drawRect(rect, paint)
        } else {
            paint.color = pal.bg; c.drawRect(rect, paint)
        }
        // "panel" strip with the name, accent pill and two text lines above it
        val stripTop = rect.bottom - rect.height() * 0.40f
        paint.color = pal.surface; c.drawRect(rect.left, stripTop, rect.right, rect.bottom, paint)
        val x = rect.left + 10 * d
        paint.color = pal.accent
        c.drawRoundRect(x, rect.top + 10 * d, x + rect.width() * 0.28f, rect.top + 20 * d, 5 * d, 5 * d, paint)
        paint.color = pal.text
        c.drawRoundRect(x, rect.top + 28 * d, x + rect.width() * 0.55f, rect.top + 33 * d, 3 * d, 3 * d, paint)
        paint.color = pal.textDim
        c.drawRoundRect(x, rect.top + 39 * d, x + rect.width() * 0.40f, rect.top + 43 * d, 2 * d, 2 * d, paint)
        label.color = pal.text; label.textSize = 14 * d
        val ty = stripTop + (rect.bottom - stripTop) / 2f + 5 * d
        c.drawText(android.text.TextUtils.ellipsize(pal.name, label, rect.width() - 20 * d, android.text.TextUtils.TruncateAt.END).toString(), x, ty, label)
        c.restore()

        if (chosen) {
            val cx = rect.right - 14 * d; val cy = rect.top + 14 * d
            paint.color = Theme.accent; c.drawCircle(cx, cy, 10 * d, paint)
            label.color = Theme.onAccent; label.textSize = 14 * d
            c.drawText("✓", cx - label.measureText("✓") / 2f, cy + 5 * d, label)
        }
        if (isFocused) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3.5f * d
            paint.color = Theme.text
            c.drawRoundRect(rect.left - 1 * d, rect.top - 1 * d, rect.right + 1 * d, rect.bottom + 1 * d, r, r, paint)
            paint.style = Paint.Style.FILL
        }
    }
}

/** Hue / saturation / brightness picker driven by the D-pad (LEFT / RIGHT on a bar). Result is always made readable by the theme maths. */
object ColourPicker {
    fun show(a: Activity, title: String, initial: Int, accentMode: Boolean, onPicked: (Int) -> Unit) {
        val hsv0 = ThemeMath.toHsv(initial)
        var h = hsv0[0]; var s = hsv0[1]; var v = hsv0[2]
        val pal = Theme.palette

        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(28), a.dp(22), a.dp(28), a.dp(22))
            setBackgroundColor(pal.bg)
        }
        fun text(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(a).apply {
            this.text = t; textSize = sp; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        col.addView(text(title, 22f, pal.text, true))
        col.addView(text("LEFT / RIGHT changes the focused bar", 14f, pal.textDim))

        fun made(): Palette = if (accentMode) pal.withAccent(ThemeMath.hsv(h, s, v)) else Palette.fromBase("custom", "Custom", ThemeMath.hsv(h, s, v))
        val preview = ThemeTile(a, made(), focusableTile = false)
        col.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, a.dp(110)).apply { topMargin = a.dp(12); bottomMargin = a.dp(8) })

        val trackH = a.dp(14)
        fun gradient(vararg colors: Int) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors).apply {
            cornerRadius = trackH / 2f; setSize(a.dp(100), trackH)
        }
        val hueColors = IntArray(7) { ThemeMath.hsv(it * 60.0, 1.0, 1.0) }
        lateinit var satTrack: GradientDrawable
        lateinit var valTrack: GradientDrawable

        fun bar(name: String, max: Int, start: Int, step: Int, track: GradientDrawable, change: (Int) -> Unit): SeekBar {
            val row = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(10), a.dp(6), a.dp(10), a.dp(8)) }
            row.addView(text(name, 15f, pal.text))
            val sb = SeekBar(a).apply {
                this.max = max; progress = start; keyProgressIncrement = step
                splitTrack = false
                progressDrawable = track
                thumb = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFFFFFFF.toInt()); setStroke(a.dp(2), 0xFF000000.toInt()); setSize(a.dp(26), a.dp(26)) }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { change(p) }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
                setOnFocusChangeListener { _, f -> row.setBackgroundColor(if (f) pal.surface2 else 0) }
            }
            row.addView(sb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = a.dp(4) })
            col.addView(row)
            return sb
        }

        fun refresh() {
            satTrack.colors = intArrayOf(ThemeMath.hsv(h, 0.0, v), ThemeMath.hsv(h, 1.0, v))
            valTrack.colors = intArrayOf(ThemeMath.hsv(h, s, 0.0), ThemeMath.hsv(h, s, 1.0))
            preview.pal = made()
        }
        satTrack = gradient(0, 0); valTrack = gradient(0, 0)
        val hueBar = bar("Colour (hue)", 359, h.toInt(), 5, gradient(*hueColors)) { h = it.toDouble(); refresh() }
        bar("Strength (saturation)", 100, (s * 100).toInt(), 2, satTrack) { s = it / 100.0; refresh() }
        bar("Brightness", 100, (v * 100).toInt(), 2, valTrack) { v = it / 100.0; refresh() }
        refresh()

        val dlg = AlertDialog.Builder(a).setView(col).create()
        val buttons = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, a.dp(10), 0, 0) }
        fun button(t: String, onClick: () -> Unit) = TextView(a).apply {
            text = t; textSize = 18f; gravity = Gravity.CENTER; isFocusable = true; isClickable = true
            tag = "t:item;bg:item"
            setPadding(a.dp(12), a.dp(12), a.dp(12), a.dp(12))
            setOnClickListener { onClick() }
        }
        buttons.addView(button("Use this colour") { onPicked(ThemeMath.hsv(h, s, v)); dlg.dismiss() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(a.dp(4), 0, a.dp(4), 0) })
        buttons.addView(button("Cancel") { dlg.dismiss() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(a.dp(4), 0, a.dp(4), 0) })
        col.addView(buttons)
        Theme.applyTree(col)

        dlg.show()
        dlg.window?.setBackgroundDrawable(ColorDrawable(pal.bg))
        dlg.window?.setLayout(a.dp(600), ViewGroup.LayoutParams.WRAP_CONTENT)
        hueBar.requestFocus()
    }
}
