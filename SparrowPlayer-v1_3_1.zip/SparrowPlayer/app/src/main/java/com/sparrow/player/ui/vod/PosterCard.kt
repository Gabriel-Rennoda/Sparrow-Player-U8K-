package com.sparrow.player.ui.vod

import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.TextUtils
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import coil.imageLoader
import coil.request.ImageRequest
import coil.size.Scale
import com.sparrow.player.R
import com.sparrow.player.ui.theme.Theme

/** Size of a poster: a share of the screen width, 2:3. Used by the card AND by the prefetcher so cache keys match. */
object PosterSize {
    fun width(ctx: Context): Int = (ctx.resources.displayMetrics.widthPixels * 0.14f).toInt()
    fun height(ctx: Context): Int = width(ctx) * 3 / 2

    fun request(ctx: Context, url: String): ImageRequest.Builder =
        ImageRequest.Builder(ctx).data(url).size(width(ctx), height(ctx)).scale(Scale.FILL).crossfade(false)
}

/**
 * Poster + title + sub line. When focused it is drawn like Netflix / Disney+: the card is enlarged by Leanback's zoom
 * (it grows wider AND taller over its neighbours) and this view adds, behind the poster, a soft black shadow that falls on
 * the neighbouring titles, edged by a thin white halo ring - so selection / shadow / titles behind read as three layers.
 */
class PosterCard(ctx: Context) : LinearLayout(ctx) {
    private val d = resources.displayMetrics.density
    private val radius = 8 * d
    private val spread = 12 * d
    private val posterW = PosterSize.width(ctx)
    private val posterH = PosterSize.height(ctx)

    val poster = ImageView(ctx)
    private val title = TextView(ctx)
    private val sub = TextView(ctx)
    private var progress = 0

    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    init {
        orientation = VERTICAL
        isFocusable = true
        isFocusableInTouchMode = true
        clipChildren = false
        clipToPadding = false
        setWillNotDraw(false)
        setPadding((spread + 4 * d).toInt(), (spread + 2 * d).toInt(), (spread + 4 * d).toInt(), (spread + 2 * d).toInt())

        poster.scaleType = ImageView.ScaleType.CENTER_CROP
        poster.setBackgroundColor(Theme.surface2)
        poster.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, radius) }
        }
        poster.clipToOutline = true
        addView(poster, LayoutParams(posterW, posterH))

        title.setSingleLine(true); title.ellipsize = TextUtils.TruncateAt.END; title.textSize = 15f
        title.setTextColor(Theme.text)
        addView(title, LayoutParams(posterW, LayoutParams.WRAP_CONTENT).apply { topMargin = (8 * d).toInt() })
        sub.setSingleLine(true); sub.ellipsize = TextUtils.TruncateAt.END; sub.textSize = 13f
        sub.setTextColor(Theme.textDim)
        addView(sub, LayoutParams(posterW, LayoutParams.WRAP_CONTENT))
    }

    fun bind(name: String, subtitle: String, posterUrl: String?, percent: Int) {
        title.text = name
        sub.text = subtitle
        progress = percent
        setPoster(posterUrl)
        invalidate()
    }

    private fun setPoster(url: String?) {
        if (url.isNullOrBlank()) { fallback(); return }
        poster.scaleType = ImageView.ScaleType.CENTER_CROP
        poster.alpha = 1f
        val req = PosterSize.request(context, url).target(poster)
            .listener(onError = { _, _ -> fallback() }).build()
        context.imageLoader.enqueue(req)
    }

    private fun fallback() {
        poster.scaleType = ImageView.ScaleType.CENTER_INSIDE
        poster.alpha = 0.35f
        poster.setImageResource(R.drawable.logo_circle)
    }

    fun clear() { poster.setImageDrawable(null); poster.alpha = 1f }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        invalidate()
    }

    override fun dispatchDraw(c: Canvas) {
        if (isFocused) drawHalo(c)
        super.dispatchDraw(c)
        if (progress in 1..100) {
            val l = poster.left.toFloat(); val r = poster.right.toFloat(); val b = poster.bottom.toFloat()
            val h = 5 * d
            bar.color = 0xAA000000.toInt(); c.drawRect(l, b - h, r, b, bar)
            bar.color = Theme.accent; c.drawRect(l, b - h, l + (r - l) * progress / 100f, b, bar)
        }
    }

    /** Shadow band (darkest next to the poster, fading outward) + a thin white ring at its outer edge. */
    private fun drawHalo(c: Canvas) {
        val l = poster.left.toFloat(); val t = poster.top.toFloat(); val r = poster.right.toFloat(); val b = poster.bottom.toFloat()
        val steps = 8
        shade.color = 0x2A000000          // each layer ~16 %; the innermost area is covered by all of them (~75 %)
        for (i in steps downTo 1) {
            val g = spread * i / steps
            box.set(l - g, t - g, r + g, b + g)
            c.drawRoundRect(box, radius + g, radius + g, shade)
        }
        ring.color = 0xF2FFFFFF.toInt()
        box.set(l - spread, t - spread, r + spread, b + spread)
        c.drawRoundRect(box, radius + spread, radius + spread, ring)
    }
}
