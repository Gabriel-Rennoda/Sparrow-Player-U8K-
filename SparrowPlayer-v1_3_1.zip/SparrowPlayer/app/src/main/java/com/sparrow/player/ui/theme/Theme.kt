package com.sparrow.player.ui.theme

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.sparrow.player.R
import com.sparrow.player.util.repo

/**
 * The app's current look. Layout files don't hard-code colours any more: views carry a tag such as
 * `t:text;b:surface` and [applyTree] paints them from the current [Palette]. Custom views (guide, poster cards) read
 * the colours straight from here. Changing the theme bumps [version]; MainActivity re-creates itself when it sees that.
 */
object Theme {
    @Volatile var palette: Palette = Palette.SPARROW
        private set
    @Volatile var version = 0
        private set

    val bg get() = palette.bg
    val surface get() = palette.surface
    val surface2 get() = palette.surface2
    val accent get() = palette.accent
    val text get() = palette.text
    val textDim get() = palette.textDim
    val onAccent get() = palette.onAccent

    fun init(ctx: Context) {
        Palette.decode(ctx.repo.prefs.theme)?.let { palette = it }
    }

    fun set(ctx: Context, p: Palette) {
        palette = p
        ctx.repo.prefs.theme = p.encode()
        version++
    }

    private val density get() = Resources.getSystem().displayMetrics.density
    private fun dp(v: Float) = v * density

    // ---- window ------------------------------------------------------------------------------------------------------
    private val bitmaps = HashMap<String, Bitmap>()

    private fun resOf(name: String): Int = when (name) {
        "bg_ink" -> R.drawable.bg_ink
        "bg_satin" -> R.drawable.bg_satin
        "bg_smoke" -> R.drawable.bg_smoke
        else -> 0
    }

    /** Each picture is decoded once and shared (RGB_565: half the memory, plenty for a darkened backdrop; about 1.8 MB each). */
    @Synchronized
    fun bitmapFor(ctx: Context, name: String): Bitmap? {
        if (name.isEmpty()) return null
        bitmaps[name]?.let { return it }
        val id = resOf(name)
        if (id == 0) return null
        val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565; inScaled = false }
        val b = try { BitmapFactory.decodeResource(ctx.resources, id, o) } catch (e: Throwable) { null }
        if (b != null) bitmaps[name] = b
        return b
    }

    fun windowBackground(ctx: Context, p: Palette = palette): Drawable {
        val b = bitmapFor(ctx, p.image) ?: return ColorDrawable(p.bg)
        return LayerDrawable(arrayOf(CropDrawable(b), ColorDrawable(p.scrimColor)))
    }

    fun applyWindow(a: Activity) {
        a.window.setBackgroundDrawable(windowBackground(a))
    }

    /** Window background + every tagged view of the activity. */
    fun applyAll(a: Activity, root: View) {
        applyWindow(a)
        applyTree(root)
    }

    // ---- tagged views ----------------------------------------------------------------------------------------------------
    fun applyTree(v: View) {
        applyTags(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) applyTree(v.getChildAt(i))
    }

    private fun applyTags(v: View) {
        val tag = v.tag as? String ?: return
        if (!tag.contains(':')) return
        for (tok in tag.split(';')) {
            val k = tok.substringBefore(':').trim()
            val n = tok.substringAfter(':').trim()
            when (k) {
                "t" -> if (v is TextView) v.setTextColor(textList(n))
                "h" -> if (v is TextView) v.setHintTextColor(color(n))
                "b" -> v.setBackgroundColor(color(n))
                "bg" -> when (n) {
                    "item" -> v.background = itemBg()
                    "player" -> v.background = playerBg()
                    "scrim" -> v.background = detailScrim()
                }
                "tint" -> if (v is ImageView) v.imageTintList = navTint()
                "pt" -> if (v is ProgressBar) v.progressTintList = ColorStateList.valueOf(color(n))
                "pb" -> if (v is ProgressBar) v.progressBackgroundTintList = ColorStateList.valueOf(color(n))
            }
        }
    }

    fun color(name: String): Int = when (name) {
        "bg" -> palette.bg
        "surface" -> palette.surface
        "surface2" -> palette.surface2
        "accent" -> palette.accent
        "accentOD" -> palette.accentOnDark
        "text" -> palette.text
        "dim" -> palette.textDim
        "onAccent" -> palette.onAccent
        "track" -> 0x55FFFFFF
        else -> palette.text
    }

    private fun textList(name: String): ColorStateList = when (name) {
        "item" -> states(palette.onAccent, null, palette.text)
        "nav" -> states(palette.onAccent, palette.accent, palette.textDim)
        else -> ColorStateList.valueOf(color(name))
    }

    private fun navTint(): ColorStateList = textList("nav")

    /** focused / selected / default colours. */
    private fun states(focused: Int, selected: Int?, normal: Int): ColorStateList {
        val st = ArrayList<IntArray>(); val co = ArrayList<Int>()
        st += intArrayOf(android.R.attr.state_focused); co += focused
        if (selected != null) { st += intArrayOf(android.R.attr.state_selected); co += selected }
        st += intArrayOf(); co += normal
        return ColorStateList(st.toTypedArray(), co.toIntArray())
    }

    private fun round(c: Int): GradientDrawable = GradientDrawable().apply { setColor(c); cornerRadius = dp(10f) }

    /** Focus = accent fill, selected = surface2, otherwise clear (list rows, buttons, tabs). */
    fun itemBg(): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), round(palette.accent))
        addState(intArrayOf(android.R.attr.state_selected), round(palette.surface2))
        addState(intArrayOf(), ColorDrawable(0))
    }

    /** The small live player box: an accent frame when focused. */
    fun playerBg(): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), round(palette.accent))
        addState(intArrayOf(), round(0xFF000000.toInt()))
    }

    /** Bar under the details-screen backdrop: fades the picture into the theme colour. */
    fun detailScrim(): Drawable {
        val b = palette.bg and 0xFFFFFF
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf((0xF0 shl 24) or b, (0x99 shl 24) or b, (0xCC shl 24) or b)
        )
    }
}

/** Centre-crops a bitmap to whatever bounds it is given (the window background). */
class CropDrawable(private val bmp: Bitmap) : Drawable() {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty || bmp.width == 0 || bmp.height == 0) return
        val s = maxOf(b.width().toFloat() / bmp.width, b.height().toFloat() / bmp.height)
        val l = b.left + (b.width() - bmp.width * s) / 2f
        val t = b.top + (b.height() - bmp.height * s) / 2f
        c.save()
        c.clipRect(b)
        c.translate(l, t)
        c.scale(s, s)
        c.drawBitmap(bmp, 0f, 0f, paint)
        c.restore()
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
