package com.sparrow.player.data

import android.app.Application
import androidx.room.Room
import androidx.room.withTransaction
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class Repository(app: Application) {
    // Providers (with their logins) live in this database. There is deliberately NO fallbackToDestructiveMigration(): if a
    // schema change ever ships without a Migration, Room must refuse loudly instead of silently deleting the user's providers.
    // Rule: any change to an @Entity => bump AppDb.version AND add a Migration here (see docs/UPGRADE_SAFETY.md).
    val db: AppDb = Room.databaseBuilder(app, AppDb::class.java, "sparrow.db").addMigrations(*Migrations.ALL).build()
    val dao = db.dao()
    val prefs = Prefs(app)

    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .addInterceptor { it.proceed(it.request().newBuilder().header("User-Agent", Prefs.UA).build()) }
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val status = MutableStateFlow("")
    val dataVersion = MutableStateFlow(0)

    @Volatile var active: Provider? = null
        private set

    suspend fun activeProvider(): Provider? {
        val p = dao.provider(prefs.activeProvider) ?: dao.providers().firstOrNull()
        if (p != null) prefs.activeProvider = p.id
        active = p
        return p
    }

    // ---- URLs -------------------------------------------------------------------------------
    fun liveUrl(c: Channel): String =
        if (c.streamUrl.isNotBlank()) c.streamUrl else Urls.live(active!!, c.remoteId, prefs.liveFormat)

    fun movieUrl(v: VodItem): String =
        if (v.streamUrl.isNotBlank()) v.streamUrl else Urls.movie(active!!, v.remoteId, v.ext.ifBlank { "mp4" })

    fun episodeUrl(e: Episode): String = Urls.episode(active!!, e.id, e.ext)

    suspend fun seriesEpisodes(v: VodItem): List<Episode> = withContext(Dispatchers.IO) {
        XtreamClient(http, active!!).seriesEpisodes(v.remoteId)
    }

    suspend fun vodInfo(v: VodItem): Map<String, Any?> = withContext(Dispatchers.IO) {
        try { XtreamClient(http, active!!).vodInfo(v.remoteId) } catch (e: Exception) { emptyMap() }
    }

    // ---- Channel helpers --------------------------------------------------------------------
    suspend fun channelsFor(pid: Long, scope: String): List<Channel> = when (scope) {
        SCOPE_ALL -> dao.channels(pid)
        SCOPE_FAV -> dao.favorites(pid)
        else -> dao.channelsIn(pid, scope)
    }

    /** Currently airing programme per epgId. */
    suspend fun nowMap(pid: Long, channels: List<Channel>): Map<String, Programme> {
        val now = System.currentTimeMillis()
        val ids = channels.map { it.epgId }.filter { it.isNotBlank() }.distinct()
        val out = HashMap<String, Programme>()
        ids.chunked(500).forEach { chunk ->
            dao.programmes(pid, chunk, now, now + 1).forEach { out[it.epgId] = it }
        }
        return out
    }

    suspend fun deleteProvider(p: Provider) {
        withContext(Dispatchers.IO) { dao.deleteProgrammes(p.id) }
        db.withTransaction {
            dao.deleteChannels(p.id); dao.deleteVod(p.id); dao.deleteCategories(p.id)
            dao.deleteProvider(p.id)
        }
        prefs.activeProvider = -1
        active = null
        dataVersion.value++
    }

    // ---- Sync -------------------------------------------------------------------------------
    fun syncAsync(p: Provider) {
        scope.launch {
            try {
                sync(p)
            } catch (e: Exception) {
                status.value = "Sync failed: ${e.message}"
                delay(8000)
                status.value = ""
            }
        }
    }

    private suspend fun sync(p0: Provider) = withContext(Dispatchers.IO) {
        var p = p0
        val st = { s: String -> status.value = s }
        if (p.type == "xtream") syncXtream(p, st) else p = syncM3u(p, st)
        try {
            syncEpg(p, st)
        } catch (e: Exception) {
            st("TV guide failed: ${e.message}"); delay(5000)
        }
        dao.updateProvider(p.copy(lastSync = System.currentTimeMillis()))
        dataVersion.value++
        st("Ready"); delay(2000); st("")
    }

    private suspend fun syncXtream(p: Provider, st: (String) -> Unit) {
        val x = XtreamClient(http, p)
        st("Signing in…")
        if (!x.authenticate()) error("Login failed – check server, username and password")
        val favs = dao.favoriteKeys(p.id)

        st("Loading categories…")
        val cats = ArrayList<Category>()
        for ((action, type) in listOf("get_live_categories" to "live", "get_vod_categories" to "vod", "get_series_categories" to "series")) {
            x.list(action) { m -> cats += Category(providerId = p.id, remoteId = m.str("category_id"), name = m.str("category_name"), type = type) }
        }

        st("Loading live channels…")
        val ch = ArrayList<Channel>(); var n = 0
        x.list("get_live_streams") { m ->
            n++
            val id = m.str("stream_id")
            ch += Channel("${p.id}:$id", p.id, id, m.str("num").toIntOrNull() ?: n, m.str("name"),
                m.str("stream_icon"), "", m.str("category_id"), m.str("epg_channel_id"), false)
        }

        st("Loading movies…")
        val vod = ArrayList<VodItem>()
        x.list("get_vod_streams") { m ->
            val id = m.str("stream_id")
            vod += VodItem("${p.id}:m:$id", p.id, id, "movie", m.str("name"), m.str("stream_icon"), m.str("stream_icon"),
                m.str("category_id"), m.str("rating"), m.str("year"), "", m.str("added").toLongOrNull() ?: 0,
                m.str("container_extension"), "", "")
        }

        st("Loading series…")
        x.list("get_series") { m ->
            val id = m.str("series_id")
            val bd = (m["backdrop_path"] as? List<*>)?.firstOrNull()?.toString() ?: ""
            vod += VodItem("${p.id}:s:$id", p.id, id, "series", m.str("name"), m.str("cover"), bd.ifBlank { m.str("cover") },
                m.str("category_id"), m.str("rating"), m.str("year").ifBlank { m.str("releaseDate").take(4) },
                m.str("plot"), m.str("last_modified").toLongOrNull() ?: 0, "", m.str("genre"), "")
        }
        st("Saving…")
        store(p, cats, ch, vod, favs)
    }

    private suspend fun syncM3u(p: Provider, st: (String) -> Unit): Provider {
        st("Downloading playlist…")
        val favs = dao.favoriteKeys(p.id)
        val ch = ArrayList<Channel>(); val vod = ArrayList<VodItem>()
        val liveGroups = LinkedHashSet<String>(); val vodGroups = LinkedHashSet<String>()
        var n = 0
        var epg = ""
        http.newCall(Request.Builder().url(p.m3uUrl).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            epg = M3uParser.parse(r.body!!.byteStream()) { e ->
                n++
                val id = Integer.toHexString(e.url.hashCode())
                if (e.url.contains("/movie/")) {
                    vodGroups += e.group
                    vod += VodItem("${p.id}:m:$id", p.id, id, "movie", e.name, e.logo, e.logo, e.group, "", "", "",
                        n.toLong(), "", "", e.url)
                } else {
                    liveGroups += e.group
                    ch += Channel("${p.id}:$id", p.id, id, e.chno ?: n, e.name, e.logo, e.url, e.group, e.tvgId, false)
                }
            }
        }
        val cats = liveGroups.map { Category(providerId = p.id, remoteId = it, name = it, type = "live") } +
            vodGroups.map { Category(providerId = p.id, remoteId = it, name = it, type = "vod") }
        st("Saving…")
        store(p, cats, ch, vod, favs)
        return if (p.epgUrl.isBlank() && epg.isNotBlank()) p.copy(epgUrl = epg) else p
    }

    private suspend fun store(p: Provider, cats: List<Category>, ch: List<Channel>, vod: List<VodItem>, favs: List<String>) {
        db.withTransaction {
            dao.deleteCategories(p.id); dao.deleteChannels(p.id); dao.deleteVod(p.id)
            dao.insertCategories(cats)
            ch.chunked(2000).forEach { dao.insertChannels(it) }
            vod.chunked(2000).forEach { dao.insertVod(it) }
            favs.chunked(500).forEach { dao.restoreFavorites(it) }
        }
        dataVersion.value++
    }

    private suspend fun syncEpg(p: Provider, st: (String) -> Unit) {
        val url = when {
            p.epgUrl.isNotBlank() -> p.epgUrl
            p.type == "xtream" -> Urls.xmltv(p)
            else -> return
        }
        val ids = dao.channels(p.id).map { it.epgId }.filter { it.isNotBlank() }.toHashSet()
        if (ids.isEmpty()) return
        st("Downloading TV guide…")
        dao.deleteProgrammes(p.id)
        val now = System.currentTimeMillis()
        val from = now - 3 * 3600_000L; val to = now + 36 * 3600_000L
        http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("EPG HTTP ${r.code}")
            val input = XmltvParser.maybeGunzip(r.body!!.byteStream())
            val buf = ArrayList<Programme>(); var count = 0
            XmltvParser.parse(input, ids, from, to) { pr ->
                buf += pr.copy(providerId = p.id); count++
                if (buf.size >= 1500) {
                    dao.insertProgrammes(ArrayList(buf)); buf.clear(); st("Importing TV guide… $count")
                }
            }
            if (buf.isNotEmpty()) dao.insertProgrammes(buf)
        }
    }

    companion object {
        const val SCOPE_ALL = "__all"
        const val SCOPE_FAV = "__fav"
    }
}
