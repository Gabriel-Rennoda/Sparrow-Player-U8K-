package com.sparrow.player.ui.epg

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.TextPaint
import android.text.TextUtils
import android.util.AttributeSet
import android.util.LruCache
import android.view.KeyEvent
import android.view.View
import coil.imageLoader
import coil.request.ImageRequest
import com.sparrow.player.R
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Programme
import com.sparrow.player.util.TimeFmt
import com.sparrow.player.util.fmtTime

/**
 * Canvas-drawn guide: a grid of equal-height channel rows x four half-hour columns (2 hours).
 *
 *  - The window starts at the CURRENT half hour. LEFT / RIGHT move the highlight from block to block; when the next block is
 *    beyond the window the grid scrolls (30 min steps) so the user can browse freely into the future (up to 36 h). Going back,
 *    it stops at the current half hour - the guide never shows the past.
 *  - OK -> [onPlay] (tune / full screen). Hold OK -> [onFavorite]. BACK after browsing ahead snaps the grid back to now.
 *  - A programme that spans several half hours is one continuous block. Rows without data show a selectable
 *    "No information" block, so browsing works on every row.
 *  - The date and clock live in the top-left corner cell (above the channel column, beside the half-hour labels).
 * Only the visible rows are drawn / loaded, so thousands of channels stay smooth on a TV SoC.
 */
class EpgView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    /** programmes == null: guide data not loaded yet (loaded lazily around the visible rows). */
    class Row(var channel: Channel, var programmes: List<Programme>?)

    var onSelect: ((Row, Programme?, Programme?) -> Unit)? = null
    var onPlay: ((Channel) -> Unit)? = null
    var onFavorite: ((Channel) -> Unit)? = null
    var onNeedData: ((first: Int, last: Int) -> Unit)? = null

    var playingUid: String = ""
        set(v) { field = v; invalidate() }
    var showNumbers: Boolean = true
        set(v) { field = v; invalidate() }

    private var rows: List<Row> = emptyList()
    val rowList: List<Row> get() = rows
    private var baseStart = 0L        // start of the current half hour
    private var windowStart = 0L      // left edge of the grid (== baseStart unless the user browsed ahead)
    private var selRow = 0
    private var selTime = 0L
    private var topRow = 0

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private val chanW = dp(220f)
    private val headerH = dp(44f)
    private val radius = dp(6f)
    private val gap = dp(2f)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(15f) }
    private val small = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(13f); color = Theme.textDim }
    private val line = Paint().apply { color = Theme.surface2; strokeWidth = 1f }
    private val clockPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(20f); typeface = Typeface.DEFAULT_BOLD }
    private val nowPaint = Paint().apply { color = 0xFFE5484D.toInt() }

    // ---- channel logos (Coil, loaded only for rows that are drawn) --------------------------------
    private val logos = LruCache<String, Drawable>(120)
    private val logoPending = HashSet<String>()
    private val logoFailed = HashSet<String>()
    private val placeholder: Drawable? by lazy { context.getDrawable(R.drawable.logo_circle)?.mutate()?.apply { alpha = 70 } }

    private fun logoFor(url: String): Drawable? {
        if (url.isBlank() || url in logoFailed) return null
        logos.get(url)?.let { return it }
        if (logoPending.add(url)) {
            context.imageLoader.enqueue(
                ImageRequest.Builder(context).data(url).size(dp(112f).toInt(), dp(80f).toInt())
                    .target(
                        onSuccess = { d -> logos.put(url, d); logoPending.remove(url); invalidate() },
                        onError = { logoPending.remove(url); logoFailed.add(url) }
                    ).build()
            )
        }
        return null
    }

    init { isFocusable = true; isFocusableInTouchMode = false }

    // ---- data ------------------------------------------------------------------------------------
    fun setData(r: List<Row>, base: Long, selectUid: String? = null) {
        rows = r; baseStart = base; windowStart = base; selTime = base
        selRow = selectUid?.let { u -> r.indexOfFirst { it.channel.uid == u } }?.takeIf { it >= 0 } ?: 0
        topRow = 0
        post { changed() }
    }

    fun removeChannel(uid: String) {
        rows = rows.filter { it.channel.uid != uid }
        selRow = selRow.coerceIn(0, maxOf(0, rows.size - 1))
        changed()
    }

    fun updateChannel(c: Channel) { rows.firstOrNull { it.channel.uid == c.uid }?.channel = c; invalidate() }

    /** The fragment filled in programmes for some rows. */
    fun dataArrived() {
        // keep memory bounded when scrolling through thousands of channels
        val lo = topRow - 80; val hi = topRow + VISIBLE_ROWS + 80
        rows.forEachIndexed { i, r -> if ((i < lo || i > hi) && r.channel.epgId.isNotBlank()) r.programmes = null }
        invalidate(); notifySel()
    }

    /** Re-announce the selection (info pane) after something about it changed. */
    fun reselect() = notifySel()

    /** Called every minute: redraws the clock and, when a new half hour starts, drops the window's left edge forward if it would be in the past. */
    fun tick(now: Long = System.currentTimeMillis()) {
        val nb = GuideMath.baseStart(now)
        if (nb != baseStart) {
            val browsedAhead = windowStart > baseStart          // the user is looking at the future: leave the window where it is
            baseStart = nb
            windowStart = (if (browsedAhead) windowStart else nb).coerceIn(GuideMath.minStart(nb), GuideMath.maxStart(nb))
            selTime = selTime.coerceIn(windowStart, GuideMath.windowEnd(windowStart) - 1)
            changed()
        } else invalidate()
    }

    // ---- model helpers --------------------------------------------------------------------------
    private fun rowH() = (height - headerH) / VISIBLE_ROWS
    private fun windowEnd() = GuideMath.windowEnd(windowStart)
    private fun segsOf(r: Int) = GuideMath.segments(rows[r].programmes ?: emptyList(), windowStart, windowEnd())
    private fun selSeg(): Int = GuideMath.indexAt(segsOf(selRow), selTime)

    /** All blocks of a row over the whole browsable range (now .. +36 h), for moving the highlight. */
    private fun allSegsOf(r: Int) = GuideMath.segments(rows[r].programmes ?: emptyList(), baseStart, baseStart + GuideMath.FUTURE)

    /** True when LEFT has nowhere to go (first block at the current half hour, window not scrolled): MainActivity opens the side panels. */
    fun atLeftEdge(): Boolean = rows.isEmpty() || (windowStart <= baseStart && GuideMath.indexAt(allSegsOf(selRow), selTime) == 0)

    /** BACK after browsing ahead: snap the grid back to now (same channel stays selected). */
    fun handleBack(): Boolean {
        if (windowStart <= baseStart) return false
        windowStart = baseStart; selTime = baseStart; changed()
        return true
    }

    private fun notifySel() {
        if (rows.isEmpty() || !isFocused) return
        val row = rows[selRow]
        val segs = segsOf(selRow)
        val s = segs[GuideMath.indexAt(segs, selTime)]
        val progs = row.programmes ?: emptyList()
        val p = s.prog
        val next = if (p != null) progs.getOrNull(progs.indexOf(p) + 1) else progs.firstOrNull { it.start >= s.stop }
        onSelect?.invoke(row, p, next)
    }

    private fun changed() { ensureVisible(); invalidate(); requestData(); notifySel() }

    private fun requestData() {
        if (rows.isEmpty()) return
        onNeedData?.invoke(topRow, minOf(rows.size - 1, topRow + VISIBLE_ROWS - 1))
    }

    private fun ensureVisible() {
        if (selRow < topRow) topRow = selRow
        else if (selRow >= topRow + VISIBLE_ROWS) topRow = selRow - VISIBLE_ROWS + 1
        topRow = topRow.coerceIn(0, maxOf(0, rows.size - VISIBLE_ROWS))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); requestData() }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        if (gainFocus) notifySel()
        invalidate()
    }

    // ---- keys -------------------------------------------------------------------------------------
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (rows.isEmpty()) return super.onKeyDown(keyCode, event)
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> { moveSeg(+1); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { moveSeg(-1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { if (selRow < rows.size - 1) { selRow++; changed() }; return true }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (selRow > 0) { selRow--; changed(); return true }
                return super.onKeyDown(keyCode, event)           // let focus leave upwards to the player box
            }
            KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { selRow = minOf(rows.size - 1, selRow + VISIBLE_ROWS); changed(); return true }
            KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { selRow = maxOf(0, selRow - VISIBLE_ROWS); changed(); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (event.repeatCount == 0) event.startTracking()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    /** OK is acted on at key-UP so a long press (favourite) never also counts as a click. */
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (rows.isNotEmpty() && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER ||
                keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) && event.isTracking && !event.isCanceled) {
            okPressed(); return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (rows.isNotEmpty() && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
            onFavorite?.invoke(rows[selRow].channel); return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    private fun okPressed() { onPlay?.invoke(rows[selRow].channel) }

    /** LEFT / RIGHT: next block in that direction; the grid scrolls when it has to (future freely, past only back to now). */
    private fun moveSeg(d: Int) {
        val m = GuideMath.moveHorizontal(allSegsOf(selRow), windowStart, baseStart, selTime, d) ?: return
        windowStart = m.windowStart; selTime = m.selTime; changed()
    }

    // ---- drawing ------------------------------------------------------------------------------------
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (rows.isEmpty()) {
            text.color = Theme.textDim
            c.drawText("No channels in this group – pick another group, or add / refresh a provider in Settings.", dp(8f), h / 2, text); return
        }
        val gl = chanW; val gt = headerH; val rh = rowH()
        val ws = windowStart; val we = windowEnd()
        val pxPerMs = (w - gl) / (GuideMath.SPAN * GuideMath.HALF).toFloat()
        fun xOf(t: Long) = gl + (t - ws) * pxPerMs
        val now = System.currentTimeMillis()
        val focused = isFocused
        val last = minOf(rows.size - 1, topRow + VISIBLE_ROWS - 1)

        // --- programme blocks
        c.save(); c.clipRect(gl, gt, w, h)
        for (r in topRow..last) {
            val y = gt + (r - topRow) * rh
            val row = rows[r]
            val loaded = row.programmes != null
            for (s in GuideMath.segments(row.programmes ?: emptyList(), ws, we)) {
                val x1 = xOf(s.start); val x2 = xOf(s.stop)
                val selected = r == selRow && selTime >= s.start && selTime < s.stop
                val p = s.prog
                fill.color = when {
                    selected && focused -> Theme.accent
                    selected -> Theme.surface2
                    p != null && p.start <= now && p.stop > now -> Theme.palette.nowCell
                    else -> Theme.surface
                }
                c.drawRoundRect(x1 + gap, y + gap, x2 - gap, y + rh - gap, radius, radius, fill)
                val tx = x1 + dp(10f)
                val avail = x2 - tx - dp(8f)
                if (avail > dp(28f)) {
                    val hot = selected && focused
                    text.color = if (hot) Theme.onAccent else if (p == null) Theme.textDim else Theme.text
                    val label = p?.title ?: if (loaded) "No information" else "…"
                    val t = TextUtils.ellipsize(label, text, avail, TextUtils.TruncateAt.END)
                    c.drawText(t, 0, t.length, tx, y + rh / 2 + dp(5f), text)
                }
            }
        }
        val nx = xOf(now)
        if (nx > gl && nx < w) c.drawRect(nx - 1.5f, gt, nx + 1.5f, h, nowPaint)
        c.restore()

        // --- time header: labels at every half hour, the end of the window right-aligned (4:30 5:00 5:30 6:00 | 6:30)
        fill.color = Theme.bg
        c.drawRect(0f, 0f, w, gt, fill)
        small.color = Theme.textDim
        for (k in 0..GuideMath.SPAN) {
            val t = ws + k * GuideMath.HALF
            val x = xOf(t)
            c.drawLine(x, gt - dp(10f), x, gt, line)
            val label = fmtTime(t)
            if (k < GuideMath.SPAN) c.drawText(label, x + dp(6f), gt - dp(9f), small)
            else c.drawText(label, w - dp(6f) - small.measureText(label), gt - dp(9f), small)
        }
        // corner cell (above the channel column): clock, and the date beneath it on the same baseline as the half-hour labels
        clockPaint.color = Theme.text
        c.drawText(TimeFmt.clock(now), dp(10f), dp(21f), clockPaint)
        small.color = Theme.textDim
        c.drawText(TimeFmt.guideDate(now), dp(10f), gt - dp(9f), small)

        // --- channel column (logo, name, optional number)
        c.save(); c.clipRect(0f, gt, gl, h)
        val logoW = dp(56f)
        for (r in topRow..last) {
            val y = gt + (r - topRow) * rh
            val ch = rows[r].channel
            fill.color = if (r == selRow) Theme.surface2 else Theme.bg
            c.drawRect(0f, y, gl, y + rh, fill)
            if (ch.uid == playingUid) { fill.color = Theme.accent; c.drawRect(0f, y + dp(8f), dp(4f), y + rh - dp(8f), fill) }
            val boxL = dp(10f); val boxT = y + dp(5f); val boxB = y + rh - dp(5f)
            val d = logoFor(ch.logo) ?: placeholder
            if (d != null) {
                val iw = d.intrinsicWidth; val ih = d.intrinsicHeight
                val bw = logoW; val bh = boxB - boxT
                val sc = if (iw > 0 && ih > 0) minOf(bw / iw, bh / ih) else 1f
                val dw = if (iw > 0) iw * sc else bw; val dh = if (ih > 0) ih * sc else bh
                val l = boxL + (bw - dw) / 2; val t = boxT + (bh - dh) / 2
                d.setBounds(l.toInt(), t.toInt(), (l + dw).toInt(), (t + dh).toInt())
                d.draw(c)
            }
            val nameX = boxL + logoW + dp(8f)
            text.color = Theme.text; text.textSize = dp(14f)
            val name = TextUtils.ellipsize((if (ch.isFavorite) "★ " else "") + ch.name, text, gl - nameX - dp(6f), TextUtils.TruncateAt.END)
            if (showNumbers) {
                c.drawText(name, 0, name.length, nameX, y + rh / 2 - dp(1f), text)
                small.color = if (ch.uid == playingUid) Theme.accent else Theme.textDim
                c.drawText(ch.number.toString(), nameX, y + rh / 2 + dp(15f), small)
            } else {
                c.drawText(name, 0, name.length, nameX, y + rh / 2 + dp(5f), text)
            }
            text.textSize = dp(15f)
        }
        c.restore()
        small.color = Theme.textDim
        c.drawLine(gl, 0f, gl, h, line)
    }

    companion object { const val VISIBLE_ROWS = 6 }
}
