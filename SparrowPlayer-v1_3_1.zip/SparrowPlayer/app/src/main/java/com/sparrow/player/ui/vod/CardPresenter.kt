package com.sparrow.player.ui.vod

import android.view.ViewGroup
import androidx.leanback.widget.Presenter
import com.sparrow.player.data.VodItem
import com.sparrow.player.util.repo

/** Poster card (2:3) in the Netflix / Disney+ manner; see [PosterCard] for the focus effect. */
class CardPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(PosterCard(parent.context))

    override fun onBindViewHolder(vh: ViewHolder, item: Any?) {
        val v = item as? VodItem ?: return
        val card = vh.view as PosterCard
        val sub = listOf(v.year, ratingText(v)).filter { it.isNotBlank() }.joinToString("  •  ")
        card.bind(v.name, sub, v.poster, card.context.repo.prefs.vodPercent(v))
    }

    override fun onUnbindViewHolder(vh: ViewHolder) { (vh.view as PosterCard).clear() }

    companion object {
        fun ratingText(v: VodItem): String {
            val r = v.rating.toDoubleOrNull() ?: return ""
            return if (r > 0) "★ " + String.format("%.1f", r) else ""
        }
    }
}
