package com.sparrow.player.ui.theme

import com.sparrow.player.ui.theme.ThemeMath.BLACK
import com.sparrow.player.ui.theme.ThemeMath.WHITE
import java.util.Random

/**
 * One complete look for the app. Pure Kotlin (JUnit-testable).
 *
 *  bg / surface / surface2  : page, panels / cards, selected-but-unfocused
 *  accent / onAccent        : focus fill (+ highlighted text) and the text drawn on it
 *  text / textDim           : primary and secondary text
 *  image / scrim            : optional background picture (resource name) and how strongly the bg colour is laid over
 *                             it (0..255) so text on top of the picture stays readable
 */
data class Palette(
    val id: String,
    val name: String,
    val bg: Int,
    val surface: Int,
    val surface2: Int,
    val accent: Int,
    val text: Int,
    val textDim: Int,
    val onAccent: Int,
    val image: String = "",
    val scrim: Int = 0
) {
    val isLight: Boolean by lazy { ThemeMath.luminance(bg) > 0.4 }

    /** Fill of a programme that is on air right now (guide): the surface tinted with the accent, never so much that text stops being readable. */
    val nowCell: Int by lazy {
        var t = 0.14
        var c = ThemeMath.mix(surface, accent, t)
        while (ThemeMath.contrast(text, c) < 4.5 && t > 0.0) { t = maxOf(0.0, t - 0.02); c = ThemeMath.mix(surface, accent, t) }
        c
    }

    /** The accent made readable on the black overlays of the full-screen player / toasts. */
    val accentOnDark: Int by lazy { ThemeMath.ensureContrast(accent, listOf(BLACK), 4.5) }

    /** Colour laid over the background picture. */
    val scrimColor: Int get() = (scrim shl 24) or (bg and 0xFFFFFF)

    fun encode(): String = listOf(
        id, name, ThemeMath.hex(bg), ThemeMath.hex(surface), ThemeMath.hex(surface2), ThemeMath.hex(accent),
        ThemeMath.hex(text), ThemeMath.hex(textDim), ThemeMath.hex(onAccent), image, scrim.toString()
    ).joinToString("|")

    fun withAccent(a: Int): Palette {
        val fixed = ThemeMath.ensureContrast(a, listOf(bg, surface, surface2), 4.5)
        return copy(id = "custom", name = "Custom", accent = fixed, onAccent = ThemeMath.bestOn(fixed))
    }

    companion object {
        fun decode(s: String?): Palette? {
            if (s.isNullOrBlank()) return null
            val p = s.split("|")
            if (p.size < 11) return null
            return try {
                fun h(i: Int) = p[i].toLong(16).toInt()
                Palette(p[0], p[1], h(2), h(3), h(4), h(5), h(6), h(7), h(8), p[9], p[10].toInt())
            } catch (e: Exception) { null }
        }

        // ---- generated palettes -----------------------------------------------------------------------------------

        /**
         * Builds a readable palette from a background colour (and optionally an accent). Whatever colour is passed in,
         * the result keeps: text / bg >= 7:1, text / surfaces >= 4.5:1, dim text / all backgrounds >= 4.5:1,
         * accent / backgrounds >= 4.5:1 and onAccent / accent >= 4.5:1.
         */
        fun fromBase(id: String, name: String, base: Int, accentIn: Int? = null): Palette {
            var bg = base
            val text = ThemeMath.bestOn(bg)
            val textLight = text == WHITE
            var guard = 0
            while (ThemeMath.contrast(text, bg) < 7.0 && guard++ < 60) {
                bg = ThemeMath.mix(bg, if (textLight) BLACK else WHITE, 0.06)
            }

            var t1 = if (textLight) 0.07 else 0.60
            var t2 = if (textLight) 0.16 else 0.10
            // Panels / cards are always lighter than the page (a dark page gets a slightly lighter panel, a light page a whiter one);
            // the selected-but-unfocused fill moves toward the text colour's opposite pole.
            var surface = ThemeMath.mix(bg, WHITE, t1)
            var surface2 = ThemeMath.mix(bg, if (textLight) WHITE else BLACK, t2)
            while (ThemeMath.contrast(text, surface) < 4.5 && t1 > 0.0) { t1 = maxOf(0.0, t1 - 0.02); surface = ThemeMath.mix(bg, WHITE, t1) }
            while (ThemeMath.contrast(text, surface2) < 4.5 && t2 > 0.0) {
                t2 = maxOf(0.0, t2 - 0.02); surface2 = ThemeMath.mix(bg, if (textLight) WHITE else BLACK, t2)
            }

            var d = 0.38
            var dim = ThemeMath.mix(text, bg, d)
            val backs = listOf(bg, surface, surface2)
            while (ThemeMath.minContrast(dim, backs) < 4.5 && d > 0.0) { d = maxOf(0.0, d - 0.04); dim = ThemeMath.mix(text, bg, d) }

            val hsv = ThemeMath.toHsv(bg)
            val rawAccent = accentIn ?: if (textLight) {
                ThemeMath.hsv(hsv[0] + if (hsv[1] > 0.35) 180.0 else 30.0, 0.62, 0.98)
            } else {
                ThemeMath.hsv(hsv[0] + if (hsv[1] > 0.35) 180.0 else 30.0, 0.85, 0.45)
            }
            val accent = ThemeMath.ensureContrast(rawAccent, backs, 4.5)
            return Palette(id, name, bg, surface, surface2, accent, text, dim, ThemeMath.bestOn(accent))
        }

        /** "Random" theme. The seed makes it reproducible in tests; the app passes a fresh Random. */
        fun random(rnd: Random): Palette {
            val h = rnd.nextDouble() * 360.0
            val light = rnd.nextInt(100) < 15
            val base = if (light) ThemeMath.hsv(h, 0.05 + rnd.nextDouble() * 0.12, 0.96)
            else ThemeMath.hsv(h, 0.45 + rnd.nextDouble() * 0.45, 0.10 + rnd.nextDouble() * 0.20)
            val shifts = doubleArrayOf(30.0, 150.0, 180.0, 210.0)
            val ah = h + shifts[rnd.nextInt(shifts.size)]
            val accent = if (light) ThemeMath.hsv(ah, 0.80, 0.50) else ThemeMath.hsv(ah, 0.55 + rnd.nextDouble() * 0.3, 0.97)
            return fromBase("random", "Random", base, accent)
        }

        // ---- stock themes ---------------------------------------------------------------------------------------

        private fun c(hex: Long) = (0xFF000000L or hex).toInt()

        val SPARROW = Palette("stock:sparrow", "Sparrow Classic",
            c(0x0E0A07), c(0x1C140E), c(0x2E2117), c(0xD98E4A), c(0xF5E9DA), c(0xA8977F), c(0x1A0F08))

        /** Black special-edition jersey with the blue logo and stripes. */
        val BIEBER = Palette("stock:bieber", "Leafs Black & Blue",
            c(0x07080B), c(0x12151B), c(0x1C2432), c(0x3D8BFF), c(0xF2F5FA), c(0xA7B1C2), c(0x0A0F1A))

        /** Classic blue home jersey. */
        val LEAFS_BLUE = Palette("stock:leafsblue", "Leafs Blue",
            c(0x001335), c(0x00205B), c(0x0B3A86), c(0xFFFFFF), c(0xFFFFFF), c(0xB5C4E4), c(0x00205B))

        /** Classic white away jersey (the one light theme). */
        val LEAFS_WHITE = Palette("stock:leafswhite", "Leafs White",
            c(0xF3F5FA), c(0xFFFFFF), c(0xDCE4F2), c(0x00205B), c(0x0A1330), c(0x4A5878), c(0xFFFFFF))

        // Scrim strengths come from tools/theme_check.py (measured on the pictures themselves).
        val INK = Palette("stock:ink", "Ink Wash",
            c(0x0F1115), c(0x171A20), c(0x2A3342), c(0x9DBCE0), c(0xF4F4F2), c(0xC3CAD6), c(0x0F1115), "bg_ink", 192)
        val SATIN = Palette("stock:satin", "Satin Night",
            c(0x05070B), c(0x0E131B), c(0x1B2638), c(0xE8A062), c(0xF5F2EE), c(0xB3BAC8), c(0x140C06), "bg_satin", 120)
        val SMOKE = Palette("stock:smoke", "Smoke",
            c(0x04070B), c(0x0D141C), c(0x1A2836), c(0x9FD2FF), c(0xF4F8FC), c(0xB8C6D6), c(0x06121C), "bg_smoke", 140)

        val STOCK: List<Palette> = listOf(BIEBER, LEAFS_BLUE, LEAFS_WHITE, INK, SATIN, SMOKE, SPARROW)

        /** Pre-selected solid colours: name, background, accent. */
        val SOLIDS: List<Triple<String, Int, Int>> = listOf(
            Triple("Crimson", c(0x2A0A12), c(0xFF6B81)),
            Triple("Ember", c(0x2B1406), c(0xFF9F43)),
            Triple("Gold", c(0x2A2205), c(0xFFD166)),
            Triple("Forest", c(0x0B2316), c(0x5FDB8A)),
            Triple("Teal", c(0x062524), c(0x3DDCCB)),
            Triple("Ocean", c(0x06203A), c(0x4DB8FF)),
            Triple("Indigo", c(0x14123B), c(0x8F8CFF)),
            Triple("Violet", c(0x241036), c(0xC58BFF)),
            Triple("Rose", c(0x33101F), c(0xFF7EB6)),
            Triple("Slate", c(0x161A20), c(0x8FA3BF)),
            Triple("Graphite", c(0x111111), c(0xE0E0E0)),
            Triple("Black", c(0x000000), c(0xFFFFFF))
        )

        fun solid(i: Int): Palette {
            val (n, b, a) = SOLIDS[i]
            return fromBase("solid:" + n.lowercase(), n, b, a)
        }

        fun allSolids(): List<Palette> = SOLIDS.indices.map { solid(it) }
    }
}
