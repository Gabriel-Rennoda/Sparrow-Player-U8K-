package com.sparrow.player.ui.theme

import org.junit.Assert.*
import org.junit.Test
import java.util.Random

class ThemeTest {
    private fun check(p: Palette) {
        val n = p.name
        val backs = listOf(p.bg, p.surface, p.surface2)
        assertTrue("$n text/bg", ThemeMath.contrast(p.text, p.bg) >= 7.0)
        assertTrue("$n text/surface", ThemeMath.contrast(p.text, p.surface) >= 4.5)
        assertTrue("$n text/surface2", ThemeMath.contrast(p.text, p.surface2) >= 4.5)
        assertTrue("$n text/nowCell", ThemeMath.contrast(p.text, p.nowCell) >= 4.5)
        assertTrue("$n dim", ThemeMath.minContrast(p.textDim, backs) >= 4.5)
        assertTrue("$n accent/bg", ThemeMath.minContrast(p.accent, listOf(p.bg, p.surface)) >= 4.5)
        assertTrue("$n accent/surface2", ThemeMath.contrast(p.accent, p.surface2) >= 3.0)
        assertTrue("$n onAccent", ThemeMath.contrast(p.onAccent, p.accent) >= 4.5)
        assertTrue("$n accentOnDark", ThemeMath.contrast(p.accentOnDark, ThemeMath.BLACK) >= 4.5)
    }

    @Test fun stockThemesAreReadable() = Palette.STOCK.forEach { check(it) }
    @Test fun solidColoursAreReadable() = Palette.allSolids().forEach { check(it) }

    @Test fun anyCustomColourIsReadable() {
        for (h in 0 until 360 step 15) for (s in 0..10 step 2) for (v in 0..10 step 2)
            check(Palette.fromBase("custom", "Custom", ThemeMath.hsv(h.toDouble(), s / 10.0, v / 10.0)))
    }

    @Test fun randomThemesAreReadable() {
        val r = Random(1)
        repeat(2000) { check(Palette.random(r)) }
    }

    @Test fun customAccentIsMadeReadable() {
        for (p in Palette.STOCK) for (a in listOf(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF808080.toInt(), 0xFFFF00FF.toInt()))
            check(p.withAccent(a))
    }

    @Test fun encodeDecodeRoundTrip() {
        for (p in Palette.STOCK + Palette.allSolids()) assertEquals(p, Palette.decode(p.encode()))
        assertNull(Palette.decode(""))
        assertNull(Palette.decode("garbage|x"))
    }

    @Test fun threeJerseysAndThreePictures() {
        val ids = Palette.STOCK.map { it.id }
        assertTrue(ids.containsAll(listOf("stock:bieber", "stock:leafsblue", "stock:leafswhite", "stock:ink", "stock:satin", "stock:smoke")))
        assertEquals(3, Palette.STOCK.count { it.image.isNotEmpty() })
    }

    @Test fun lightThemeIsLight() { assertTrue(Palette.LEAFS_WHITE.isLight); assertFalse(Palette.BIEBER.isLight) }
}
