#!/usr/bin/env python3
"""Mirror of ui/theme/ThemeMath.kt + Palette.kt (same constants, same loops) so the legibility rules can be verified
off-device, plus a pixel-level check of the three background pictures under their scrim.

  python3 tools/theme_check.py [path/to/res/drawable-nodpi]
Exit code 1 if any rule fails.
"""
import math, random, sys, os

WHITE, BLACK, INK = (255,255,255), (0,0,0), (0x0B,0x0F,0x14)
def hexrgb(h): return ((h>>16)&255, (h>>8)&255, h&255)
def lin(v):
    c=v/255.0
    return c/12.92 if c<=0.03928 else ((c+0.055)/1.055)**2.4
def lum(c): return 0.2126*lin(c[0])+0.7152*lin(c[1])+0.0722*lin(c[2])
def contrast(a,b):
    la,lb=lum(a),lum(b); return (max(la,lb)+0.05)/(min(la,lb)+0.05)
def minc(c,l): return min(contrast(c,x) for x in l)
def rnd(x): return int(math.floor(x+0.5))
def mix(a,b,t): return tuple(max(0,min(255,rnd(a[i]+(b[i]-a[i])*t))) for i in range(3))
def hsv(h,s,v):
    h=((h%360)+360)%360; s=min(1,max(0,s)); v=min(1,max(0,v))
    c=v*s; x=c*(1-abs((h/60)%2-1)); m=v-c
    if h<60: r,g,b=c,x,0
    elif h<120: r,g,b=x,c,0
    elif h<180: r,g,b=0,c,x
    elif h<240: r,g,b=0,x,c
    elif h<300: r,g,b=x,0,c
    else: r,g,b=c,0,x
    return (min(255,rnd((r+m)*255)),min(255,rnd((g+m)*255)),min(255,rnd((b+m)*255)))
def tohsv(c):
    r,g,b=[x/255 for x in c]; mx=max(r,g,b); mn=min(r,g,b); d=mx-mn
    if d==0: h=0
    elif mx==r: h=60*(math.fmod((g-b)/d,6))
    elif mx==g: h=60*((b-r)/d+2)
    else: h=60*((r-g)/d+4)
    if h<0: h+=360
    return h,(0 if mx==0 else d/mx),mx
def best_on(bg): return WHITE if contrast(WHITE,bg)>=contrast(INK,bg) else INK
def ensure(c,against,ratio):
    if minc(c,against)>=ratio: return c
    avg=sum(lum(x) for x in against)/len(against)
    target=WHITE if avg<0.4 else BLACK
    t=0.0; out=c
    while t<1.0:
        t=min(1.0,t+0.04); out=mix(c,target,t)
        if minc(out,against)>=ratio: return out
    return out

def from_base(base, accent_in=None):
    bg=base; text=best_on(bg); light=(text==WHITE); g=0
    while contrast(text,bg)<7.0 and g<60:
        g+=1; bg=mix(bg, BLACK if light else WHITE, 0.06)
    t1=0.07 if light else 0.60; t2=0.16 if light else 0.10
    surface=mix(bg,WHITE,t1); surface2=mix(bg, WHITE if light else BLACK, t2)
    while contrast(text,surface)<4.5 and t1>0: t1=max(0,t1-0.02); surface=mix(bg,WHITE,t1)
    while contrast(text,surface2)<4.5 and t2>0:
        t2=max(0,t2-0.02); surface2=mix(bg, WHITE if light else BLACK, t2)
    d=0.38; dim=mix(text,bg,d); backs=[bg,surface,surface2]
    while minc(dim,backs)<4.5 and d>0: d=max(0,d-0.04); dim=mix(text,bg,d)
    h,s,v=tohsv(bg)
    if accent_in is None:
        raw=hsv(h+(180 if s>0.35 else 30), 0.62 if light else 0.85, 0.98 if light else 0.45)
    else: raw=accent_in
    acc=ensure(raw,backs,4.5)
    return dict(bg=bg,surface=surface,surface2=surface2,accent=acc,text=text,dim=dim,onAccent=best_on(acc))

c=lambda h: hexrgb(h)
STOCK={
 "Leafs Black & Blue": dict(bg=c(0x07080B),surface=c(0x12151B),surface2=c(0x1C2432),accent=c(0x3D8BFF),text=c(0xF2F5FA),dim=c(0xA7B1C2),onAccent=c(0x0A0F1A)),
 "Leafs Blue":  dict(bg=c(0x001335),surface=c(0x00205B),surface2=c(0x0B3A86),accent=c(0xFFFFFF),text=c(0xFFFFFF),dim=c(0xB5C4E4),onAccent=c(0x00205B)),
 "Leafs White": dict(bg=c(0xF3F5FA),surface=c(0xFFFFFF),surface2=c(0xDCE4F2),accent=c(0x00205B),text=c(0x0A1330),dim=c(0x4A5878),onAccent=c(0xFFFFFF)),
 "Ink Wash":    dict(bg=c(0x0F1115),surface=c(0x171A20),surface2=c(0x2A3342),accent=c(0x9DBCE0),text=c(0xF4F4F2),dim=c(0xC3CAD6),onAccent=c(0x0F1115),image="bg_ink",scrim=192),
 "Satin Night": dict(bg=c(0x05070B),surface=c(0x0E131B),surface2=c(0x1B2638),accent=c(0xE8A062),text=c(0xF5F2EE),dim=c(0xB3BAC8),onAccent=c(0x140C06),image="bg_satin",scrim=120),
 "Smoke":       dict(bg=c(0x04070B),surface=c(0x0D141C),surface2=c(0x1A2836),accent=c(0x9FD2FF),text=c(0xF4F8FC),dim=c(0xB8C6D6),onAccent=c(0x06121C),image="bg_smoke",scrim=140),
 "Sparrow Classic": dict(bg=c(0x0E0A07),surface=c(0x1C140E),surface2=c(0x2E2117),accent=c(0xD98E4A),text=c(0xF5E9DA),dim=c(0xA8977F),onAccent=c(0x1A0F08)),
}
SOLIDS=[("Crimson",0x2A0A12,0xFF6B81),("Ember",0x2B1406,0xFF9F43),("Gold",0x2A2205,0xFFD166),("Forest",0x0B2316,0x5FDB8A),
 ("Teal",0x062524,0x3DDCCB),("Ocean",0x06203A,0x4DB8FF),("Indigo",0x14123B,0x8F8CFF),("Violet",0x241036,0xC58BFF),
 ("Rose",0x33101F,0xFF7EB6),("Slate",0x161A20,0x8FA3BF),("Graphite",0x111111,0xE0E0E0),("Black",0x000000,0xFFFFFF)]

def now_cell(p):
    t=0.14; c=mix(p["surface"],p["accent"],t)
    while contrast(p["text"],c)<4.5 and t>0:
        t=max(0,t-0.02); c=mix(p["surface"],p["accent"],t)
    return c

fails=[]
def check(name,p):
    bgs=[p["bg"],p["surface"],p["surface2"]]
    now=now_cell(p)
    rules=[
     ("text/bg >=7", contrast(p["text"],p["bg"])>=7.0),
     ("text/surface >=4.5", contrast(p["text"],p["surface"])>=4.5),
     ("text/surface2 >=4.5", contrast(p["text"],p["surface2"])>=4.5),
     ("text/nowCell >=4.5", contrast(p["text"],now)>=4.5),
     ("dim/all >=4.5", minc(p["dim"],bgs)>=4.5),
     ("accent/bg+surface >=4.5", minc(p["accent"],[p["bg"],p["surface"]])>=4.5),
     ("accent/surface2 >=3", contrast(p["accent"],p["surface2"])>=3.0),
     ("onAccent/accent >=4.5", contrast(p["onAccent"],p["accent"])>=4.5),
     ("accentOnDark/black >=4.5", True),
    ]
    bad=[r for r,ok in rules if not ok]
    if bad: fails.append((name,bad))
    return bad

print("== stock themes ==")
for n,p in STOCK.items():
    bad=check(n,p)
    print("%-20s text/bg %5.1f  dim/worst %4.1f  accent/bg %4.1f  onAccent %4.1f  %s"%(n,contrast(p["text"],p["bg"]),minc(p["dim"],[p["bg"],p["surface"],p["surface2"]]),contrast(p["accent"],p["bg"]),contrast(p["onAccent"],p["accent"]),"OK" if not bad else "FAIL "+str(bad)))
print("== solid colour presets ==")
for n,b,a in SOLIDS:
    p=from_base(c(b),c(a)); bad=check("solid "+n,p); print("%-10s %s"%(n,"OK" if not bad else "FAIL "+str(bad)))
print("== custom colours: 24x24x6 grid of picker values ==")
cnt=0
for h in range(0,360,15):
    for s in (0,0.2,0.4,0.6,0.8,1.0):
        for v in (0.0,0.15,0.3,0.5,0.7,0.85,1.0):
            p=from_base(hsv(h,s,v)); cnt+=1; check("custom h%d s%.1f v%.2f"%(h,s,v),p)
print("  checked",cnt)
print("== random themes: 5000 seeds ==")
R=random.Random(1)
for i in range(5000):
    h=R.random()*360; light=R.randrange(100)<15
    base=hsv(h,0.05+R.random()*0.12,0.96) if light else hsv(h,0.45+R.random()*0.45,0.10+R.random()*0.20)
    ah=h+[30,150,180,210][R.randrange(4)]
    acc=hsv(ah,0.80,0.50) if light else hsv(ah,0.55+R.random()*0.3,0.97)
    check("random %d"%i,from_base(base,acc))
print("  failures so far:",len(fails))

# ---- background pictures under their scrim ---------------------------------------------------------------
try:
    from PIL import Image
    import numpy as np
    d=sys.argv[1] if len(sys.argv)>1 else os.path.join(os.path.dirname(__file__),"..","app","src","main","res","drawable-nodpi")
    print("== pictures under scrim (needs text >=4.5 at the 99.5th pct pixel, dim text >=4.5 at the 97th pct) ==")
    def L(a):
        a=a/255.0; a=np.where(a<=0.03928,a/12.92,((a+0.055)/1.055)**2.4); return 0.2126*a[...,0]+0.7152*a[...,1]+0.0722*a[...,2]
    for n,p in STOCK.items():
        if not p.get("image"): continue
        im=np.asarray(Image.open(os.path.join(d,p["image"]+".jpg")).convert("RGB")).astype(float)
        a=p["scrim"]/255.0; scr=np.array(p["bg"],float)
        out=im*(1-a)+scr*a; l=L(out)
        def need(txt,pct):
            lt=lum(txt); lbg=np.percentile(l,pct); return (max(lt,lbg)+0.05)/(min(lt,lbg)+0.05)
        ct=need(p["text"],99.5); cd=need(p["dim"],97); ca=need(p["accent"],97)
        # smallest alpha that would satisfy the rules
        best=None
        for al in range(0,256,2):
            o=(im*(1-al/255)+scr*al/255); ll=L(o)
            def nd(txt,pct):
                lt=lum(txt); lb=np.percentile(ll,pct); return (max(lt,lb)+0.05)/(min(lt,lb)+0.05)
            if nd(p["text"],99.5)>=4.5 and nd(p["dim"],97)>=4.5 and nd(p["accent"],97)>=4.5: best=al; break
        ok = ct>=4.5 and cd>=4.5 and ca>=3.0
        print("%-12s scrim %3d (%.0f%%): text@p99.5 %.1f  dim@p97 %.1f  accent@p97 %.1f  min scrim for all>=4.5: %s  visible picture: %.0f%%  %s"%(n,p["scrim"],a*100,ct,cd,ca,best,(1-a)*100,"OK" if ok else "FAIL"))
        if not ok: fails.append((n,["picture legibility"]))
except ImportError:
    print("PIL/numpy missing - picture check skipped")

print()
if fails:
    print("FAILURES:"); [print(" ",f) for f in fails[:20]]; sys.exit(1)
print("ALL THEME CHECKS PASSED")
