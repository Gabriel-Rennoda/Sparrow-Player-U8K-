package com.sparrow.player.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sparrow", Context.MODE_PRIVATE)

    var activeProvider: Long
        get() = sp.getLong("active", -1L)
        set(v) { sp.edit().putLong("active", v).apply() }

    /** "ts" (raw MPEG-TS, lowest latency, most compatible) or "m3u8" (HLS). Xtream providers only. */
    var liveFormat: String
        get() = sp.getString("fmt", "ts") ?: "ts"
        set(v) { sp.edit().putString("fmt", v).apply() }

    var lastChannel: String
        get() = sp.getString("lastCh", "") ?: ""
        set(v) { sp.edit().putString("lastCh", v).apply() }

    /** false = 12 hour clock (default), true = 24 hour. */
    var clock24: Boolean
        get() = sp.getBoolean("clock24", false)
        set(v) { sp.edit().putBoolean("clock24", v).apply() }

    var showNumbers: Boolean
        get() = sp.getBoolean("showNum", true)
        set(v) { sp.edit().putBoolean("showNum", v).apply() }

    /** EPG auto-sync interval in hours (24, 12, 6, 3 or 2). */
    var epgHours: Int
        get() = sp.getInt("epgHours", 24)
        set(v) { sp.edit().putInt("epgHours", v).apply() }

    /** Download the guide when the app starts. */
    var epgOnStart: Boolean
        get() = sp.getBoolean("epgOnStart", true)
        set(v) { sp.edit().putBoolean("epgOnStart", v).apply() }

    fun lastEpgSync(providerId: Long): Long = sp.getLong("epgSync_$providerId", 0L)
    fun setLastEpgSync(providerId: Long, v: Long) = sp.edit().putLong("epgSync_$providerId", v).apply()

    /** Preferred audio language code ("" = automatic, e.g. "en", "fr"). */
    var audioLang: String
        get() = sp.getString("audioLang", "") ?: ""
        set(v) { sp.edit().putString("audioLang", v).apply() }

    /** Subtitles: "" = automatic (player default), "off", or a language code. */
    var subtitleLang: String
        get() = sp.getString("subLang", "") ?: ""
        set(v) { sp.edit().putString("subLang", v).apply() }

    /** The user's channel / group edits for one provider (see Customize). */
    fun custom(providerId: Long): String = sp.getString("cust_$providerId", "") ?: ""
    fun setCustom(providerId: Long, v: String) = sp.edit().putString("cust_$providerId", v).apply()

    /** Current theme, see ui/theme/Palette.encode(). Empty = default. */
    var theme: String
        get() = sp.getString("theme", "") ?: ""
        set(v) { sp.edit().putString("theme", v).apply() }

    /** Watch history (see History): one "uid<TAB>timestamp" per line, newest first. */
    fun history(): List<History.Entry> = History.parse(sp.getString("history", ""))
    fun recordWatch(uid: String) {
        if (uid.isBlank()) return
        sp.edit().putString("history", History.serialize(History.record(history(), uid, System.currentTimeMillis()))).apply()
    }

    /** Last episode id watched for a series (so Play continues the series). */
    fun lastEpisode(seriesUid: String): String = sp.getString("lastEp_$seriesUid", "") ?: ""
    fun setLastEpisode(seriesUid: String, epId: String) = sp.edit().putString("lastEp_$seriesUid", epId).apply()

    fun duration(key: String): Long = sp.getLong("dur_$key", 0L)
    fun setDuration(key: String, v: Long) = sp.edit().putLong("dur_$key", v).apply()
    fun percent(key: String): Int = Resume.percent(position(key), duration(key))

    fun position(key: String): Long = sp.getLong("pos_$key", 0L)
    fun setPosition(key: String, v: Long) = sp.edit().putLong("pos_$key", v).apply()

    /** Movie: its own progress. Series: progress of the episode being watched. */
    fun vodPercent(v: VodItem): Int {
        if (v.type == "movie") return percent(v.uid)
        val ep = lastEpisode(v.uid)
        return if (ep.isBlank()) 0 else percent("ep:$ep")
    }

    /** Started, not finished: shows up in "Continue watching". */
    fun inProgress(v: VodItem): Boolean {
        val key = if (v.type == "movie") v.uid else lastEpisode(v.uid).let { if (it.isBlank()) return false else "ep:$it" }
        return Resume.hasProgress(position(key))
    }

    companion object {
        /** Some panels block unknown user agents; a VLC UA is the most widely accepted. */
        const val UA = "VLC/3.0.20 LibVLC/3.0.20"
    }
}
