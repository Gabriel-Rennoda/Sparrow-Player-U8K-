package com.sparrow.player.ui.vod

import android.os.Bundle
import android.view.View
import androidx.core.view.doOnLayout
import androidx.leanback.app.RowsSupportFragment
import androidx.leanback.widget.ArrayObjectAdapter
import androidx.leanback.widget.HeaderItem
import androidx.leanback.widget.ListRow
import androidx.leanback.widget.OnItemViewClickedListener
import androidx.leanback.widget.OnItemViewSelectedListener
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Recommender
import com.sparrow.player.data.VodItem
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.TabContent
import com.sparrow.player.util.TitleCase
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Netflix / Disney+ style rows of posters. The page background is the theme (solid colour or picture) and never changes
 * while browsing; only the details screen shows a title's own artwork.
 *
 * Rows, top to bottom: Continue watching, Because you watched ..., Recommended for you, New in <favourite category>,
 * Top rated (these come from the watch history), then the provider's own: Recently added and its categories.
 */
class VodFragment : RowsSupportFragment(), TabContent {
    private val type get() = requireArguments().getString("type")!!
    private var loadJob: Job? = null
    private var selIndex = 0          // position of the selected poster inside its row (0 = left-most)
    private var lastRow = -1
    private var lastCol = -1
    private var prefetcher: Prefetcher? = null
    private var lastItem: VodItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setOnItemViewClickedListener(OnItemViewClickedListener { _, item, _, _ ->
            if (item is VodItem) startActivity(DetailsActivity.intent(requireContext(), item.uid))
        })
        setOnItemViewSelectedListener(OnItemViewSelectedListener { _, item, _, row ->
            if (item is VodItem && row is ListRow) {
                selIndex = (row.adapter as? ArrayObjectAdapter)?.indexOf(item) ?: 0
                onSelected(item)
                prefetchAround(row, item)
            }
        })
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefetcher = Prefetcher(requireContext().applicationContext)
        loadRows()
    }

    // ---- rows ---------------------------------------------------------------------------------------------------
    private fun toRec(v: VodItem) = Recommender.Item(v.uid, v.categoryId, Recommender.genresOf(v.genre), Recommender.yearOf(v.year), Recommender.ratingOf(v.rating))

    private fun loadRows() {
        loadJob?.cancel()
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val p = repo.activeProvider()
            if (p == null) { (activity as? MainActivity)?.contentReady(); return@launch }
            val dao = repo.dao
            val prefs = repo.prefs
            val rows = ArrayObjectAdapter(SparrowRowPresenter())
            var id = 0L
            fun addRow(title: String, items: List<VodItem>) {
                if (items.isEmpty()) return
                rows.add(ListRow(HeaderItem(id++, title), ArrayObjectAdapter(CardPresenter()).apply { addAll(0, items) }))
            }

            val catType = if (type == "movie") "vod" else "series"
            val cats = dao.categories(p.id, catType)
            val catName = cats.associate { it.remoteId to TitleCase.of(it.name) }

            // ---- what the user watched (newest first, this tab's kind only)
            val hist = prefs.history()
            val byUid = if (hist.isEmpty()) emptyMap<String, VodItem>() else dao.vodByUids(hist.map { it.uid }).associateBy { it.uid }
            val watched = hist.mapNotNull { byUid[it.uid] }.filter { it.type == type && it.providerId == p.id }
            val watchedUids = watched.map { it.uid }.toSet()
            val shown = HashSet<String>()

            addRow("Continue Watching", watched.filter { prefs.inProgress(it) }.take(20))

            if (watched.isNotEmpty()) {
                val profile = Recommender.profile(watched.map { toRec(it) })
                // candidate pool: the user's favourite categories / genres plus the best rated titles
                val pool = LinkedHashMap<String, VodItem>()
                fun add(l: List<VodItem>) { l.forEach { pool.putIfAbsent(it.uid, it) } }
                val topCats = Recommender.topKeys(profile.categories, 4)
                for (c in topCats) add(dao.vodIn(p.id, type, c, 200))
                for (g in Recommender.topKeys(profile.genres, 3)) add(dao.vodByGenre(p.id, type, "%$g%", 200))
                val seeds = ArrayList<VodItem>()
                watched.firstOrNull()?.let { seeds += it }
                watched.drop(1).firstOrNull { w -> Recommender.similarity(toRec(seeds[0]), toRec(w)) < 2.0 }?.let { seeds += it }
                for (s in seeds) if (s.categoryId !in topCats) add(dao.vodIn(p.id, type, s.categoryId, 200))
                add(dao.vodTopRated(p.id, type, 100))
                val recs = pool.values.map { toRec(it) }

                for (s in seeds) {
                    val l = Recommender.becauseYouWatched(toRec(s), recs, watchedUids, 20).mapNotNull { pool[it.uid] }
                    addRow("Because You Watched " + s.name, l)
                    shown += l.map { it.uid }
                }
                val forYou = Recommender.forYou(profile, recs, watchedUids + shown, 30).mapNotNull { pool[it.uid] }
                addRow("Recommended for You", forYou)
                shown += forYou.map { it.uid }

                topCats.firstOrNull()?.let { c ->
                    val fresh = dao.vodIn(p.id, type, c, 60).filter { it.uid !in watchedUids && it.uid !in shown }.take(30)
                    addRow("New in " + (catName[c] ?: "Your Favourites"), fresh)
                }
            }
            addRow("Top Rated", dao.vodTopRated(p.id, type, 60)
                .filter { it.uid !in watchedUids && Recommender.ratingOf(it.rating) >= 6.5 }.take(30))

            // ---- the provider's own rows
            addRow("Recently Added", dao.vodRecent(p.id, type, 30))
            for (cat in cats) addRow(TitleCase.of(cat.name), dao.vodIn(p.id, type, cat.remoteId, 40))

            val hadFocus = view?.hasFocus() == true
            val keepRow = selectedPosition
            setAdapter(rows)
            if (hadFocus && keepRow in 0 until rows.size()) setSelectedPosition(keepRow)
            lastRow = -1; lastCol = -1
            prefetchStart(rows)
            (activity as? MainActivity)?.contentReady()
        }
    }

    // ---- look-ahead image loading -----------------------------------------------------------------------------
    private fun rowItems(rows: ArrayObjectAdapter, r: Int): ArrayObjectAdapter? =
        ((if (r in 0 until rows.size()) rows.get(r) else null) as? ListRow)?.adapter as? ArrayObjectAdapter

    private fun posterAt(a: ArrayObjectAdapter?, i: Int): String? =
        if (a != null && i in 0 until a.size()) (a.get(i) as? VodItem)?.poster else null

    /** First screenful, before anything is selected. */
    private fun prefetchStart(rows: ArrayObjectAdapter) {
        val urls = ArrayList<String>()
        for (r in 0..2) { val a = rowItems(rows, r); for (i in 0..9) posterAt(a, i)?.let { urls += it } }
        prefetcher?.want(urls)
    }

    /**
     * Selection moved: load the posters the user is heading for. Along the row: 10 ahead in the direction of travel (and
     * 3 behind). Up / down: the neighbouring rows around this column (both directions the first time).
     */
    private fun prefetchAround(row: ListRow, item: VodItem) {
        val rows = adapter as? ArrayObjectAdapter ?: return
        val ri = rows.indexOf(row)
        val cur = row.adapter as? ArrayObjectAdapter ?: return
        val ci = cur.indexOf(item)
        val dirX = if (ri == lastRow && lastCol >= 0) Integer.signum(ci - lastCol) else 0
        val dirY = if (lastRow < 0) 0 else Integer.signum(ri - lastRow)
        lastRow = ri; lastCol = ci
        val dx = if (dirX == 0) 1 else dirX
        val urls = ArrayList<String>()
        for (k in 1..10) posterAt(cur, ci + dx * k)?.let { urls += it }
        for (k in 1..3) posterAt(cur, ci - dx * k)?.let { urls += it }
        posterAt(cur, ci)?.let { urls += it }
        val targets = when (dirY) { 1 -> listOf(ri + 1, ri + 2); -1 -> listOf(ri - 1, ri - 2); else -> listOf(ri - 1, ri + 1) }
        for (r in targets) { val a = rowItems(rows, r); for (i in ci - 2..ci + 8) posterAt(a, i)?.let { urls += it } }
        prefetcher?.want(urls)
    }

    // ---- TabContent -------------------------------------------------------------------------------------------
    override fun focusContent(): Boolean {
        val grid = verticalGridView ?: return false
        if (adapter == null || adapter.size() == 0) return false
        grid.doOnLayout { it.requestFocus() }
        return true
    }

    override fun isAtLeftEdge() = selIndex <= 0

    override fun reload() {
        val hadFocus = view?.hasFocus() == true
        loadRows()
        if (hadFocus) (activity as? MainActivity)?.wantFocus()
    }

    private fun onSelected(v: VodItem) {
        lastItem = v
        (activity as? MainActivity)?.showHero(v.name, metaOf(v), v.plot, requireContext().repo.prefs.vodPercent(v))
    }

    private fun metaOf(v: VodItem) = listOf(v.year, CardPresenter.ratingText(v), v.genre).filter { it.isNotBlank() }.joinToString("   •   ")

    override fun onResume() {
        super.onResume()
        // Back from the player / details: refresh the progress bars on the cards and in the hero, keeping the position.
        lastItem?.let { onSelected(it) }
        val rows = adapter as? ArrayObjectAdapter ?: return
        for (r in 0 until rows.size()) rowItems(rows, r)?.let { it.notifyArrayItemRangeChanged(0, it.size()) }
    }

    override fun onDestroyView() {
        loadJob?.cancel()
        prefetcher?.cancel(); prefetcher = null
        super.onDestroyView()
    }

    companion object {
        fun newInstance(type: String) = VodFragment().apply { arguments = Bundle().apply { putString("type", type) } }
    }
}
