"""
Model of MainActivity's remote navigation (ported 1:1 from PanelState.kt + MainActivity.kt control flow).
This verifies the LOGIC of requirement #3/#4 (panel stack, focus memory, tab/group selection). It is not the Android app.
"""
NONE, GROUPS, NAV = 'NONE', 'GROUPS', 'NAV'
LIVE, MOVIES, SERIES, FAVS, SETTINGS = range(5)
GUIDE = LIVE   # v1.1: the Guide tab was removed; Live TV now IS the guide

class PanelState:                                   # == PanelState.kt
    def __init__(s): s.panel=NONE; s.nav_from=NONE; s.has_groups=False
    nav_open=property(lambda s: s.panel==NAV)
    groups_open=property(lambda s: s.panel==GROUPS or (s.panel==NAV and s.nav_from==GROUPS))
    def left(s, edge):
        if s.panel==NONE:
            if not edge: return False
            s.nav_from=NONE; s.panel=GROUPS if s.has_groups else NAV; return True
        if s.panel==GROUPS: s.nav_from=GROUPS; s.panel=NAV; return True
        return True
    def back(s):
        if s.panel==NONE: return False
        if s.panel==GROUPS: s.panel=NONE; return True
        s.panel=s.nav_from; s.nav_from=NONE; return True
    def back_press(s):                               # == PanelState.backPress (BACK key)
        if s.panel==NONE: s.nav_from=NONE; s.panel=GROUPS if s.has_groups else NAV; return True
        if s.panel==GROUPS: s.nav_from=GROUPS; s.panel=NAV; return True
        return False
    def reset(s): s.panel=NONE; s.nav_from=NONE

class App:                                          # == MainActivity (focus = (zone, index))
    def __init__(s):
        s.p=PanelState(); s.current=-1; s.focus=None; s.content_focus=None; s.groups_focus=None
        s.exit_prompt=False; s.pending=False; s.group='all'; s.groups=['all','fav','uk','sports','news']; s.exited=False
        s.rows={LIVE:5,GUIDE:5,FAVS:0}; s.playing_row=2; s.vod_sel=0; s.nav_focusable=False
        s.select(LIVE)
    # -- tab content ('TabContent')
    def has_groups(s): return s.current in (LIVE,GUIDE)
    def live_tab(s): return s.current in (LIVE,GUIDE,FAVS)
    def content_focus_default(s):
        if s.current in (LIVE,FAVS):
            if s.rows[s.current]==0: return None
            return ('epg', 0)
        if s.current in (MOVIES,SERIES): return ('vod',0)
        return ('settings',0)
    def at_left_edge(s):
        z=s.focus
        if z is None: return True                      # no focus counts as edge (dead-end fix)
        if z[0]=='player': return True
        if z[0] in('list','settings'): return True
        if z[0]=='epg': return z[1]==0                 # index = programme index in row
        if z[0]=='vod': return z[1]==0
        return False
    def content_ready(s):
        if s.pending and s.p.panel==NONE:
            d=s.content_focus_default()
            if d: s.focus=d; s.pending=False
            elif s.live_tab(): s.focus=('player',0); s.pending=False
    def select(s,i):
        if i==s.current: return
        s.current=i; s.pending=True; s.focus=None
        s.content_ready()                              # fragment loads -> contentReady()
    # -- panels
    def apply(s): s.nav_focusable=s.p.nav_open
    def focus_groups(s): s.focus=('group', s.groups.index(s.group))
    def focus_nav(s): s.focus=('nav', s.current)
    def restore(s,v): return v is not None
    def restore_content(s):
        if s.restore(s.content_focus): s.focus=s.content_focus
        else: s.focus=s.content_focus_default()
    def key(s,k,repeat=0):
        if k=='LEFT': return s.on_left(repeat)
        if k=='RIGHT':
            if s.p.panel==NONE: return False
            if repeat==0: s.close_top()
            return True
        if k=='BACK':                                  # MainActivity.openNextPanel (v1.4.0): Back OPENS the panels in turn
            if s.p.panel==NONE:
                s.content_focus=s.focus; s.p.has_groups=s.has_groups(); s.p.back_press(); s.apply()
                if s.p.panel==GROUPS: s.focus_groups()
                else: s.focus_nav()
            elif s.p.panel==GROUPS: s.groups_focus=s.focus; s.p.back_press(); s.apply(); s.focus_nav()
            else: s.exit_prompt=True                   # tab list open: "Press Back again to exit"
            return True
        if k in('UP','DOWN'):                          # simple vertical move inside the focused list-like zone
            z=s.focus
            if z and z[0] in('list','group','nav'):
                n={'list':s.rows.get(s.current,0),'group':len(s.groups),'nav':5}[z[0]]
                s.focus=(z[0], max(0,min(n-1, z[1]+(1 if k=='DOWN' else -1))))
            if z and z[0]=='list' and k=='UP' and z[1]==0: s.focus=('player',0)
            if z and z[0]=='player' and k=='DOWN': s.focus=s.content_focus_default()
            return False
        if k=='OK': return s.ok()
    def on_left(s,repeat):
        first=repeat==0
        if s.p.panel==NAV: return True
        if s.p.panel==GROUPS:
            if first: s.groups_focus=s.focus; s.p.left(False); s.apply(); s.focus_nav()
            return True
        if s.focus is not None and not s.at_left_edge(): return False
        if first:
            s.content_focus=s.focus; s.p.has_groups=s.has_groups(); s.p.left(True); s.apply()
            if s.p.panel==GROUPS: s.focus_groups()
            else: s.focus_nav()
        return True
    def close_top(s):
        if s.p.panel==NAV:
            s.p.back()
            if s.p.panel==GROUPS:
                if s.restore(s.groups_focus): s.focus=s.groups_focus
                else: s.focus_groups()
            else: s.restore_content()
        elif s.p.panel==GROUPS: s.p.back(); s.restore_content()
        s.apply()
    def ok(s):
        z=s.focus
        if not z: return False
        if z[0]=='group' and s.p.panel==GROUPS:        # pickGroup
            s.group=s.groups[z[1]]; s.p.reset(); s.content_focus=None; s.groups_focus=None
            s.pending=True; s.apply(); s.focus=None
            s.rows[LIVE]=0 if s.group=='fav' else 5     # list reloads (favs empty in this model)
            s.content_ready(); return True
        if z[0]=='nav' and s.p.panel==NAV:             # onNavPicked
            i=z[1]; s.p.reset()
            if i==s.current: s.restore_content(); s.apply(); return True
            s.content_focus=None; s.groups_focus=None; s.apply(); s.select(i); return True
        return False

fails=0
def check(name,cond,detail=''):
    global fails
    print(('PASS ' if cond else 'FAIL ')+name+('' if cond else '  -> '+str(detail)))
    fails+= 0 if cond else 1

# S1 Guide: programme -> groups -> nav (LEFT), RIGHT closes level by level with selections restored
a=App(); a.select(GUIDE); a.focus=('epg',0)             # at left-most programme
a.key('LEFT');  check('S1a guide LEFT opens groups, selector on active group', a.p.panel==GROUPS and a.focus==('group',0), (a.p.panel,a.focus))
a.key('DOWN'); a.key('DOWN')                           # browse groups (no switching)
check('S1b browsing groups does not change the guide group', a.group=='all')
a.key('LEFT');  check('S1c second LEFT expands tab list on current tab', a.p.panel==NAV and a.p.nav_open and a.p.groups_open and a.focus==('nav',GUIDE) and a.nav_focusable, (a.p.panel,a.focus))
a.key('LEFT');  check('S1d third LEFT does nothing more', a.p.panel==NAV)
a.key('RIGHT'); check('S1e RIGHT closes tab list; selector back on LAST group selection', a.p.panel==GROUPS and a.focus==('group',2), (a.p.panel,a.focus))
a.key('RIGHT'); check('S1f RIGHT closes groups; selector back on previous guide selection', a.p.panel==NONE and a.focus==('epg',0), (a.p.panel,a.focus))

# S1B (v1.4.0) BACK opens the two side panels one after the other, then the exit prompt
a=App(); a.select(GUIDE); a.focus=('epg',0)
a.key('BACK');  check('S1B-a Back from the guide opens Channel Groups', a.p.panel==GROUPS and a.focus==('group',0), (a.p.panel,a.focus))
a.key('BACK');  check('S1B-b Back again opens the Tab List', a.p.panel==NAV and a.p.nav_open and a.focus==('nav',GUIDE), (a.p.panel,a.focus))
check('S1B-c no exit prompt yet', not a.exit_prompt and not a.exited)
a.key('BACK');  check('S1B-d Back on the Tab List starts the exit prompt', a.exit_prompt and a.p.panel==NAV)
a.key('RIGHT'); a.key('RIGHT'); check('S1B-e RIGHT x2 returns to the guide where we were', a.p.panel==NONE and a.focus==('epg',0), (a.p.panel,a.focus))

# S1C Back from every tab ends at the main tab list
for t,name in ((MOVIES,'Movies'),(SERIES,'Series'),(FAVS,'Favourites'),(SETTINGS,'Settings')):
    a=App(); a.select(t); a.focus=a.content_focus_default() or ('player',0)
    a.key('BACK'); check(f'S1C {name}: Back opens the tab list directly', a.p.panel==NAV and not a.p.groups_open and a.focus==('nav',t), (a.p.panel,a.focus))
a=App(); a.select(MOVIES); a.focus=('vod',0); a.key('BACK'); a.key('OK')
check('S1C Back then OK on Live TV switches tab', a.current==MOVIES and a.p.panel==NONE)
a=App(); a.select(MOVIES); a.focus=('vod',0); a.key('BACK'); a.key('DOWN'); a.key('UP'); a.focus=('nav',LIVE); a.key('OK')
check('S1C Back, pick Live TV: lands in Live TV', a.current==LIVE and a.p.panel==NONE, (a.current,a.p.panel))

# S2 from the player box
a=App(); a.focus=('player',0)
a.key('LEFT');  check('S2a LEFT on player opens groups', a.p.panel==GROUPS)
a.key('RIGHT'); check('S2b RIGHT returns selector to the player', a.p.panel==NONE and a.focus==('player',0), a.focus)

# S3 guide not at edge: LEFT is a normal move
a=App(); a.select(GUIDE); a.focus=('epg',3)
check('S3 LEFT mid-grid is not hijacked', a.key('LEFT') is False and a.p.panel==NONE)

# S4 live list: any row is on the left edge
a=App(); a.focus=('list',3); a.key('LEFT')
check('S4 list row LEFT opens groups; RIGHT restores row 3', a.p.panel==GROUPS and (a.key('RIGHT') or True) and a.focus==('list',3), a.focus)

# S5 pick a group with OK
a=App(); a.focus=('list',3); a.key('LEFT'); a.key('DOWN'); a.key('DOWN'); a.key('OK')
check('S5 OK on group applies it, closes panel, selector goes to content', a.group=='uk' and a.p.panel==NONE and a.focus is not None and a.focus[0]=='epg', (a.group,a.p.panel,a.focus))

# S6 tab list -> Movies -> navigation stays in Movies (requirement #3)
a=App(); a.focus=('list',1); a.key('LEFT'); a.key('LEFT')
for _ in range(1): a.key('DOWN')
check('S6a tab list highlights moving down', a.focus==('nav',1), a.focus)
a.key('OK')
check('S6b OK on Movies: tab switched, panels closed, selector inside Movies content', a.current==MOVIES and a.p.panel==NONE and a.focus==('vod',0), (a.current,a.p.panel,a.focus))
a.vod_sel=2; a.focus=('vod',2)
check('S6c LEFT on card #2 is a normal move (does not bump out)', a.key('LEFT') is False and a.current==MOVIES and a.p.panel==NONE)
a.focus=('vod',0); a.key('LEFT')
check('S6d LEFT on first card opens the tab list directly (no groups for Movies)', a.p.panel==NAV and not a.p.groups_open and a.focus==('nav',MOVIES))
a.key('RIGHT')
check('S6e RIGHT returns to the same Movies card', a.p.panel==NONE and a.focus==('vod',0) and a.current==MOVIES)
# Series
a.focus=('vod',0); a.key('LEFT'); a.key('DOWN'); a.key('OK')
check('S6f same flow lands in Series', a.current==SERIES and a.focus==('vod',0), (a.current,a.focus))

# S7 held key must not race through levels
a=App(); a.focus=('list',0); a.key('LEFT',0); a.key('LEFT',1); a.key('LEFT',2)
check('S7 repeated LEFT events do not open the next level', a.p.panel==GROUPS, a.p.panel)

# S8 RIGHT closes one level
a=App(); a.focus=('list',0); a.key('LEFT'); a.key('LEFT'); a.key('RIGHT')
check('S8 RIGHT in tab list == BACK (one level)', a.p.panel==GROUPS)

# S9 selecting the current tab just closes and restores
a=App(); a.focus=('list',4); a.key('LEFT'); a.key('LEFT'); a.key('OK')
check('S9 OK on current tab closes panels, restores row 4', a.p.panel==NONE and a.current==LIVE and a.focus==('list',4), (a.p.panel,a.focus))

# S10 dead end: empty favourites group
a=App(); a.focus=('list',0); a.key('LEFT'); a.key('DOWN'); a.key('OK')   # pick 'fav' (empty)
check('S10a empty group: selector parks on player (not lost)', a.group=='fav' and a.focus==('player',0), a.focus)
a.key('LEFT')
check('S10b ...and LEFT still opens the panels', a.p.panel==GROUPS)

# S11 Favourites / Settings tabs have no groups
for t in (FAVS,SETTINGS):
    a=App(); a.select(t); a.focus=a.content_focus_default() or ('player',0); a.key('LEFT')
    check(f'S11 tab {t}: LEFT opens tab list directly', a.p.panel==NAV and not a.p.groups_open, a.p.panel)

# S12 tab switches by selection only (old bug: focus alone switched/bounced tabs)
a=App(); a.focus=('list',1); a.key('LEFT'); a.key('LEFT'); a.key('DOWN'); a.key('DOWN')
check('S12 merely focusing tab names never switches tab', a.current==LIVE and a.focus==('nav',2))

print('\nRESULT:', 'ALL PASSED' if fails==0 else f'{fails} FAILED')
