package com.sparrow.player.ui.search

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.doOnLayout
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sparrow.player.R
import com.sparrow.player.data.Candidate
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Langs
import com.sparrow.player.data.MediaTags
import com.sparrow.player.data.Repository
import com.sparrow.player.data.SearchEngine
import com.sparrow.player.data.SearchFilters
import com.sparrow.player.data.SearchIndex
import com.sparrow.player.data.SearchKind
import com.sparrow.player.data.SortBy
import com.sparrow.player.data.SparrowRating
import com.sparrow.player.data.SubsFilter
import com.sparrow.player.data.UserRatings
import com.sparrow.player.databinding.ActivitySearchBinding
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.ui.vod.DetailsActivity
import com.sparrow.player.ui.vod.RatedImageView
import com.sparrow.player.util.TitleCase
import com.sparrow.player.util.dp
import com.sparrow.player.util.loadUrl
import com.sparrow.player.util.repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The search window. Opened from the Search entry at the top of the tab list / channel groups, the Search button on Movies and Series,
 * or the remote's search key, after choosing Live Channels, Movies or Series.
 *
 *  Left: the title box, then the filters ([FilterPanel]) on the page itself: Live / Movie / Series buttons (the chosen one outlined), drop-downs and toggles,
 *    Release Years, Sort By, Reset. Type is filled in by the chooser (SearchChooser) and can be changed with the buttons at the top.
 *  Results (right) update after every change. The last filters of each kind are remembered while the app is open.
 */
class SearchActivity : FragmentActivity() {
    private lateinit var b: ActivitySearchBinding
    private var kind = SearchKind.MOVIE
    private var f = SearchFilters(SearchKind.MOVIE)

    private var all: List<Candidate> = emptyList()
    private var channels: List<Channel> = emptyList()
    private val chanByUid = HashMap<String, Channel>()
    private var index: SearchIndex? = null
    private var providerId = -1L
    private var random = false                    // "Random Pick": filters + a button that opens one unwatched title
    private var pick = false                      // "choose a channel" mode (Settings -> EPG -> Opening Channel)
    private var genreOptions: List<String> = emptyList()
    private var panel: FilterPanel? = null
    private var yearFromBox: EditText? = null
    private var yearToBox: EditText? = null
    private var syncing = false                   // true while the boxes are being filled from the filters (no change events then)
    private var typeJob: Job? = null
    private var carry: SearchFilters? = null      // filters chosen in the sheet together with a new Type, for the restart
    private var loaded = false                    // the list for this kind is ready (typing before that only records the filters)

    private val updaters = ArrayList<() -> Unit>()
    private var loadJob: Job? = null
    private var refreshJob: Job? = null
    private lateinit var adapter: ResultAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(b.root)
        Theme.applyAll(this, b.root)
        pick = intent.getBooleanExtra("pick", false)
        random = intent.getBooleanExtra("random", false)
        kind = runCatching { SearchKind.valueOf(intent.getStringExtra("kind") ?: "") }.getOrDefault(SearchKind.MOVIE)

        adapter = ResultAdapter({ c -> open(c) }, { c -> imageOf(c) })
        b.results.itemAnimator = null
        b.results.adapter = adapter
        start()
    }

    /**
     * (Re)open the window for [kind]. The window itself - the search box, the filters, the results grid - is on screen at once, with the cursor in
     * the box, so the title can be typed while the list is still being made ready; results appear as soon as it is.
     */
    private fun start() {
        f = carry?.also { carry = null } ?: if (random && remembered[kind] == null) SearchFilters(kind, unwatchedOnly = true) else if (pick) SearchFilters(kind) else remembered[kind] ?: SearchFilters(kind)
        b.title.text = if (pick) "Choose Opening Channel" else if (random) "Random Pick – " + kind.label else "Search – " + kind.label
        b.count.text = "Loading…"
        b.empty.visibility = View.GONE
        loaded = false
        val vod = kind != SearchKind.LIVE
        adapter.live = !vod
        adapter.submit(emptyList())
        b.results.layoutManager = if (vod) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        if (vod) b.results.doOnLayout { rv ->
            (rv as RecyclerView).layoutManager = GridLayoutManager(this@SearchActivity, maxOf(2, rv.width / dp(130)))
        }
        setupSearchBox()
        buildFilters()
        syncInputs()
        if (random) b.filterList.getChildAt(0)?.requestFocus() else if (pick) b.searchBox.requestFocus() else showKeyboard()
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            val repo = applicationContext.repo
            val p = repo.activeProvider()
            if (p == null) { finish(); return@launch }
            providerId = p.id
            withContext(Dispatchers.Default) { load(repo, p.id) }
            loaded = true
            refresh()
        }
    }

    /** The big labelled box on top: results follow the typing (after a short pause); the keyboard's Search key closes the keyboard. */
    private fun setupSearchBox() {
        val box = b.searchBox
        val ring = GradientDrawable().apply { setColor(Theme.bg); cornerRadius = dp(12).toFloat(); setStroke(dp(2), Theme.surface2) }
        b.searchBoxRow.background = ring
        b.searchIcon.imageTintList = ColorStateList.valueOf(Theme.textDim)
        box.setOnFocusChangeListener { _, has -> ring.setStroke(dp(if (has) 3 else 2), if (has) Theme.accent else Theme.surface2) }
        box.removeTextChangedListener(searchWatcher)
        box.addTextChangedListener(searchWatcher)
        box.setOnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH || id == EditorInfo.IME_ACTION_DONE) {
                typeJob?.cancel(); f = f.copy(text = v.text.toString().trim()); refresh()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
                b.filterList.getChildAt(1)?.requestFocus() ?: b.results.requestFocus()
                true
            } else false
        }
    }

    private val searchWatcher = object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
            if (syncing) return
            val t = s?.toString()?.trim() ?: ""
            typeJob?.cancel()
            typeJob = lifecycleScope.launch { kotlinx.coroutines.delay(250); f = f.copy(text = t); refresh() }
        }
    }

    private fun showKeyboard() {
        b.searchBox.requestFocus()
        b.searchBox.post { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(b.searchBox, InputMethodManager.SHOW_IMPLICIT) }
    }

    /** Fill the boxes (text, years) from the filters, e.g. when the window opens or Reset Filters is pressed. */
    private fun syncInputs() {
        syncing = true
        if (b.searchBox.text.toString() != f.text) b.searchBox.setText(f.text)
        b.searchBox.setSelection(b.searchBox.text.length)
        yearFromBox?.setText(if (f.yearFrom > 0) f.yearFrom.toString() else "")
        yearToBox?.setText(if (f.yearTo > 0) f.yearTo.toString() else "")
        syncing = false
    }

    // ---- data -----------------------------------------------------------------------------------------------------
    private suspend fun load(repo: Repository, pid: Long) {
        if (kind == SearchKind.LIVE) {
            val cats = repo.dao.categories(pid, "live").associate { it.remoteId to TitleCase.of(it.name) }
            channels = repo.channelsFor(pid, Repository.SCOPE_ALL, includeHidden = true)      // hidden ones are left out by the filters ("Hide" row), not here
            val cu = repo.custom(pid)
            val inHiddenGroup = HashSet<String>().also { s -> cu.hiddenGroups.forEach { g -> cu.added[g]?.let { s += it } } }
            chanByUid.clear(); channels.forEach { chanByUid[it.uid] = it }
            index = null; genreOptions = emptyList()
            all = channels.map { c ->
                val g = cats[c.categoryId] ?: ""
                val tagText = c.name + " " + g
                Candidate(
                    uid = c.uid, name = c.name, group = g, quality = MediaTags.quality(tagText), languages = MediaTags.languages(tagText),
                    subtitles = MediaTags.hasSubtitles(c.name), channelType = MediaTags.channelType(g, c.name), number = c.number, live = true,
                    hiddenChannel = c.uid in cu.hidden, hiddenGroup = c.categoryId in cu.hiddenGroups || c.uid in inHiddenGroup
                )
            }.sortedBy { it.nameLower }
        } else {
            // the list was built once, in the background, when the app started (see Repository.searchIndex): only the profile's own state is refreshed here
            val cat = repo.catalog(pid, if (kind == SearchKind.MOVIE) "movie" else "series")
            val idx = repo.searchIndex(cat)
            index = idx; chanByUid.clear(); channels = emptyList()
            genreOptions = idx.genreOptions
            all = idx.items
        }
    }

    private fun imageOf(c: Candidate): String? = if (c.live) chanByUid[c.uid]?.logo else index?.poster?.invoke(c.uid)

    private fun open(c: Candidate) {
        if (pick) { setResult(RESULT_OK, Intent().putExtra("uid", c.uid).putExtra("name", c.name)); finish(); return }
        if (c.live) startActivity(PlayerActivity.live(this, c.uid, Repository.SCOPE_ALL))
        else startActivity(DetailsActivity.intent(this, c.uid))
    }

    // ---- results ----------------------------------------------------------------------------------------------------
    private fun refresh() {
        if (!random && !pick) remembered[kind] = f
        updaters.forEach { it() }
        panel?.refresh()
        val n = f.activeCount
        b.summary.text = if (n == 0) "No Filters On" else "$n Filter${if (n == 1) "" else "s"} On"
        if (!loaded) return
        refreshJob?.cancel()
        refreshJob = lifecycleScope.launch {
            val desc: Set<String> =
                if (kind == SearchKind.LIVE && f.inDescription && f.text.isNotBlank()) withContext(Dispatchers.IO) { liveDescriptionMatches() }
                else emptySet()
            val res = withContext(Dispatchers.Default) { SearchEngine.apply(all, f, desc, presortedByName = true) }
            adapter.submit(res)
            b.count.text = "${res.size} Result${if (res.size == 1) "" else "s"}"
            b.empty.visibility = if (res.isEmpty()) View.VISIBLE else View.GONE
            b.empty.text = if (all.isEmpty()) "Nothing To Search Yet – Sync Your Playlist First" else "No Results – Try Fewer Filters"
        }
    }

    /** Live channels whose guide listing (title or description, anywhere in the downloaded guide) contains the text. */
    private suspend fun liveDescriptionMatches(): Set<String> {
        val ids = applicationContext.repo.dao.epgIdsMatching(providerId, "%" + f.text.trim() + "%").toHashSet()
        return channels.filter { it.epgId in ids }.map { it.uid }.toHashSet()
    }

    // ---- filter rows ------------------------------------------------------------------------------------------------
    private fun row(label: String, value: () -> String, onClick: () -> Unit) {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            tag = "bg:item"
            minimumHeight = dp(50)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            isFocusable = true
            isClickable = true
        }
        val l = TextView(this).apply {
            text = label; textSize = 17f; tag = "t:item"; isDuplicateParentStateEnabled = true
            setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
        }
        val vv = TextView(this).apply {
            textSize = 16f; tag = "t:item"; isDuplicateParentStateEnabled = true
            setTypeface(typeface, Typeface.BOLD)
            setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.END; maxWidth = dp(190); setPadding(dp(12), 0, 0, 0)
        }
        v.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        v.addView(vv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        updaters += { vv.text = value() }
        v.setOnClickListener { onClick() }
        Theme.applyTree(v)
        b.filterList.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) })
    }

    private fun summarize(set: Set<String>, label: (String) -> String, out: Boolean = false): String {
        if (set.isEmpty()) return "Any"
        val txt = if (set.size <= 2) set.joinToString(", ") { label(it) } else "${set.size} Selected"
        return if (out) "Hide: $txt" else txt
    }

    private fun starsLabel(v: Double) = if (v <= 0) "Any" else SparrowRating.format(v) + " & Up"

    /**
     * The left column: [random pick], then the filters themselves ([FilterPanel]: Live / Movie / Series buttons, drop-downs, toggles), the one-line
     * Release Years boxes (typed before or after searching), Sort By, Reset. Everything applies as soon as it is changed.
     */
    private fun buildFilters() {
        b.filterList.removeAllViews(); updaters.clear()
        yearFromBox = null; yearToBox = null
        val pn = FilterPanel(this, b.filterList, { kind }, { f }, { genreOptions }, pick, { nf -> f = nf; refresh() }, { nk -> switchKind(nk) })
        panel = pn
        if (random) row("🎲  Pick A Random Title", { "" }) { pickRandom() }
        pn.buildTop()
        if (kind != SearchKind.LIVE) yearRangeRow()
        pn.buildSort()
        row("Reset Filters", { "" }) { f = SearchFilters(kind); syncInputs(); refresh() }
        pn.refresh()
    }

    /** Another Type (Live / Movie / Series): the window is opened again for it; the text and years are kept. */
    private fun switchKind(nk: SearchKind) {
        if (nk == kind) return
        val nf = SearchFilters(nk, text = f.text, yearFrom = f.yearFrom, yearTo = f.yearTo)
        if (!random && !pick) { remembered[kind] = f; remembered[nk] = (remembered[nk] ?: nf).copy(text = f.text) } else carry = nf
        kind = nk; start()
    }

    /** One random title from what the filters currently show. Only the info page opens: nothing starts playing. */
    private fun pickRandom() {
        val shown = adapter.current()
        if (shown.isEmpty()) { toast("No titles match these filters"); return }
        open(shown.random())
    }

    /** ONE line: Release Years  [ from ] – [ to ]. Type the years before or after searching; a year counts once it has four digits. */
    private fun yearRangeRow() {
        fun box(hint: String): EditText = EditText(this).apply {
            this.hint = hint; textSize = 17f; tag = "t:text;h:dim"; gravity = Gravity.CENTER
            setSingleLine(true); inputType = InputType.TYPE_CLASS_NUMBER; imeOptions = EditorInfo.IME_ACTION_DONE
            filters = arrayOf<InputFilter>(InputFilter.LengthFilter(4))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            val ring = GradientDrawable().apply { setColor(Theme.bg); cornerRadius = dp(8).toFloat(); setStroke(dp(2), Theme.surface2) }
            background = ring
            setOnFocusChangeListener { _, has -> ring.setStroke(dp(if (has) 3 else 2), if (has) Theme.accent else Theme.surface2) }
        }
        val from = box("From"); val to = box("To")
        yearFromBox = from; yearToBox = to
        fun year(e: EditText): Int = e.text.toString().trim().let { if (it.length == 4) it.toIntOrNull() ?: 0 else 0 }
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (syncing) return
                val y1 = year(from); val y2 = year(to)
                if (y1 != f.yearFrom || y2 != f.yearTo) { f = f.copy(yearFrom = y1, yearTo = y2); refresh() }
            }
        }
        from.addTextChangedListener(watcher); to.addTextChangedListener(watcher)
        val done = TextView.OnEditorActionListener { v, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0); true
            } else false
        }
        from.setOnEditorActionListener(done); to.setOnEditorActionListener(done)
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(6), dp(16), dp(6)) }
        line.addView(TextView(this).apply { text = "Release Years"; textSize = 17f; tag = "t:text"; setSingleLine(true) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        line.addView(from, LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT))
        line.addView(TextView(this).apply { text = "–"; textSize = 20f; tag = "t:dim"; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(24), ViewGroup.LayoutParams.WRAP_CONTENT))
        line.addView(to, LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT))
        Theme.applyTree(line)
        b.filterList.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) })
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---- adapter ----------------------------------------------------------------------------------------------------
    class ResultAdapter(
        private val onPick: (Candidate) -> Unit,
        private val image: (Candidate) -> String?
    ) : RecyclerView.Adapter<ResultAdapter.VH>() {
        var live = false
        private var items: List<Candidate> = emptyList()

        fun submit(l: List<Candidate>) { items = l; notifyDataSetChanged() }
        fun current(): List<Candidate> = items

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val poster: ImageView = v.findViewById(R.id.poster)
            val name: TextView = v.findViewById(R.id.name)
            val sub: TextView = v.findViewById(R.id.sub)
        }

        override fun getItemViewType(position: Int) = if (live) 1 else 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(if (viewType == 1) R.layout.item_result_row else R.layout.item_result_poster, parent, false)
            Theme.applyTree(v)
            return VH(v)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val c = items[position]
            h.name.text = c.name
            h.sub.text = subtitle(c)
            h.poster.loadUrl(image(c))
            (h.poster as? RatedImageView)?.setRatings(c.stars, c.sparrow)        // provider top left, Sparrow top right
            h.itemView.setOnClickListener { onPick(c) }
        }

        override fun getItemCount() = items.size

        private fun subtitle(c: Candidate): String =
            if (c.live) listOf(if (c.number > 0) "#${c.number}" else "", c.group).filter { it.isNotBlank() }.joinToString("  •  ")
            else listOf(
                if (c.year > 0) c.year.toString() else "", if (c.quality != "SD") c.quality else ""
            ).filter { it.isNotBlank() }.joinToString("  •  ")
    }

    companion object {
        /** Filters stay as the user left them (per kind) while the app is running. */
        private val remembered = HashMap<SearchKind, SearchFilters>()

        fun intent(ctx: Context, kind: SearchKind) = Intent(ctx, SearchActivity::class.java).putExtra("kind", kind.name)

        /** Live channel chooser: returns "uid" and "name" as the result. */
        /** Random Pick for Movies or Series: the filters window with a "Pick A Random Title" row; unwatched titles only by default. */
        fun random(ctx: Context, kind: SearchKind) = intent(ctx, kind).putExtra("random", true)

        fun pickChannel(ctx: Context) = intent(ctx, SearchKind.LIVE).putExtra("pick", true)
    }
}
