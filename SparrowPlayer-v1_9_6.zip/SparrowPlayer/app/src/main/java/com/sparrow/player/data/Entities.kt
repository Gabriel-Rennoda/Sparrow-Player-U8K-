package com.sparrow.player.data

import androidx.room.*

@Entity(tableName = "providers")
data class Provider(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,               // "xtream" | "m3u"
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val m3uUrl: String = "",
    val epgUrl: String = "",
    val lastSync: Long = 0
)

@Entity(tableName = "categories", indices = [Index("providerId", "type")])
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val providerId: Long,
    val remoteId: String,
    val name: String,
    val type: String                // "live" | "vod" | "series"
)

@Entity(tableName = "channels", indices = [Index("providerId", "categoryId"), Index("providerId", "epgId")])
data class Channel(
    @PrimaryKey val uid: String,    // "<providerId>:<remoteId>"
    val providerId: Long,
    val remoteId: String,
    val number: Int,
    val name: String,
    val logo: String,
    val streamUrl: String,          // empty for Xtream (built at runtime so the TS/HLS setting applies)
    val categoryId: String,
    val epgId: String,
    val isFavorite: Boolean = false
)

@Entity(tableName = "vod", indices = [Index("providerId", "type", "categoryId")])
data class VodItem(
    @PrimaryKey val uid: String,
    val providerId: Long,
    val remoteId: String,
    val type: String,               // "movie" | "series"
    val name: String,
    val poster: String,
    val backdrop: String,
    val categoryId: String,
    val rating: String,
    val year: String,
    val plot: String,
    val added: Long,
    val ext: String,
    val genre: String,
    val streamUrl: String
)

@Entity(tableName = "programmes", indices = [Index("providerId", "epgId", "start")])
data class Programme(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val providerId: Long,
    val epgId: String,
    val start: Long,
    val stop: Long,
    val title: String,
    val descr: String
)

@Dao
interface AppDao {
    @Query("SELECT * FROM providers ORDER BY id") suspend fun providers(): List<Provider>
    @Query("SELECT * FROM providers WHERE id = :id") suspend fun provider(id: Long): Provider?
    @Insert suspend fun insertProvider(p: Provider): Long
    @Update suspend fun updateProvider(p: Provider)
    @Query("DELETE FROM providers WHERE id = :id") suspend fun deleteProvider(id: Long)

    @Query("SELECT * FROM categories WHERE providerId = :pid AND type = :type ORDER BY id")
    suspend fun categories(pid: Long, type: String): List<Category>
    @Insert suspend fun insertCategories(l: List<Category>)
    @Query("DELETE FROM categories WHERE providerId = :pid") suspend fun deleteCategories(pid: Long)

    @Query("SELECT * FROM channels WHERE providerId = :pid ORDER BY number, name") suspend fun channels(pid: Long): List<Channel>
    @Query("SELECT * FROM channels WHERE providerId = :pid AND categoryId = :cat ORDER BY number, name")
    suspend fun channelsIn(pid: Long, cat: String): List<Channel>
    @Query("SELECT * FROM channels WHERE providerId = :pid AND isFavorite = 1 ORDER BY number, name")
    suspend fun favorites(pid: Long): List<Channel>
    @Query("SELECT uid FROM channels WHERE providerId = :pid AND isFavorite = 1") suspend fun favoriteKeys(pid: Long): List<String>
    @Query("SELECT * FROM channels WHERE uid = :uid") suspend fun channel(uid: String): Channel?
    @Query("SELECT * FROM channels WHERE uid IN (:uids) ORDER BY number, name") suspend fun channelsByUids(uids: List<String>): List<Channel>
    @Query("UPDATE channels SET isFavorite = :fav WHERE uid = :uid") suspend fun setFavorite(uid: String, fav: Boolean)
    @Query("UPDATE channels SET isFavorite = 1 WHERE uid IN (:uids)") suspend fun restoreFavorites(uids: List<String>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertChannels(l: List<Channel>)
    @Query("DELETE FROM channels WHERE providerId = :pid") suspend fun deleteChannels(pid: Long)

    @Query("SELECT * FROM vod WHERE providerId = :pid AND type = :type ORDER BY added DESC LIMIT :limit")
    suspend fun vodRecent(pid: Long, type: String, limit: Int): List<VodItem>
    @Query("SELECT * FROM vod WHERE providerId = :pid AND type = :type AND categoryId = :cat ORDER BY added DESC LIMIT :limit")
    suspend fun vodIn(pid: Long, type: String, cat: String, limit: Int): List<VodItem>
    @Query("SELECT * FROM vod WHERE providerId = :pid AND type = :type") suspend fun vodAll(pid: Long, type: String): List<VodItem>
    @Query("SELECT DISTINCT categoryId, genre FROM vod WHERE providerId = :pid AND type = :type") suspend fun catGenres(pid: Long, type: String): List<CatGenre>
    @Query("SELECT uid, categoryId, name, poster, rating, year, added, genre FROM vod WHERE providerId = :pid AND type = :type")
    suspend fun vodLite(pid: Long, type: String): List<VodLite>
    @Query("SELECT uid, plot FROM vod WHERE providerId = :pid AND type = :type AND plot != ''")
    suspend fun vodPlots(pid: Long, type: String): List<UidPlot>
    @Query("SELECT DISTINCT epgId FROM programmes WHERE providerId = :pid AND (title LIKE :q OR descr LIKE :q)")
    suspend fun epgIdsMatching(pid: Long, q: String): List<String>
    @Query("SELECT * FROM vod WHERE uid = :uid") suspend fun vod(uid: String): VodItem?
    @Query("SELECT * FROM vod WHERE uid IN (:uids)") suspend fun vodByUids(uids: List<String>): List<VodItem>
    @Query("SELECT * FROM vod WHERE providerId = :pid AND type = :type AND genre LIKE :pattern ORDER BY added DESC LIMIT :limit")
    suspend fun vodByGenre(pid: Long, type: String, pattern: String, limit: Int): List<VodItem>
    @Query("SELECT * FROM vod WHERE providerId = :pid AND type = :type ORDER BY CAST(rating AS REAL) DESC, added DESC LIMIT :limit")
    suspend fun vodTopRated(pid: Long, type: String, limit: Int): List<VodItem>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertVod(l: List<VodItem>)
    @Query("UPDATE vod SET poster = :poster WHERE uid = :uid") suspend fun updatePoster(uid: String, poster: String)
    @Query("DELETE FROM vod WHERE providerId = :pid") suspend fun deleteVod(pid: Long)

    // EPG (blocking variants are used from the importer, which already runs on Dispatchers.IO)
    @Insert fun insertProgrammes(l: List<Programme>)
    @Query("DELETE FROM programmes WHERE providerId = :pid") fun deleteProgrammes(pid: Long)
    @Query("SELECT * FROM programmes WHERE providerId = :pid AND epgId IN (:ids) AND stop > :from AND start < :to ORDER BY start")
    suspend fun programmes(pid: Long, ids: List<String>, from: Long, to: Long): List<Programme>
    @Query("SELECT * FROM programmes WHERE providerId = :pid AND epgId = :id AND stop > :now ORDER BY start LIMIT 2")
    suspend fun nowNext(pid: Long, id: String, now: Long): List<Programme>
}

@Database(
    entities = [Provider::class, Category::class, Channel::class, VodItem::class, Programme::class],
    version = 1, exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
}
