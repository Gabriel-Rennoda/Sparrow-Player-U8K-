plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.sparrow.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sparrow.player"
        minSdk = 24
        targetSdk = 34
        versionCode = 20
        versionName = "1.9.6"
    }

    // ONE fixed signing key for every build (committed: app/sparrow-signing.jks). Android only installs an APK over an existing
    // install when both are signed with the same key; the default debug key is generated fresh on every GitHub runner, so each CI
    // build would be a "different app" and the only way to install it would be to uninstall first - losing all data and logins.
    // NEVER change this file, the alias or the passwords: doing so breaks "install over the old version" for everybody.
    signingConfigs {
        create("sparrow") {
            storeFile = file("sparrow-signing.jks")
            storePassword = "sparrowplayer"
            keyAlias = "sparrow"
            keyPassword = "sparrowplayer"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("sparrow") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("sparrow")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }
    lint {
        // Media3's @UnstableApi is a lint-only opt-in; don't fail release builds on it.
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.leanback:leanback:1.2.0-alpha04")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")

    // Media3 / ExoPlayer
    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-exoplayer-rtsp:$media3")
    implementation("androidx.media3:media3-datasource-okhttp:$media3")
    implementation("androidx.media3:media3-ui:$media3")

    // Data
    val room = "2.6.1"
    implementation("androidx.room:room-runtime:$room")
    implementation("androidx.room:room-ktx:$room")
    ksp("androidx.room:room-compiler:$room")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Images
    implementation("io.coil-kt:coil:2.7.0")

    testImplementation("junit:junit:4.13.2")
}
