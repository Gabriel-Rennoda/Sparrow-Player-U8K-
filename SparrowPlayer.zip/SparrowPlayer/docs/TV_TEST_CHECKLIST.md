# Hisense U8K checklist (please run on the TV - these could not be run off-device)

The build (`gradle assembleDebug`) is verified by your GitHub Action. Remote behaviour below needs a real TV.

## Sizing (75", 3840x2160)
- [ ] Live TV: player top-left (16:9, not cut off), info pane to its right fully visible, list below, nothing clipped at any edge
- [ ] Guide: same header; grid rows fully visible; time header visible
- [ ] Movies / Series: hero text on top, posters below, nothing clipped
- [ ] Settings / Add provider / Details readable and inside the screen

## Player + info (#2)
- [ ] App opens with the last channel playing in the top-left box
- [ ] Moving up/down the list or around the guide updates the info pane (tag says BROWSING) while the picture keeps playing
- [ ] Focus on the player box (Up from the first row) -> info returns to the playing channel (tag NOW PLAYING)
- [ ] OK on another channel tunes the player; OK on the playing channel (or on the player box) = full screen; Back returns to the list
- [ ] Hold OK on a channel toggles favourite

## Movies / Series (#3)
- [ ] Tab list -> Movies (OK): selector lands on the first poster and STAYS there
- [ ] Browse rows left/right/up/down for 30+ seconds, including while a sync finishes: selector never jumps to another tab
- [ ] Same for Series

## Panels (#4)
- [ ] Guide, left-most programme, LEFT -> channel groups open, selector on the active group
- [ ] LEFT again -> tab list expands (labels visible)
- [ ] BACK -> groups, selector on the group you were on; BACK -> guide, selector on the programme you left
- [ ] Same starting from the player box and from the Live TV list
- [ ] OK on a group applies it and returns to the list/guide; Back on groups (without OK) changes nothing
- [ ] Movies/Series/Favourites/Settings: LEFT at the first item opens the tab list directly; Back returns

## Language (#5)
- [ ] "Favourites" everywhere (tab, group, toasts), "program" in guide text
