# Sparrow Player

IPTV player for Android TV / Google TV (built and tuned for the Hisense U8K, 75").
Kotlin · Leanback · Media3/ExoPlayer · Room · OkHttp · Coil.

## Build & install
1. Open this folder in **Android Studio (Koala or newer)** – it generates the Gradle wrapper and syncs.
   (Command line: `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleDebug`.)
2. On the TV: Settings → System → About → tap *Build* 7× → Developer options → enable **USB/Network debugging**.
3. `adb connect <tv-ip>:5555` then `adb install -r app/build/outputs/apk/debug/app-debug.apk`
   (or Run ▶ from Android Studio with the TV selected).

## Using it
First launch asks for a provider: **Xtream Codes** (server, user, password) or an **M3U URL** (+ optional XMLTV URL).
Channels, movies, series and a 36 h guide window are imported into a local database; progress shows at the top right.

### Screen layout
* **Live TV / Guide / Favourites**: the player is in the top-left corner and always shows the channel you are
  watching. The info pane to its right follows whatever you are browsing (label says *NOW PLAYING* or *BROWSING*).
* **Left side**: a minimized icon bar is always visible.

### Remote
| Where | Keys |
|---|---|
| Channel list | ↑/↓ browse, **OK** = tune the top-left player, **OK on the playing channel** (or on the player) = full screen, **hold OK** = favourite |
| Guide | ←/→ programmes, ↑/↓ channels, **OK** = tune / full screen, CH± = page |
| Player box | ↑ from the first channel reaches it; **OK** = full screen |
| Movies / Series | ←/→/↑/↓ browse posters, OK = details → Play / pick episode |
| Full screen (live) | ↑/↓ or CH± = zap, 0-9 = channel number, OK = info, hold OK = favourite, **Menu** = audio / subtitles / video track |
| Full screen (VOD) | standard Media3 controls, position is remembered |

### Side panels (Live TV and Guide)
1. **←** at the left-most item of the player / list / guide opens **Channel groups** (All channels, Favourites, other groups). Move with ↑/↓, **OK** picks a group.
2. **←** again expands the **tab list** (Live TV, Movies, Series, Guide, Favourites, Settings). **OK** opens a tab.
3. **Back** (or **→**) closes one level at a time and puts the selector back where you were:
   tab list → channel groups → your last selection in the guide / list.

Movies, Series, Favourites and Settings have no channel groups, so **←** at their left edge opens the tab list directly.

## Project map
- `data/` Room entities+DAO, `XtreamClient`, `M3uParser`, `XmltvParser` (streaming, gzip aware), `Repository` (sync)
- `ui/MainActivity` shell: icon bar / tab list, groups panel, top-left player, info pane, D-pad panel navigation
- `ui/nav/PanelState` pure state machine for the side panels (unit tested: `app/src/test`)
- `ui/live` channel list · `ui/epg` EpgView (custom canvas grid) · `ui/vod` rows + details · `ui/player` full-screen player
- `ui/settings` provider management · `res/` theme, layouts, icons

## Screen sizing
Layouts are weight / percentage based. Google TV 4K panels report a 960 × 540 dp viewport (640 dpi); the screens also
adapt to 1280 × 720 dp and 1920 × 1080 dp. Poster size and the player are derived from the screen size, not fixed dp.

## Notes / tuning
- Live format for Xtream: Settings → toggle **TS** (default, fastest zap) or **HLS (m3u8)**.
- User-Agent is `Prefs.UA` (VLC string) – change if your provider whitelists something else.
- The Guide shows the first 300 channels of the selected group (keeps it smooth); use a group to narrow it down.
- MP2 / some exotic audio isn't decodable by Android's built-in codecs. If you hit silent channels, add the
  Media3 FFmpeg decoder extension (build it locally; it is not published to Maven).
- Release builds are signed with the debug key for convenience; use your own keystore for distribution.
- EPG matching uses `epg_channel_id` / `tvg-id` only; name-based fuzzy matching is a good next step.
- In-app text uses Canadian English (favourite, program, ...).
