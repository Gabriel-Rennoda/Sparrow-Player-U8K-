# Sparrow Player

IPTV player for Android TV / Google TV (built and tuned for the Hisense U8K).
Kotlin · Leanback · Media3/ExoPlayer · Room · OkHttp · Coil.

## Build & install
1. Open this folder in **Android Studio (Koala or newer)** – it generates the Gradle wrapper and syncs.
   (Command line: `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleDebug`.)
2. On the TV: Settings → System → About → tap *Build* 7× → Developer options → enable **USB/Network debugging**.
3. `adb connect <tv-ip>:5555` then `adb install -r app/build/outputs/apk/debug/app-debug.apk`
   (or Run ▶ from Android Studio with the TV selected).

## Using it
First launch asks for a provider: **Xtream Codes** (server, user, password) or an **M3U URL** (+ optional XMLTV URL).
Channels, movies, series and a 36 h guide window are imported into a local database; progress shows in the top bar.

| Screen | Style | Controls |
|---|---|---|
| Live TV | TiviMate-like: categories · channels with now/next bar · live preview + EPG info | OK = fullscreen, **hold OK = favorite** |
| Guide | EPG grid (channels × time) | ←/→ programmes, ↑/↓ channels, OK = watch, CH± = page |
| Movies / Series | Netflix/Disney+-like Leanback rows, changing backdrop + hero text | OK = details → Play / pick episode |
| Favorites | Favorited channels | same as Live |
| Player (live) | Info banner, zapping | ↑/↓ or CH± = zap, 0-9 = channel number, OK = info, hold OK = favorite, **Menu = audio / subtitles / video track** |
| Player (VOD) | Media3 controls, resume position | standard |

## Project map
- `data/` Room entities+DAO, `XtreamClient`, `M3uParser`, `XmltvParser` (streaming, gzip aware), `Repository` (sync)
- `ui/live` Live TV · `ui/epg` EpgView (custom canvas grid) · `ui/vod` browse + details · `ui/player` PlayerActivity/PlayerFactory
- `ui/settings` provider management · `res/` theme, layouts, circular icon + TV banner

## Notes / tuning
- Live format for Xtream: Settings → toggle **TS** (default, fastest zap) or **HLS (m3u8)**.
- User-Agent is `Prefs.UA` (VLC string) – change if your provider whitelists something else.
- MP2 / some exotic audio isn't decodable by Android's built-in codecs. If you hit silent channels, add the
  Media3 FFmpeg decoder extension (build it locally; it is not published to Maven).
- Release builds are signed with the debug key for convenience; use your own keystore for distribution.
- EPG matching uses `epg_channel_id` / `tvg-id` only; name-based fuzzy matching is a good next step.
