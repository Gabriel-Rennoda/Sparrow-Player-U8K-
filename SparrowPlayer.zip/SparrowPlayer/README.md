# Sparrow Player

IPTV player for Android TV / Google TV (built and tuned for the Hisense U8K, 75").
Kotlin · Leanback · Media3/ExoPlayer · Room · OkHttp · Coil.

## Build & install
1. Open this folder in **Android Studio (Koala or newer)** – it generates the Gradle wrapper and syncs.
   (Command line: `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleDebug`.)
2. On the TV: Settings → System → About → tap *Build* 7× → Developer options → enable **USB/Network debugging**.
3. `adb connect <tv-ip>:5555` then `adb install -r app/build/outputs/apk/debug/app-debug.apk`
   (or Run ▶ from Android Studio with the TV selected).

## Using it
First launch asks for a provider: **Xtream Codes** (server, user, password) or an **M3U URL** (+ optional XMLTV URL).
Channels, movies, series and a 36 h guide window are imported into a local database; progress shows at the top right.

### Screen layout
* **Live TV / Favourites** share one guide: player top-left (always the channel you are watching), info pane to its
  right (follows the highlighted program), date + time top-left of the guide, then a grid of channels (logo, name,
  optional number) x four half-hour columns (2 h) starting at the current half hour.
* **Left side**: a minimized icon bar is always visible.

### Remote
| Where | Keys |
|---|---|
| Live TV (guide) | ←/→ highlight programs (the time window never moves), ↑/↓ channels, **OK** = time shifting mode (3 s pop-up), **OK twice** = tune / full screen, **hold OK** = favourite, CH± = page |
| Live TV, time shifting mode | ←/→ move the window by 30 min (past and future), ↑/↓ channels, **Back** = leave (window returns to now, same channel) |
| Player box | ↑ from the first channel reaches it; **OK** = full screen |
| Movies / Series | ←/→/↑/↓ browse posters (backdrop shows the highlighted title), OK = details → Play / pick episode (**one OK plays it**) |
| Full screen (live) | ↑/↓ or CH± = zap, 0-9 = channel number, OK = info, hold OK = favourite, **Menu** = audio / subtitles / video track |
| Full screen (VOD) | standard Media3 controls; resumes 30 s before where you stopped |
| Main screen | **Back** once = hint, **Back** twice = "Exit?  Yes / No" |

### Side panels (Live TV and Guide)
1. **←** at the left-most item of the player / guide opens **Channel groups**. The guide shows the group you are on as you move with ↑/↓; **OK** confirms, **Back** keeps what is shown.
2. **←** again expands the **tab list** (Live TV, Movies, Series, Favourites, Settings). **OK** opens a tab.
3. **Back** (or **→**) closes one level at a time and puts the selector back where you were:
   tab list → channel groups → your last selection in the guide / list.

Movies, Series, Favourites and Settings have no channel groups, so **←** at their left edge opens the tab list directly.

## Project map
- `data/` Room entities+DAO, `XtreamClient`, `M3uParser`, `XmltvParser` (streaming, gzip aware), `Repository` (sync)
- `ui/MainActivity` shell: icon bar / tab list, groups panel, top-left player, info pane, D-pad panel navigation
- `ui/nav/PanelState` pure state machine for the side panels (unit tested: `app/src/test`)
- `ui/epg` EpgView (custom canvas grid) + GuideMath (pure, tested) · `ui/vod` rows + details · `ui/player` full-screen player
- `ui/settings` provider management · `res/` theme, layouts, icons

## Screen sizing
Layouts are weight / percentage based. Google TV 4K panels report a 960 × 540 dp viewport (640 dpi); the screens also
adapt to 1280 × 720 dp and 1920 × 1080 dp. Poster size and the player are derived from the screen size, not fixed dp.

## Notes / tuning
- Live format for Xtream: Settings → toggle **TS** (default, fastest zap) or **HLS (m3u8)**.
- User-Agent is `Prefs.UA` (VLC string) – change if your provider whitelists something else.
- The Guide lists every channel of the group; programs are loaded lazily for the rows around the selection.
- Settings: 12 / 24 hour clock, show / hide channel numbers.
- MP2 / some exotic audio isn't decodable by Android's built-in codecs. If you hit silent channels, add the
  Media3 FFmpeg decoder extension (build it locally; it is not published to Maven).
- Release builds are signed with the debug key for convenience; use your own keystore for distribution.
- EPG matching uses `epg_channel_id` / `tvg-id` only; name-based fuzzy matching is a good next step.
- In-app text uses Canadian English (favourite, program, ...).

### v1.1.1
- The separate Guide tab is gone: **Live TV is the guide**.
- The live info pane has no progress bar. Movies, series and episodes show a watch-progress bar (hero on the Movies / Series tabs,
  details screen, and per focused episode).
