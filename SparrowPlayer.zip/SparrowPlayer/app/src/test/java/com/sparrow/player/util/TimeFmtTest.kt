package com.sparrow.player.util

import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class TimeFmtTest {
    @Before fun utc() { TimeZone.setDefault(TimeZone.getTimeZone("UTC")) }
    private fun at(y: Int, mo: Int, d: Int, h: Int, mi: Int) =
        Calendar.getInstance().apply { clear(); set(y, mo, d, h, mi) }.timeInMillis

    @Test fun header12h() = assertEquals("Thurs, Nov. 05     -    1:15 am", TimeFmt.guideHeader(at(2026, Calendar.NOVEMBER, 5, 1, 15), false))
    @Test fun header24h() = assertEquals("Thurs, Nov. 05     -    13:15", TimeFmt.guideHeader(at(2026, Calendar.NOVEMBER, 5, 13, 15), true))
    @Test fun noonAndMidnight() {
        assertEquals("12:00 pm", TimeFmt.clock(at(2026, 0, 1, 12, 0), false))
        assertEquals("12:05 am", TimeFmt.clock(at(2026, 0, 1, 0, 5), false))
    }
}
