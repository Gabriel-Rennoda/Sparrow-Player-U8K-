package com.sparrow.player.ui.nav

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PanelStateTest {
    @Test fun leftOnlyOpensAtTheEdge() {
        val s = PanelState().apply { hasGroups = true }
        assertFalse(s.left(atContentEdge = false))
        assertEquals(Panel.NONE, s.panel)
    }

    @Test fun guideFlow_groups_then_nav_then_backUnwinds() {
        val s = PanelState().apply { hasGroups = true }
        assertTrue(s.left(true));  assertEquals(Panel.GROUPS, s.panel); assertTrue(s.groupsOpen); assertFalse(s.navOpen)
        assertTrue(s.left(true));  assertEquals(Panel.NAV, s.panel);    assertTrue(s.groupsOpen); assertTrue(s.navOpen)
        assertTrue(s.left(true));  assertEquals(Panel.NAV, s.panel)     // a third LEFT does nothing more
        assertTrue(s.back());      assertEquals(Panel.GROUPS, s.panel)
        assertTrue(s.back());      assertEquals(Panel.NONE, s.panel)
        assertFalse(s.back())                                           // let the system handle Back
    }

    @Test fun screensWithoutGroups_goStraightToNav() {
        val s = PanelState().apply { hasGroups = false }
        assertTrue(s.left(true)); assertEquals(Panel.NAV, s.panel); assertFalse(s.groupsOpen)
        assertTrue(s.back());     assertEquals(Panel.NONE, s.panel)
    }

    @Test fun resetClosesEverything() {
        val s = PanelState().apply { hasGroups = true }
        s.left(true); s.left(true); s.reset()
        assertEquals(Panel.NONE, s.panel); assertFalse(s.groupsOpen); assertFalse(s.navOpen)
    }
}
