package com.sparrow.player.ui.epg

import com.sparrow.player.data.Programme
import org.junit.Assert.*
import org.junit.Test

class GuideMathTest {
    private val H = 3600_000L
    private val M = 60_000L
    private fun t(h: Int, m: Int) = h * H + m * M            // UTC day 0; offset 0 in every call below
    private fun base(h: Int, m: Int) = GuideMath.baseStart(t(h, m), 0)
    private fun prog(s: Long, e: Long, title: String = "p") = Programme(providerId = 1, epgId = "x", start = s, stop = e, title = title, descr = "")

    @Test fun windowStartsAtCurrentHalfHour() {
        assertEquals(t(4, 30), base(4, 30))
        assertEquals(t(4, 30), base(4, 50))
        assertEquals(t(4, 0), base(4, 0))
        assertEquals(t(4, 30), base(4, 59))
        assertEquals(t(4, 0), base(4, 29))
    }

    @Test fun windowSpansTwoHours() = assertEquals(t(6, 30), GuideMath.windowEnd(t(4, 30)))

    @Test fun multiBlockProgrammeIsOneContinuousBlock() {
        val ws = t(4, 30); val we = GuideMath.windowEnd(ws)
        val segs = GuideMath.segments(listOf(prog(t(4, 0), t(5, 30), "A"), prog(t(5, 30), t(8, 0), "B")), ws, we)
        assertEquals(2, segs.size)
        assertEquals(ws, segs[0].start); assertEquals(t(5, 30), segs[0].stop)
        assertEquals(t(5, 30), segs[1].start); assertEquals(we, segs[1].stop)      // clipped to the window end
    }

    @Test fun rowWithoutDataIsOneSelectableNoInformationBlock() {
        val ws = t(4, 30)
        val segs = GuideMath.segments(emptyList(), ws, GuideMath.windowEnd(ws))
        assertEquals(1, segs.size); assertNull(segs[0].prog)
    }

    @Test fun gapsAreFilled() {
        val ws = t(4, 30)
        val segs = GuideMath.segments(listOf(prog(t(5, 0), t(5, 30))), ws, GuideMath.windowEnd(ws))
        assertEquals(listOf(null, "p", null), segs.map { it.prog?.title })
        assertEquals(GuideMath.windowEnd(ws), segs.last().stop)
    }

    @Test fun timeShiftIsClamped() {
        val b = t(10, 0)
        assertEquals(b + GuideMath.HALF, GuideMath.shift(b, b, 1))
        assertEquals(GuideMath.minStart(b), GuideMath.shift(GuideMath.minStart(b), b, -1))
        assertEquals(GuideMath.maxStart(b), GuideMath.shift(GuideMath.maxStart(b), b, 1))
    }

    @Test fun doubleOkWithinWindowOnly() {
        val k = GuideMath.OkTracker(500)
        assertFalse(k.isDouble(1000)); assertTrue(k.isDouble(1300))
        assertFalse(k.isDouble(1400))                       // a third press does not chain
        assertFalse(k.isDouble(5000))
    }
}
