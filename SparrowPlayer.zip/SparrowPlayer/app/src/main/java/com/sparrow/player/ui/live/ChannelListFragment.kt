package com.sparrow.player.ui.live

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.doOnLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Programme
import com.sparrow.player.data.Repository
import com.sparrow.player.databinding.FragmentChannelsBinding
import com.sparrow.player.databinding.ItemChannelBinding
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.TabContent
import com.sparrow.player.util.loadUrl
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Channel list with now-playing bar. Used for Live TV (follows the group picked in the groups panel) and for the
 * Favourites tab (fixed to favourites). The player and the info pane live in MainActivity's header.
 */
class ChannelListFragment : Fragment(), TabContent {
    private var _b: FragmentChannelsBinding? = null
    private val b get() = _b!!
    private val favOnly get() = requireArguments().getBoolean("favs")
    private val host get() = requireActivity() as MainActivity

    private lateinit var adapter: ChannelAdapter
    private var scopeId = Repository.SCOPE_ALL
    private var loadJob: Job? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentChannelsBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = ChannelAdapter(
            onFocus = { host.browseChannel(it) },
            onClick = { host.onChannelClicked(it, scopeId) },
            onLong = { c, pos -> toggleFavorite(c, pos) }
        )
        b.channelList.layoutManager = LinearLayoutManager(requireContext())
        b.channelList.adapter = adapter
        b.channelList.itemAnimator = null
        load()
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun load() {
        loadJob?.cancel()
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val p = repo.activeProvider()
            if (p == null) {
                adapter.items = emptyList(); adapter.notifyDataSetChanged(); host.contentReady(); return@launch
            }
            scopeId = if (favOnly) Repository.SCOPE_FAV else host.groupScope
            val list = repo.channelsFor(p.id, scopeId)
            adapter.items = list
            adapter.now = emptyMap()
            adapter.playingUid = host.playing?.uid ?: repo.prefs.lastChannel
            adapter.notifyDataSetChanged()
            host.contentReady()
            val now = repo.nowMap(p.id, list)
            if (_b != null) { adapter.now = now; adapter.notifyItemRangeChanged(0, adapter.itemCount) }
        }
    }

    // ---- TabContent ---------------------------------------------------------------------------
    override fun focusContent(): Boolean {
        if (_b == null || adapter.itemCount == 0) return false
        val pos = adapter.items.indexOfFirst { it.uid == adapter.playingUid }.coerceAtLeast(0)
        val rv = b.channelList
        rv.scrollToPosition(pos)
        rv.doOnLayout { rv.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
        return true
    }

    override fun isAtLeftEdge() = true            // single column: every row is on the left edge

    override fun reload() {
        val hadFocus = _b?.root?.hasFocus() == true
        load()
        if (hadFocus) host.wantFocus()
    }

    override fun onGroupChanged() { if (!favOnly) load() }

    @SuppressLint("NotifyDataSetChanged")
    override fun onPlayingChanged() {
        if (_b == null) return
        adapter.playingUid = host.playing?.uid ?: ""
        adapter.notifyDataSetChanged()
    }

    private fun toggleFavorite(c: Channel, pos: Int) {
        viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val newVal = !c.isFavorite
            repo.dao.setFavorite(c.uid, newVal)
            val updated = c.copy(isFavorite = newVal)
            if (favOnly && !newVal) {
                adapter.items = adapter.items.filter { it.uid != c.uid }; adapter.notifyItemRemoved(pos)
                val target = pos.coerceAtMost(adapter.items.size - 1)
                val rv = b.channelList
                if (target >= 0) rv.post { rv.findViewHolderForAdapterPosition(target)?.itemView?.requestFocus() }
            } else {
                adapter.items = adapter.items.toMutableList().also { it[pos] = updated }; adapter.notifyItemChanged(pos)
                host.onFavoriteChanged(updated)
            }
            Toast.makeText(requireContext(), if (newVal) "Added to favourites" else "Removed from favourites", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() { super.onDestroyView(); loadJob?.cancel(); _b = null }

    companion object {
        fun newInstance(favs: Boolean) = ChannelListFragment().apply { arguments = Bundle().apply { putBoolean("favs", favs) } }
    }
}

class ChannelAdapter(
    private val onFocus: (Channel) -> Unit,
    private val onClick: (Channel) -> Unit,
    private val onLong: (Channel, Int) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    class VH(val b: ItemChannelBinding) : RecyclerView.ViewHolder(b.root)

    var items: List<Channel> = emptyList()
    var now: Map<String, Programme> = emptyMap()
    var playingUid: String = ""

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(ItemChannelBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val c = items[i]
        h.b.playMark.visibility = if (c.uid == playingUid) View.VISIBLE else View.INVISIBLE
        h.b.number.text = c.number.toString()
        h.b.name.text = c.name
        h.b.logo.loadUrl(c.logo)
        h.b.fav.visibility = if (c.isFavorite) View.VISIBLE else View.GONE
        val pr = now[c.epgId]
        h.b.now.text = pr?.title ?: ""
        val t = System.currentTimeMillis()
        h.b.progress.progress = pr?.let { ((t - it.start) * 100 / (it.stop - it.start).coerceAtLeast(1)).toInt() } ?: 0
        h.b.progress.visibility = if (pr != null) View.VISIBLE else View.INVISIBLE
        h.itemView.setOnFocusChangeListener { _, f -> if (f) onFocus(c) }
        h.itemView.setOnClickListener { onClick(c) }
        h.itemView.setOnLongClickListener { onLong(c, h.bindingAdapterPosition); true }
    }
}
