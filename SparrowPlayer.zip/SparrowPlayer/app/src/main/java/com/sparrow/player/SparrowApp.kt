package com.sparrow.player

import android.app.Application
import com.sparrow.player.data.Repository

class SparrowApp : Application() {
    lateinit var repo: Repository
        private set

    override fun onCreate() {
        super.onCreate()
        repo = Repository(this)
    }
}
