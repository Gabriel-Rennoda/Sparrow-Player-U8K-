package com.sparrow.player

import android.app.Application
import com.sparrow.player.data.Repository
import com.sparrow.player.util.TimeFmt

class SparrowApp : Application() {
    lateinit var repo: Repository
        private set

    override fun onCreate() {
        super.onCreate()
        repo = Repository(this)
        TimeFmt.is24h = repo.prefs.clock24
    }
}
