package com.sparrow.player.util

import android.content.Context
import android.widget.ImageView
import coil.load
import com.sparrow.player.R
import com.sparrow.player.SparrowApp
import com.sparrow.player.data.Repository

val Context.repo: Repository get() = (applicationContext as SparrowApp).repo

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Clock text honouring the 12 / 24 hour setting. */
fun fmtTime(ms: Long): String = TimeFmt.clock(ms)

fun ImageView.loadUrl(url: String?) {
    if (url.isNullOrBlank()) {
        setImageResource(R.drawable.logo_circle); alpha = 0.3f
    } else {
        alpha = 1f
        load(url) {
            crossfade(true)
            placeholder(R.drawable.logo_circle)
            error(R.drawable.logo_circle)
        }
    }
}

/**
 * Generic one-line list adapter used for seasons / episodes.
 * Focus changes only flip the "selected" flag on the views directly. (The old version called notifyItemChanged on every
 * focus change; RecyclerView's change animation swaps in a copy of the row, the focused view vanishes and focus jumps
 * to another list - that was the "momentarily breaks / back to the tab row" bug while browsing episodes.)
 */
class TextAdapter<T>(
    private val label: (T) -> String,
    private val onClick: (T) -> Unit,
    private val onFocus: ((T, Int) -> Unit)? = null,
    private val layoutRes: Int = R.layout.item_text
) : androidx.recyclerview.widget.RecyclerView.Adapter<TextAdapter.VH>() {
    class VH(v: android.view.View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(v)

    var items: List<T> = emptyList()
    var selected = 0
    private var rv: androidx.recyclerview.widget.RecyclerView? = null

    @android.annotation.SuppressLint("NotifyDataSetChanged")
    fun submit(l: List<T>, sel: Int = 0) { items = l; selected = sel; notifyDataSetChanged() }

    override fun onAttachedToRecyclerView(r: androidx.recyclerview.widget.RecyclerView) { rv = r; r.itemAnimator = null }
    override fun onDetachedFromRecyclerView(r: androidx.recyclerview.widget.RecyclerView) { rv = null }

    override fun onCreateViewHolder(p: android.view.ViewGroup, t: Int) =
        VH(android.view.LayoutInflater.from(p.context).inflate(layoutRes, p, false))

    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        (h.itemView as android.widget.TextView).text = label(item)
        h.itemView.isSelected = i == selected
        h.itemView.isClickable = true
        h.itemView.setOnClickListener { val p = h.bindingAdapterPosition; if (p >= 0) onClick(items[p]) }
        h.itemView.setOnFocusChangeListener { _, f ->
            val now = h.bindingAdapterPosition
            if (f && now >= 0) {
                val old = selected
                selected = now
                rv?.findViewHolderForAdapterPosition(old)?.itemView?.isSelected = false
                h.itemView.isSelected = true
                onFocus?.invoke(items[now], now)
            }
        }
    }
}
