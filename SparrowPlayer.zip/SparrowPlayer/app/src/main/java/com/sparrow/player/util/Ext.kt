package com.sparrow.player.util

import android.content.Context
import android.widget.ImageView
import coil.load
import com.sparrow.player.R
import com.sparrow.player.SparrowApp
import com.sparrow.player.data.Repository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Context.repo: Repository get() = (applicationContext as SparrowApp).repo

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
fun fmtTime(ms: Long): String = synchronized(timeFmt) { timeFmt.format(Date(ms)) }

fun ImageView.loadUrl(url: String?) {
    if (url.isNullOrBlank()) {
        setImageResource(R.drawable.logo_circle); alpha = 0.3f
    } else {
        alpha = 1f
        load(url) {
            crossfade(true)
            placeholder(R.drawable.logo_circle)
            error(R.drawable.logo_circle)
        }
    }
}

/** Generic one-line list adapter used for categories, seasons, episodes. */
class TextAdapter<T>(
    private val label: (T) -> String,
    private val onClick: (T) -> Unit,
    private val onFocus: ((T, Int) -> Unit)? = null,
    private val layoutRes: Int = R.layout.item_text
) : androidx.recyclerview.widget.RecyclerView.Adapter<TextAdapter.VH>() {
    class VH(v: android.view.View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(v)

    var items: List<T> = emptyList()
    var selected = 0
    @android.annotation.SuppressLint("NotifyDataSetChanged")
    fun submit(l: List<T>, sel: Int = 0) { items = l; selected = sel; notifyDataSetChanged() }

    override fun onCreateViewHolder(p: android.view.ViewGroup, t: Int) =
        VH(android.view.LayoutInflater.from(p.context).inflate(layoutRes, p, false))

    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        (h.itemView as android.widget.TextView).text = label(item)
        h.itemView.isSelected = i == selected
        h.itemView.setOnClickListener { onClick(item) }
        h.itemView.setOnFocusChangeListener { _, f ->
            if (f) {
                val old = selected; val now = h.bindingAdapterPosition
                selected = now
                h.itemView.post { notifyItemChanged(old); notifyItemChanged(now) }
                onFocus?.invoke(item, now)
            }
        }
    }
}
