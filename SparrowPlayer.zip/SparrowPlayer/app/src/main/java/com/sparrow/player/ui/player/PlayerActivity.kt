package com.sparrow.player.ui.player

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Repository
import com.sparrow.player.data.Resume
import com.sparrow.player.databinding.ActivityPlayerBinding
import com.sparrow.player.util.fmtTime
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * Full-screen player.
 *  Live:  Up/Down or CH+/CH- zap, 0-9 jump to channel number, OK = info, hold OK = favourite, Menu = audio/subtitle/video tracks.
 *  VOD:   standard Media3 transport controls, position is remembered and resumed.
 */
class PlayerActivity : FragmentActivity() {
    private lateinit var b: ActivityPlayerBinding
    private lateinit var repo: Repository
    private var player: ExoPlayer? = null
    private var live = false
    private var channels: List<Channel> = emptyList()
    private var index = 0
    private var posKey: String? = null
    private var retries = 0
    private var stopped = false
    private var finished = false
    private var numBuf = ""
    private val handler = Handler(Looper.getMainLooper())

    private val hideInfo = Runnable { b.infoBar.visibility = View.GONE }
    private val commitNumber = Runnable {
        val n = numBuf.toIntOrNull(); numBuf = ""; b.numberText.visibility = View.GONE
        val i = channels.indexOfFirst { it.number == n }
        if (i >= 0) playIndex(i) else Toast.makeText(this, "No channel $n", Toast.LENGTH_SHORT).show()
    }
    private val savePos = object : Runnable {
        override fun run() { savePosition(); handler.postDelayed(this, 5_000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = applicationContext.repo
        live = intent.getBooleanExtra("live", false)

        val p = PlayerFactory.create(this)
        player = p
        b.playerView.player = p
        b.playerView.useController = !live
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (retries++ < 5) {
                    showError("Stream error – retrying ($retries/5)…")
                    handler.postDelayed({ if (live) playIndex(index) else player?.prepare() }, 2000)
                } else showError("Channel unavailable (${error.errorCodeName})")
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { retries = 0; b.errorText.visibility = View.GONE }
                if (state == Player.STATE_ENDED && !live) { finished = true; posKey?.let { repo.prefs.setPosition(it, Resume.FINISHED) } }
            }
        })

        if (live) {
            lifecycleScope.launch {
                val prov = repo.activeProvider() ?: return@launch finish()
                val uid = intent.getStringExtra("uid")
                channels = repo.channelsFor(prov.id, intent.getStringExtra("scope") ?: Repository.SCOPE_ALL)
                // The channel may not be in the group that was open (e.g. it was tuned in another group): fall back to all.
                if (channels.none { it.uid == uid }) channels = repo.channelsFor(prov.id, Repository.SCOPE_ALL)
                index = channels.indexOfFirst { it.uid == uid }.coerceAtLeast(0)
                if (channels.isEmpty()) finish() else playIndex(index)
            }
        } else {
            posKey = intent.getStringExtra("key")
            // Resume 30 seconds before where the user stopped last time.
            val start = Resume.resumeAt(posKey?.let { repo.prefs.position(it) } ?: 0L)
            val item = MediaItem.Builder().setUri(intent.getStringExtra("url")!!)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(intent.getStringExtra("title")).build()).build()
            p.setMediaItem(item, if (start > 0) start else C.TIME_UNSET)
            p.prepare(); p.playWhenReady = true
            handler.postDelayed(savePos, 5_000)
        }
    }

    // ---- Live ------------------------------------------------------------------------------
    private fun playIndex(i: Int) {
        if (channels.isEmpty()) return
        index = (i + channels.size) % channels.size
        val c = channels[index]
        repo.prefs.lastChannel = c.uid
        val p = player ?: return
        p.setMediaItem(MediaItem.fromUri(repo.liveUrl(c)))
        p.prepare(); p.playWhenReady = true
        showInfo()
    }

    private fun zap(delta: Int) { retries = 0; b.errorText.visibility = View.GONE; playIndex(index + delta) }

    private fun showInfo() {
        if (!live || channels.isEmpty()) return
        val c = channels[index]
        b.infoChannel.text = (if (c.isFavorite) "★ " else "") + (if (repo.prefs.showNumbers) "${c.number}  " else "") + c.name
        b.infoNow.text = ""; b.infoNext.text = ""; b.infoProgress.progress = 0
        b.infoBar.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo); handler.postDelayed(hideInfo, 4500)
        if (c.epgId.isBlank()) return
        lifecycleScope.launch {
            val now = System.currentTimeMillis()
            val l = repo.dao.nowNext(c.providerId, c.epgId, now)
            val cur = l.firstOrNull()?.takeIf { it.start <= now }
            val next = if (cur != null) l.getOrNull(1) else l.firstOrNull()
            if (channels.getOrNull(index)?.uid != c.uid) return@launch
            b.infoNow.text = cur?.let { "${fmtTime(it.start)}–${fmtTime(it.stop)}  ${it.title}" } ?: ""
            b.infoProgress.progress = cur?.let { ((now - it.start) * 100 / (it.stop - it.start).coerceAtLeast(1)).toInt() } ?: 0
            b.infoNext.text = next?.let { "Next ${fmtTime(it.start)}  ${it.title}" } ?: ""
        }
    }

    private fun toggleFavorite() {
        val c = channels.getOrNull(index) ?: return
        lifecycleScope.launch {
            val nv = !c.isFavorite
            repo.dao.setFavorite(c.uid, nv)
            channels = channels.toMutableList().also { it[index] = c.copy(isFavorite = nv) }
            Toast.makeText(this@PlayerActivity, if (nv) "Added to favourites" else "Removed from favourites", Toast.LENGTH_SHORT).show()
            showInfo()
        }
    }

    private fun digit(d: Int) {
        if (numBuf.length >= 5) numBuf = ""
        numBuf += d
        b.numberText.text = numBuf; b.numberText.visibility = View.VISIBLE
        handler.removeCallbacks(commitNumber); handler.postDelayed(commitNumber, 1800)
    }

    private fun showError(msg: String) { b.errorText.text = msg; b.errorText.visibility = View.VISIBLE }

    // ---- Keys ------------------------------------------------------------------------------
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (!live && b.playerView.dispatchKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (live) when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(+1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> { event.startTracking(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_INFO -> { showInfo(); return true }
            KeyEvent.KEYCODE_MENU -> { showTrackMenu(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { player?.let { it.playWhenReady = !it.playWhenReady }; return true }
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> { digit(keyCode - KeyEvent.KEYCODE_0); return true }
        } else if (keyCode == KeyEvent.KEYCODE_MENU) { showTrackMenu(); return true }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (live && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) &&
            event.isTracking && !event.isCanceled) { showInfo(); return true }
        return super.onKeyUp(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (live && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) { toggleFavorite(); return true }
        return super.onKeyLongPress(keyCode, event)
    }

    // ---- Tracks (own dialog: Media3's TrackSelectionDialogBuilder needs an AppCompat theme) --
    private fun showTrackMenu() {
        val items = arrayOf("Audio", "Subtitles", "Video quality")
        AlertDialog.Builder(this).setItems(items) { _, w ->
            when (w) {
                0 -> chooseTrack(C.TRACK_TYPE_AUDIO, "Audio")
                1 -> chooseTrack(C.TRACK_TYPE_TEXT, "Subtitles")
                else -> chooseTrack(C.TRACK_TYPE_VIDEO, "Video")
            }
        }.show()
    }

    private fun describe(f: Format, type: Int): String {
        val parts = ArrayList<String>()
        f.label?.let { parts += it }
        f.language?.takeIf { it != "und" }?.let { parts += it.uppercase() }
        when (type) {
            C.TRACK_TYPE_AUDIO -> {
                if (f.channelCount > 0) parts += "${f.channelCount}ch"
                f.sampleMimeType?.substringAfter('/')?.let { parts += it }
            }
            C.TRACK_TYPE_VIDEO -> if (f.height > 0) parts += "${f.height}p"
        }
        return parts.joinToString(" · ").ifBlank { "Track" }
    }

    private fun chooseTrack(type: Int, title: String) {
        val p = player ?: return
        val entries = ArrayList<Pair<Tracks.Group, Int>>()
        val labels = ArrayList<String>()
        if (type == C.TRACK_TYPE_TEXT) labels += "Off"
        if (type == C.TRACK_TYPE_VIDEO) labels += "Auto"
        p.currentTracks.groups.filter { it.type == type }.forEach { g ->
            for (i in 0 until g.length) if (g.isTrackSupported(i)) { entries += g to i; labels += describe(g.getTrackFormat(i), type) }
        }
        if (entries.isEmpty()) { Toast.makeText(this, "No $title tracks", Toast.LENGTH_SHORT).show(); return }
        val hasHead = type == C.TRACK_TYPE_TEXT || type == C.TRACK_TYPE_VIDEO
        AlertDialog.Builder(this).setTitle(title).setItems(labels.toTypedArray()) { _, which ->
            val params = p.trackSelectionParameters.buildUpon()
            if (hasHead && which == 0) {
                if (type == C.TRACK_TYPE_TEXT) params.setTrackTypeDisabled(type, true) else params.clearOverridesOfType(type)
            } else {
                val (g, i) = entries[if (hasHead) which - 1 else which]
                params.setTrackTypeDisabled(type, false).setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            }
            p.trackSelectionParameters = params.build()
        }.show()
    }

    // ---- Lifecycle -------------------------------------------------------------------------
    private fun savePosition() {
        val p = player ?: return; val k = posKey ?: return
        if (live || finished || p.duration <= 0 || p.playbackState == Player.STATE_IDLE) return
        repo.prefs.setDuration(k, p.duration)
        repo.prefs.setPosition(k, Resume.toStore(p.currentPosition, p.duration))
    }

    override fun onStop() {
        super.onStop()
        stopped = true
        savePosition()
        player?.pause()
    }

    override fun onStart() {
        super.onStart()
        if (stopped) {
            stopped = false
            if (live) playIndex(index) else player?.play()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        savePosition()
        b.playerView.player = null
        player?.release(); player = null
        super.onDestroy()
    }

    companion object {
        fun live(ctx: Context, uid: String, scope: String) = Intent(ctx, PlayerActivity::class.java)
            .putExtra("live", true).putExtra("uid", uid).putExtra("scope", scope)

        fun vod(ctx: Context, url: String, title: String, key: String) = Intent(ctx, PlayerActivity::class.java)
            .putExtra("live", false).putExtra("url", url).putExtra("title", title).putExtra("key", key)
    }
}
