package com.sparrow.player.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sparrow.player.R

/**
 * Channel groups list. Unlike a "selected follows focus" list, the highlighted (active) group only changes when the
 * user presses OK, so browsing the list and pressing Back leaves the guide exactly as it was.
 */
class GroupAdapter(private val onPick: (Pair<String, String>) -> Unit) : RecyclerView.Adapter<GroupAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v)

    private var items: List<Pair<String, String>> = emptyList()
    private var activeId: String = ""

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<Pair<String, String>>, active: String) { items = list; activeId = active; notifyDataSetChanged() }

    @SuppressLint("NotifyDataSetChanged")
    fun setActive(id: String) { activeId = id; notifyDataSetChanged() }

    fun positionOf(id: String) = items.indexOfFirst { it.first == id }

    override fun getItemCount() = items.size
    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_text, p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        (h.itemView as TextView).text = item.second
        h.itemView.isSelected = item.first == activeId
        h.itemView.setOnClickListener { onPick(item) }
    }
}
