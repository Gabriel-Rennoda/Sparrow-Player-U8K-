package com.sparrow.player.data

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.InputStream
import java.net.URLEncoder

data class Episode(
    val id: String, val season: Int, val num: Int, val title: String,
    val ext: String, val image: String, val plot: String, val duration: String
)

object Urls {
    fun base(p: Provider): String {
        val s = p.server.trim().trimEnd('/')
        return if (s.startsWith("http://") || s.startsWith("https://")) s else "http://$s"
    }
    fun live(p: Provider, id: String, fmt: String) = "${base(p)}/live/${p.username}/${p.password}/$id.$fmt"
    fun movie(p: Provider, id: String, ext: String) = "${base(p)}/movie/${p.username}/${p.password}/$id.$ext"
    fun episode(p: Provider, id: String, ext: String) = "${base(p)}/series/${p.username}/${p.password}/$id.$ext"
    fun xmltv(p: Provider) = "${base(p)}/xmltv.php?username=${enc(p.username)}&password=${enc(p.password)}"
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

/** Minimal Xtream Codes (player_api.php) client. */
class XtreamClient(private val http: OkHttpClient, private val p: Provider) {

    private fun api(action: String? = null, extra: String = ""): String {
        val sb = StringBuilder("${Urls.base(p)}/player_api.php?username=${Urls.enc(p.username)}&password=${Urls.enc(p.password)}")
        if (action != null) sb.append("&action=").append(action)
        return sb.append(extra).toString()
    }

    private fun <T> get(url: String, block: (InputStream) -> T): T {
        http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            return block(r.body!!.byteStream())
        }
    }

    fun authenticate(): Boolean {
        val o = get(api()) { Json.readObject(it) }
        val ui = o["user_info"] as? Map<*, *> ?: return false
        return ui["auth"]?.toString() == "1"
    }

    fun list(action: String, cb: (Map<String, Any?>) -> Unit) = get(api(action)) { Json.streamArray(it, cb) }

    @Suppress("UNCHECKED_CAST")
    fun vodInfo(id: String): Map<String, Any?> =
        (get(api("get_vod_info", "&vod_id=$id")) { Json.readObject(it) }["info"] as? Map<String, Any?>) ?: emptyMap()

    @Suppress("UNCHECKED_CAST")
    fun seriesEpisodes(id: String): List<Episode> {
        val o = get(api("get_series_info", "&series_id=$id")) { Json.readObject(it) }
        val out = ArrayList<Episode>()
        fun addSeason(s: Int, l: Any?) {
            (l as? List<*>)?.forEach { e ->
                val m = e as? Map<String, Any?> ?: return@forEach
                val info = m["info"] as? Map<String, Any?> ?: emptyMap()
                out += Episode(
                    m.str("id"), m.str("season").toIntOrNull() ?: s, m.str("episode_num").toIntOrNull() ?: 0,
                    m.str("title"), m.str("container_extension").ifBlank { "mp4" },
                    info.str("movie_image"), info.str("plot"), info.str("duration")
                )
            }
        }
        when (val e = o["episodes"]) {
            is Map<*, *> -> e.forEach { (k, v) -> addSeason(k.toString().toIntOrNull() ?: 1, v) }
            is List<*> -> e.forEachIndexed { i, v -> addSeason(i + 1, v) }
        }
        return out.sortedWith(compareBy({ it.season }, { it.num }))
    }
}
