package com.sparrow.player.data

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.InputStream
import java.util.zip.GZIPInputStream

object XmltvParser {

    /** Transparently handles .xml and .xml.gz */
    fun maybeGunzip(i: InputStream): InputStream {
        val b = BufferedInputStream(i, 64 * 1024)
        b.mark(2)
        val a = b.read(); val c = b.read()
        b.reset()
        return if (a == 0x1f && c == 0x8b) GZIPInputStream(b, 64 * 1024) else b
    }

    /** Streams <programme> entries whose channel is in [ids] and that overlap [from, to]. */
    fun parse(input: InputStream, ids: Set<String>, from: Long, to: Long, sink: (Programme) -> Unit) {
        val xp = Xml.newPullParser()
        xp.setInput(input, null)
        var ev = xp.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && xp.name == "programme") {
                val ch = xp.getAttributeValue(null, "channel") ?: ""
                val start = parseTime(xp.getAttributeValue(null, "start") ?: "")
                val stop = parseTime(xp.getAttributeValue(null, "stop") ?: "")
                var title = ""; var desc = ""
                var depth = 1
                while (depth > 0) {
                    ev = xp.next()
                    when (ev) {
                        XmlPullParser.START_TAG -> when (xp.name) {
                            "title" -> { val t = xp.nextText(); if (title.isEmpty()) title = t }
                            "desc" -> { val t = xp.nextText(); if (desc.isEmpty()) desc = t }
                            else -> depth++
                        }
                        XmlPullParser.END_TAG -> depth--
                        XmlPullParser.END_DOCUMENT -> depth = 0
                    }
                }
                if (ch in ids && stop > start && stop > from && start < to)
                    sink(Programme(providerId = 0, epgId = ch, start = start, stop = stop,
                        title = title.trim(), descr = desc.trim().take(400)))
            }
            ev = xp.next()
        }
    }

    /** "20240131183000 +0100" -> epoch millis (no SimpleDateFormat: it is far too slow for 500k entries). */
    fun parseTime(s: String): Long {
        if (s.length < 14) return 0
        return try {
            val y = s.substring(0, 4).toInt(); val mo = s.substring(4, 6).toInt(); val d = s.substring(6, 8).toInt()
            val h = s.substring(8, 10).toInt(); val mi = s.substring(10, 12).toInt(); val se = s.substring(12, 14).toInt()
            var off = 0L
            val rest = s.substring(14).trim()
            if (rest.length >= 5 && (rest[0] == '+' || rest[0] == '-')) {
                val sign = if (rest[0] == '-') -1 else 1
                off = sign * (rest.substring(1, 3).toLong() * 3600 + rest.substring(3, 5).toLong() * 60)
            }
            (daysFromCivil(y, mo, d) * 86400L + h * 3600L + mi * 60L + se - off) * 1000L
        } catch (e: Exception) { 0 }
    }

    private fun daysFromCivil(y0: Int, m: Int, d: Int): Long {
        val y = if (m <= 2) y0 - 1 else y0
        val era = (if (y >= 0) y else y - 399) / 400
        val yoe = y - era * 400
        val doy = (153 * (m + (if (m > 2) -3 else 9)) + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097L + doe - 719468L
    }
}
