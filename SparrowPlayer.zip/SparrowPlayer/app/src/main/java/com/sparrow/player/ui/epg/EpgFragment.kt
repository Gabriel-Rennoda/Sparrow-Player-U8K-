package com.sparrow.player.ui.epg

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.R
import com.sparrow.player.data.Programme
import com.sparrow.player.data.Repository
import com.sparrow.player.databinding.FragmentEpgBinding
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.TabContent
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Programme guide grid (channels x time). The channel group comes from the groups panel; the player and the info
 * pane (which follows the highlighted programme) live in MainActivity's header.
 */
class EpgFragment : Fragment(R.layout.fragment_epg), TabContent {
    private var _b: FragmentEpgBinding? = null
    private val b get() = _b!!
    private val host get() = requireActivity() as MainActivity
    private var scope = Repository.SCOPE_ALL
    private var loadJob: Job? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _b = FragmentEpgBinding.bind(view)
        b.epgView.onSelect = { row, p ->
            val i = if (p == null) -1 else row.programmes.indexOf(p)
            host.browseProgramme(row.channel, p, row.programmes.getOrNull(i + 1))
        }
        b.epgView.onPlay = { c -> host.onChannelClicked(c, scope) }
        b.epgView.playingUid = host.playing?.uid ?: ""
        load()
    }

    private fun load() {
        loadJob?.cancel()
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val p = repo.activeProvider()
            if (p == null) { b.epgView.setData(emptyList(), 0, 0); host.contentReady(); return@launch }
            scope = host.groupScope
            val channels = repo.channelsFor(p.id, scope).take(300)
            val now = System.currentTimeMillis()
            val ws = (now - 2 * 3600_000L) / 1_800_000L * 1_800_000L
            val we = ws + 30 * 3600_000L
            val ids = channels.map { it.epgId }.filter { it.isNotBlank() }.distinct()
            val byId = HashMap<String, MutableList<Programme>>()
            ids.chunked(400).forEach { chunk ->
                repo.dao.programmes(p.id, chunk, ws, we).forEach { byId.getOrPut(it.epgId) { ArrayList() }.add(it) }
            }
            if (_b == null) return@launch
            b.epgView.setData(
                channels.map { EpgView.Row(it, byId[it.epgId] ?: emptyList()) }, ws, we,
                selectUid = host.playing?.uid ?: repo.prefs.lastChannel
            )
            host.contentReady()
        }
    }

    // ---- TabContent ---------------------------------------------------------------------------
    override fun focusContent(): Boolean = _b != null && b.epgView.requestFocus()

    override fun isAtLeftEdge(): Boolean = _b == null || b.epgView.atLeftEdge()

    override fun reload() {
        val hadFocus = _b?.epgView?.isFocused == true
        load()
        if (hadFocus) host.wantFocus()
    }

    override fun onGroupChanged() = load()

    override fun onPlayingChanged() { if (_b != null) b.epgView.playingUid = host.playing?.uid ?: "" }

    override fun onDestroyView() { super.onDestroyView(); loadJob?.cancel(); _b = null }
}
