package com.sparrow.player.ui.epg

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.R
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Programme
import com.sparrow.player.data.Repository
import com.sparrow.player.databinding.FragmentEpgBinding
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.util.fmtTime
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/** Programme guide grid. Pick a category (or favorites) on top, navigate the grid with the D-pad. */
class EpgFragment : Fragment(R.layout.fragment_epg) {
    private var _b: FragmentEpgBinding? = null
    private val b get() = _b!!
    private var providerId = -1L
    private var scope = Repository.SCOPE_ALL
    private var scopes: List<Pair<String, String>> = emptyList()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _b = FragmentEpgBinding.bind(view)
        b.catButton.setOnClickListener { pickCategory() }
        b.epgView.onSelect = { row, p -> describe(row.channel, p) }
        b.epgView.onPlay = { c -> startActivity(PlayerActivity.live(requireContext(), c.uid, scope)) }
        viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val p = repo.activeProvider() ?: run { b.epgTitle.text = "No provider configured"; return@launch }
            providerId = p.id
            val cats = repo.dao.categories(p.id, "live")
            scopes = listOf(Repository.SCOPE_FAV to "★  Favorites", Repository.SCOPE_ALL to "All channels (first 300)") +
                cats.map { it.remoteId to it.name }
            val hasFav = repo.dao.favorites(p.id).isNotEmpty()
            val start = if (hasFav) Repository.SCOPE_FAV else cats.firstOrNull()?.remoteId ?: Repository.SCOPE_ALL
            show(start)
        }
    }

    private fun pickCategory() {
        AlertDialog.Builder(requireContext()).setTitle("Guide category")
            .setItems(scopes.map { it.second }.toTypedArray()) { _, i -> show(scopes[i].first) }.show()
    }

    private fun show(id: String) {
        scope = id
        b.catButton.text = (scopes.firstOrNull { it.first == id }?.second ?: "Channels") + "  ▾"
        viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val channels = repo.channelsFor(providerId, id).take(300)
            val now = System.currentTimeMillis()
            val ws = (now - 2 * 3600_000L) / 1_800_000L * 1_800_000L
            val we = ws + 30 * 3600_000L
            val ids = channels.map { it.epgId }.filter { it.isNotBlank() }.distinct()
            val byId = HashMap<String, MutableList<Programme>>()
            ids.chunked(400).forEach { chunk ->
                repo.dao.programmes(providerId, chunk, ws, we).forEach { byId.getOrPut(it.epgId) { ArrayList() }.add(it) }
            }
            if (_b == null) return@launch
            b.epgView.setData(channels.map { EpgView.Row(it, byId[it.epgId] ?: emptyList()) }, ws, we)
            if (channels.isEmpty()) { b.epgTitle.text = "No channels here"; b.epgDesc.text = "" }
        }
    }

    private fun describe(c: Channel, p: Programme?) {
        if (p == null) { b.epgTitle.text = c.name; b.epgDesc.text = "No programme information"; return }
        b.epgTitle.text = "${c.name}  •  ${p.title}   ${fmtTime(p.start)}–${fmtTime(p.stop)}"
        b.epgDesc.text = p.descr
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
