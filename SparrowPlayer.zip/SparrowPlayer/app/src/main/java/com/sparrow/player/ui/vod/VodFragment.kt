package com.sparrow.player.ui.vod

import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewTreeObserver
import androidx.core.content.ContextCompat
import androidx.core.view.doOnLayout
import androidx.leanback.app.BackgroundManager
import androidx.leanback.app.RowsSupportFragment
import androidx.leanback.widget.ArrayObjectAdapter
import androidx.leanback.widget.FocusHighlight
import androidx.leanback.widget.HeaderItem
import androidx.leanback.widget.ListRow
import androidx.leanback.widget.ListRowPresenter
import androidx.leanback.widget.OnItemViewClickedListener
import androidx.leanback.widget.OnItemViewSelectedListener
import androidx.lifecycle.lifecycleScope
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.sparrow.player.R
import com.sparrow.player.data.VodItem
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.TabContent
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Netflix / Disney+ style rows of posters with a changing backdrop and hero text.
 *
 * Uses RowsSupportFragment (rows only) instead of BrowseSupportFragment: no headers pane, title view or
 * back-transition machinery that could steal focus / Back from the tab navigation in MainActivity.
 */
class VodFragment : RowsSupportFragment(), TabContent {
    private val type get() = requireArguments().getString("type")!!
    private var bg: BackgroundManager? = null
    private var bgJob: Job? = null
    private var loadJob: Job? = null
    private var lastItem: VodItem? = null
    private var rowsFocused = false           // is the selector on the posters (not in a side panel)?
    private var imageArmed = BACKDROP_ON_ENTRY // false: the auto-selected first poster keeps the solid theme colour
    private var firstSeen = false
    private val focusListener = ViewTreeObserver.OnGlobalFocusChangeListener { _, _ ->
        val inRows = view?.hasFocus() == true
        if (inRows != rowsFocused) {
            rowsFocused = inRows
            val v = lastItem
            if (inRows && imageArmed && v != null) applyBackdrop(v) else if (!inRows) clearBackdrop()
        }
    }
    private var selIndex = 0          // position of the selected poster inside its row (0 = left-most)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setOnItemViewClickedListener(OnItemViewClickedListener { _, item, _, _ ->
            if (item is VodItem) startActivity(DetailsActivity.intent(requireContext(), item.uid))
        })
        setOnItemViewSelectedListener(OnItemViewSelectedListener { _, item, _, row ->
            if (item is VodItem) {
                selIndex = ((row as? ListRow)?.adapter as? ArrayObjectAdapter)?.indexOf(item) ?: 0
                onSelected(item)
            }
        })
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bg = BackgroundManager.getInstance(requireActivity()).also {
            if (!it.isAttached) it.attach(requireActivity().window)
            it.color = ContextCompat.getColor(requireContext(), R.color.bg)
        }
        view.viewTreeObserver.addOnGlobalFocusChangeListener(focusListener)
        loadRows()
    }

    private fun loadRows() {
        loadJob?.cancel()
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val p = repo.activeProvider()
            if (p == null) { (activity as? MainActivity)?.contentReady(); return@launch }
            val rowsPresenter = ListRowPresenter(FocusHighlight.ZOOM_FACTOR_MEDIUM).apply { shadowEnabled = false }
            val rows = ArrayObjectAdapter(rowsPresenter)
            var id = 0L
            val recent = repo.dao.vodRecent(p.id, type, 30)
            if (recent.isNotEmpty()) {
                rows.add(ListRow(HeaderItem(id++, "Recently added"), ArrayObjectAdapter(CardPresenter()).apply { addAll(0, recent) }))
            }
            val catType = if (type == "movie") "vod" else "series"
            for (cat in repo.dao.categories(p.id, catType)) {
                val items = repo.dao.vodIn(p.id, type, cat.remoteId, 40)
                if (items.isEmpty()) continue
                rows.add(ListRow(HeaderItem(id++, cat.name), ArrayObjectAdapter(CardPresenter()).apply { addAll(0, items) }))
            }
            val hadFocus = view?.hasFocus() == true
            val keepRow = selectedPosition
            setAdapter(rows)
            if (hadFocus && keepRow in 0 until rows.size()) setSelectedPosition(keepRow)
            (activity as? MainActivity)?.contentReady()
        }
    }

    // ---- TabContent ---------------------------------------------------------------------------
    override fun focusContent(): Boolean {
        val grid = verticalGridView ?: return false
        if (adapter == null || adapter.size() == 0) return false
        grid.doOnLayout { it.requestFocus() }
        return true
    }

    override fun isAtLeftEdge() = selIndex <= 0

    override fun reload() {
        val hadFocus = view?.hasFocus() == true
        loadRows()
        if (hadFocus) (activity as? MainActivity)?.wantFocus()
    }

    private fun onSelected(v: VodItem) {
        val meta = listOf(v.year, CardPresenter.ratingText(v), v.genre).filter { it.isNotBlank() }.joinToString("   •   ")
        (activity as? MainActivity)?.showHero(v.name, meta, v.plot)
        // The very first (automatic) selection keeps the solid colour; once the user moves to a title, its image shows.
        if (firstSeen && lastItem?.uid != v.uid) imageArmed = true
        firstSeen = true
        lastItem = v
        if (rowsFocused && imageArmed) applyBackdrop(v) else if (!imageArmed) clearBackdrop()
    }

    private fun clearBackdrop() {
        bgJob?.cancel()
        bg?.clearDrawable()
        bg?.color = ContextCompat.getColor(requireContext(), R.color.bg)
    }

    private fun applyBackdrop(v: VodItem) {
        bgJob?.cancel()
        bgJob = viewLifecycleOwner.lifecycleScope.launch {
            delay(250)
            val url = v.backdrop.ifBlank { v.poster }
            if (url.isBlank()) return@launch
            val ctx = requireContext()
            val res = ctx.imageLoader.execute(ImageRequest.Builder(ctx).data(url).build())
            if (res is SuccessResult && rowsFocused) {
                val scrim = ContextCompat.getDrawable(ctx, R.drawable.scrim)!!
                bg?.setDrawable(LayerDrawable(arrayOf(res.drawable, scrim)))
            }
        }
    }

    override fun onDestroyView() {
        view?.viewTreeObserver?.removeOnGlobalFocusChangeListener(focusListener)
        bgJob?.cancel(); loadJob?.cancel()
        bg?.release()
        super.onDestroyView()
    }

    companion object {
        /** true = show the first poster's backdrop as soon as the tab opens; false = solid colour until the user moves. */
        const val BACKDROP_ON_ENTRY = false

        fun newInstance(type: String) = VodFragment().apply { arguments = Bundle().apply { putString("type", type) } }
    }
}
