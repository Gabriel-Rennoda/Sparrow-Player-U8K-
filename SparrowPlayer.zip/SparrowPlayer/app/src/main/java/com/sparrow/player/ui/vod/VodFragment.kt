package com.sparrow.player.ui.vod

import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.leanback.app.BackgroundManager
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.*
import androidx.lifecycle.lifecycleScope
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.sparrow.player.R
import com.sparrow.player.data.VodItem
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Netflix / Disney+ style browse: Leanback rows of posters, changing backdrop and hero text on selection. */
class VodFragment : BrowseSupportFragment() {
    private val type get() = requireArguments().getString("type")!!
    private var bg: BackgroundManager? = null
    private var bgJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        headersState = HEADERS_DISABLED
        isHeadersTransitionOnBackEnabled = false
        onItemViewClickedListener = OnItemViewClickedListener { _, item, _, _ ->
            if (item is VodItem) startActivity(DetailsActivity.intent(requireContext(), item.uid))
        }
        onItemViewSelectedListener = OnItemViewSelectedListener { _, item, _, _ ->
            if (item is VodItem) onSelected(item)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        showTitle(false)
        bg = BackgroundManager.getInstance(requireActivity()).also {
            if (!it.isAttached) it.attach(requireActivity().window)
            it.color = ContextCompat.getColor(requireContext(), R.color.bg)
        }
        loadRows()
    }

    private fun loadRows() = viewLifecycleOwner.lifecycleScope.launch {
        val repo = requireContext().repo
        val p = repo.activeProvider() ?: return@launch
        val rowsPresenter = ListRowPresenter(FocusHighlight.ZOOM_FACTOR_MEDIUM).apply { shadowEnabled = false }
        val rows = ArrayObjectAdapter(rowsPresenter)
        var id = 0L
        val recent = repo.dao.vodRecent(p.id, type, 30)
        if (recent.isNotEmpty()) {
            rows.add(ListRow(HeaderItem(id++, "Recently added"), ArrayObjectAdapter(CardPresenter()).apply { addAll(0, recent) }))
        }
        val catType = if (type == "movie") "vod" else "series"
        for (cat in repo.dao.categories(p.id, catType)) {
            val items = repo.dao.vodIn(p.id, type, cat.remoteId, 40)
            if (items.isEmpty()) continue
            rows.add(ListRow(HeaderItem(id++, cat.name), ArrayObjectAdapter(CardPresenter()).apply { addAll(0, items) }))
        }
        adapter = rows
    }

    private fun onSelected(v: VodItem) {
        val meta = listOf(v.year, CardPresenter.ratingText(v), v.genre).filter { it.isNotBlank() }.joinToString("   •   ")
        (activity as? MainActivity)?.showHero(v.name, meta, v.plot)
        bgJob?.cancel()
        bgJob = viewLifecycleOwner.lifecycleScope.launch {
            delay(250)
            val url = v.backdrop.ifBlank { v.poster }
            if (url.isBlank()) return@launch
            val ctx = requireContext()
            val res = ctx.imageLoader.execute(ImageRequest.Builder(ctx).data(url).build())
            if (res is SuccessResult) {
                val scrim = ContextCompat.getDrawable(ctx, R.drawable.scrim)!!
                bg?.setDrawable(LayerDrawable(arrayOf(res.drawable, scrim)))
            }
        }
    }

    override fun onDestroyView() {
        bgJob?.cancel()
        bg?.release()
        super.onDestroyView()
    }

    companion object {
        fun newInstance(type: String) = VodFragment().apply { arguments = Bundle().apply { putString("type", type) } }
    }
}
