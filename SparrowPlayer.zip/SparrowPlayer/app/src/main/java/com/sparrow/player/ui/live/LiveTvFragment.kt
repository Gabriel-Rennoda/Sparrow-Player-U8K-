package com.sparrow.player.ui.live

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Programme
import com.sparrow.player.data.Repository
import com.sparrow.player.databinding.FragmentLiveBinding
import com.sparrow.player.databinding.ItemChannelBinding
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.ui.player.PlayerFactory
import com.sparrow.player.util.TextAdapter
import com.sparrow.player.util.fmtTime
import com.sparrow.player.util.loadUrl
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** TiviMate-style live TV: categories | channels (with now-playing) | preview + EPG info. Also used for Favorites. */
class LiveTvFragment : Fragment() {
    private var _b: FragmentLiveBinding? = null
    private val b get() = _b!!
    private val favOnly get() = requireArguments().getBoolean("favs")

    private lateinit var catAdapter: TextAdapter<Pair<String, String>>
    private lateinit var chAdapter: ChannelAdapter
    private var providerId = -1L
    private var scopeId = Repository.SCOPE_ALL
    private var player: ExoPlayer? = null
    private var previewRunnable: Runnable? = null
    private var infoJob: Job? = null
    private var catJob: Job? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentLiveBinding.inflate(i, c, false); return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        catAdapter = TextAdapter({ it.second }, { selectCategory(it.first) }, { c, _ ->
            catJob?.cancel(); catJob = viewLifecycleOwner.lifecycleScope.launch { delay(150); selectCategory(c.first) }
        })
        chAdapter = ChannelAdapter(
            onFocus = { showInfo(it) },
            onClick = { play(it) },
            onLong = { c, pos -> toggleFavorite(c, pos) }
        )
        b.categoryList.layoutManager = LinearLayoutManager(requireContext())
        b.categoryList.adapter = catAdapter
        b.channelList.layoutManager = LinearLayoutManager(requireContext())
        b.channelList.adapter = chAdapter
        b.channelList.itemAnimator = null
        load()
    }

    private fun load() = viewLifecycleOwner.lifecycleScope.launch {
        val repo = requireContext().repo
        val p = repo.activeProvider() ?: run {
            b.chName.text = "No provider yet"; b.nowTitle.text = "Open Settings → Add playlist / provider"; return@launch
        }
        providerId = p.id
        if (favOnly) {
            b.categoryList.visibility = View.GONE
            scopeId = Repository.SCOPE_FAV
            showChannels(repo.dao.favorites(p.id))
            if (chAdapter.items.isEmpty()) { b.chName.text = "No favorites yet"; b.nowTitle.text = "Hold OK on a channel in Live TV to add it" }
        } else {
            val cats = repo.dao.categories(p.id, "live")
            val list = listOf(Repository.SCOPE_ALL to "All channels", Repository.SCOPE_FAV to "★  Favorites") +
                cats.map { it.remoteId to it.name }
            catAdapter.submit(list, 0)
            selectCategory(Repository.SCOPE_ALL)
        }
    }

    private fun selectCategory(id: String) {
        if (id == scopeId && chAdapter.items.isNotEmpty()) return
        scopeId = id
        viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            showChannels(repo.channelsFor(providerId, id))
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    private suspend fun showChannels(list: List<Channel>) {
        val repo = requireContext().repo
        chAdapter.items = list; chAdapter.now = emptyMap(); chAdapter.notifyDataSetChanged()
        val last = repo.prefs.lastChannel
        val idx = list.indexOfFirst { it.uid == last }
        if (idx > 0 && favOnly.not()) b.channelList.scrollToPosition(idx)
        val now = repo.nowMap(providerId, list)
        if (_b != null) { chAdapter.now = now; chAdapter.notifyDataSetChanged() }
    }

    private fun showInfo(c: Channel) {
        b.chName.text = "${c.number}  ${c.name}"
        infoJob?.cancel()
        infoJob = viewLifecycleOwner.lifecycleScope.launch {
            val now = System.currentTimeMillis()
            val l: List<Programme> = if (c.epgId.isBlank()) emptyList() else requireContext().repo.dao.nowNext(providerId, c.epgId, now)
            val cur = l.firstOrNull()?.takeIf { it.start <= now }
            val next = if (cur != null) l.getOrNull(1) else l.firstOrNull()
            b.nowTitle.text = cur?.title ?: "No programme information"
            b.nowTime.text = cur?.let { "${fmtTime(it.start)} – ${fmtTime(it.stop)}" } ?: ""
            b.nowProgress.progress = cur?.let { ((now - it.start) * 100 / (it.stop - it.start).coerceAtLeast(1)).toInt() } ?: 0
            b.nowDesc.text = cur?.descr ?: ""
            b.nextTitle.text = next?.let { "Next  ${fmtTime(it.start)}  ${it.title}" } ?: ""
        }
        // Mini preview after the focus has dwelled for a moment
        previewRunnable?.let { handler.removeCallbacks(it) }
        previewRunnable = Runnable { startPreview(c) }.also { handler.postDelayed(it, 1200) }
    }

    private fun startPreview(c: Channel) {
        if (_b == null) return
        val repo = requireContext().repo
        val p = player ?: PlayerFactory.create(requireContext()).also { player = it; b.preview.player = it }
        p.setMediaItem(MediaItem.fromUri(repo.liveUrl(c)))
        p.prepare(); p.playWhenReady = true
    }

    private fun play(c: Channel) {
        releasePlayer()
        startActivity(PlayerActivity.live(requireContext(), c.uid, scopeId))
    }

    private fun toggleFavorite(c: Channel, pos: Int) {
        viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val newVal = !c.isFavorite
            repo.dao.setFavorite(c.uid, newVal)
            val updated = c.copy(isFavorite = newVal)
            if (favOnly && !newVal) {
                chAdapter.items = chAdapter.items.filter { it.uid != c.uid }; chAdapter.notifyItemRemoved(pos)
            } else {
                chAdapter.items = chAdapter.items.toMutableList().also { it[pos] = updated }; chAdapter.notifyItemChanged(pos)
            }
            Toast.makeText(requireContext(), if (newVal) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
        }
    }

    private fun releasePlayer() {
        previewRunnable?.let { handler.removeCallbacks(it) }
        b.preview.player = null
        player?.release(); player = null
    }

    override fun onStop() { super.onStop(); if (_b != null) releasePlayer() }
    override fun onDestroyView() { super.onDestroyView(); releasePlayer(); _b = null }

    companion object {
        fun newInstance(favs: Boolean) = LiveTvFragment().apply { arguments = Bundle().apply { putBoolean("favs", favs) } }
    }
}

class ChannelAdapter(
    private val onFocus: (Channel) -> Unit,
    private val onClick: (Channel) -> Unit,
    private val onLong: (Channel, Int) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    class VH(val b: ItemChannelBinding) : RecyclerView.ViewHolder(b.root)

    var items: List<Channel> = emptyList()
    var now: Map<String, Programme> = emptyMap()

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(ItemChannelBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val c = items[i]
        h.b.number.text = c.number.toString()
        h.b.name.text = c.name
        h.b.logo.loadUrl(c.logo)
        h.b.fav.visibility = if (c.isFavorite) View.VISIBLE else View.GONE
        val pr = now[c.epgId]
        h.b.now.text = pr?.title ?: ""
        val t = System.currentTimeMillis()
        h.b.progress.progress = pr?.let { ((t - it.start) * 100 / (it.stop - it.start).coerceAtLeast(1)).toInt() } ?: 0
        h.b.progress.visibility = if (pr != null) View.VISIBLE else View.INVISIBLE
        h.itemView.setOnFocusChangeListener { _, f -> if (f) onFocus(c) }
        h.itemView.setOnClickListener { onClick(c) }
        h.itemView.setOnLongClickListener { onLong(c, h.bindingAdapterPosition); true }
    }
}
