package com.sparrow.player.ui.settings

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.format.DateUtils
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.R
import com.sparrow.player.databinding.FragmentSettingsBinding
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

class SettingsFragment : Fragment(R.layout.fragment_settings) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentSettingsBinding.bind(view)
        val repo = requireContext().repo
        val scope = viewLifecycleOwner.lifecycleScope

        fun refresh() = scope.launch {
            val p = repo.activeProvider()
            b.info.text = if (p == null) "No provider configured" else
                "Active: ${p.name} (${p.type})   •   last sync: " +
                    if (p.lastSync == 0L) "never" else DateUtils.getRelativeTimeSpanString(p.lastSync)
            b.formatBtn.text = "Live stream format: ${repo.prefs.liveFormat.uppercase()}   (Xtream only – TS or HLS)"
        }
        refresh()

        b.addBtn.setOnClickListener { startActivity(Intent(requireContext(), AddProviderActivity::class.java)) }

        b.switchBtn.setOnClickListener {
            scope.launch {
                val all = repo.dao.providers()
                if (all.isEmpty()) return@launch
                AlertDialog.Builder(requireContext()).setTitle("Switch provider")
                    .setItems(all.map { it.name }.toTypedArray()) { _, i ->
                        repo.prefs.activeProvider = all[i].id
                        repo.dataVersion.value++
                        refresh()
                    }.show()
            }
        }

        b.refreshBtn.setOnClickListener {
            scope.launch { repo.activeProvider()?.let { repo.syncAsync(it) } }
        }

        b.formatBtn.setOnClickListener {
            repo.prefs.liveFormat = if (repo.prefs.liveFormat == "ts") "m3u8" else "ts"
            refresh()
        }

        b.deleteBtn.setOnClickListener {
            scope.launch {
                val p = repo.activeProvider() ?: return@launch
                AlertDialog.Builder(requireContext()).setTitle("Remove ${p.name}?")
                    .setMessage("Channels, VOD and guide data for this provider will be deleted.")
                    .setPositiveButton("Remove") { _, _ ->
                        scope.launch {
                            repo.deleteProvider(p)
                            if (repo.activeProvider() == null) startActivity(Intent(requireContext(), AddProviderActivity::class.java))
                            refresh()
                        }
                    }.setNegativeButton("Cancel", null).show()
            }
        }

        b.about.text = "Sparrow Player 1.0   •   Media3 / ExoPlayer   •   Leanback\n" +
            "Live: OK = watch, hold OK = favorite   •   Player: Up/Down = zap, 0-9 = channel number, Menu = audio/subtitles"
        scope.launch { repo.status.collect { if (it == "Ready") refresh() } }
    }
}
