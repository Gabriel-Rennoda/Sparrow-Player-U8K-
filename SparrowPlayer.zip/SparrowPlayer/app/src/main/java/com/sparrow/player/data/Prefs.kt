package com.sparrow.player.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sparrow", Context.MODE_PRIVATE)

    var activeProvider: Long
        get() = sp.getLong("active", -1L)
        set(v) { sp.edit().putLong("active", v).apply() }

    /** "ts" (raw MPEG-TS, lowest latency, most compatible) or "m3u8" (HLS). Xtream providers only. */
    var liveFormat: String
        get() = sp.getString("fmt", "ts") ?: "ts"
        set(v) { sp.edit().putString("fmt", v).apply() }

    var lastChannel: String
        get() = sp.getString("lastCh", "") ?: ""
        set(v) { sp.edit().putString("lastCh", v).apply() }

    /** false = 12 hour clock (default), true = 24 hour. */
    var clock24: Boolean
        get() = sp.getBoolean("clock24", false)
        set(v) { sp.edit().putBoolean("clock24", v).apply() }

    var showNumbers: Boolean
        get() = sp.getBoolean("showNum", true)
        set(v) { sp.edit().putBoolean("showNum", v).apply() }

    /** Last episode id watched for a series (so Play continues the series). */
    fun lastEpisode(seriesUid: String): String = sp.getString("lastEp_$seriesUid", "") ?: ""
    fun setLastEpisode(seriesUid: String, epId: String) = sp.edit().putString("lastEp_$seriesUid", epId).apply()

    fun duration(key: String): Long = sp.getLong("dur_$key", 0L)
    fun setDuration(key: String, v: Long) = sp.edit().putLong("dur_$key", v).apply()
    fun percent(key: String): Int = Resume.percent(position(key), duration(key))

    fun position(key: String): Long = sp.getLong("pos_$key", 0L)
    fun setPosition(key: String, v: Long) = sp.edit().putLong("pos_$key", v).apply()

    companion object {
        /** Some panels block unknown user agents; a VLC UA is the most widely accepted. */
        const val UA = "VLC/3.0.20 LibVLC/3.0.20"
    }
}
