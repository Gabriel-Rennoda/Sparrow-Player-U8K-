package com.sparrow.player.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sparrow", Context.MODE_PRIVATE)

    var activeProvider: Long
        get() = sp.getLong("active", -1L)
        set(v) { sp.edit().putLong("active", v).apply() }

    /** "ts" (raw MPEG-TS, lowest latency, most compatible) or "m3u8" (HLS). Xtream providers only. */
    var liveFormat: String
        get() = sp.getString("fmt", "ts") ?: "ts"
        set(v) { sp.edit().putString("fmt", v).apply() }

    var lastChannel: String
        get() = sp.getString("lastCh", "") ?: ""
        set(v) { sp.edit().putString("lastCh", v).apply() }

    fun position(key: String): Long = sp.getLong("pos_$key", 0L)
    fun setPosition(key: String, v: Long) = sp.edit().putLong("pos_$key", v).apply()

    companion object {
        /** Some panels block unknown user agents; a VLC UA is the most widely accepted. */
        const val UA = "VLC/3.0.20 LibVLC/3.0.20"
    }
}
