package com.sparrow.player.data

import android.util.JsonReader
import android.util.JsonToken
import java.io.InputStream
import java.io.InputStreamReader

/** Streaming JSON helpers. Xtream panels return wildly inconsistent types, so everything numeric becomes a String. */
object Json {
    private fun readValue(r: JsonReader): Any? = when (r.peek()) {
        JsonToken.BEGIN_OBJECT -> {
            val m = HashMap<String, Any?>()
            r.beginObject()
            while (r.hasNext()) m[r.nextName()] = readValue(r)
            r.endObject(); m
        }
        JsonToken.BEGIN_ARRAY -> {
            val l = ArrayList<Any?>()
            r.beginArray()
            while (r.hasNext()) l.add(readValue(r))
            r.endArray(); l
        }
        JsonToken.STRING, JsonToken.NUMBER -> r.nextString()
        JsonToken.BOOLEAN -> r.nextBoolean().toString()
        JsonToken.NULL -> { r.nextNull(); null }
        else -> { r.skipValue(); null }
    }

    @Suppress("UNCHECKED_CAST")
    fun streamArray(input: InputStream, onItem: (Map<String, Any?>) -> Unit) {
        JsonReader(InputStreamReader(input, Charsets.UTF_8)).use { r ->
            r.isLenient = true
            if (r.peek() != JsonToken.BEGIN_ARRAY) return
            r.beginArray()
            while (r.hasNext()) {
                val v = readValue(r)
                if (v is Map<*, *>) onItem(v as Map<String, Any?>)
            }
            r.endArray()
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun readObject(input: InputStream): Map<String, Any?> =
        JsonReader(InputStreamReader(input, Charsets.UTF_8)).use { r ->
            r.isLenient = true
            if (r.peek() != JsonToken.BEGIN_OBJECT) emptyMap() else readValue(r) as Map<String, Any?>
        }
}

fun Map<String, Any?>.str(key: String): String = (this[key] as? String) ?: ""
