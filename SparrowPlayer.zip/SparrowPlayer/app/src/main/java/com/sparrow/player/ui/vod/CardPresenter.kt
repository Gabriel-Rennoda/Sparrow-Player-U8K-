package com.sparrow.player.ui.vod

import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.leanback.widget.ImageCardView
import androidx.leanback.widget.Presenter
import com.sparrow.player.R
import com.sparrow.player.data.VodItem
import com.sparrow.player.util.loadUrl

/** Poster card (2:3) in the Netflix / Disney+ manner; Leanback handles the focus zoom. */
class CardPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val ctx = parent.context
        val card = ImageCardView(ctx).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            // Poster width is a share of the screen so the rows look right at any dp viewport (2:3 posters).
            val w = (ctx.resources.displayMetrics.widthPixels * 0.15f).toInt()
            setMainImageDimensions(w, w * 3 / 2)
            setInfoAreaBackgroundColor(ContextCompat.getColor(ctx, R.color.surface))
            mainImageView?.scaleType = ImageView.ScaleType.CENTER_CROP
        }
        return ViewHolder(card)
    }

    override fun onBindViewHolder(vh: ViewHolder, item: Any?) {
        val v = item as? VodItem ?: return
        val card = vh.view as ImageCardView
        card.titleText = v.name
        card.contentText = listOf(v.year, ratingText(v)).filter { it.isNotBlank() }.joinToString("  •  ")
        card.mainImageView?.loadUrl(v.poster)
    }

    override fun onUnbindViewHolder(vh: ViewHolder) { (vh.view as ImageCardView).mainImage = null }

    companion object {
        fun ratingText(v: VodItem): String {
            val r = v.rating.toDoubleOrNull() ?: return ""
            return if (r > 0) "★ " + String.format("%.1f", r) else ""
        }
    }
}
