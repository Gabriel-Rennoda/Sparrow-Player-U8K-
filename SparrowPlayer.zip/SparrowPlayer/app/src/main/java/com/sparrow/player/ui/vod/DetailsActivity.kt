package com.sparrow.player.ui.vod

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.sparrow.player.R
import com.sparrow.player.data.Episode
import com.sparrow.player.data.Resume
import com.sparrow.player.data.VodItem
import com.sparrow.player.data.str
import com.sparrow.player.databinding.ActivityDetailsBinding
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.util.TextAdapter
import com.sparrow.player.util.loadUrl
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

class DetailsActivity : FragmentActivity() {
    private lateinit var b: ActivityDetailsBinding
    private var episodes: List<Episode> = emptyList()
    private var shown: List<Episode> = emptyList()          // episodes of the season on screen
    private var episodeAdapter: TextAdapter<Episode>? = null
    private var item: VodItem? = null
    private var seriesMeta = ""
    private var seriesPlot = ""
    private var seriesBackdrop = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(b.root)
        val uid = intent.getStringExtra("uid") ?: return finish()
        val repo = applicationContext.repo
        b.seasonList.itemAnimator = null
        b.episodeList.itemAnimator = null

        lifecycleScope.launch {
            repo.activeProvider()
            val v = repo.dao.vod(uid) ?: return@launch finish()
            item = v
            b.title.text = v.name
            b.poster.loadUrl(v.poster)
            seriesBackdrop = v.backdrop
            if (v.backdrop.isNotBlank()) b.backdrop.load(v.backdrop)
            seriesMeta = metaOf(v.year, v.rating, v.genre)
            seriesPlot = v.plot
            b.meta.text = seriesMeta
            b.plot.text = seriesPlot

            if (v.type == "movie") {
                b.seasonList.visibility = View.GONE; b.episodeList.visibility = View.GONE
                refreshPlayLabel()
                b.playBtn.setOnClickListener {
                    val m = item ?: return@setOnClickListener
                    startActivity(PlayerActivity.vod(this@DetailsActivity, repo.movieUrl(m), m.name, m.uid))
                }
                b.playBtn.requestFocus()
                val info = repo.vodInfo(v)   // enrich with plot / backdrop when the panel provides it
                info.str("plot").ifBlank { info.str("description") }.takeIf { p -> p.isNotBlank() }?.let { p -> b.plot.text = p }
                (info["backdrop_path"] as? List<*>)?.firstOrNull()?.toString()?.let { u -> b.backdrop.load(u) }
                b.meta.text = metaOf(v.year.ifBlank { info.str("releasedate").take(4) }, v.rating,
                    v.genre.ifBlank { info.str("genre") }, info.str("duration"))
            } else {
                setupSeries(v)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Back from the player: refresh the "watched" markers / Resume label in place (no animations, focus is kept).
        episodeAdapter?.let { a -> a.notifyItemRangeChanged(0, a.itemCount) }
        if (item != null) refreshPlayLabel()
    }

    private suspend fun setupSeries(it: VodItem) {
        val repo = applicationContext.repo
        val adapter = TextAdapter<Episode>(
            { e -> episodeLabel(e) },
            { e -> playEpisode(e) },                               // ONE press of OK plays that episode
            { e, _ -> showEpisodeInfo(e) }                         // browsing shows the episode's info on top
        )
        episodeAdapter = adapter
        b.episodeList.layoutManager = LinearLayoutManager(this)
        b.episodeList.adapter = adapter
        episodes = try { repo.seriesEpisodes(it) } catch (e: Exception) { emptyList() }
        if (episodes.isEmpty()) { b.plot.text = it.plot.ifBlank { "No episodes found." }; b.playBtn.requestFocus(); return }

        val seasons = episodes.map { e -> e.season }.distinct().sorted()
        val seasonAdapter = TextAdapter<Int>({ s -> "Season $s" }, { s -> showSeason(s) }, { s, _ -> showSeason(s) }, R.layout.item_tab)
        b.seasonList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.seasonList.adapter = seasonAdapter
        seasonAdapter.submit(seasons, 0)
        showSeason(seasons.first())
        refreshPlayLabel()
        b.playBtn.setOnClickListener { continueTarget()?.let { e -> playEpisode(e) } }
        b.playBtn.requestFocus()
    }

    private fun showSeason(s: Int) {
        shown = episodes.filter { it.season == s }
        episodeAdapter?.submit(shown)
    }

    private fun episodeLabel(e: Episode): String {
        val saved = applicationContext.repo.prefs.position("ep:${e.id}")
        val mark = when { saved == Resume.FINISHED -> "   ✓"; Resume.hasProgress(saved) -> "   ▶ resume"; else -> "" }
        return "E${e.num}   ${e.title}$mark"
    }

    /** Top info section: details of the focused episode (falls back to the series text for anything missing). */
    private fun showEpisodeInfo(e: Episode) {
        b.epTitle.text = "S${e.season} E${e.num}   ${e.title}"
        b.epTitle.visibility = View.VISIBLE
        val m = metaOf(e.duration.takeIf { it != "00:00:00" } ?: "", e.released, e.rating.takeIf { it != "0" } ?: "")
        b.meta.text = m.ifBlank { seriesMeta }
        b.plot.text = e.plot.ifBlank { seriesPlot }
        setProgress(applicationContext.repo.prefs.percent("ep:${e.id}"))
        if (e.image.isNotBlank()) b.backdrop.load(e.image)
    }

    /** Which episode the Play button continues: the last one watched (or the next one if it was finished). */
    private fun continueTarget(): Episode? {
        val it = item ?: return null
        if (episodes.isEmpty()) return null
        val prefs = applicationContext.repo.prefs
        val last = prefs.lastEpisode(it.uid)
        val i = episodes.indexOfFirst { e -> e.id == last }
        if (i < 0) return episodes.first()
        return if (prefs.position("ep:${episodes[i].id}") == Resume.FINISHED) episodes.getOrNull(i + 1) ?: episodes[i] else episodes[i]
    }

    private fun setProgress(percent: Int) {
        b.watchProgress.visibility = if (percent > 0) View.VISIBLE else View.GONE
        b.watchProgress.progress = percent
    }

    private fun refreshPlayLabel() {
        val it = item ?: return
        val prefs = applicationContext.repo.prefs
        if (it.type == "movie") setProgress(prefs.percent(it.uid))
        else setProgress(continueTarget()?.let { e -> prefs.percent("ep:${e.id}") } ?: 0)
        if (it.type == "movie") {
            b.playBtn.text = if (Resume.hasProgress(prefs.position(it.uid))) "▶  Resume" else "▶  Play"
        } else {
            val e = continueTarget()
            val started = e != null && prefs.lastEpisode(it.uid).isNotBlank()
            b.playBtn.text = if (started && e != null) "▶  Resume S${e.season} E${e.num}" else "▶  Play"
        }
    }

    private fun playEpisode(e: Episode) {
        val it = item ?: return
        val repo = applicationContext.repo
        repo.prefs.setLastEpisode(it.uid, e.id)
        startActivity(PlayerActivity.vod(this, repo.episodeUrl(e), "${it.name} · S${e.season}E${e.num}  ${e.title}", "ep:${e.id}"))
    }

    private fun metaOf(vararg parts: String) = parts.filter { it.isNotBlank() && it != "0" }.joinToString("   •   ")

    companion object {
        fun intent(ctx: Context, uid: String) = Intent(ctx, DetailsActivity::class.java).putExtra("uid", uid)
    }
}
