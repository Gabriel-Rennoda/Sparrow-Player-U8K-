package com.sparrow.player.ui.vod

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.sparrow.player.R
import com.sparrow.player.data.Episode
import com.sparrow.player.data.VodItem
import com.sparrow.player.data.str
import com.sparrow.player.databinding.ActivityDetailsBinding
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.util.TextAdapter
import com.sparrow.player.util.loadUrl
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

class DetailsActivity : FragmentActivity() {
    private lateinit var b: ActivityDetailsBinding
    private var episodes: List<Episode> = emptyList()
    private lateinit var episodeAdapter: TextAdapter<Episode>
    private lateinit var item: VodItem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(b.root)
        val uid = intent.getStringExtra("uid") ?: return finish()
        val repo = applicationContext.repo

        lifecycleScope.launch {
            repo.activeProvider()
            item = repo.dao.vod(uid) ?: return@launch finish()
            b.title.text = item.name
            b.poster.loadUrl(item.poster)
            if (item.backdrop.isNotBlank()) b.backdrop.load(item.backdrop)
            b.meta.text = metaOf(item.year, item.rating, item.genre)
            b.plot.text = item.plot

            if (item.type == "movie") {
                b.seasonList.visibility = View.GONE; b.episodeList.visibility = View.GONE
                b.playBtn.setOnClickListener {
                    startActivity(PlayerActivity.vod(this@DetailsActivity, repo.movieUrl(item), item.name, item.uid))
                }
                b.playBtn.requestFocus()
                val info = repo.vodInfo(item)   // enrich with plot / backdrop when the panel provides it
                info.str("plot").ifBlank { info.str("description") }.takeIf { it.isNotBlank() }?.let { b.plot.text = it }
                (info["backdrop_path"] as? List<*>)?.firstOrNull()?.toString()?.let { b.backdrop.load(it) }
                b.meta.text = metaOf(item.year.ifBlank { info.str("releasedate").take(4) }, item.rating,
                    item.genre.ifBlank { info.str("genre") }, info.str("duration"))
            } else {
                setupSeries()
            }
        }
    }

    private suspend fun setupSeries() {
        val repo = applicationContext.repo
        episodeAdapter = TextAdapter(
            { "S${it.season} E${it.num}   ${it.title}" },
            { e -> playEpisode(e) }
        )
        b.episodeList.layoutManager = LinearLayoutManager(this)
        b.episodeList.adapter = episodeAdapter
        episodes = try { repo.seriesEpisodes(item) } catch (e: Exception) { emptyList() }
        if (episodes.isEmpty()) { b.plot.text = item.plot.ifBlank { "No episodes found." }; return }

        val seasons = episodes.map { it.season }.distinct().sorted()
        val seasonAdapter = TextAdapter<Int>({ "Season $it" }, { showSeason(it) }, { s, _ -> showSeason(s) }, R.layout.item_tab)
        b.seasonList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.seasonList.adapter = seasonAdapter
        seasonAdapter.submit(seasons, 0)
        showSeason(seasons.first())
        b.playBtn.setOnClickListener { episodes.firstOrNull { it.season == seasons.first() }?.let { playEpisode(it) } }
        b.playBtn.requestFocus()
    }

    private fun showSeason(s: Int) = episodeAdapter.submit(episodes.filter { it.season == s })

    private fun playEpisode(e: Episode) {
        val repo = applicationContext.repo
        startActivity(PlayerActivity.vod(this, repo.episodeUrl(e), "${item.name} · S${e.season}E${e.num}  ${e.title}", "ep:${e.id}"))
    }

    private fun metaOf(vararg parts: String) = parts.filter { it.isNotBlank() && it != "0" }.joinToString("   •   ")

    companion object {
        fun intent(ctx: Context, uid: String) = Intent(ctx, DetailsActivity::class.java).putExtra("uid", uid)
    }
}
