package com.sparrow.player.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.R
import com.sparrow.player.databinding.ActivityMainBinding
import com.sparrow.player.ui.epg.EpgFragment
import com.sparrow.player.ui.live.LiveTvFragment
import com.sparrow.player.ui.settings.AddProviderActivity
import com.sparrow.player.ui.settings.SettingsFragment
import com.sparrow.player.ui.vod.VodFragment
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    private lateinit var b: ActivityMainBinding
    private val names = listOf("Live TV", "Movies", "Series", "Guide", "Favorites", "Settings")
    private val tabViews = ArrayList<TextView>()
    private var current = -1
    private val handler = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        names.forEachIndexed { i, n ->
            val tv = layoutInflater.inflate(R.layout.item_tab, b.tabs, false) as TextView
            tv.text = n
            tv.setOnClickListener { select(i) }
            // Leanback-style: tabs switch as soon as they get focus (debounced).
            tv.setOnFocusChangeListener { _, f ->
                if (f) {
                    pending?.let { handler.removeCallbacks(it) }
                    pending = Runnable { select(i) }.also { handler.postDelayed(it, 180) }
                }
            }
            b.tabs.addView(tv); tabViews += tv
        }
        select(savedInstanceState?.getInt("tab") ?: 0)

        val repo = applicationContext.repo
        lifecycleScope.launch {
            if (repo.activeProvider() == null) startActivity(Intent(this@MainActivity, AddProviderActivity::class.java))
        }
        lifecycleScope.launch {
            repo.status.collect {
                b.status.text = it
                b.status.visibility = if (it.isEmpty()) View.GONE else View.VISIBLE
            }
        }
        lifecycleScope.launch {
            var first = true
            repo.dataVersion.collect {
                if (first) first = false else if (current != 5) select(current, force = true)
            }
        }
    }

    private fun select(i: Int, force: Boolean = false) {
        if (i == current && !force) return
        current = i
        tabViews.forEachIndexed { j, t -> t.isSelected = j == i }
        val f: Fragment = when (i) {
            0 -> LiveTvFragment.newInstance(false)
            1 -> VodFragment.newInstance("movie")
            2 -> VodFragment.newInstance("series")
            3 -> EpgFragment()
            4 -> LiveTvFragment.newInstance(true)
            else -> SettingsFragment()
        }
        if (i != 1 && i != 2) hideHero()
        supportFragmentManager.beginTransaction().replace(R.id.content, f).commitAllowingStateLoss()
    }

    fun showHero(title: String, meta: String, plot: String) {
        b.hero.visibility = View.VISIBLE
        b.heroTitle.text = title; b.heroMeta.text = meta; b.heroPlot.text = plot
    }

    fun hideHero() { b.hero.visibility = View.GONE }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", current)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val f = currentFocus
        if (f != null && tabViews.none { it === f }) tabViews[current.coerceAtLeast(0)].requestFocus()
        else super.onBackPressed()
    }
}
