package com.sparrow.player.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.doOnLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.sparrow.player.R
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Programme
import com.sparrow.player.data.Repository
import com.sparrow.player.databinding.ActivityMainBinding
import com.sparrow.player.ui.epg.EpgFragment
import com.sparrow.player.ui.nav.Panel
import com.sparrow.player.ui.nav.PanelState
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.ui.player.PlayerFactory
import com.sparrow.player.ui.settings.AddProviderActivity
import com.sparrow.player.ui.settings.SettingsFragment
import com.sparrow.player.ui.vod.VodFragment
import com.sparrow.player.util.fmtTime
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Shell of the app.
 *
 *  - Left: minimized icon bar (always visible). LEFT from the left edge of the content opens the channel groups
 *    (Live TV / Guide) and LEFT again expands the tab list. BACK / RIGHT close one level at a time and put the
 *    selector back where the user was.  (State machine: [PanelState])
 *  - Live TV / Guide / Favourites share one header: the player (top-left, always the channel being watched)
 *    and an info pane that follows whatever is being browsed.
 */
class MainActivity : FragmentActivity() {
    private lateinit var b: ActivityMainBinding

    private val names = listOf("Live TV", "Movies", "Series", "Favourites", "Settings")
    private val icons = listOf(
        R.drawable.ic_nav_live, R.drawable.ic_nav_movies, R.drawable.ic_nav_series,
        R.drawable.ic_nav_fav, R.drawable.ic_nav_settings
    )
    private val navItems = ArrayList<View>()
    private val panels = PanelState()
    private var current = -1

    // Focus memory so BACK can put the selector back one level at a time
    private var contentFocus: View? = null
    private var groupsFocus: View? = null
    private var pendingFocus = false

    // Channel groups
    private lateinit var groupAdapter: GroupAdapter
    var groupScope: String = Repository.SCOPE_ALL
        private set

    // Top-left player
    private var player: ExoPlayer? = null
    var playing: Channel? = null
        private set
    private var playingScope: String = Repository.SCOPE_ALL
    private var liveJob: Job? = null
    private var infoJob: Job? = null

    private val tabContent: TabContent? get() = supportFragmentManager.findFragmentById(R.id.content) as? TabContent

    private val playerListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            b.playerMsg.text = "Channel unavailable"; b.playerMsg.visibility = View.VISIBLE
        }
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) b.playerMsg.visibility = View.GONE
        }
    }

    // ---- Lifecycle ------------------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        val repo = applicationContext.repo

        buildNav()
        groupAdapter = GroupAdapter({ pickGroup(it.first) }, { onGroupFocused(it.first) })
        b.groupList.layoutManager = LinearLayoutManager(this)
        b.groupList.adapter = groupAdapter
        b.groupList.itemAnimator = null
        b.playerBox.setOnFocusChangeListener { _, f -> if (f) showNowPlaying() }
        b.playerBox.setOnClickListener { fullscreen() }
        applyPanels()

        select(savedInstanceState?.getInt("tab") ?: TAB_LIVE)
        refreshGroups()

        lifecycleScope.launch {
            if (repo.activeProvider() == null) startActivity(Intent(this@MainActivity, AddProviderActivity::class.java))
        }
        lifecycleScope.launch {
            repo.status.collect {
                b.status.text = it
                b.status.visibility = if (it.isEmpty()) View.GONE else View.VISIBLE
            }
        }
        lifecycleScope.launch {
            var first = true
            repo.dataVersion.collect {
                if (first) {
                    first = false
                } else {
                    // Refresh IN PLACE. (The old code replaced the visible fragment here, which destroyed the
                    // focused view and bounced the selector back to the first tab.)
                    refreshGroups()
                    if (current != TAB_SETTINGS) tabContent?.reload()
                    if (isLiveTab()) ensureLivePlaying()
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (isLiveTab()) ensureLivePlaying()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()          // frees the decoder for the full-screen player and stops audio in the background
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", current)
    }

    // ---- Tabs -----------------------------------------------------------------------------------
    private fun buildNav() {
        names.forEachIndexed { i, n ->
            val v = layoutInflater.inflate(R.layout.item_nav, b.tabs, false)
            v.findViewById<ImageView>(R.id.navIcon).setImageResource(icons[i])
            v.findViewById<TextView>(R.id.navLabel).text = n
            v.setOnClickListener { onNavPicked(i) }
            v.isFocusable = false          // only focusable while the tab list is expanded
            b.tabs.addView(v); navItems += v
        }
    }

    private fun isLiveTab() = current == TAB_LIVE || current == TAB_FAVS
    private fun tabHasGroups() = current == TAB_LIVE

    private fun select(i: Int) {
        if (i == current) return
        current = i
        navItems.forEachIndexed { j, v -> v.isSelected = j == i }
        val f: Fragment = when (i) {
            TAB_LIVE -> EpgFragment.newInstance(false)
            TAB_MOVIES -> VodFragment.newInstance("movie")
            TAB_SERIES -> VodFragment.newInstance("series")
            TAB_FAVS -> EpgFragment.newInstance(true)
            else -> SettingsFragment()
        }
        val live = isLiveTab()
        b.liveHeader.visibility = if (live) View.VISIBLE else View.GONE
        if (i != TAB_MOVIES && i != TAB_SERIES) hideHero()
        pendingFocus = true
        supportFragmentManager.beginTransaction().replace(R.id.content, f).commitAllowingStateLoss()
        if (live) ensureLivePlaying() else releasePlayer()
    }

    private fun onNavPicked(i: Int) {
        if (panels.panel != Panel.NAV) return
        panels.reset()
        if (i == current) {                       // same tab: just close and go back to where we were
            restoreContent(); applyPanels(); return
        }
        contentFocus = null; groupsFocus = null
        applyPanels()
        select(i)                                 // pendingFocus => the new tab takes focus once it has loaded
    }

    /** Called by a tab body when its data is on screen. Takes focus if a tab / group was just chosen. */
    fun contentReady() {
        if (pendingFocus && panels.panel == Panel.NONE) {
            if (tabContent?.focusContent() == true) pendingFocus = false
            else if (isLiveTab() && b.playerBox.requestFocus()) pendingFocus = false   // empty list: park on the player
        }
    }

    /** A body that refreshed in place and had focus asks for focus back once it's reloaded. */
    fun wantFocus() { pendingFocus = true }

    // ---- Panels / D-pad -------------------------------------------------------------------------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> if (onLeft(e)) return true
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (onRight(e)) return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        when {
            panels.panel != Panel.NONE -> closeTopPanel()
            tabContent?.handleBack() == true -> Unit            // e.g. leave guide time-shifting mode, stay where you were
            else -> backToExit()
        }
    }

    /** Back on the main screen: 1st press = hint, 2nd press (within 2.5 s) = "Exit?  Yes / No". */
    private var lastBack = 0L
    private fun backToExit() {
        val now = SystemClock.uptimeMillis()
        if (lastBack != 0L && now - lastBack <= 2500) {
            lastBack = 0L
            AlertDialog.Builder(this)
                .setTitle("Exit Sparrow Player?")
                .setPositiveButton("Yes") { _, _ -> finishAffinity() }
                .setNegativeButton("No", null)
                .show()
        } else {
            lastBack = now
            Toast.makeText(this, "Press Back again to exit", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onLeft(e: KeyEvent): Boolean {
        val first = e.repeatCount == 0        // a held key must not race through all the levels
        return when (panels.panel) {
            Panel.NAV -> true
            Panel.GROUPS -> {
                if (first) { groupsFocus = currentFocus; panels.left(false); applyPanels(); focusNav() }
                true
            }
            Panel.NONE -> {
                // No focus at all (e.g. an empty group) counts as the edge, so the user can never get stuck.
                if (currentFocus != null && !atLeftEdge()) {
                    false
                } else {
                    if (first) {
                        contentFocus = currentFocus
                        panels.hasGroups = tabHasGroups()
                        panels.left(true)
                        applyPanels()
                        if (panels.panel == Panel.GROUPS) focusGroups() else focusNav()
                    }
                    true
                }
            }
        }
    }

    private fun onRight(e: KeyEvent): Boolean {
        if (panels.panel == Panel.NONE) return false
        if (e.repeatCount == 0) closeTopPanel()
        return true
    }

    private fun atLeftEdge(): Boolean {
        val f = currentFocus ?: return false
        if (b.liveHeader.visibility == View.VISIBLE && f === b.playerBox) return true
        return tabContent?.isAtLeftEdge() ?: false
    }

    /** BACK / RIGHT: close one level, move the selector back to the user's last selection there. */
    private fun closeTopPanel() {
        when (panels.panel) {
            Panel.NAV -> {
                panels.back()
                if (panels.panel == Panel.GROUPS) { if (!restore(groupsFocus)) focusGroups() } else restoreContent()
            }
            Panel.GROUPS -> { flushGroupPreview(); groupAdapter.setActive(groupScope); panels.back(); restoreContent() }
            Panel.NONE -> return
        }
        applyPanels()
    }

    private fun restore(v: View?): Boolean =
        v != null && v.isAttachedToWindow && v.isShown && v.isFocusable && v.requestFocus()

    private fun restoreContent() { if (!restore(contentFocus)) tabContent?.focusContent() }

    private fun focusGroups() {
        val pos = groupAdapter.positionOf(groupScope).coerceAtLeast(0)
        val rv = b.groupList
        rv.scrollToPosition(pos)
        rv.doOnLayout { (rv.findViewHolderForAdapterPosition(pos)?.itemView ?: rv.getChildAt(0))?.requestFocus() }
    }

    private fun focusNav() {
        navItems.getOrNull(current.coerceAtLeast(0))?.let { it.isFocusable = true; it.requestFocus() }
    }

    /** Make the views match [panels]. Always move focus BEFORE calling this when closing a panel. */
    private fun applyPanels() {
        val nav = panels.navOpen
        b.groupsPanel.visibility = if (panels.groupsOpen) View.VISIBLE else View.GONE
        b.navRail.layoutParams = b.navRail.layoutParams.apply {
            width = resources.getDimensionPixelSize(if (nav) R.dimen.rail_expanded else R.dimen.rail_collapsed)
        }
        b.navTitle.visibility = if (nav) View.VISIBLE else View.GONE
        navItems.forEach { v ->
            v.isFocusable = nav
            v.findViewById<View>(R.id.navLabel).visibility = if (nav) View.VISIBLE else View.GONE
        }
    }

    // ---- Channel groups -------------------------------------------------------------------------
    private val handler = Handler(Looper.getMainLooper())
    private var previewPending = false
    private val previewRun = Runnable { previewPending = false; tabContent?.onGroupChanged() }

    /** Focus moved to a group in the side menu: the guide shows that group right away (OK commits, Back keeps it). */
    private fun onGroupFocused(id: String) {
        if (panels.panel != Panel.GROUPS || id == groupScope) return
        groupScope = id
        groupAdapter.setActiveQuiet(id)             // no notifyDataSetChanged: that would drop focus
        previewPending = true
        handler.removeCallbacks(previewRun); handler.postDelayed(previewRun, 250)   // debounce fast scrolling
    }

    private fun flushGroupPreview() {
        if (!previewPending) return
        handler.removeCallbacks(previewRun); previewPending = false
        tabContent?.onGroupChanged()
    }

    private fun pickGroup(id: String) {
        if (panels.panel != Panel.GROUPS) return
        handler.removeCallbacks(previewRun); previewPending = false
        groupScope = id
        groupAdapter.setActive(id)
        panels.reset()
        contentFocus = null; groupsFocus = null
        pendingFocus = true
        applyPanels()
        tabContent?.onGroupChanged()
    }

    private fun refreshGroups() {
        lifecycleScope.launch {
            val repo = applicationContext.repo
            val p = repo.activeProvider()
            val cats = if (p == null) emptyList() else repo.dao.categories(p.id, "live")
            val list = listOf(Repository.SCOPE_ALL to "All channels", Repository.SCOPE_FAV to "★  Favourites") +
                cats.map { it.remoteId to it.name }
            if (list.none { it.first == groupScope }) groupScope = Repository.SCOPE_ALL
            groupAdapter.submit(list, groupScope)
        }
    }

    // ---- Top-left player ------------------------------------------------------------------------
    private fun ensurePlayer(): ExoPlayer = player ?: PlayerFactory.create(this).also {
        it.addListener(playerListener); b.playerView.player = it; player = it
    }

    private fun releasePlayer() {
        liveJob?.cancel()
        b.playerView.player = null
        player?.release(); player = null
    }

    /** Make sure the top-left player is playing the channel the user was last watching. */
    private fun ensureLivePlaying() {
        liveJob?.cancel()
        liveJob = lifecycleScope.launch {
            val repo = applicationContext.repo
            val p = repo.activeProvider() ?: run { showNoProvider(); return@launch }
            val last = repo.prefs.lastChannel
            val c = (if (last.isNotBlank()) repo.dao.channel(last)?.takeIf { it.providerId == p.id } else null)
                ?: repo.dao.channels(p.id).firstOrNull()
                ?: return@launch
            if (player != null && playing?.uid == c.uid) { if (infoUid.isEmpty()) showNowPlaying(); return@launch }
            tune(c, if (playing?.uid == c.uid) playingScope else Repository.SCOPE_ALL)
        }
    }

    /** Switch the top-left player to [c]. */
    fun tune(c: Channel, scope: String) {
        val infoWasPlaying = infoPlaying
        playing = c; playingScope = scope
        applicationContext.repo.prefs.lastChannel = c.uid
        val p = ensurePlayer()
        b.playerMsg.visibility = View.GONE
        p.setMediaItem(MediaItem.fromUri(applicationContext.repo.liveUrl(c)))
        p.prepare(); p.playWhenReady = true
        tabContent?.onPlayingChanged()
        when {
            infoUid.isEmpty() || infoUid == c.uid || infoWasPlaying -> render(c)   // pane should now describe the playing channel
            else -> { infoPlaying = false; b.infoTag.text = "BROWSING" }          // pane shows another channel
        }
    }

    /** OK on a channel: tune it; OK on the channel that is already playing: full screen. */
    fun onChannelClicked(c: Channel, scope: String) {
        if (playing?.uid == c.uid && player != null) fullscreen() else tune(c, scope)
    }

    private fun fullscreen() {
        val c = playing ?: return
        startActivity(PlayerActivity.live(this, c.uid, playingScope))
    }

    fun onFavoriteChanged(c: Channel) {
        if (playing?.uid == c.uid) playing = c
    }

    // ---- Info pane (follows what is browsed; the player keeps playing) ---------------------------
    private var infoUid = ""            // channel the info pane currently describes
    private var infoPlaying = false     // ... and whether that is the channel in the player

    private fun showNoProvider() {
        b.infoTag.text = ""; b.chName.text = "No provider yet"
        b.nowTitle.text = "Open Settings → Add playlist / provider"
        b.nowTime.text = ""; b.nowDesc.text = ""; b.nextTitle.text = ""
    }

    fun showNowPlaying() {
        val c = playing ?: return
        render(c)
    }

    /** A list row got focus: show its now / next while the player carries on. */
    fun browseChannel(c: Channel) = render(c)

    /** A guide cell got focus: show that programme (and the one after it). */
    fun browseProgramme(c: Channel, p: Programme?, next: Programme?) {
        infoJob?.cancel()
        setHeader(c)
        fill(p, next)
    }

    private fun setHeader(c: Channel) {
        val isPlaying = c.uid == playing?.uid
        infoUid = c.uid; infoPlaying = isPlaying
        b.infoTag.text = if (isPlaying) "NOW PLAYING" else "BROWSING"
        val num = if (applicationContext.repo.prefs.showNumbers) "${c.number}  " else ""
        b.chName.text = (if (c.isFavorite) "★ " else "") + num + c.name
    }

    private fun render(c: Channel) {
        setHeader(c)
        infoJob?.cancel()
        infoJob = lifecycleScope.launch {
            val now = System.currentTimeMillis()
            val l: List<Programme> = if (c.epgId.isBlank()) emptyList() else applicationContext.repo.dao.nowNext(c.providerId, c.epgId, now)
            val cur = l.firstOrNull()?.takeIf { it.start <= now }
            val next = if (cur != null) l.getOrNull(1) else l.firstOrNull()
            fill(cur, next)
        }
    }

    private fun fill(p: Programme?, next: Programme?) {
        val now = System.currentTimeMillis()
        b.nowTitle.text = p?.title ?: "No program information"
        b.nowTime.text = p?.let { "${fmtTime(it.start)} – ${fmtTime(it.stop)}" } ?: ""
        b.nowDesc.text = p?.descr ?: ""
        b.nextTitle.text = next?.let { "Next  ${fmtTime(it.start)}  ${it.title}" } ?: ""
    }

    // ---- Movies / Series hero -------------------------------------------------------------------
    fun showHero(title: String, meta: String, plot: String, percent: Int = 0) {
        b.hero.visibility = View.VISIBLE
        b.heroTitle.text = title; b.heroMeta.text = meta; b.heroPlot.text = plot
        b.heroProgress.visibility = if (percent > 0) View.VISIBLE else View.GONE
        b.heroProgress.progress = percent
    }

    fun hideHero() { b.hero.visibility = View.GONE }

    companion object {
        const val TAB_LIVE = 0
        const val TAB_MOVIES = 1
        const val TAB_SERIES = 2
        const val TAB_FAVS = 3
        const val TAB_SETTINGS = 4
    }
}
