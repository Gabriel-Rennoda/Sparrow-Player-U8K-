package com.sparrow.player.ui.settings

import android.os.Bundle
import android.view.View
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Provider
import com.sparrow.player.data.XtreamClient
import com.sparrow.player.databinding.ActivityAddProviderBinding
import com.sparrow.player.util.repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AddProviderActivity : FragmentActivity() {
    private lateinit var b: ActivityAddProviderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAddProviderBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.typeGroup.setOnCheckedChangeListener { _, _ -> toggle() }
        b.saveBtn.setOnClickListener { save() }
    }

    private fun toggle() {
        val x = b.rbXtream.isChecked
        b.xtreamFields.visibility = if (x) View.VISIBLE else View.GONE
        b.m3uFields.visibility = if (x) View.GONE else View.VISIBLE
    }

    private fun save() {
        val xtream = b.rbXtream.isChecked
        val name = b.name.text.toString().trim().ifBlank { "My IPTV" }
        val epg = b.epgUrl.text.toString().trim()
        val p = if (xtream) Provider(
            name = name, type = "xtream", server = b.server.text.toString().trim(),
            username = b.username.text.toString().trim(), password = b.password.text.toString().trim(), epgUrl = epg
        ) else Provider(name = name, type = "m3u", m3uUrl = b.m3uUrl.text.toString().trim(), epgUrl = epg)

        if (xtream && (p.server.isBlank() || p.username.isBlank() || p.password.isBlank())) {
            b.error.text = "Server, username and password are required"; return
        }
        if (!xtream && p.m3uUrl.isBlank()) { b.error.text = "Playlist URL is required"; return }

        b.saveBtn.isEnabled = false
        b.error.setTextColor(0xFFD98E4A.toInt()); b.error.text = "Connecting…"
        lifecycleScope.launch {
            val repo = applicationContext.repo
            try {
                if (xtream) {
                    val ok = withContext(Dispatchers.IO) { XtreamClient(repo.http, p).authenticate() }
                    if (!ok) error("Login failed – check server, username and password")
                }
                val id = repo.dao.insertProvider(p)
                repo.prefs.activeProvider = id
                repo.syncAsync(p.copy(id = id))
                finish()
            } catch (e: Exception) {
                b.error.setTextColor(0xFFFF8A80.toInt())
                b.error.text = e.message ?: "Could not connect"
                b.saveBtn.isEnabled = true
            }
        }
    }
}
