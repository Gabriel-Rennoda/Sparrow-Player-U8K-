package com.sparrow.player.data

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

data class M3uEntry(
    val name: String, val url: String, val logo: String,
    val group: String, val tvgId: String, val chno: Int?
)

object M3uParser {
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")

    /** Streams the playlist; returns the EPG url from the #EXTM3U header (url-tvg / x-tvg-url) or "". */
    fun parse(input: InputStream, onEntry: (M3uEntry) -> Unit): String {
        var epg = ""
        var attrs: Map<String, String> = emptyMap()
        var name = ""; var group = ""; var have = false
        BufferedReader(InputStreamReader(input, Charsets.UTF_8), 64 * 1024).forEachLine { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTM3U") -> {
                    val m = attr.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    epg = (m["url-tvg"] ?: m["x-tvg-url"] ?: "").split(',').first().trim()
                }
                line.startsWith("#EXTINF") -> {
                    attrs = attr.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    val idx = line.lastIndexOf("\",")
                    name = (if (idx >= 0) line.substring(idx + 2) else line.substringAfterLast(',')).trim()
                    group = attrs["group-title"] ?: ""
                    have = true
                }
                line.startsWith("#EXTGRP:") -> group = line.removePrefix("#EXTGRP:").trim()
                line.isEmpty() || line.startsWith("#") -> {}
                have -> {
                    onEntry(
                        M3uEntry(
                            name.ifBlank { attrs["tvg-name"] ?: "Channel" }, line,
                            attrs["tvg-logo"] ?: "", group.ifBlank { "Uncategorized" },
                            attrs["tvg-id"] ?: "", attrs["tvg-chno"]?.toIntOrNull()
                        )
                    )
                    have = false
                }
            }
        }
        return epg
    }
}
