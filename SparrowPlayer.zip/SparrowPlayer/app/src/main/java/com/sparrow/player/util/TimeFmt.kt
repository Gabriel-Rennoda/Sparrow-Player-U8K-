package com.sparrow.player.util

import java.util.Calendar
import java.util.Locale

/** Pure (java.util only) clock / date formatting so it can be unit tested on the JVM. */
object TimeFmt {
    /** Set from Settings (and at app start). false = 12 hour clock. */
    @Volatile var is24h = false

    private val DAYS = arrayOf("Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat")
    private val MONTHS = arrayOf("Jan.", "Feb.", "Mar.", "Apr.", "May", "Jun.", "Jul.", "Aug.", "Sep.", "Oct.", "Nov.", "Dec.")

    private fun two(n: Int) = String.format(Locale.US, "%02d", n)

    /** "1:15 am" / "13:15". Written by hand so the locale can never turn am/pm into "a.m." or "AM". */
    fun clock(ms: Long, h24: Boolean = is24h): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val h = c.get(Calendar.HOUR_OF_DAY); val m = c.get(Calendar.MINUTE)
        if (h24) return two(h) + ":" + two(m)
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "$h12:${two(m)} ${if (h < 12) "am" else "pm"}"
    }

    /** "Thurs, Nov. 05     -    1:15 am" (top-left of the guide). */
    fun guideHeader(ms: Long, h24: Boolean = is24h): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return "${DAYS[c.get(Calendar.DAY_OF_WEEK) - 1]}, ${MONTHS[c.get(Calendar.MONTH)]} ${two(c.get(Calendar.DAY_OF_MONTH))}" +
            "     -    " + clock(ms, h24)
    }
}
