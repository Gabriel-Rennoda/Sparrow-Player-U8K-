package com.sparrow.player.ui.epg

import com.sparrow.player.data.Programme
import java.util.TimeZone

/** Pure guide-grid maths (no Android) so it is unit tested: window start, programme blocks, time shifting, OK presses. */
object GuideMath {
    const val HALF = 30 * 60_000L
    const val SPAN = 4                       // visible half-hour columns = 2 hours
    const val PAST = 3 * 3600_000L           // time shifting may go this far back (= EPG import window)
    const val FUTURE = 36 * 3600_000L        // ... and this far ahead

    /** Start of the current half hour in LOCAL time: 4:00->4:00, 4:29->4:00, 4:30->4:30, 4:50->4:30, 4:59->4:30. */
    fun baseStart(now: Long, offsetMs: Long = TimeZone.getDefault().getOffset(now).toLong()): Long =
        Math.floorDiv(now + offsetMs, HALF) * HALF - offsetMs

    fun windowEnd(ws: Long) = ws + SPAN * HALF
    fun minStart(base: Long) = base - PAST
    fun maxStart(base: Long) = base + FUTURE - SPAN * HALF

    /** Move the window by [steps] half hours, never beyond the data we hold. */
    fun shift(ws: Long, base: Long, steps: Int): Long = (ws + steps * HALF).coerceIn(minStart(base), maxStart(base))

    /** One block of a row. start/stop are VISUAL (clipped to the window, never overlapping). prog == null: no information. */
    class Seg(val start: Long, val stop: Long, val prog: Programme?)

    /**
     * Cuts a row into blocks that exactly tile [ws, we). A programme that spans several half hours is ONE block;
     * gaps (and rows with no data at all) become selectable "No information" blocks, so the guide can never dead-end.
     */
    fun segments(progs: List<Programme>, ws: Long, we: Long): List<Seg> {
        val out = ArrayList<Seg>()
        var cursor = ws
        for (p in progs) {
            if (p.stop <= cursor) continue
            if (p.start >= we) break
            if (p.start > cursor) out += Seg(cursor, p.start, null)
            val end = minOf(p.stop, we)
            out += Seg(maxOf(p.start, cursor), end, p)
            cursor = end
            if (cursor >= we) break
        }
        if (cursor < we) out += Seg(cursor, we, null)
        return out
    }

    fun indexAt(segs: List<Seg>, t: Long): Int {
        val i = segs.indexOfFirst { t >= it.start && t < it.stop }
        return if (i >= 0) i else if (t < segs.first().start) 0 else segs.lastIndex
    }

    /** OK key: first press -> time mode, second press within [windowMs] -> "double press" (change channel). */
    class OkTracker(private val windowMs: Long = 500) {
        private var last = -1L
        fun isDouble(now: Long): Boolean {
            val d = last >= 0 && now - last <= windowMs
            last = if (d) -1L else now
            return d
        }
    }
}
