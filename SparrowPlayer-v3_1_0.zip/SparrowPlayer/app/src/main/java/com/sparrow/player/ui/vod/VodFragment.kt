package com.sparrow.player.ui.vod

import android.os.Bundle
import android.os.SystemClock
import android.view.ViewGroup
import android.widget.TextView
import android.view.View
import androidx.core.view.doOnLayout
import androidx.leanback.app.RowsSupportFragment
import androidx.leanback.widget.ArrayObjectAdapter
import androidx.leanback.widget.ClassPresenterSelector
import androidx.leanback.widget.HeaderItem
import androidx.leanback.widget.ListRow
import androidx.leanback.widget.ListRowPresenter
import androidx.leanback.widget.OnItemViewClickedListener
import androidx.leanback.widget.OnItemViewSelectedListener
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Genres
import com.sparrow.player.data.RowSpec
import com.sparrow.player.data.HomeRows
import com.sparrow.player.data.Holidays
import com.sparrow.player.data.Pages
import com.sparrow.player.data.Recommender
import com.sparrow.player.data.Repository
import com.sparrow.player.data.RowCtx
import com.sparrow.player.data.UserRatings
import com.sparrow.player.data.VodCatalog
import com.sparrow.player.data.VodItem
import com.sparrow.player.data.VodLite
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.TabContent
import com.sparrow.player.util.repo
import java.util.Calendar
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Netflix / Disney+ style rows of posters. The page background is the theme and never changes while browsing.
 *
 * Speed (30 000 - 100 000 titles): everything is worked out from the in-memory [VodCatalog] (read once in the background, see
 * Repository.catalog) - no database query per row any more. The first rows are on screen at once, the rest are added in small batches,
 * and the heavy named carousels (Top 10, platforms, moods ...) are cached and slotted in when ready.
 *
 * Rows of the "All" page, top to bottom: Continue Watching, Because You Watched ..., Top Picks, New in <favourite category> (from the
 * profile), the named carousels, Top Rated, Recently Added, then the provider's own categories.
 */
class VodFragment : RowsSupportFragment(), TabContent {
    private val type get() = requireArguments().getString("type")!!
    private var loadJob: Job? = null
    private var bannerJob: Job? = null
    private val plotCache = HashMap<String, String>()
    private var selIndex = 0          // position of the selected poster inside its row (0 = left-most)
    private var lastRow = -1
    private var lastCol = -1
    private var prefetcher: Prefetcher? = null
    private var lastItem: VodItem? = null
    private val specById = HashMap<Long, Spec>()          // the FULL list of every row on screen (a row shows only its first titles; See All shows the rest)
    private var selRow: ListRow? = null                   // the row the selector is on (hold OK / Menu = See All of this row)
    private var cardSel: ClassPresenterSelector? = null
    private var resetPending = false                     // a new page (tab / group) was asked for and its rows are not all in yet
    private var topLocked = false                         // v3.0.0: true from the moment a page starts until the user presses Up / Down (a timer alone ran out on slow pages)
    private var topLockUntil = 0L                         // a new page (tab / group) always starts on the top row: until this time any other row the grid lands on is put back

    /** One row to show: heading, the uids of its titles and (holiday lists) the See All tile in front of them. */
    private class Spec(val title: String, val uids: List<String>, val seeAll: SeeAll? = null)

    private class Plan(val specs: List<Spec>, val namedAt: Int, val empty: Triple<String, String, String>?)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setOnItemViewClickedListener(OnItemViewClickedListener { _, item, _, row ->
            if (item is VodItem) {
                val scope = (activity as? MainActivity)?.groupScope ?: Repository.SCOPE_ALL
                val holiday = scope == Repository.SCOPE_HOLIDAYS || scope == Repository.SCOPE_HOLIDAY_FAVS || scope.startsWith("holiday:")
                // which holiday's row / page the title was opened from (a series then lists only that holiday's episodes)
                val hid = if (scope.startsWith("holiday:")) scope.removePrefix("holiday:")
                    else (row as? ListRow)?.adapter?.let { a -> (0 until a.size()).map { a.get(it) }.filterIsInstance<SeeAll>().firstOrNull()?.scope?.removePrefix("holiday:") } ?: ""
                startActivity(DetailsActivity.intent(requireContext(), item.uid, holiday, hid))
            }
            else if (item is SeeAll) (activity as? MainActivity)?.openGroup(item.scope)
            else if (item is GridTile) specById[item.rowId]?.let { openGrid(it) }
        })
        setOnItemViewSelectedListener(OnItemViewSelectedListener { itemVh, item, rowVh, row ->
            if (row is ListRow && topLocked && SystemClock.uptimeMillis() < topLockUntil && ((adapter as? ArrayObjectAdapter)?.indexOf(row) ?: 0) > 0) {
                setSelectedPosition(0, false)            // Leanback re-applied the previous page's row: back to the top row
                return@OnItemViewSelectedListener
            }
            if (row is ListRow) {
                selRow = row
                if (item != null) selIndex = (row.adapter as? ArrayObjectAdapter)?.indexOf(item) ?: 0      // also on a See All tile: Left from the first poster opens the side panels
            }
            if (item is VodItem && row is ListRow) {
                selIndex = (row.adapter as? ArrayObjectAdapter)?.indexOf(item) ?: 0
                onSelected(item)
                prefetchAround(row, item)
                requireContext().applicationContext.repo.prefetchInfo(item)
            }
        })
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefetcher = Prefetcher(requireContext().applicationContext)
        verticalGridView?.setPadding(0, verticalGridView!!.paddingTop, 0, verticalGridView!!.paddingBottom)   // no stock side margin: rows start flush with the title line
        loadRows(true)
    }

    // ---- See All ---------------------------------------------------------------------------------------------------
    /** Opens the grid of every title of [s]; what a poster opened from there belongs to (a holiday page) is passed along. */
    private fun openGrid(s: Spec) {
        val scope = (activity as? MainActivity)?.groupScope ?: Repository.SCOPE_ALL
        val holiday = scope == Repository.SCOPE_HOLIDAYS || scope == Repository.SCOPE_HOLIDAY_FAVS || scope.startsWith("holiday:")
        val hid = if (scope.startsWith("holiday:")) scope.removePrefix("holiday:") else s.seeAll?.scope?.removePrefix("holiday:") ?: ""
        val token = SeeAllStore.put(SeeAllStore.Entry(s.title, s.uids, holiday, hid, type))
        startActivity(SeeAllActivity.intent(requireContext(), token))
    }

    /** Hold OK / Menu on any poster: the grid of the row the selector is on. False when no row is selected. */
    fun seeAllSelected(): Boolean {
        val row = selRow ?: return false
        val s = specById[row.headerItem?.id ?: return false] ?: return false
        if (s.uids.isEmpty()) return false
        openGrid(s)
        return true
    }

    // ---- rows ---------------------------------------------------------------------------------------------------
    private fun spec(title: String, l: List<VodLite>) = Spec(title, l.map { it.uid })

    /** [reset]: a new page (tab or group): start on the top row, first title. False = refresh in place, keep the position. */
    private fun loadRows(resetReq: Boolean = false) {
        // v3.0.0: a refresh in place (TMDB ratings arriving, a hidden title ...) that cancels a page load which has not finished yet used to leave the selector on the
        // PREVIOUS page's row (a big catalogue like Movies is slow enough for that to happen). The unfinished page load hands its "start on the top row" on.
        val reset = resetReq || resetPending
        resetPending = reset
        loadJob?.cancel()
        // v3.1.0: choosing another group clears the old posters at once (and shows "Loading…"), so it is clear the app is switching over; the new page fades in
        if (resetReq) { setAdapter(ArrayObjectAdapter(SparrowRowPresenter())); view?.alpha = 0f; (activity as? MainActivity)?.showHero("Loading…", "", "", 0) }
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val main = activity as? MainActivity
            val p = repo.activeProvider()
            if (p == null) { view?.alpha = 1f; main?.contentReady(); return@launch }
            if (adapter == null || adapter.size() == 0) main?.showHero("Loading…", "", "", 0)
            val cat = repo.catalog(p.id, type)
            val scope = main?.groupScope ?: Repository.SCOPE_ALL

            // the heavy named carousels are only wanted by the "All" page; ask for them now, use them if they are ready within a moment
            val named = if (scope == Repository.SCOPE_ALL) repo.namedRows(cat) else null
            val ready = if (named != null) withTimeoutOrNull(300) { named.await() } else null

            val plan = withContext(Dispatchers.Default) { hideRows(repo, limitPlan(repo, cat, buildPlan(repo, cat, scope, ready))) }
            val cards = ClassPresenterSelector()
                .addClassPresenter(VodItem::class.java, CardPresenter()).addClassPresenter(SeeAll::class.java, SeeAllPresenter())
                .addClassPresenter(GridTile::class.java, GridTilePresenter())
            cardSel = cards
            specById.clear(); selRow = null
            fun row(id: Long, s: Spec): ListRow = makeRow(cat, cards, id, s)

            if (reset) { topLocked = true; topLockUntil = SystemClock.uptimeMillis() + 90_000 }
            val hadFocus = view?.hasFocus() == true
            val keepRow = if (topLocked) 0 else selectedPosition           // nobody moved up / down on this page yet: the top row
            val rows = ArrayObjectAdapter(SparrowRowPresenter())
            var id = 0L
            val first = plan.specs.take(FIRST_ROWS)
            for (s in first) rows.add(row(id++, s))
            setAdapter(rows)
            view?.let { v -> if (v.alpha < 1f) v.animate().alpha(1f).setDuration(250).start() }
            // Leanback re-applies the PREVIOUS page's row position to a new adapter (the "starts several rows down" bug): a new page always starts on the top row
            if (reset) { setSelectedPosition(0, false); selIndex = 0 }
            else if (hadFocus && keepRow in 0 until rows.size()) setSelectedPosition(keepRow)
            lastRow = -1; lastCol = -1
            prefetchStart(rows)
            if (rows.size() == 0) main?.hideBanner()
            if (rows.size() == 0 && plan.empty != null) main?.showHero(plan.empty.first, plan.empty.second, plan.empty.third, 0)
            main?.contentReady()
            alignRows()

            // the carousels that were not ready: slot them in after the profile rows (the selection stays on the row it was on)
            if (named != null && ready == null) launchLateRows(named, rows, cat, plan.namedAt, cards)

            // the remaining rows, a few at a time, so the screen keeps answering the remote
            var n = FIRST_ROWS
            while (n < plan.specs.size) {
                val end = minOf(n + BATCH_ROWS, plan.specs.size)
                for (k in n until end) rows.add(row(id++, plan.specs[k]))
                n = end
                delay(60)
            }
            resetPending = false
            if (reset) { topLockUntil = SystemClock.uptimeMillis() + 4000; if (topLocked && selectedPosition > 0) setSelectedPosition(0, false) }
        }
    }

    // ---- the rows start at the same left edge as the "Hold OK = See All" line (v2.9.0): measured on the screen, so it holds on every theme ----------
    private fun firstText(v: View): TextView? {
        if (v is TextView) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) firstText(v.getChildAt(i))?.let { return it }
        return null
    }

    private fun alignRows() {
        val grid = verticalGridView ?: return
        grid.postDelayed({
            val main = activity as? MainActivity ?: return@postDelayed
            val target = main.heroLeftOnScreen()
            val head = grid.getChildAt(0)?.let { firstText(it) }
            if (target >= 0 && head != null && head.isShown) {
                val loc = IntArray(2); head.getLocationOnScreen(loc)
                val delta = loc[0] + head.paddingLeft - target
                if (Math.abs(delta) > 1 && Math.abs(delta) < 400) grid.translationX = grid.translationX - delta
            }
        }, 350)
    }

    /** One row: the first [HomeRows.ROW_CAP] titles, then (when there are more) the See All tile. The full list is kept for the grid. */
    private fun makeRow(cat: VodCatalog, cards: ClassPresenterSelector, id: Long, s: Spec): ListRow {
        specById[id] = s
        val items = ArrayList<Any>(HomeRows.ROW_CAP + 2)
        if (s.seeAll != null) items += s.seeAll
        items.addAll(cat.items(s.uids.take(HomeRows.ROW_CAP)))
        if (s.uids.size > HomeRows.ROW_CAP) items += GridTile(id, s.title, s.uids.size)
        return ListRow(HeaderItem(id, s.title), ArrayObjectAdapter(cards).apply { addAll(0, items) })
    }

    private fun launchLateRows(named: kotlinx.coroutines.Deferred<List<com.sparrow.player.data.RowSpec>>, rows: ArrayObjectAdapter, cat: VodCatalog, at: Int, cards: ClassPresenterSelector) {
        viewLifecycleOwner.lifecycleScope.launch {
            val specs = named.await()
            if (adapter !== rows || specs.isEmpty()) return@launch
            val sel = selectedPosition
            val hadFocus = view?.hasFocus() == true
            val blocked = withContext(Dispatchers.Default) { requireContext().repo.blockedFor(cat) }
            val hiddenRows = requireContext().repo.hiddenVodRows()
            val made = specs.filter { s -> com.sparrow.player.data.VodHide.rowKey(type, s.title) !in hiddenRows }
                .map { s -> Spec(s.title, if (blocked == null) s.uids else s.uids.filter { it !in blocked }) }
                .filter { it.uids.isNotEmpty() }.mapIndexed { i, s -> makeRow(cat, cards, 1_000_000L + i, s) }
            val pos = at.coerceIn(0, rows.size())
            rows.addAll(pos, made)
            if (hadFocus && sel >= pos) setSelectedPosition(sel + made.size, false)
        }
    }

    /** Carousels the profile hid (See All -> Hide This Carousel) leave the page. */
    private fun hideRows(repo: Repository, plan: Plan): Plan {
        val hr = repo.hiddenVodRows()
        if (hr.isEmpty()) return plan
        val specs = plan.specs.filter { com.sparrow.player.data.VodHide.rowKey(type, it.title) !in hr }
        return Plan(specs, minOf(plan.namedAt, specs.size), plan.empty)
    }

    /** A profile with an age limit (Content Preferences) sees no title above it in any row: titles are taken out of every row and a row left empty is dropped. */
    private fun limitPlan(repo: Repository, cat: VodCatalog, plan: Plan): Plan {
        val blocked = repo.blockedFor(cat) ?: return plan
        val specs = ArrayList<Spec>(plan.specs.size)
        for (s in plan.specs) {
            val kept = s.uids.filter { it !in blocked }
            if (kept.isEmpty()) continue
            specs += if (kept.size == s.uids.size) s else Spec(s.title, kept, s.seeAll)
        }
        return Plan(specs, minOf(plan.namedAt, specs.size), plan.empty)
    }

    /** The rows of the page for [scope], worked out on a background thread from the catalogue. [named]: the ready named carousels (All page). */
    private fun buildPlan(repo: Repository, cat: VodCatalog, scope: String, named: List<com.sparrow.player.data.RowSpec>?): Plan {
        val prefs = repo.prefs
        val profileName = repo.activeProfile().name
        val nowMs = System.currentTimeMillis()
        val known = repo.maturities()
        val hist = prefs.history()
        val watched = hist.mapNotNull { cat.lite(it.uid) }                       // newest first; only this kind of title is in the catalogue
        val verdicts = repo.myRatings()
        val rated = verdicts.keys.mapNotNull { cat.lite(it) }
        val verdictOf = rated.associate { it.uid to (verdicts[it.uid] ?: "") }
        val profile = Recommender.profile(watched.map { cat.rec(it) }, rated.map { cat.rec(it) to (verdictOf[it.uid] ?: "") })
        val country = if (prefs.isCanada) "Canada" else "United States"

        if (scope == Repository.SCOPE_HOLIDAYS) {
            // ---- The Holidays: for each holiday (calendar order from the next one) its "Top 10 What's Hot"; OK on "See All" opens its page
            val c = Calendar.getInstance()
            val today = Holidays.epochDay(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
            val specs = Pages.holidayList(cat, today, prefs.isCanada, nowMs).map { (d, uids) ->
                val head = d.holiday.name + "  •  " + (if (d.recentlyPassed) "Just Passed " else "") + Holidays.label(d.day) + "  –  Top 10 What's Hot"
                Spec(head, uids, SeeAll("holiday:" + d.holiday.id, d.holiday.name))
            }
            return Plan(specs, 0, Triple("No Holiday Titles Found", "", "Titles with holiday words in their name, category or description (Christmas, Halloween, Easter ...) appear here, one row per holiday."))
        }
        if (scope == Repository.SCOPE_HOLIDAY_FAVS) {
            val mine = repo.holidayFavUids().filter { cat.indexOf(it) >= 0 }
            return Plan(if (mine.isEmpty()) emptyList() else listOf(Spec("My Holiday Favourites", mine)), 0,
                Triple("My Holiday Favourites", "", "Nothing saved yet. Open a title and choose ＋ My Holiday Favourites to keep it here."))
        }
        if (scope.startsWith("holiday:")) {
            // ---- one holiday's page: What's Hot, Continue Watching, Top Picks, Holiday Classics, Cult Followings (all its titles)
            val hol = Holidays.ALL.firstOrNull { it.id == scope.removePrefix("holiday:") } ?: return Plan(emptyList(), 0, null)
            val progress = watched.filter { prefs.inProgress(cat.type, it.uid) }.map { it.uid }
            val specs = HomeRows.holiday(hol, cat.titles, RowCtx(nowMs, type == "movie", country, profileName, maturity = known), progress) { t ->
                cat.lite(t.uid)?.let { Recommender.score(profile, cat.rec(it)) } ?: 0.0
            }.map { Spec(it.title, it.uids) }
            return Plan(specs, 0, Triple("No ${hol.name} Titles", "", "Nothing in this playlist mentions this holiday yet."))
        }
        if (scope.startsWith(Genres.SCOPE_PREFIX)) {
            // ---- a main genre or one of its sub-genres: the same kinds of carousels as All Movies / All Series, made from THIS group's titles
            val (mainId, sub) = Pages.parseGenreScope(scope)
            val main = Genres.mainOf(mainId) ?: return Plan(emptyList(), 0, null)
            val label = if (sub != null) main.subs[sub].name else main.name
            val out = ArrayList<Spec>()
            val picks = Pages.genrePicks(cat, main, sub, known)
            val pickUids = picks.map { it.uid }.toHashSet()
            val inProgress = watched.filter { it.uid in pickUids && prefs.inProgress(cat.type, it.uid) }.map { it.uid }
            if (inProgress.isNotEmpty()) out += Spec("Continue Watching for $profileName", inProgress.take(HomeRows.FULL))
            if (watched.isNotEmpty() || rated.isNotEmpty()) {
                val gone = watched.map { it.uid }.toSet() + rated.filter { verdictOf[it.uid] == UserRatings.DISLIKED }.map { it.uid }.toSet()
                val recs = picks.mapNotNull { t -> cat.lite(t.uid)?.let { cat.rec(it) } }
                val forYou = Recommender.forYou(profile, recs, gone, 30).map { it.uid }
                if (forYou.size >= HomeRows.MIN_ROW) out += Spec("Top Picks for $profileName in $label", forYou)
            }
            val finished = watched.filter { !prefs.inProgress(cat.type, it.uid) }.map { it.uid }
            val named = HomeRows.build(picks, RowCtx(nowMs, type == "movie", country, profileName, finished, repo.myListUids(), verdicts, known, label))
            for (r in named) out += Spec(r.title, r.uids)
            out += Pages.genre(cat, main, sub, known).map { Spec(it.title, it.uids) }
            return Plan(out, 0, Triple("No Titles In $label", "", "Nothing in this playlist is filed under this genre."))
        }

        // ---- All: what the profile watched first, then the named carousels, then the provider's own rows
        val out = ArrayList<Spec>()
        val watchedUids = watched.map { it.uid }.toSet()
        val shown = HashSet<String>()
        fun add(s: Spec) { if (s.uids.isNotEmpty()) out += s }

        add(spec("Continue Watching for $profileName", watched.filter { prefs.inProgress(cat.type, it.uid) }.take(20)))

        val disliked = rated.filter { verdictOf[it.uid] == UserRatings.DISLIKED }.map { it.uid }.toSet()
        val exclude = watchedUids + disliked
        val lovedSeed = verdicts.keys.toList().asReversed().firstOrNull { verdictOf[it] == UserRatings.LOVED }?.let { cat.lite(it) }

        if (watched.isNotEmpty() || rated.isNotEmpty()) {
            val pool = LinkedHashMap<String, VodLite>()
            fun pull(l: List<VodLite>) { l.forEach { pool.putIfAbsent(it.uid, it) } }
            val topCats = Recommender.topKeys(profile.categories, 4)
            for (c in topCats) pull(cat.inCategory(c, 200))
            for (g in Recommender.topKeys(profile.genres, 3)) pull(cat.byGenre(g, 200))
            val seeds = ArrayList<VodLite>()
            watched.firstOrNull()?.let { seeds += it }
            if (seeds.isNotEmpty()) watched.drop(1).firstOrNull { w -> Recommender.similarity(cat.rec(seeds[0]), cat.rec(w)) < 2.0 }?.let { seeds += it }
            val verb = HashMap<String, String>()
            if (lovedSeed != null && seeds.none { it.uid == lovedSeed.uid }) { seeds.add(0, lovedSeed); verb[lovedSeed.uid] = "Because You Loved " }
            else if (lovedSeed != null) verb[lovedSeed.uid] = "Because You Loved "
            for (s in seeds) if (s.categoryId !in topCats) pull(cat.inCategory(s.categoryId, 200))
            pull(cat.topRated(100))
            val recs = pool.values.map { cat.rec(it) }

            for (s in seeds) {
                val l = Recommender.becauseYouWatched(cat.rec(s), recs, exclude, 20).map { it.uid }
                add(Spec((verb[s.uid] ?: "Because You Watched ") + s.name, l))
                shown += l
            }
            val forYou = Recommender.forYou(profile, recs, exclude + shown, 30).map { it.uid }
            add(Spec("Top Picks for $profileName", forYou))
            shown += forYou

            topCats.firstOrNull()?.let { c ->
                add(spec("New in " + (cat.categoryNames[c] ?: "Your Favourites"), cat.inCategory(c, 60).filter { it.uid !in exclude && it.uid !in shown }.take(30)))
            }
        }
        val namedAt = out.size
        if (named != null) for (r in named) add(Spec(r.title, r.uids))
        add(spec("Top Rated", cat.topRated(HomeRows.FULL * 2).filter { it.uid !in exclude && Recommender.ratingOf(it.rating) >= 6.5 }.take(HomeRows.FULL)))
        add(spec("Recently Added", cat.recent(HomeRows.FULL)))
        return Plan(out + categoryRows(repo, cat), namedAt, Triple("Nothing Here Yet", "", "Sync your playlist (Settings → EPG → Sync Now) to load movies and series."))
    }

    /** The provider's own categories, in the provider's order. */
    private fun categoryRows(repo: Repository, cat: VodCatalog): List<Spec> {
        val out = ArrayList<Spec>()
        // category ids in the provider's order: the catalogue knows their names; the order of the name map is the database order
        for ((cid, name) in cat.categoryNames) {
            val l = cat.inCategory(cid, HomeRows.FULL)
            if (l.isNotEmpty()) out += Spec(name, l.map { it.uid })
        }
        return out
    }

    // ---- look-ahead image loading -----------------------------------------------------------------------------
    private fun rowItems(rows: ArrayObjectAdapter, r: Int): ArrayObjectAdapter? =
        ((if (r in 0 until rows.size()) rows.get(r) else null) as? ListRow)?.adapter as? ArrayObjectAdapter

    private fun posterAt(a: ArrayObjectAdapter?, i: Int): String? =
        if (a != null && i in 0 until a.size()) (a.get(i) as? VodItem)?.poster else null

    /** First screenful, before anything is selected. */
    private fun prefetchStart(rows: ArrayObjectAdapter) {
        val urls = ArrayList<String>()
        for (r in 0..2) { val a = rowItems(rows, r); for (i in 0..13) posterAt(a, i)?.let { urls += it } }
        prefetcher?.want(urls)
    }

    /**
     * Selection moved: load the posters the user is heading for. Along the row: 10 ahead in the direction of travel (and
     * 3 behind). Up / down: the neighbouring rows around this column (both directions the first time).
     */
    private fun prefetchAround(row: ListRow, item: VodItem) {
        val rows = adapter as? ArrayObjectAdapter ?: return
        val ri = rows.indexOf(row)
        val cur = row.adapter as? ArrayObjectAdapter ?: return
        val ci = cur.indexOf(item)
        val dirX = if (ri == lastRow && lastCol >= 0) Integer.signum(ci - lastCol) else 0
        val dirY = if (lastRow < 0) 0 else Integer.signum(ri - lastRow)
        lastRow = ri; lastCol = ci
        val dx = if (dirX == 0) 1 else dirX
        val urls = ArrayList<String>()
        for (k in 1..20) posterAt(cur, ci + dx * k)?.let { urls += it }      // a long look-ahead: the first trip along a row was limited by posters still arriving
        for (k in 1..3) posterAt(cur, ci - dx * k)?.let { urls += it }
        posterAt(cur, ci)?.let { urls += it }
        val targets = when (dirY) { 1 -> listOf(ri + 1, ri + 2); -1 -> listOf(ri - 1, ri - 2); else -> listOf(ri - 1, ri + 1) }
        for (r in targets) { val a = rowItems(rows, r); for (i in ci - 2..ci + 10) posterAt(a, i)?.let { urls += it } }
        prefetcher?.want(urls)
    }

    // ---- TabContent -------------------------------------------------------------------------------------------
    override fun focusContent(): Boolean {
        val grid = verticalGridView ?: return false
        if (adapter == null || adapter.size() == 0) return false
        grid.doOnLayout { it.requestFocus() }
        return true
    }

    override fun scrollView(): View? = verticalGridView

    override fun isAtLeftEdge() = selIndex <= 0

    override fun isAtTop() = selectedPosition <= 0

    /** The user pressed Up / Down on this page: from now on the selector goes where the remote sends it. */
    fun userMovedVertically() { topLocked = false }

    override fun onGroupChanged() { loadRows(true); (activity as? MainActivity)?.wantFocus() }

    override fun reload() {
        val hadFocus = view?.hasFocus() == true
        loadRows()
        if (hadFocus) (activity as? MainActivity)?.wantFocus()
    }

    /**
     * A poster is selected. The title, year and rating are not written in the slim top line any more (the posters are big enough to carry them; the rating
     * badges stay on the poster itself): that line only clears a "Loading…" / empty-page message and keeps the "Hold OK = See All" hint.
     * With the hero banner switched on (Settings -> General) the banner above the rows shows the title's name, year / rating / genre and description.
     */
    private fun onSelected(v: VodItem) {
        lastItem = v
        val main = activity as? MainActivity ?: return
        // the selected title's name (and year / rating) on the slim top line, as in See All
        val sub = listOf(v.year, CardPresenter.ratingText(v)).filter { it.isNotBlank() }.joinToString("   ")
        main.showHero(v.name, if (sub.isEmpty()) "" else "•   $sub", "")
        val repo = requireContext().repo
        if (!repo.prefs.heroBanner) { main.hideBanner(); return }
        val cached = plotCache[v.uid] ?: v.plot
        main.showBanner(v.name, metaOf(v), cached)
        bannerJob?.cancel()
        // the catalogue rows carry no description: fetch the highlighted title's own one (one row by key) once the selection rests
        if (cached.isBlank() && plotCache[v.uid] == null) {
            bannerJob = viewLifecycleOwner.lifecycleScope.launch {
                delay(150)
                val plot = repo.dao.vod(v.uid)?.plot ?: ""
                plotCache[v.uid] = plot
                if (lastItem?.uid == v.uid) (activity as? MainActivity)?.showBanner(v.name, metaOf(v), plot)
            }
        }
    }

    private fun metaOf(v: VodItem) = listOf(v.year, CardPresenter.ratingText(v), v.genre).filter { it.isNotBlank() }.joinToString("   •   ")

    override fun onResume() {
        super.onResume()
        // Back from the player / details: refresh the progress bars on the cards and in the hero, keeping the position.
        lastItem?.let { onSelected(it) }
        val rows = adapter as? ArrayObjectAdapter ?: return
        for (r in 0 until rows.size()) rowItems(rows, r)?.let { it.notifyArrayItemRangeChanged(0, it.size()) }
    }

    override fun onDestroyView() {
        loadJob?.cancel(); bannerJob?.cancel()
        prefetcher?.cancel(); prefetcher = null
        super.onDestroyView()
    }

    companion object {
        private const val FIRST_ROWS = 10
        private const val BATCH_ROWS = 10
        fun newInstance(type: String) = VodFragment().apply { arguments = Bundle().apply { putString("type", type) } }
    }
}
