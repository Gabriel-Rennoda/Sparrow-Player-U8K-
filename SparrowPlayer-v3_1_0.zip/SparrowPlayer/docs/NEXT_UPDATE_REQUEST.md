# Next update (v3.2.0) - copy / paste this into the next chat
Same rules: investigate and test each item before changing code, apply in stages, test for the 75" U8K remote, then give me the updated zip. If anything is not completed, write a new copy-paste document.

Version 3.1.0 is the base (written WITHOUT a compiler). FIRST check the GitHub build log for the 3.1.0 run (versionCode 41) and fix compile errors before anything else. Check docs/TV_TEST_CHECKLIST_3_1.md (my results are pasted below).

Done in 3.1.0: long-press Left, Live TV Back confirm, double-Back exit removed, keyboard keeps the selector, arrow 1 s return delay, 0.25 s fades, "Never", Kids uses the title's own genres, search focus / clearing, group switch transition, details page age badge + grey Play, backup keeps wake-up + opening channel, restart prompt, restore on Add Playlist, TMDB notice, S0 (tmdbId column, schema 2, migration + unit test, filled from get_vod_streams / get_series).

NOT done (each needs its own build + TV test):
S2 TMDB genres + animation + family tags for genre groups / carousels (needs tmdbId stored: now available).
S3 TMDB keywords for holiday carousels + holiday pre-menu (23).
S0 TMDB logo on Settings / About (send me the logo file or allow a download in the build; the notice text is already in About).
19 / 20 multiple custom Favourites sections; Copy To for Movies / Series.
12 live sync.
3 / 6 four-channel split screen.
"Bigger watched badges on posters": tell me what you want on the poster (a tick on finished titles?).
Kids: if titles still slip in, send photos: the filter now trusts the title's own genre text, so a title with NO genre text still relies on its category.
