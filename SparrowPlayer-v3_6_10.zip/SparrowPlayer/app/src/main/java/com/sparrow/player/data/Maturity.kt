package com.sparrow.player.data

/**
 * Age ratings for the "Children & Family" genre. IPTV lists carry NO age rating, so this is evidence based and says so:
 *
 *  1. A rating the panel told us (remembered when a details page was opened, see [MetaCache]) is trusted: only TV-Y, TV-G, G, TV-PG, PG and PG-13 pass.
 *     TV-14, TV-MA, R and NC-17 never do (TV-14 is kept out on purpose: Rick and Morty is TV-14).
 *  2. A rating written in the title or category ("[TV-MA]") counts the same way.
 *  3. Words that say "not for children" in the category / genre (adult, mature, 18+, horror ...) or a well-known adult cartoon in the title keep
 *     it out. Crime / thriller / war only do so when nothing says "family" or "kids" (Despicable Me is tagged Crime on many panels).
 *  4. What is left needs a reason to be here: kids / family / children / Disney ... in its category or genre, or a well-known children's title. A film that is only "animation"
 *     is let through; a SERIES that is only "animation" waits until its rating is known (adult cartoons are mostly series).
 * Pure Kotlin, unit tested.
 */
object Maturity {
    val FAMILY_OK = setOf("TV-Y", "TV-G", "G", "TV-PG", "PG", "PG-13")

    fun familyOk(code: String) = code in FAMILY_OK

    // ---- age limits of a profile (Content Preferences) ----------------------------------------------------------------
    /** (limit code, label): the highest rating a profile may see. "" = no limit. */
    val LIMITS: List<Pair<String, String>> = listOf(
        "" to "No Limit",
        "R" to "Up To R  (Hides NC-17 / Adults Only)",
        "TV-14" to "Up To TV-14",
        "PG-13" to "Up To PG-13",
        "PG" to "Up To PG",
        "G" to "G / TV-G Only"
    )
    private val SET_G = setOf("TV-Y", "TV-G", "G")
    private val SET_PG = SET_G + setOf("TV-PG", "PG")
    private val SET_PG13 = SET_PG + "PG-13"
    private val SET_TV14 = SET_PG13 + "TV-14"
    private val SET_R = SET_TV14 + setOf("R", "TV-MA")

    /** The ratings a limit lets through; null = no limit. */
    fun ratingsFor(limit: String): Set<String>? = when (limit) {
        "G" -> SET_G; "PG" -> SET_PG; "PG-13" -> SET_PG13; "TV-14" -> SET_TV14; "R" -> SET_R; else -> null
    }

    /** Words that put a title with no rating out of even the mildest limit (Up To R / Up To TV-14). */
    private val ADULT_ONLY = listOf("xxx", "erotic", "porn", "adults only", "adult only", "nc 17", "uncut", "uncensored", "explicit")

    /**
     * May a profile with age [limit] see this title? A rating the panel gave, or written in the title / category, decides. When nothing says what it is rated
     * the Kids filter's evidence is used: for PG-13 and under the title must pass [familyOk] (no adult words, no well-known adult cartoon; a series also needs a family
     * / kids sign), for Up To TV-14 / R only adults-only words and (TV-14) well-known adult cartoons keep it out.
     */
    fun allowed(limit: String, known: String, rawName: String, category: String, nameNorm: String, prepared: String, series: Boolean, strict: Boolean = false): Boolean {
        val ok = ratingsFor(limit) ?: return true
        val code = if (known.isNotEmpty()) known else MediaTags.maturity("$rawName $category")
        if (code.isNotEmpty()) return code in ok
        // Strict (Child profiles): nothing says what it is rated, so it only shows when something says "kids / family" (category, genre or a well-known children's title).
        if (strict && limit in STRICT_LIMITS) return hasKidsSign(nameNorm, prepared) && familyOk("", rawName, category, nameNorm, prepared, series)
        if (limit == "R") return !TextNorm.hasAny(prepared, ADULT_ONLY)
        if (limit == "TV-14") return !TextNorm.hasAny(prepared, ADULT_ONLY) && !isAdultTitle(nameNorm)
        return familyOk("", rawName, category, nameNorm, prepared, series)
    }

    fun allowed(limit: String, t: RowTitle, known: String, series: Boolean, strict: Boolean = false): Boolean =
        !(strict && limit in STRICT_LIMITS && !genreKidsOk(genreOf(t))) && allowed(limit, known, t.name, t.category, t.nameNorm, t.prepared, series, strict)

    /** The limits Strict applies to (the ones a Child profile can have). */
    private val STRICT_LIMITS = setOf("PG-13", "PG", "G")

    /** Does the category / genre text or the title say "kids / family" (and is it not a well-known adult cartoon)? */
    fun hasKidsSign(nameNorm: String, prepared: String): Boolean = TextNorm.hasAny(prepared, STRONG) || isKidsTitle(nameNorm)

    /** Rating code for an age number from a panel (\"16\", \"18+\"); "" when it is not one. */
    fun fromAge(n: Int): String = when {
        n >= 18 -> "TV-MA"; n >= 16 -> "R"; n >= 14 -> "TV-14"; n >= 13 -> "PG-13"; n >= 10 -> "TV-PG"; n >= 1 -> "TV-Y"; else -> ""
    }

    /** "PG-13", "TV-MA", "Rated R", "16", "18+" -> a code of [MediaTags.MATURITIES]; "" if it says nothing. */
    fun normalize(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return ""
        val m = MediaTags.maturity(s)
        if (m.isNotEmpty()) return m
        if (s.length <= 4 && s.all { it.isDigit() || it == '+' }) return fromAge(s.filter { it.isDigit() }.toIntOrNull() ?: 0)
        return ""
    }

    private val STRONG = listOf("kids", "kid", "children", "childrens", "family", "families", "disney", "pixar", "junior", "toddler", "toddlers",
        "preschool", "nick jr", "nickelodeon", "baby")
    /** Never for children, whatever else the text says. */
    private val UNSAFE = listOf("adult", "adults", "mature", "erotic", "xxx", "18", "tv ma", "tv 14", "nc 17", "uncut", "uncensored", "explicit",
        "after dark", "adult swim", "horror", "slasher")
    private val GROWN_TV = listOf("hallmark", "lifetime", "lmn", "romance movies", "romantic movies", "erotic thriller", "mystery movies", "murder mystery")
    private val GROWN_NAME = listOf("murder", "murders", "murdered", "killer", "killers", "affair", "affairs", "seduction", "seduced", "stalker", "stalked", "deadly", "kidnapped", "obsession", "betrayal", "sins", "scandal", "mistress", "cheating", "cheater")
    /** Genre words that are common on family films too (Despicable Me is "Animation, Family, Comedy, Crime"): they only keep a title out when nothing says "family". */
    private val UNSAFE_UNLESS_FAMILY = listOf("crime", "true crime", "thriller", "thrillers", "zombie", "zombies", "gangster", "mafia", "war")

    /** Well-known children's titles and brands (title starts with one of them): let through even when the panel's genre text is poor or missing. */
    private val KIDS_TITLES = listOf(
        "paw patrol", "bluey", "peppa pig", "sesame street", "dora the explorer", "spongebob", "sponge bob", "mickey mouse", "mickey and", "winnie the pooh",
        "toy story", "finding nemo", "finding dory", "moana", "shrek", "madagascar", "kung fu panda", "how to train your dragon", "despicable me", "minions",
        "cocomelon", "pj masks", "blue s clues", "thomas and friends", "thomas the tank engine", "barbie", "lego", "trolls", "ice age", "encanto", "zootopia",
        "paddington", "the lion king", "aladdin", "beauty and the beast", "the little mermaid", "tangled", "cinderella", "snow white", "lilo and stitch", "monsters inc",
        "the incredibles", "inside out", "wall e", "ratatouille", "kung fu panda", "puss in boots", "the secret life of pets", "hotel transylvania",
        "the garfield", "garfield", "scooby doo", "tom and jerry", "looney tunes", "the smurfs", "alvin and the chipmunks", "curious george", "arthur",
        "daniel tiger", "octonauts", "wonder pets", "dragon tales", "caillou", "max and ruby", "pokemon", "teenage mutant ninja turtles", "the magic school bus",
        "ben and holly", "hey duggee", "numberblocks", "gabby s dollhouse", "miraculous", "the loud house", "the amazing world of gumball", "adventure time", "steven universe",
        "phineas and ferb", "gravity falls", "doc mcstuffins", "sofia the first", "elena of avalor", "puppy dog pals", "the wiggles", "veggietales", "chip n dale",
        // v3.2.0: more well-known children's films / shows (Frozen was missing, so it never reached Kids)
        "frozen", "cars 2", "cars 3", "sing 2", "rio 2", "coco 2", "the muppets", "muppet movie", "onward", "turning red", "big hero 6", "wreck it ralph", "ralph breaks the internet",
        "the princess and the frog", "mulan", "pocahontas", "bambi", "dumbo", "sleeping beauty", "peter pan", "pinocchio", "fantasia",
        "the jungle book", "the aristocats", "101 dalmatians", "one hundred and one dalmatians", "the emperor s new groove", "raya and the last dragon", "strange world",
        "the croods", "the lego movie", "the lego batman movie", "cloudy with a chance of meatballs", "chicken run", "wallace and gromit", "shaun the sheep",
        "the iron giant", "happy feet", "megamind", "the bad guys", "the boss baby", "storks", "abominable", "klaus", "the mitchells vs the machines", "ferdinand",
        "open season", "over the hedge", "flushed away", "bee movie", "monsters university", "monsters vs aliens", "the peanuts movie",
        "the smurfs", "the addams family", "rango", "the wild robot", "the super mario bros movie",
        "sonic the hedgehog", "trolls", "kung fu panda", "mr peabody and sherman", "hoodwinked", "norm of the north", "the nut job", "smallfoot", "playmobil", "paw patrol",
        "gnomeo and juliet", "cats and dogs", "stuart little", "charlotte s web", "free willy", "the parent trap", "home alone",
        "mary poppins", "the sound of music", "chitty chitty bang bang", "high school musical", "the muppets", "bob the builder",
        "fireman sam", "postman pat", "the cat in the hat", "horton hears a who", "the grinch", "the lorax", "dr seuss", "the very hungry caterpillar", "the gruffalo",
        "room on the broom", "peter rabbit", "winnie the pooh", "christopher robin", "the little rascals", "night at the museum", "diary of a wimpy kid",
        "tinker bell", "the princess diaries", "cheaper by the dozen", "air bud", "marmaduke", "garfield", "alvin and the chipmunks", "ice age", "minions"
    ).map { " $it " }

    /**
     * v3.2.0: the DESCRIPTION as a Kids clue (in [TextNorm] form). Only wording that is about the audience, never a plot word that adult films use too; the age
     * screen ([familyOk]) and the title's own genres still apply on top.
     */
    private val PLOT_KIDS = listOf("preschool", "preschoolers", "toddler", "toddlers", "for kids", "for children", "young children", "nursery rhymes", "kids show",
        "little ones", "learn the alphabet", "learn to count", "sing along", "singalong", "talking animals", "animated adventure", "animated family")
    fun plotKidsSign(plotPrepared: String): Boolean = TextNorm.hasAny(plotPrepared, PLOT_KIDS)

    /** Language / quality tags a panel puts in front of a title ("EN - Frozen", "4K - Moana"). */
    private val NAME_PREFIX = setOf("en", "us", "uk", "ca", "fr", "es", "de", "4k", "hd", "uhd", "fhd", "3d", "multi", "vod")

    fun isKidsTitle(nameNorm: String): Boolean {
        if (KIDS_TITLES.any { nameNorm.startsWith(it) }) return true
        // v3.4.0: Frozen was missing from Kids; a tag in front of the name stopped the "starts with" test. Up to three such tags are skipped.
        var s = nameNorm.trim(); var n = 0
        while (n < 3) {
            val sp = s.indexOf(' ')
            if (sp <= 0 || s.substring(0, sp) !in NAME_PREFIX) break
            s = s.substring(sp + 1).trimStart(); n++
        }
        if (n == 0) return false
        val t = " $s "
        return KIDS_TITLES.any { t.startsWith(it) }
    }

    /** v3.4.0: set by the repository: the genres TMDB gave for a title ("" = none known yet). */
    @Volatile var genreLookup: (String) -> String = { "" }

    /** The title's genre text: the panel's list (movies: the other category names) plus what TMDB said. */
    private fun genreOf(t: RowTitle): String { val g = genreLookup(t.uid); return if (g.isEmpty()) t.genre else if (t.genre.isBlank()) g else t.genre + ", " + g }

    /** TMDB says Animation AND Family (or Kids): a film like Frozen belongs on the Kids page (the age screen still applies). */
    fun animFamilyGenre(uid: String): Boolean {
        val g = genreLookup(uid); if (g.isEmpty()) return false
        val p = TextNorm.prepare(g)
        return TextNorm.hasAny(p, listOf("animation")) && TextNorm.hasAny(p, listOf("family", "kids"))
    }

    /** Well-known cartoons / films for adults, in [TextNorm] form (title starts with one of them). */
    private val ADULT_TITLES = listOf(
        "rick and morty", "rick morty", "bojack horseman", "beavis and butt head", "beavis butt head", "south park", "family guy", "american dad",
        "the cleveland show", "archer", "big mouth", "bob s burgers", "harley quinn", "invincible", "castlevania", "hazbin hotel", "helluva boss",
        "the boondocks", "solar opposites", "disenchantment", "final space", "paradise pd", "robot chicken", "aqua teen hunger force", "metalocalypse",
        "futurama", "king of the hill", "love death and robots", "undone", "arcane", "blue eye samurai", "the legend of vox machina", "primal",
        "sausage party", "team america", "central park", "bless the harts", "the great north", "duncanville", "bordertown", "tuca and bertie",
        "madagascar skin", "cinderella man", "herpers", "lies and ex wives", "occupied", "a prayer for compassion", "the curse of the voodoo child", "attack on titan", "death note", "hit monkey", "close enough", "king star king", "ren and stimpy adult party cartoon", "drawn together"
    ).map { " $it " }

    fun isAdultTitle(nameNorm: String) = ADULT_TITLES.any { nameNorm.startsWith(it) }

    /**
     * May this title (already in the Children & Family genre) stay there? [known]: a rating the panel gave ("" = unknown),
     * [rawName] / [category] / [genre] as the panel wrote them, [nameNorm] / [prepared] their [TextNorm] forms (prepared = genre + category).
     */
    fun familyOk(known: String, rawName: String, category: String, nameNorm: String, prepared: String, series: Boolean): Boolean {
        // v3.4.0: a rating that passes (TMDB gives G / PG to many romance and murder-mystery TV films) no longer ends the screen: the grown-up words below still apply.
        val code = if (known.isNotEmpty()) known else MediaTags.maturity("$rawName $category")
        if (code.isNotEmpty() && !familyOk(code)) return false
        if (TextNorm.hasAny(prepared, UNSAFE)) return false
        if (isAdultTitle(nameNorm)) return false
        // v3.3.0: grown-up TV films (romance / murder-mystery channel movies) kept landing in Kids through a "Family" category or because a movie with no
        // evidence at all was let through. Channel names in the category / genre, and murder / affair style words in the TITLE, keep them out (a well-known children's title is never touched).
        if (!isKidsTitle(nameNorm) && (TextNorm.hasAny(prepared, GROWN_TV) || TextNorm.hasAny(nameNorm, GROWN_NAME))) return false
        if (code.isNotEmpty()) return true
        val family = TextNorm.hasAny(prepared, STRONG)
        if (!family && TextNorm.hasAny(prepared, UNSAFE_UNLESS_FAMILY)) return false
        if (family || isKidsTitle(nameNorm)) return true
        return !series
    }

    fun familyOk(t: RowTitle, known: String, series: Boolean): Boolean =
        genreKidsOk(genreOf(t)) && familyOk(known, t.name, t.category, t.nameNorm, t.prepared, series)

    /**
     * v3.7.0 (Chat H): an UNRATED title never enters Kids on a bare "Family" category (My Gay Life, Liszt's Rhapsody ... sat there that way).
     * Kids needs a rating that passes the age screen, or real evidence that it is for children: a well-known children's title, TMDB Animation + Family,
     * or an animation / kids / children genre or category. Only the Kids page uses this; the Family page and the profile age limits are unchanged.
     * Open question (not decided here): whether the user's own Sparrow Rating may override this.
     */
    fun kidsEvidence(t: RowTitle, known: String): Boolean {
        if (tmdbBlocksKids(t.uid, t.nameNorm)) return false
        val code = if (known.isNotEmpty()) known else MediaTags.maturity("${t.name} ${t.category}")
        if (code.isNotEmpty()) return familyOk(code)
        return isKidsTitle(t.nameNorm) || animFamilyGenre(t.uid) || TextNorm.hasAny(t.prepared, GENRE_ANIM_OR_KIDS)
    }

    private val TMDB_KIDS = listOf("animation", "kids", "children", "childrens")

    /**
     * v3.6.8: once TMDB has told us what a title IS, the provider's category (\"Family\", \"Kids Christmas\" ...) can no longer put it on the Kids page.
     * TMDB's own genres must say Animation / Kids / Children, or Family without \"TV Movie\" (live-action family films), or it is a well-known children's title.
     * A plain \"TV Movie\" (channel romance, thriller and mystery films, documentaries and stand-up filed as TV Movie) is never Kids, rated G or not.
     * Nothing known yet (\"\") = not blocked here; the other tests of [kidsEvidence] still apply. Used for Kids only: the Family page is unchanged.
     */
    fun tmdbBlocksKids(uid: String, nameNorm: String): Boolean {
        val tm = genreLookup(uid)
        if (tm.isBlank() || isKidsTitle(nameNorm)) return false
        val g = TextNorm.prepare(tm)
        if (TextNorm.hasAny(g, TMDB_KIDS)) return false
        if (TextNorm.hasAny(g, listOf("family")) && !TextNorm.hasAny(g, listOf("tv movie"))) return false
        return true
    }

    // ---- the title's OWN genre list (v3.1.0) ----------------------------------------------------------------------------------
    // A provider category that says "kids / family" used to outvote the title's own genres, so "Crime, Drama" TV movies landed in Kids.
    private val GENRE_NEVER = listOf("horror", "documentary", "biography", "history", "reality", "news", "talk", "erotic", "adult", "thriller", "thrillers", "slasher")
    private val GENRE_ANIM_OR_KIDS = listOf("animation", "kids", "children", "childrens")
    private val GENRE_KID_SIGN = listOf("family", "animation", "kids", "children", "childrens")
    private val GENRE_WEAK = listOf("crime", "war", "mystery", "drama", "music", "western", "tv movie")
    private val GENRE_ROMANCE = listOf("romance", "romantic")
    /** v3.4.0: grown-up film genres that were NOT on the list above, so "Action, Science Fiction, Adventure" (Inception) passed as "no objection". Like the weak ones, they need family / animation too. */
    private val GENRE_ADULT_ISH = listOf("action", "sci fi", "science fiction", "scifi", "suspense", "supernatural", "psychological", "heist", "spy", "espionage", "film noir", "noir")

    /**
     * May a title with this genre text ("TV Movie, Crime, Drama") be on a Kids / Family page? Blank = no evidence, true.
     * Horror / documentary / biography / history / thriller ... never; romance only for animation (Disney); crime / war / mystery / drama /
     * music / a plain "TV Movie" only when the list also says family or animation.
     */
    fun genreKidsOk(genre: String): Boolean {
        if (genre.isBlank()) return true
        val g = TextNorm.prepare(genre)
        if (g.isBlank()) return true
        val kid = TextNorm.hasAny(g, GENRE_KID_SIGN)
        if (TextNorm.hasAny(g, GENRE_NEVER) && !(TextNorm.hasAny(g, GENRE_ANIM_OR_KIDS) && !TextNorm.hasAny(g, listOf("horror", "documentary", "biography", "erotic", "adult", "slasher")))) return false
        if (TextNorm.hasAny(g, GENRE_ROMANCE) && !TextNorm.hasAny(g, GENRE_ANIM_OR_KIDS)) return false
        if (TextNorm.hasAny(g, GENRE_WEAK) && !kid) return false
        if (TextNorm.hasAny(g, GENRE_ADULT_ISH) && !kid) return false
        return true
    }
}
