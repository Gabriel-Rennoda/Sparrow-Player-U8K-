Next update (v3.3.0) - copy / paste this into the next chat
Same rules: investigate and test each item before changing code, apply in stages, test for the 75" U8K remote, then give me the updated zip. If anything is not completed, write a new copy-paste document.
Version 3.2.0 is the base (written WITHOUT a compiler). FIRST check the GitHub build log for the 3.2.0 run (versionCode 42) and fix compile errors before anything else. Check docs/TV_TEST_CHECKLIST_3_2.md (my results are pasted below).
Done in 3.2.0: real restart (helper activity in its own process), keyboard swallow also checks the window's real keyboard state, "more below" arrow present on first load + on Add Playlist, icon list opens on the current tab, details page (icon-only Love/Like/Dislike beside Play; series season drop-down in place), Kids (more known children's titles incl. Frozen; description clue), genre pages built in stages (first carousels fast, the rest appended while browsing).
NOT done (each needs its own build + TV test):
Group loading is still computed per page; if a group is still slow, send which group and how long (a cache of finished genre pages is the next step).
S2 TMDB genres + animation + family tags (tmdbId is stored). S3 TMDB keywords for holiday carousels + holiday pre-menu (23). S0 TMDB logo on Settings / About (send the logo file).
19 / 20 multiple custom Favourites sections; Copy To for Movies / Series. 12 live sync. 3 / 6 four-channel split screen.
"Bigger watched badges on posters": tell me what you want on the poster (a tick on finished titles?).
