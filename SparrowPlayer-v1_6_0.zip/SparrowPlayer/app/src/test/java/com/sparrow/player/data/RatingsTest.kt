package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class RatingsTest {
    @Test fun userRatingsToggleAndRoundTrip() {
        val r = UserRatings(); r.toggle("u1", UserRatings.LOVED); r.toggle("u2", UserRatings.DISLIKED)
        assertEquals("loved", r.get("u1")); r.toggle("u1", UserRatings.LOVED); assertEquals("", r.get("u1"))
        r.toggle("u2", UserRatings.LIKED); assertEquals("liked", r.get("u2"))
        val d = UserRatings.parse(r.serialize()); assertEquals("liked", d.get("u2")); assertEquals(1, d.all().size)
        assertTrue(UserRatings.parse("junk\nu\tbogus").all().isEmpty())
    }

    @Test fun providerScoreKeepsOneDecimal() {
        assertEquals(8.0, SparrowRating.providerOf("8"), 0.0); assertEquals(7.3, SparrowRating.providerOf("7.26"), 0.0)
        assertEquals(7.2, SparrowRating.providerOf("7.2"), 0.0); assertEquals(8.7, SparrowRating.providerOf(" 8.7 "), 0.0)
        assertEquals(-1.0, SparrowRating.providerOf(""), 0.0); assertEquals(-1.0, SparrowRating.providerOf("0"), 0.0)
        assertEquals(-1.0, SparrowRating.providerOf("n/a"), 0.0); assertEquals(10.0, SparrowRating.providerOf("11"), 0.0)
    }

    @Test fun formatDropsTheDecimalOnWholeNumbers() {
        assertEquals("7.3", SparrowRating.format(7.3)); assertEquals("8.7", SparrowRating.format(8.7)); assertEquals("9", SparrowRating.format(9.0))
        assertEquals("8.5", SparrowRating.format(8.5)); assertEquals("10", SparrowRating.format(10.0)); assertEquals("", SparrowRating.format(-1.0))
        assertEquals("", SparrowRating.format(0.0)); assertEquals("6", SparrowRating.format(5.96))
    }

    @Test fun sparrowRatingIsAlwaysInHalfSteps() {
        val ks = SparrowRating.keys("10", setOf("action"))
        val aff = SparrowRating.affinity(listOf(ks to UserRatings.LOVED, ks to UserRatings.LOVED))
        assertEquals(9.0, SparrowRating.score(7.0, ks, aff, ""), 0.0)                                  // +2 for a loved genre
        val bad = SparrowRating.affinity(listOf(ks to UserRatings.DISLIKED))
        assertEquals(5.0, SparrowRating.score(7.0, ks, bad, ""), 0.0)
        assertEquals(7.5, SparrowRating.score(7.3, setOf("c:99"), aff, ""), 0.0)                       // nothing in common: rounded to a half
        assertEquals(7.0, SparrowRating.score(7.2, setOf("c:99"), aff, ""), 0.0)
        assertEquals(-1.0, SparrowRating.score(-1.0, ks, aff, ""), 0.0)
        assertEquals(10.0, SparrowRating.score(2.0, ks, bad, UserRatings.LOVED), 0.0)
        assertEquals(8.0, SparrowRating.score(5.0, ks, aff, UserRatings.LIKED), 0.0)
        assertEquals(2.0, SparrowRating.score(9.0, ks, aff, UserRatings.DISLIKED), 0.0)
        assertEquals(10.0, SparrowRating.score(9.5, ks, aff, ""), 0.0)                                 // clamped
        for (p in listOf(6.1, 6.4, 6.6, 7.7, 8.9, 9.3)) { val sc = SparrowRating.score(p, ks, aff, ""); assertEquals(0.0, (sc * 2) % 1.0, 0.0) }
    }

    @Test fun metaCacheRoundTripAndMerge() {
        val c = MetaCache(); c.put("u1", 105, "PG-13", "Plot\twith tab\nand newline")
        c.put("u1", -1, "", "")                                                                         // empty update keeps what we know
        val d = MetaCache.parse(c.serialize()); val m = d.get("u1")!!
        assertEquals(105, m.lengthMin); assertEquals("PG-13", m.maturity); assertEquals("Plot\twith tab\nand newline", m.plot)
        assertNull(d.get("nope"))
    }

    @Test fun lengthParsing() {
        assertEquals(105, MetaCache.lengthMinutes("01:45:30")); assertEquals(105, MetaCache.lengthMinutes("105"))
        assertEquals(105, MetaCache.lengthMinutes("1h 45min")); assertEquals(95, MetaCache.lengthMinutes("95 min"))
        assertEquals(105, MetaCache.lengthMinutes("1:45")); assertEquals(-1, MetaCache.lengthMinutes("")); assertEquals(-1, MetaCache.lengthMinutes("n/a"))
    }
}
