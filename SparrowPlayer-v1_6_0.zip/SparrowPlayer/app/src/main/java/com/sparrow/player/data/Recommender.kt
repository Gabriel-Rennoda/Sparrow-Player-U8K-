package com.sparrow.player.data

import kotlin.math.abs

/**
 * "Because you watched ..." / "Recommended for you" ranking, from nothing but what the provider gives us for every
 * title (category, genre, year, rating). Pure Kotlin (no Android / Room types) so it is unit tested on the JVM.
 *
 * Movies usually have no genre field in IPTV panels, so the provider's category (often "Action", "Comedy", ...) is
 * the main signal for them; series also carry genre text. Recent history counts more than old history.
 */
object Recommender {
    data class Item(val uid: String, val category: String, val genres: Set<String>, val year: Int, val rating: Double)

    class Profile(val categories: Map<String, Double>, val genres: Map<String, Double>) {
        val isEmpty get() = categories.isEmpty() && genres.isEmpty()
    }

    fun genresOf(raw: String): Set<String> =
        raw.split(',', '/', '|', ';', '&').map { it.trim().lowercase() }.filter { it.length > 1 }.toSet()

    fun yearOf(raw: String): Int = raw.trim().take(4).toIntOrNull() ?: 0

    fun ratingOf(raw: String): Double = raw.trim().toDoubleOrNull()?.coerceIn(0.0, 10.0) ?: 0.0

    /** How alike [b] is to [a] (0 = nothing in common, so never recommended just for being highly rated). */
    fun similarity(a: Item, b: Item): Double {
        var s = 0.0
        if (a.category.isNotEmpty() && a.category == b.category) s += 2.0
        if (a.genres.isNotEmpty() && b.genres.isNotEmpty()) {
            val inter = a.genres.intersect(b.genres).size
            if (inter > 0) s += 3.0 * inter / a.genres.union(b.genres).size
        }
        if (s == 0.0) return 0.0
        if (a.year > 0 && b.year > 0) {
            val d = abs(a.year - b.year)
            s += if (d <= 3) 0.5 else if (d <= 8) 0.25 else 0.0
        }
        return s + 0.5 * b.rating / 10.0
    }

    private val byScore = compareByDescending<Pair<Item, Double>> { it.second }
        .thenByDescending { it.first.rating }
        .thenBy { it.first.uid }

    /** Titles most like [seed], best first. [exclude] = already watched. */
    fun becauseYouWatched(seed: Item, pool: List<Item>, exclude: Set<String>, limit: Int): List<Item> =
        pool.asSequence()
            .filter { it.uid != seed.uid && it.uid !in exclude }
            .map { it to similarity(seed, it) }
            .filter { it.second > 0.0 }
            .sortedWith(byScore)
            .take(limit).map { it.first }.toList()

    /** Taste profile from the watched titles, newest first (each step back in time counts 8 % less). */
    fun profile(watchedNewestFirst: List<Item>): Profile {
        val cw = HashMap<String, Double>(); val gw = HashMap<String, Double>()
        var w = 1.0
        for (h in watchedNewestFirst) {
            if (h.category.isNotEmpty()) cw[h.category] = (cw[h.category] ?: 0.0) + w
            for (g in h.genres) gw[g] = (gw[g] ?: 0.0) + w / h.genres.size
            w *= 0.92
        }
        return Profile(cw, gw)
    }

    fun topKeys(m: Map<String, Double>, n: Int): List<String> =
        m.entries.sortedWith(compareByDescending<Map.Entry<String, Double>> { it.value }.thenBy { it.key }).take(n).map { it.key }

    fun score(p: Profile, item: Item): Double {
        val ct = p.categories.values.sum(); val gt = p.genres.values.sum()
        var s = 0.0
        if (ct > 0) s += 2.0 * (p.categories[item.category] ?: 0.0) / ct
        if (gt > 0) s += 3.0 * item.genres.sumOf { g -> p.genres[g] ?: 0.0 } / gt
        return if (s > 0.0) s + 0.3 * item.rating / 10.0 else 0.0
    }

    /** "Recommended for you": best match to the whole taste profile, not yet watched. */
    fun forYou(p: Profile, pool: List<Item>, exclude: Set<String>, limit: Int): List<Item> =
        pool.asSequence()
            .filter { it.uid !in exclude }
            .map { it to score(p, it) }
            .filter { it.second > 0.0 }
            .sortedWith(byScore)
            .take(limit).map { it.first }.toList()

    /** Highly rated titles (rating >= [min]) not yet watched. */
    fun topRated(pool: List<Item>, exclude: Set<String>, limit: Int, min: Double = 6.5): List<Item> =
        pool.filter { it.uid !in exclude && it.rating >= min }
            .sortedWith(compareByDescending<Item> { it.rating }.thenBy { it.uid })
            .take(limit)
}
