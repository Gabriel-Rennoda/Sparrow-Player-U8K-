package com.sparrow.player.ui.player

import org.junit.Assert.assertEquals
import org.junit.Test

class SplitMathTest {
    @Test fun connectionLimitHoldsTilesBack() {
        assertEquals(4, SplitMath.allowed(4, 0))
        assertEquals(2, SplitMath.allowed(4, 2))
        assertEquals(3, SplitMath.allowed(3, 5))
        assertEquals(4, SplitMath.allowed(9, 0))
    }
    @Test fun qualityCap() {
        assertEquals(720, SplitMath.tileHeight(2))
        assertEquals(540, SplitMath.tileHeight(3))
        assertEquals(540, SplitMath.tileHeight(4))
    }
    @Test fun gridShape() {
        assertEquals(2, SplitMath.cols(2)); assertEquals(1, SplitMath.rows(2))
        assertEquals(2, SplitMath.cols(3)); assertEquals(2, SplitMath.rows(3))
        assertEquals(2, SplitMath.cols(4)); assertEquals(2, SplitMath.rows(4))
    }
    @Test fun dpadMovesInFourTiles() {
        assertEquals(1, SplitMath.move(0, 4, 1, 0))
        assertEquals(2, SplitMath.move(0, 4, 0, 1))
        assertEquals(3, SplitMath.move(1, 4, 0, 1))
        assertEquals(0, SplitMath.move(0, 4, -1, 0))      // edge: stays
        assertEquals(3, SplitMath.move(3, 4, 1, 0))
    }
    @Test fun dpadInThreeAndTwoTiles() {
        assertEquals(2, SplitMath.move(0, 3, 0, 1))
        assertEquals(2, SplitMath.move(2, 3, 1, 0))       // no 4th tile: stays
        assertEquals(1, SplitMath.move(0, 2, 1, 0))
        assertEquals(0, SplitMath.move(0, 2, 0, 1))
    }
    @Test fun decoderPlanFlipsOnRetry() {
        assertEquals(false, SplitMath.softwareFirst(0, 0)); assertEquals(true, SplitMath.softwareFirst(1, 0))
        assertEquals(true, SplitMath.softwareFirst(0, 1)); assertEquals(false, SplitMath.softwareFirst(2, 1))
        assertEquals(false, SplitMath.softwareFirst(0, 2))
    }
    @Test fun decoderModes() {
        assertEquals(true, SplitMath.softwareFirst(0, 0, "software")); assertEquals(false, SplitMath.softwareFirst(1, 0, "hardware"))
        assertEquals(true, SplitMath.softwareFirst(1, 0, "auto"))
        assertEquals(true, SplitMath.isSoftwareDecoder("c2.android.avc.decoder")); assertEquals(false, SplitMath.isSoftwareDecoder("c2.mtk.hevc.decoder"))
    }
}
