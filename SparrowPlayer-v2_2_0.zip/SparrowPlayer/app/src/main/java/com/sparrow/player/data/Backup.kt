package com.sparrow.player.data

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Backup / Restore (Settings -> Data, Backup & About). A backup is one JSON file: every saved setting (profiles, history, resume points, ratings, My List,
 * favourites, channel / group edits, theme ...) and the playlist logins. Restoring ADDS: nothing on the device is removed.
 *  - a setting the device does not have yet is added;
 *  - lists (My List, holiday favourites, watch history, profiles) are merged - both sides' entries are kept;
 *  - resume points keep the furthest one;
 *  - anything else that differs is a conflict: it is listed and the person approves (Use Backup) or denies (Keep Mine) each one, or approves all.
 * Device-specific keys (active profile / playlist, start-up profile, last channel, sync times) are never saved or restored.
 */
object Backup {
    const val FORMAT = 1

    private val SKIP_EXACT = setOf("profileActive", "active", "bootProfile", "startOnBoot", "lastCh", "openCh")
    private fun skip(key: String) = key in SKIP_EXACT || key.startsWith("syncCounts_") || key.startsWith("epgSync_")

    /** One saved value: [t] = b (boolean) i (int) l (long) f (float) s (text) set (text set, one per line); [v] its text. */
    class Entry(val t: String, val v: String)

    class Parsed(val prefs: Map<String, Entry>, val providers: List<Provider>, val app: String, val created: Long)

    /** [kind]: "add" (new here), "merge" (both sides kept, applied by itself) or "conflict" (needs a decision). */
    class Change(val key: String, val label: String, val kind: String, val old: Entry?, val new: Entry)

    fun entryOf(x: Any?): Entry? = when (x) {
        is Boolean -> Entry("b", x.toString())
        is Int -> Entry("i", x.toString())
        is Long -> Entry("l", x.toString())
        is Float -> Entry("f", x.toString())
        is String -> Entry("s", x)
        is Set<*> -> Entry("set", x.filterIsInstance<String>().sorted().joinToString("\n"))
        else -> null
    }

    fun export(all: Map<String, Any?>, providers: List<Provider>, appVersion: String): String {
        val root = JSONObject()
        root.put("format", FORMAT); root.put("app", appVersion); root.put("created", System.currentTimeMillis())
        val prefs = JSONObject()
        for (k in all.keys.sorted()) {
            if (skip(k)) continue
            val e = entryOf(all[k]) ?: continue
            prefs.put(k, JSONObject().put("t", e.t).put("v", e.v))
        }
        root.put("prefs", prefs)
        val arr = JSONArray()
        for (p in providers) arr.put(JSONObject().put("id", p.id).put("name", p.name).put("type", p.type).put("server", p.server)
            .put("username", p.username).put("password", p.password).put("m3uUrl", p.m3uUrl).put("epgUrl", p.epgUrl))
        root.put("providers", arr)
        return root.toString(2)
    }

    /** null when the text is not a Sparrow backup. */
    fun parse(text: String): Parsed? {
        try {
            val root = JSONObject(text)
            if (root.optInt("format", 0) != FORMAT) return null
            val po = root.getJSONObject("prefs")
            val m = LinkedHashMap<String, Entry>()
            val it = po.keys()
            while (it.hasNext()) { val k = it.next(); val o = po.getJSONObject(k); m[k] = Entry(o.getString("t"), o.getString("v")) }
            val provs = ArrayList<Provider>()
            val pa = root.optJSONArray("providers")
            if (pa != null) for (i in 0 until pa.length()) {
                val o = pa.getJSONObject(i)
                provs += Provider(o.optLong("id"), o.optString("name"), o.optString("type"), o.optString("server"), o.optString("username"),
                    o.optString("password"), o.optString("m3uUrl"), o.optString("epgUrl"), 0L)
            }
            return Parsed(m, provs, root.optString("app"), root.optLong("created"))
        } catch (e: Exception) { return null }
    }

    private val PROFILE_PREFIX = Regex("^p(\\d+)_")
    private fun baseName(key: String) = PROFILE_PREFIX.replace(key, "")

    fun labelOf(key: String): String {
        val m = PROFILE_PREFIX.find(key)
        val who = if (m != null) "Profile " + m.groupValues[1] + ": " else ""
        val n = baseName(key)
        val what = when {
            n == "history" -> "Watch history"; n == "myList" -> "My List"; n == "holidayFavs" -> "Holiday favourites"
            n == "ratings" -> "Ratings"; n == "sparrowScores" -> "Sparrow ratings"; n == "profiles" -> "Profiles"
            n.startsWith("pos_") -> "Resume point"; n.startsWith("dur_") -> "Length"; n.startsWith("lastEp_") -> "Last episode"
            n.startsWith("cust_") -> "Channel / group edits"; n == "theme" -> "Theme"
            else -> n
        }
        return who + what
    }

    /** Both sides' text merged, or null when this kind of value cannot be merged (a conflict). */
    fun mergeText(name: String, old: String, new: String): String? = when {
        name == "myList" || name == "holidayFavs" -> {
            val have = old.split('\n').filter { it.isNotBlank() }
            val extra = new.split('\n').filter { it.isNotBlank() && it !in have }
            (have + extra).joinToString("\n")
        }
        name == "history" -> {
            val best = LinkedHashMap<String, Long>()
            for (line in (old + "\n" + new).split('\n')) {
                if (line.isBlank()) continue
                val uid = line.substringBefore('\t')
                val ts = line.substringAfter('\t', "0").trim().toLongOrNull() ?: 0L
                if ((best[uid] ?: -1L) < ts) best[uid] = ts
            }
            best.entries.sortedByDescending { it.value }.joinToString("\n") { it.key + "\t" + it.value }
        }
        name == "profiles" -> {
            val have = old.split('\n').filter { it.isNotBlank() }
            val ids = have.map { it.substringBefore('\t') }.toSet()
            val extra = new.split('\n').filter { it.isNotBlank() && it.substringBefore('\t') !in ids }
            (have + extra).joinToString("") { it + "\n" }
        }
        else -> null
    }

    /** What restoring [backup] onto [local] would change. Equal values are not listed. */
    fun diff(local: Map<String, Any?>, backup: Map<String, Entry>): List<Change> {
        val out = ArrayList<Change>()
        for ((k, ne) in backup) {
            if (skip(k)) continue
            val oe = entryOf(local[k])
            if (oe == null) { out += Change(k, labelOf(k), "add", null, ne); continue }
            if (oe.t == ne.t && oe.v == ne.v) continue
            val name = baseName(k)
            if (oe.t == "l" && ne.t == "l" && (name.startsWith("pos_") || name.startsWith("dur_"))) {
                val a = oe.v.toLongOrNull() ?: 0L; val b = ne.v.toLongOrNull() ?: 0L
                if (b > a) out += Change(k, labelOf(k), "merge", oe, ne)
                continue
            }
            val merged = if (oe.t == "s" && ne.t == "s") mergeText(name, oe.v, ne.v) else null
            if (merged != null) { if (merged != oe.v) out += Change(k, labelOf(k), "merge", oe, Entry("s", merged)) }
            else out += Change(k, labelOf(k), "conflict", oe, ne)
        }
        return out
    }

    fun apply(ed: SharedPreferences.Editor, changes: List<Change>) {
        for (c in changes) {
            val e = c.new
            when (e.t) {
                "b" -> ed.putBoolean(c.key, e.v.toBoolean())
                "i" -> ed.putInt(c.key, e.v.toIntOrNull() ?: 0)
                "l" -> ed.putLong(c.key, e.v.toLongOrNull() ?: 0L)
                "f" -> ed.putFloat(c.key, e.v.toFloatOrNull() ?: 0f)
                "set" -> ed.putStringSet(c.key, e.v.split('\n').filter { it.isNotEmpty() }.toSet())
                else -> ed.putString(c.key, e.v)
            }
        }
    }
}
