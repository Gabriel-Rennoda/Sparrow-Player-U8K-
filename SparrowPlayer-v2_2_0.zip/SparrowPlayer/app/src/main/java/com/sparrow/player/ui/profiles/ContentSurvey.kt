package com.sparrow.player.ui.profiles

import android.app.Activity
import android.widget.Toast
import com.sparrow.player.data.Maturity
import com.sparrow.player.data.Profile
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.util.repo

/**
 * Content Preferences Survey, asked every time a profile is created (and from the profile's own window afterwards):
 *  1. Adult or Child.  A child profile never shows anything rated above PG-13 (it can be made stricter: PG, or G / TV-G only).
 *  2. An adult can leave everything open or limit what the profile sees (Up To R, TV-14, PG-13, PG, G).
 * The limit is applied to Movies, Series, every group / holiday list, Random Pick and Search (see Repository.blockedFor and Maturity.allowed).
 * Closing the survey with Back keeps what the profile had (a new profile: Adult, no limit); it can be answered again from Settings -> General -> Profiles.
 */
object ContentSurvey {
    /** [done] runs when the survey is over (answered or closed). */
    fun run(a: Activity, id: String, done: () -> Unit) {
        val repo = a.applicationContext.repo
        val pr = repo.profileStore().get(id)
        if (pr == null) { done(); return }
        val p = Popup(a, "Content Preferences", "Who is " + pr.name + " for?")
        p.note("Child profiles never show anything rated above PG-13. Adults can restrict what is shown further. Titles with no rating information are judged by their category and name. You can change this later: Settings → General → Profiles → " + pr.name + " → Content Preferences.")
        p.row("Adult", if (!pr.child) "✓" else "") { second(a, id, false, done) }
        p.row("Child  (nothing above PG-13)", if (pr.child) "✓" else "") { second(a, id, true, done) }
        p.onBack { done() }
        p.show()
    }

    private fun second(a: Activity, id: String, child: Boolean, done: () -> Unit) {
        val repo = a.applicationContext.repo
        val pr = repo.profileStore().get(id) ?: run { done(); return }
        val options: List<Pair<String, String>> =
            if (child) Maturity.LIMITS.filter { it.first in Profile.CHILD_LIMITS } else Maturity.LIMITS
        val current = options.indexOfFirst { it.first == pr.limit }.let { if (it >= 0) it else 0 }
        val p = Popup(a, if (child) "How Strict?" else "Limit What " + pr.name + " Can See?",
            if (child) "Child profile: PG-13 is the highest rating allowed" else "Adult profile")
        options.forEachIndexed { i, (code, label) ->
            p.row(label, if (i == current) "✓" else "") { finish(a, id, child, code, done) }
        }
        p.onBack { run(a, id, done) }                        // Back on the second question = the first one again
        p.show()
    }

    private fun finish(a: Activity, id: String, child: Boolean, limit: String, done: () -> Unit) {
        val repo = a.applicationContext.repo
        repo.profileStore().get(id)?.let { it.child = child; it.limit = limit }
        repo.saveProfiles()
        repo.dataVersion.value++                                 // rows are rebuilt with the new limit
        val shown = repo.profileStore().get(id)?.ageLimit ?: ""
        Toast.makeText(a, if (shown.isEmpty()) "No age limit" else "Shows up to " + shown + " only", Toast.LENGTH_SHORT).show()
        done()
    }
}
