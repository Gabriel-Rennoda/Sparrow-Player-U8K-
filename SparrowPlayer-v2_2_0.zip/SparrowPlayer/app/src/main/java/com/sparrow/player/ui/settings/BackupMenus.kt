package com.sparrow.player.ui.settings

import android.app.Activity
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Backup
import com.sparrow.player.data.Provider
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.util.repo
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Settings -> Data, Backup & About -> Backup Now / Restore From Backup. The file lives in the app's own folder (no storage permission needed);
 * to move a backup to another device copy the .json file into the same folder there (USB stick / file manager / computer), then Restore.
 * Restoring only adds (see [Backup]); conflicts are listed and approved or denied one by one, or all at once.
 */
object BackupMenus {
    private fun dir(a: Activity): File = (a.getExternalFilesDir(null) ?: a.filesDir).also { it.mkdirs() }
    private fun version(a: Activity): String = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }
    private fun toast(a: Activity, m: String) = Toast.makeText(a, m, Toast.LENGTH_LONG).show()

    fun backupNow(a: FragmentActivity) {
        val repo = a.applicationContext.repo
        a.lifecycleScope.launch {
            val name = "SparrowBackup-" + SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date()) + ".json"
            val f = File(dir(a), name)
            val ok = withContext(Dispatchers.IO) {
                try { f.writeText(Backup.export(repo.prefs.rawAll(), repo.dao.providers(), version(a))); true } catch (e: Exception) { false }
            }
            val p = Popup(a, if (ok) "Backup Saved" else "Backup Failed")
            if (ok) {
                p.note(name)
                p.note("Folder: " + dir(a).absolutePath)
                p.note("It holds every profile, watch history, resume points, ratings, My List, favourites, channel and group edits, theme and settings, and your playlist logins. Keep the file private.")
            } else p.note("The file could not be written on this device.")
            p.row("Close") { }
            p.show()
        }
    }

    fun restore(a: FragmentActivity) {
        val files = (dir(a).listFiles()?.filter { it.name.endsWith(".json") } ?: emptyList()).sortedByDescending { it.lastModified() }
        val p = Popup(a, "Restore From Backup", "Looking in " + dir(a).absolutePath)
        if (files.isEmpty()) p.note("No backup files found. Use Backup Now, or copy a SparrowBackup-….json file into the folder above, then open this window again.")
        for (f in files) p.row(f.name.removePrefix("SparrowBackup-").removeSuffix(".json")) { review(a, f) }
        p.row("Close") { }
        p.show()
    }

    private fun review(a: FragmentActivity, f: File) {
        val repo = a.applicationContext.repo
        a.lifecycleScope.launch {
            val parsed = withContext(Dispatchers.IO) { try { Backup.parse(f.readText()) } catch (e: Exception) { null } }
            if (parsed == null) { toast(a, "That file is not a Sparrow Player backup"); return@launch }
            val changes = Backup.diff(repo.prefs.rawAll(), parsed.prefs)
            val auto = changes.filter { it.kind != "conflict" }
            val conflicts = changes.filter { it.kind == "conflict" }
            val have: List<Provider> = withContext(Dispatchers.IO) { repo.dao.providers() }
            val addProviders: List<Provider> = if (have.isEmpty()) parsed.providers else emptyList()
            val approved = HashSet<String>()

            val p = Popup(a, "Restore", f.name)
            p.note("Added by themselves (nothing is removed): " + auto.size + " item(s) - new settings, merged lists, furthest resume points." +
                (if (addProviders.isNotEmpty()) " This device has no playlist yet: " + addProviders.size + " playlist(s) from the backup are added." else ""))
            val shown = conflicts.take(MAX_LISTED)
            val rows = ArrayList<Pair<Backup.Change, Popup.Row>>()
            if (conflicts.isEmpty()) p.note("No conflicts: nothing on this device differs from the backup.")
            else {
                p.note(conflicts.size.toString() + " conflict(s): this device and the backup hold different values. Keep Mine = deny, Use Backup = approve.")
                p.row("Approve All Conflicts", keepOpen = true) {
                    approved.clear(); conflicts.forEach { approved += it.key }
                    rows.forEach { (_, r) -> r.setValue("Use Backup") }
                }
                p.row("Deny All Conflicts", keepOpen = true) {
                    approved.clear(); rows.forEach { (_, r) -> r.setValue("Keep Mine") }
                }
                for (c in shown) {
                    val r = p.row(c.label, "Keep Mine", keepOpen = true) { row ->
                        if (!approved.add(c.key)) approved.remove(c.key)
                        row.setValue(if (c.key in approved) "Use Backup" else "Keep Mine")
                    }
                    rows += c to r
                }
                if (conflicts.size > shown.size) p.note("The other " + (conflicts.size - shown.size) + " follow Approve All / Deny All.")
            }
            p.row("Apply Restore") {
                val chosen = auto + conflicts.filter { it.key in approved }
                val ed = repo.prefs.rawEdit()
                Backup.apply(ed, chosen); ed.apply()
                a.lifecycleScope.launch {
                    if (addProviders.isNotEmpty()) {
                        withContext(Dispatchers.IO) { for (pv in addProviders) repo.dao.insertProvider(pv) }
                        repo.prefs.activeProvider = addProviders.first().id
                        repo.syncAsync(addProviders.first())
                    }
                    repo.reloadAfterRestore()
                    toast(a, "Restored " + chosen.size + " item(s). Restart the app to see every change.")
                }
            }
            p.row("Cancel") { }
            p.show()
        }
    }

    private const val MAX_LISTED = 40
}
