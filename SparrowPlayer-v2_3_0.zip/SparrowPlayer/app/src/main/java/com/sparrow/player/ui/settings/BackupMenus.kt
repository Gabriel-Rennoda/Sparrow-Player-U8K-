package com.sparrow.player.ui.settings

import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Backup
import com.sparrow.player.data.Provider
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.util.repo
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Settings -> Data, Backup & About -> Backup Now / Restore From Backup. A backup is saved in the shared Documents/SparrowPlayer folder (visible to any
 * file manager / USB copy; Android 10+ needs no permission for this), and, only when that fails, in the app's own folder (not reachable by file managers).
 * "Share / Email" sends the file through any app that accepts it; Restore lists this app's own backups and has "Browse For Backup File…" (the system
 * file picker) for a file copied from another device.
 * Restoring only adds (see [Backup]); conflicts are listed and approved or denied one by one, or all at once.
 */
object BackupMenus {
    private fun dir(a: Activity): File = (a.getExternalFilesDir(null) ?: a.filesDir).also { it.mkdirs() }
    private fun version(a: Activity): String = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }
    private fun toast(a: Activity, m: String) = Toast.makeText(a, m, Toast.LENGTH_LONG).show()

    /** A backup that can be read again: shown in the list ([label]) and read by [read]. */
    private class Src(val label: String, val read: () -> String)

    /** Where a saved backup ended up: [where] for the person, [uri] (null when it only is in the app folder) for sharing. */
    private class Saved(val where: String, val uri: Uri?)

    private const val SHARED_DIR = "Documents/SparrowPlayer"

    private fun saveShared(a: Activity, name: String, text: String): Saved? {
        val bytes = text.toByteArray(Charsets.UTF_8)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, SHARED_DIR)
                }
                val uri = a.contentResolver.insert(MediaStore.Files.getContentUri("external"), values) ?: return null
                val out = a.contentResolver.openOutputStream(uri) ?: return null
                out.use { it.write(bytes) }
                return Saved("$SHARED_DIR/$name", uri)
            }
            // Android 7-9: the public Documents folder needs the storage permission; without it this fails and the app folder is used
            val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "SparrowPlayer")
            d.mkdirs()
            val f = File(d, name)
            f.writeBytes(bytes)
            return Saved(f.absolutePath, null)
        } catch (e: Exception) { return null }
    }

    fun backupNow(a: FragmentActivity) {
        val repo = a.applicationContext.repo
        a.lifecycleScope.launch {
            val name = "SparrowBackup-" + SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date()) + ".json"
            val saved: Saved? = withContext(Dispatchers.IO) {
                try {
                    val text = Backup.export(repo.prefs.rawAll(), repo.dao.providers(), version(a))
                    saveShared(a, name, text) ?: run { File(dir(a), name).writeText(text); Saved(File(dir(a), name).absolutePath, null) }
                } catch (e: Exception) { null }
            }
            val p = Popup(a, if (saved != null) "Backup Saved" else "Backup Failed")
            if (saved != null) {
                p.note(name)
                p.note("Saved in: " + saved.where)
                if (saved.uri == null) p.note("This copy is in the app's own folder, which file managers cannot open. Use Share / Email to send it, or try again after allowing storage access in Android settings.")
                else p.note("Open your file manager and look in Documents → SparrowPlayer to copy it to a USB stick or another device.")
                p.note("It holds every profile, watch history, resume points, ratings, My List, favourites, channel and group edits, theme and settings, and your playlist logins. Keep the file private.")
                if (saved.uri != null) p.row("Share / Email This File…") { share(a, saved.uri) }
            } else p.note("The file could not be written on this device.")
            p.row("Close") { }
            p.show()
        }
    }

    private fun share(a: Activity, uri: Uri) {
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Sparrow Player backup")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            a.startActivity(Intent.createChooser(send, "Send backup with"))
        } catch (e: Exception) { toast(a, "No app on this device can send files. Copy the file from Documents/SparrowPlayer instead.") }
    }

    /** Backups this app made in Documents/SparrowPlayer (Android 10+: only files this app created are visible to it), newest first. */
    private fun sharedBackups(a: Activity): List<Src> {
        if (Build.VERSION.SDK_INT < 29) return emptyList()
        val out = ArrayList<Src>()
        try {
            val base = MediaStore.Files.getContentUri("external")
            val cols = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val sel = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ? AND " + MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?"
            a.contentResolver.query(base, cols, sel, arrayOf("Documents/SparrowPlayer%", "SparrowBackup-%.json"), MediaStore.MediaColumns.DATE_MODIFIED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(base, c.getLong(0))
                    val n = c.getString(1) ?: continue
                    out += Src(n) { a.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "" }
                }
            }
        } catch (e: Exception) { }
        return out
    }

    private var pickerSeq = 0

    /** The system file picker (Android TV usually has one) for a backup file copied from another device. */
    private fun browse(a: FragmentActivity) {
        try {
            val key = "sparrow_backup_pick_" + (pickerSeq++)
            var launcher: androidx.activity.result.ActivityResultLauncher<Array<String>>? = null
            launcher = a.activityResultRegistry.register(key, ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                launcher?.unregister()
                if (uri != null) review(a, Src(uri.lastPathSegment ?: "Backup file") { a.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "" })
            }
            launcher?.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*"))
        } catch (e: Exception) { toast(a, "This device has no file picker. Put the backup in Documents/SparrowPlayer and use Restore again.") }
    }

    fun restore(a: FragmentActivity) {
        val own: List<Src> = (dir(a).listFiles()?.filter { it.name.endsWith(".json") } ?: emptyList()).sortedByDescending { it.lastModified() }
            .map { f -> Src(f.name) { f.readText() } }
        val srcs = sharedBackups(a) + own
        val p = Popup(a, "Restore From Backup", "Saved by this app in Documents/SparrowPlayer or the app folder")
        p.row("Browse For Backup File…", desc = "Pick a SparrowBackup-….json file copied from another device (needs a file picker app).") { browse(a) }
        if (srcs.isEmpty()) p.note("No backups made by this app were found. Use Browse For Backup File… to pick one copied from another device.")
        for (s in srcs) p.row(s.label.removePrefix("SparrowBackup-").removeSuffix(".json")) { review(a, s) }
        p.row("Close") { }
        p.show()
    }

    private fun review(a: FragmentActivity, f: Src) {
        val repo = a.applicationContext.repo
        a.lifecycleScope.launch {
            val parsed = withContext(Dispatchers.IO) { try { Backup.parse(f.read()) } catch (e: Exception) { null } }
            if (parsed == null) { toast(a, "That file is not a Sparrow Player backup"); return@launch }
            val changes = Backup.diff(repo.prefs.rawAll(), parsed.prefs)
            val auto = changes.filter { it.kind != "conflict" }
            val conflicts = changes.filter { it.kind == "conflict" }
            val have: List<Provider> = withContext(Dispatchers.IO) { repo.dao.providers() }
            val addProviders: List<Provider> = if (have.isEmpty()) parsed.providers else emptyList()
            val approved = HashSet<String>()

            val p = Popup(a, "Restore", f.label)
            p.note("Added by themselves (nothing is removed): " + auto.size + " item(s) - new settings, merged lists, furthest resume points." +
                (if (addProviders.isNotEmpty()) " This device has no playlist yet: " + addProviders.size + " playlist(s) from the backup are added." else ""))
            val shown = conflicts.take(MAX_LISTED)
            val rows = ArrayList<Pair<Backup.Change, Popup.Row>>()
            if (conflicts.isEmpty()) p.note("No conflicts: nothing on this device differs from the backup.")
            else {
                p.note(conflicts.size.toString() + " conflict(s): this device and the backup hold different values. Keep Mine = deny, Use Backup = approve.")
                p.row("Approve All Conflicts", keepOpen = true) {
                    approved.clear(); conflicts.forEach { approved += it.key }
                    rows.forEach { (_, r) -> r.setValue("Use Backup") }
                }
                p.row("Deny All Conflicts", keepOpen = true) {
                    approved.clear(); rows.forEach { (_, r) -> r.setValue("Keep Mine") }
                }
                for (c in shown) {
                    val r = p.row(c.label, "Keep Mine", keepOpen = true) { row ->
                        if (!approved.add(c.key)) approved.remove(c.key)
                        row.setValue(if (c.key in approved) "Use Backup" else "Keep Mine")
                    }
                    rows += c to r
                }
                if (conflicts.size > shown.size) p.note("The other " + (conflicts.size - shown.size) + " follow Approve All / Deny All.")
            }
            p.row("Apply Restore") {
                val chosen = auto + conflicts.filter { it.key in approved }
                val ed = repo.prefs.rawEdit()
                Backup.apply(ed, chosen); ed.apply()
                a.lifecycleScope.launch {
                    if (addProviders.isNotEmpty()) {
                        withContext(Dispatchers.IO) { for (pv in addProviders) repo.dao.insertProvider(pv) }
                        repo.prefs.activeProvider = addProviders.first().id
                        repo.syncAsync(addProviders.first())
                    }
                    repo.reloadAfterRestore()
                    toast(a, "Restored " + chosen.size + " item(s). Restart the app to see every change.")
                }
            }
            p.row("Cancel") { }
            p.show()
        }
    }

    private const val MAX_LISTED = 40
}
