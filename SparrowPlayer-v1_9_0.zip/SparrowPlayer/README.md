# Sparrow Player

IPTV player for Android TV / Google TV (built and tuned for the Hisense U8K, 75").
Kotlin · Leanback · Media3/ExoPlayer · Room · OkHttp · Coil.

## Build & install
1. Open this folder in **Android Studio (Koala or newer)** – it generates the Gradle wrapper and syncs.
   (Command line: `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleDebug`.)
2. On the TV: Settings → System → About → tap *Build* 7× → Developer options → enable **USB/Network debugging**.
3. `adb connect <tv-ip>:5555` then `adb install -r app/build/outputs/apk/debug/app-debug.apk`
   (or Run ▶ from Android Studio with the TV selected).

## Using it
First launch asks for a provider: **Xtream Codes** (server, user, password) or an **M3U URL** (+ optional XMLTV URL).
Channels, movies, series and a 36 h guide window are imported into a local database; progress shows at the top right.

### Screen layout
* **Live TV / Favourites** share one guide: player top-left (always the channel you are watching), info pane to its
  right (follows the highlighted program), date + time top-left of the guide, then a grid of channels (logo, name,
  optional number) x four half-hour columns (2 h) starting at the current half hour.
* **Left side**: a minimized icon bar is always visible.

### Remote
| Where | Keys |
|---|---|
| Live TV (guide) | ←/→ move between programmes and scroll the guide into the future (up to 36 h); going back stops at the current half hour. ↑/↓ channels, **OK** = tune / full screen, **hold OK** = channel options (favourite, hide, copy, move, rename), CH± = page, **Back** after browsing ahead = jump back to now. Date and clock sit in the top-left corner of the grid. |
| Player box | ↑ from the first channel reaches it; **OK** = full screen |
| Movies / Series | ←/→/↑/↓ browse posters (backdrop shows the highlighted title), OK = details → Play / pick episode (**one OK plays it**) |
| Full screen (live) | ↑/↓ or CH± = zap, 0-9 = channel number, OK = info bar, **OK again = audio / subtitles / video quality** (gear icon), hold OK = favourite |
| Full screen (VOD) | standard Media3 controls plus a **gear button** (top right: press ↑ from the bar, then OK) for audio language, subtitles and video quality; resumes 30 s before where you stopped |
| Any tab | **Back** opens *Channel Groups* (Live TV), then the *Tab List*; **Back** on the Tab List = hint, twice = "Exit?  Yes / No" |

### Side panels (Live TV and Guide)
1. **←** at the left-most item of the player / guide opens **Channel groups**. The guide shows the group you are on as you move with ↑/↓; **OK** confirms, **Back** keeps what is shown.
2. **←** again expands the **tab list** (Live TV, Movies, Series, Favourites, Settings). **OK** opens a tab.
3. **→** closes one level at a time and puts the selector back where you were: tab list → channel groups → your last selection.
   **Back** goes the other way (v1.4.0): from the guide it opens Channel Groups, Back again opens the Tab List, Back on the Tab List asks to exit.
4. **Hold OK on a group** = rename, move up / down, hide, delete (own groups), create a new group.

Movies, Series, Favourites and Settings have no channel groups, so **←** at their left edge opens the tab list directly.

## Project map
- `data/` Room entities+DAO, `XtreamClient`, `M3uParser`, `XmltvParser` (streaming, gzip aware), `Repository` (sync)
- `ui/MainActivity` shell: icon bar / tab list, groups panel, top-left player, info pane, D-pad panel navigation
- `ui/nav/PanelState` pure state machine for the side panels (unit tested: `app/src/test`)
- `ui/epg` EpgView (custom canvas grid) + GuideMath (pure, tested) · `ui/vod` rows + details · `ui/player` full-screen player
- `ui/settings` provider management · `res/` theme, layouts, icons

## Screen sizing
Layouts are weight / percentage based. Google TV 4K panels report a 960 × 540 dp viewport (640 dpi); the screens also
adapt to 1280 × 720 dp and 1920 × 1080 dp. Poster size and the player are derived from the screen size, not fixed dp.

## Notes / tuning
- Live format for Xtream: Settings → toggle **TS** (default, fastest zap) or **HLS (m3u8)**.
- User-Agent is `Prefs.UA` (VLC string) – change if your provider whitelists something else.
- The Guide lists every channel of the group; programs are loaded lazily for the rows around the selection.
- Settings (v1.4.0): General (playlists, hidden items, channel numbers, 12 hr clock, audio / subtitle language), Appearance, Network and Buffering, EPG (sync interval, sync on start, Sync Now), About. Each opens a pop-up window.
- MP2 / some exotic audio isn't decodable by Android's built-in codecs. If you hit silent channels, add the
  Media3 FFmpeg decoder extension (build it locally; it is not published to Maven).
- Release builds are signed with the debug key for convenience; use your own keystore for distribution.
- EPG matching uses `epg_channel_id` / `tvg-id` only; name-based fuzzy matching is a good next step.
- In-app text uses Canadian English (favourite, program, ...).

### v1.7.0
- Next Episode button (bottom right, 15 s) near the credits of a series episode.
- Profiles with icons (supplied / upload / web address) and an optional 4-digit lock; per-profile history, ratings and My List. "Who's Watching?" at launch.
- Opening Channel (Settings -> EPG), Random Pick, open on device start-up / wake-up (Settings -> General).
- Posters load through the app's HTTP client (logo-only posters); no more poster flash before the backdrop.
- The Holidays: Top 10 What's Hot per holiday + a page per holiday. Many new named carousels (Top 10 Today, My List, Watch It Again, mood / acclaim / theme / binge rows, collections, platforms ...).
- Details: `docs/INVESTIGATION_7.md`.

### v1.6.1
- Sparrow Rating is your own rating: a 0.5 - 10 drop down on the details screen (next to the provider's rating on the poster); shown top right of the poster once set.
- Loved It / Liked It / Disliked It is a separate three-step scale that steers recommendations (Disliked titles are never recommended; a "Because You Loved ..." row).

### v1.6.0
- Ratings on every poster: provider rating top left (one decimal, "9" not "9.0"), Sparrow Rating (your own) top right (logo + number, half steps only); both stay put on the details screen. Whole system now 0 - 10.
- Movies / Series groups: All, **The Holidays**, then main genre tabs (Action & Adventure, Comedies, Horror ...) built from the Netflix genre list; sub-genres are rows inside a genre.
- Details: `docs/INVESTIGATION_6.md`.

### v1.5.0
- Player: one settings gear, bottom right, that disappears with the controls; Media3's own gear / CC open the same Sparrow menu.
- Search (Live Channels / Movies / Series): entry at the top of the tab list and channel groups, button above Movies / Series rows, remote search key. Filters: text (+ descriptions), quality, subtitles, language, channel type; year range, genre, length, my ratings, star / Sparrow rating, maturity. Sort + ascending / descending.
- The Holidays group in Movies and Series: one row per holiday, in calendar order, just-passed holidays stay below the next one for 7 days.
- Loved It / Liked It / Disliked It on the details screen.
- Down on the tab list stops at Settings.
- Details: `docs/INVESTIGATION_5.md`.

### v1.4.0
- Fixed: highlighted tab / group text was unreadable (tab labels never got the "focused" colour); movie / series details now show the artwork (the veil over it was 60-94 % opaque).
- Back opens Channel Groups, then the Tab List, from every tab. Right closes. Back on the Tab List = exit prompt.
- Settings redone as General / Appearance / Network and Buffering / EPG / About pop-ups; Add or Switch Playlist (switch or delete any), Delete Playlist, Hidden, EPG Sync (24/12/6/3/2 h), Sync EPG on App Start, Sync Now.
- Hold OK on a channel: Play, Favourite, Hide / Unhide, Copy To Group (or a new one), Move To Group (asks Yes / No), Remove From This Group, Edit Channel Name. Hold OK on a group: Rename, Move Up / Down, Hide, Delete, New Group. Edits survive syncs (stored per playlist, `Customize`).
- Audio / subtitle picker: gear button in full screen (live: OK twice) and preferred languages in Settings -> General.
- Add Playlist: Username, Password, Server URL, Playlist Name (optional), XMLTV EPG URL (optional); starts on Username; OK / Go verifies and syncs by itself.
- Leafs White removed; Random and Custom backgrounds are always dark. All headings are in title case.
- Details: `docs/INVESTIGATION_4.md`.

### v1.3.1
- Build fix only: renamed a method in DetailsActivity that clashed with `Activity.setProgress` (compile error in 1.3.0). Delete the SparrowPlayer-v1_3_0.zip from the repo; v1.3.1 has a higher versionCode so it is picked anyway.

### v1.3.0
- Guide: time-shifting mode removed. Browse freely to the right (future); LEFT stops at the current half hour. OK now tunes directly. Date + clock moved into the grid's top-left corner.
- Screensaver: the mini player now reports playback to the TV (keep-screen-on + an active media session), so it no longer starts while a channel plays and you browse the guide.
- A title counts as watched (recommendations) after 40 % played.
- Updates install over the old version: one fixed signing key is now committed (`app/sparrow-signing.jks`), the database never wipes itself on a schema change, entities / preference keys unchanged. **Read `docs/UPGRADE_SAFETY.md`** (one-time note for the very first install of this version).

### v1.2.0
- **Themes**: Settings -> Theme. Stock: Leafs Black & Blue (special-edition jersey), Leafs Blue, Leafs White, Ink Wash, Satin Night, Smoke, Sparrow Classic (the old look, default); 12 solid colours; custom background / accent; Random. Text colours are automatic and checked for contrast (`tools/theme_check.py`).
- Movies / Series pages use the theme background; only the details screen shows a title's backdrop.
- Selected poster is bigger, overlaps its neighbours, with a shadow and thin white halo. Posters are preloaded in the direction you browse.
- Recommendation rows from your watch history; resume time shown beside the Resume button.
- Full-screen player: the first press of D-pad / OK / Back / CH+/- only shows the controls (hide after 3 s); a second press acts.
- Tools: `tools/theme_check.py`, `tools/logic_check.py`, `tools/kt_static_check.py`. Details: `docs/INVESTIGATION_3.md`.

### v1.1.1
- The separate Guide tab is gone: **Live TV is the guide**.
- The live info pane has no progress bar. Movies, series and episodes show a watch-progress bar (hero on the Movies / Series tabs,
  details screen, and per focused episode).

## What's new in 1.9.0
Search has a visible, labelled text box and a one-line Release Years range and opens at once (shared search index); sub-genres are carousels inside their genre page
(no more sub-entries in the Groups list); Children & Family keeps family films tagged "Crime" and well-known kids' titles; The Holidays screens titles in and out with
per-holiday word lists (`Holidays.kt`); Move keeps the list still while the group travels; Hide asks first (with "Do Not Show This Again") and acts at once; the
"＋ My Holiday Favourites" button only appears on pages opened from The Holidays. Details: `docs/INVESTIGATION_9.md`.
