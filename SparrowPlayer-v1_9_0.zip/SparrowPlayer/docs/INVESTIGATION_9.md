# Version 1.9.0 – investigation and changes

Every item was traced in the code BEFORE anything was changed. **Not compiled or run on a TV here** (no Kotlin compiler, Gradle or device on the build box):
the first real compile is the GitHub Action, and the remote behaviour needs the checklist at the bottom of `docs/TV_TEST_CHECKLIST.md` (Round 9).
What was run here: `tools/kt_balance.py`, `tools/kt_static_check.py` (same two baseline false positives as 1.8.0 in SettingsFragment / now also PosterCard, caused by
string literals in the checker; `kt_balance.py` is clean), `tools/upgrade_check.py` against the 1.8.0 zip (schema, DB name, every preference key kept; one key added),
all older model tests, and the new `tools/v19_model_test.py` (word lists are *parsed from the Kotlin sources*). New JUnit tests: `SearchIndexTest`, additions to
`HolidayMaskTest`, `CatalogTest`, `MaturityTest` (they run in the workflow's informational test step).

## Findings → changes (in the order they were built)

| # | Report | Root cause found | Change |
|---|---|---|---|
| 1 | Holidays: use word lists to screen titles in and out | one flat keyword list; "holiday" matched *Roman Holiday*, "santa" matched *Santa Fe / Santa Clarita*; the category was matched with the title's list; nothing kept adult material out | `Holidays.Holiday` now has three lists: `keywords` (in: title, category, description), `categoryWords` (in: category only – "Holiday Movies"), `exclude` (OUT: the name screens the title out). Adult categories / titles are out of every holiday. Lists are at the top of `Holidays.kt` |
| 2 | Children & Family: limited content | `Maturity` dropped any title whose genre text said *crime / thriller / war* – Despicable Me, Minions, Zootopia are tagged that way; a *series* that is only "animation" waited for a rating; nothing recognised well-known kids' titles | crime / thriller / war only exclude when nothing says family / kids; horror & adult words still always exclude; ~85 well-known children's titles/brands are let in even with no genre text; more kids words (Nickelodeon, DreamWorks, PBS Kids, preschool …). Sample: 1 of 9 typical titles kept before, 8 of 9 now |
| 3 | Children & Family: sub-genres as separate tabs; one group, sub-groups as rows | 1.8.0 listed each sub-genre as an entry under the open genre | **all** genres: the Groups list holds one entry per genre; its page = Top Rated, Recently Added, then a carousel per sub-genre (≥ 3 titles, fullest first, max 24), then the provider's categories |
| 4 | Children & Family posters not loading | **Not reproduced** (no playlist here; the cards use exactly the same code as every other genre). The only poster path that can differ per source is the address itself | `PosterSize.clean()` repairs addresses panels write oddly (`//host/x.jpg`, `http:\/\/…`, spaces, line breaks); a failed poster is retried once over the other scheme (http ⇄ https) before the logo is shown. **If posters stay blank, tell me which category; the likely cause is then empty poster fields in that provider's data** |
| 5 | Movie search slow to open | each open rebuilt 100 000 `Candidate`s: 4–5 regex passes per title (quality, language, subtitles, maturity), prefs reads, a genre-count over all of them, a poster map | `SearchIndex`: built **once** per catalogue in the background (chained in `warmCatalogs`), shared; a visit only applies the profile's few hundred entries (my ratings, watched, Sparrow, remembered length/plot). The window and search box are on screen at once, results appear as soon as ready |
| 6 | Search: where to type | the text was a row that opened a pop-up | a labelled box on top of the filters ("Type a title to search…"), cursor in it on open, keyboard shown, results follow the typing after 250 ms, Search/Done closes the keyboard |
| 7 | Release years on one line | two pick-list rows | one row `Release Years [from] – [to]`, typed (4 digits count), usable before or after searching, cleared by Reset Filters |
| 8 | Group Move tracks badly | RecyclerView lays out around the **focused** row: with the moving group focused it stayed put on screen while the whole list slid | during Move no row is focused (the list holds focus), the moving group is a solid accent bar with ⇅, other rows slide one place with a short animation, the list scrolls only if the group would leave the screen; OK places, Back restores (unchanged) |
| 9 | Remove "＋ My Holiday Favourites" on normal posters | button always shown | shown only when the details page was opened from The Holidays / a holiday page / My Holiday Favourites |
| 10 | Confirm before hide; hide takes effect at once | hide kept the row on screen (dimmed) until the list was reloaded – by design in 1.8.0 | "Hide <channel/group>?" No (focused first) / Do Not Show This Again ☐ / Yes, Hide. Yes removes the row at once (selector goes to the next one). Settings → General → **Ask Before Hiding** turns the question back on; Settings → General → Hidden unhides |

## Not done / needs you
* **"See attached Search pop up page for desired layout"** – no image came with the upload (only the zip and `build.yml`). The search window follows your written description. Send the picture and I will match it exactly.
* Posters (item 4): see above – hardened, not proven.
* `watched` in search is now "in the last 150 titles of the history" (the history is capped at 150 anyway); a title started long ago that fell out of the history is no longer marked watched in search.
* The old rule "a hidden channel stays listed so a mistaken Hide can be undone from the same menu" is gone on purpose (you asked for immediate hiding); the confirmation replaces it.
