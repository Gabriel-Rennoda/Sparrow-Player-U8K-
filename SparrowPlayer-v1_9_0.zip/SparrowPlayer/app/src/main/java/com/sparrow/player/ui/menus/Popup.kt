package com.sparrow.player.ui.menus

import android.app.Activity
import android.app.Dialog
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp
import com.sparrow.player.util.repo

/**
 * The app's own pop-up window (a themed card with focusable rows), used for every settings page and context menu.
 * Everything is D-pad friendly: rows take focus, OK activates, Back closes. A row can show a value on its right ("On", "24 Hours"),
 * and can keep the window open when pressed (toggles) so the value changes in place.
 *
 * Text colours follow the focus state (see Theme "t:item"): the label and value are drawn by their own TextViews that mirror the
 * row's state, so a highlighted row always shows its text in the "on accent" colour - never accent on accent.
 */
class Popup(private val a: Activity, private val title: String, private val subtitle: String = "") {

    class Row(
        val label: String,
        value: String,
        val keepOpen: Boolean,
        val enabled: Boolean,
        val onClick: (Row) -> Unit
    ) {
        var value: String = value
            private set
        internal var valueView: TextView? = null
        internal var view: View? = null

        fun setValue(v: String) { value = v; valueView?.text = v }
    }

    private sealed class Item {
        class R(val row: Row) : Item()
        class Note(val text: String) : Item()
    }

    private val items = ArrayList<Item>()
    private var dialog: Dialog? = null
    private var dismissHook: (() -> Unit)? = null
    private var backHook: (() -> Unit)? = null
    private var chosen = false                 // a row that closes the window was pressed

    fun row(label: String, value: String = "", keepOpen: Boolean = false, enabled: Boolean = true, onClick: (Row) -> Unit): Row {
        val r = Row(label, value, keepOpen, enabled, onClick)
        items += Item.R(r)
        return r
    }

    /** Plain explanatory text (not focusable). */
    fun note(text: String) { items += Item.Note(text) }

    fun onDismiss(block: () -> Unit): Popup { dismissHook = block; return this }

    /** Runs when the window is closed WITHOUT pressing a row that closes it (Back): used to return to the window the user came from. */
    fun onBack(block: () -> Unit): Popup { backHook = block; return this }

    fun dismiss() { dialog?.dismiss() }

    fun show(): Popup {
        if (a.isFinishing) return this
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(24), a.dp(20), a.dp(24), a.dp(20))
        }
        col.addView(TextView(a).apply {
            text = title; textSize = 24f; tag = "t:text"
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
        })
        if (subtitle.isNotBlank()) col.addView(TextView(a).apply { text = subtitle; textSize = 15f; tag = "t:dim"; setPadding(0, a.dp(2), 0, 0) })
        col.addView(View(a), LinearLayout.LayoutParams(1, a.dp(10)))

        val list = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        var firstFocusable: View? = null
        for (item in items) when (item) {
            is Item.Note -> list.addView(TextView(a).apply {
                text = item.text; textSize = 15f; tag = "t:dim"; setPadding(a.dp(6), a.dp(6), a.dp(6), a.dp(6))
            })
            is Item.R -> {
                val v = rowView(item.row, d)
                if (firstFocusable == null && item.row.enabled) firstFocusable = v
                list.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = a.dp(4) })
            }
        }
        val scroll = ScrollView(a).apply { isFillViewport = false; addView(list) }
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        Theme.applyTree(col)

        d.setContentView(col)
        d.setOnDismissListener { dismissHook?.invoke(); if (!chosen) backHook?.invoke() }
        d.show()
        d.window?.apply {
            setBackgroundDrawable(GradientDrawable().apply { setColor(Theme.surface); cornerRadius = a.dp(16).toFloat() })
            setLayout(a.dp(620), ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.65f)
        }
        firstFocusable?.requestFocus()
        dialog = d
        return this
    }

    private fun rowView(r: Row, d: Dialog): View {
        val v = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            tag = "bg:item"
            minimumHeight = a.dp(54)
            setPadding(a.dp(18), a.dp(10), a.dp(18), a.dp(10))
            isFocusable = r.enabled
            isClickable = r.enabled
            alpha = if (r.enabled) 1f else 0.45f
        }
        val label = TextView(a).apply {
            text = r.label; textSize = 19f; tag = "t:item"; isDuplicateParentStateEnabled = true
            setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
        }
        v.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (r.value.isNotEmpty() || r.keepOpen) {
            val value = TextView(a).apply {
                text = r.value; textSize = 19f; tag = "t:item"; isDuplicateParentStateEnabled = true
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(a.dp(16), 0, 0, 0)
            }
            v.addView(value, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            r.valueView = value
        }
        r.view = v
        if (r.enabled) v.setOnClickListener {
            if (!r.keepOpen) { chosen = true; d.dismiss() }
            r.onClick(r)
        }
        return v
    }

    companion object {
        /** Pick one of [options]; the current one carries a tick. */
        fun choose(a: Activity, title: String, options: List<String>, selected: Int, onBack: () -> Unit = {}, onPick: (Int) -> Unit) {
            val p = Popup(a, title)
            options.forEachIndexed { i, o -> p.row(o, if (i == selected) "✓" else "") { onPick(i) } }
            p.onBack(onBack)
            p.show()
        }

        /** Yes / No question. "No" has the focus first, so a stray OK press never confirms. */
        fun confirm(a: Activity, title: String, message: String, yes: String = "Yes", onNo: () -> Unit = {}, onYes: () -> Unit) {
            val p = Popup(a, title)
            p.note(message)
            p.row("No") { onNo() }
            p.row(yes) { onYes() }
            p.onBack(onNo)
            p.show()
        }

        /**
         * "Are you sure you want to hide it?" - Yes / No plus a "Do Not Show This Again" check box. "No" has the focus first. When the user
         * already turned the question off (Prefs.askBeforeHide) [onYes] runs at once. Hiding is undone in Settings -> General -> Hidden.
         */
        fun confirmHide(a: Activity, what: String, name: String, onNo: () -> Unit = {}, onYes: () -> Unit) {
            val prefs = a.applicationContext.repo.prefs
            if (!prefs.askBeforeHide) { onYes(); return }
            var dontAsk = false
            val p = Popup(a, "Hide $what?")
            p.note("Hide \"$name\"? It leaves the list right away. You can bring it back in Settings → General → Hidden.")
            p.row("No") { onNo() }
            p.row("Do Not Show This Again", "☐", keepOpen = true) { r -> dontAsk = !dontAsk; r.setValue(if (dontAsk) "☑" else "☐") }
            p.row("Yes, Hide") { if (dontAsk) prefs.askBeforeHide = false; onYes() }
            p.onBack(onNo)
            p.show()
        }

        /**
         * Check boxes: [options] are (value, label) pairs. Rows toggle in place; [onDone] gets the ticked values when the window closes.
         * With [modeShow] / [modeHide] a first row switches between "show only the ticked" and "hide the ticked" (the include / exclude toggle).
         */
        fun multi(
            a: Activity, title: String, options: List<Pair<String, String>>, selected: Set<String>,
            modeShow: String? = null, modeHide: String = "", out: Boolean = false,
            onDone: (Set<String>, Boolean) -> Unit
        ) {
            val sel = LinkedHashSet(selected)
            var hide = out
            val p = Popup(a, title)
            val boxes = ArrayList<Pair<String, Row>>()
            if (modeShow != null) p.row("Mode", if (hide) modeHide else modeShow, keepOpen = true) { r ->
                hide = !hide; r.setValue(if (hide) modeHide else modeShow)
            }
            p.row("Clear All", keepOpen = true) { boxes.forEach { (_, r) -> r.setValue("☐") }; sel.clear() }
            for ((value, label) in options) {
                val r = p.row(label, if (value in sel) "☑" else "☐", keepOpen = true) { row ->
                    if (!sel.add(value)) sel.remove(value)
                    row.setValue(if (value in sel) "☑" else "☐")
                }
                boxes += value to r
            }
            p.onDismiss { onDone(sel, hide) }
            p.show()
        }

        /** One line of text (a name). The on-screen keyboard opens straight away; Done on it (or the OK row) accepts. */
        fun ask(a: Activity, title: String, hint: String, initial: String, okLabel: String = "Save", allowEmpty: Boolean = false, onCancel: () -> Unit = {}, onDone: (String) -> Unit) {
            if (a.isFinishing) return
            val d = Dialog(a)
            d.requestWindowFeature(Window.FEATURE_NO_TITLE)
            val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(24), a.dp(20), a.dp(24), a.dp(20)) }
            col.addView(TextView(a).apply {
                text = title; textSize = 24f; tag = "t:text"; setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            val edit = EditText(a).apply {
                setText(initial); setSelection(initial.length)
                this.hint = hint; textSize = 20f; tag = "t:text;h:dim"
                setSingleLine(true)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
                imeOptions = EditorInfo.IME_ACTION_DONE
                setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12))
                background = GradientDrawable().apply { setColor(Theme.bg); cornerRadius = a.dp(10).toFloat(); setStroke(a.dp(2), Theme.surface2) }
            }
            col.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = a.dp(14); bottomMargin = a.dp(10) })
            var answered = false
            fun submit() {
                val t = edit.text.toString().trim()
                if (t.isEmpty() && !allowEmpty) return
                answered = true; d.dismiss(); onDone(t)
            }
            d.setOnDismissListener { if (!answered) onCancel() }          // Cancel button or Back: the caller can return to where it came from
            edit.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { submit(); true } else false }
            fun button(t: String, go: () -> Unit) = TextView(a).apply {
                text = t; textSize = 19f; tag = "t:item;bg:item"; gravity = Gravity.CENTER
                isFocusable = true; isClickable = true
                setPadding(a.dp(14), a.dp(14), a.dp(14), a.dp(14))
                setOnClickListener { go() }
            }
            val buttons = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.addView(button(okLabel) { submit() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = a.dp(6) })
            buttons.addView(button("Cancel") { d.dismiss() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = a.dp(6) })
            col.addView(buttons)
            Theme.applyTree(col)
            d.setContentView(col)
            d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
            d.show()
            d.window?.apply {
                setBackgroundDrawable(GradientDrawable().apply { setColor(Theme.surface); cornerRadius = a.dp(16).toFloat() })
                setLayout(a.dp(620), ViewGroup.LayoutParams.WRAP_CONTENT)
                setDimAmount(0.65f)
            }
            edit.requestFocus()
        }
    }
}
