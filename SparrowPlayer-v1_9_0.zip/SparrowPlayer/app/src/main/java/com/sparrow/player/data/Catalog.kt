package com.sparrow.player.data

/**
 * Everything the Movies / Series screens and search need about ONE kind of title (movies or series) of ONE provider, read from the
 * database once and kept in memory: the light columns of every title ([VodLite], no plot / stream url), the [RowTitle]s the carousel builder
 * works on, and a few orders (newest, best rated, newest per category). For a 30 000 - 100 000 title catalogue the old code read all
 * of it again - every column, several times - each time a tab, a group or the search was opened, which is what made them crawl.
 *
 * Built in the background (see Repository.catalog) when the app starts and after every sync, so by the time a tab is opened it is ready.
 * Pure Kotlin (no Android types): unit tested.
 */
class VodCatalog private constructor(
    val providerId: Long,
    val type: String,
    val items: List<VodLite>,
    val titles: List<RowTitle>,
    val categoryNames: Map<String, String>
) {
    private val pos = HashMap<String, Int>(items.size * 2)
    init { items.forEachIndexed { i, v -> pos[v.uid] = i } }

    val size: Int get() = items.size

    fun indexOf(uid: String): Int = pos[uid] ?: -1
    fun lite(uid: String): VodLite? = pos[uid]?.let { items[it] }
    fun title(uid: String): RowTitle? = pos[uid]?.let { titles[it] }

    /** A card / row item. Plot, backdrop and stream url are left empty: the details screen reads the full row by uid. */
    fun item(v: VodLite): VodItem =
        VodItem(v.uid, providerId, v.uid.substringAfterLast(':'), type, v.name, v.poster, "", v.categoryId, v.rating, v.year, "", v.added, "", v.genre, "")

    fun items(uids: List<String>): List<VodItem> {
        val out = ArrayList<VodItem>(uids.size)
        for (u in uids) { val i = pos[u]; if (i != null) out += item(items[i]) }
        return out
    }

    private val genreSets = HashMap<String, Set<String>>()
    fun rec(v: VodLite): Recommender.Item {
        val g = synchronized(genreSets) { genreSets.getOrPut(v.genre) { Recommender.genresOf(v.genre) } }
        return Recommender.Item(v.uid, v.categoryId, g, Recommender.yearOf(v.year), Recommender.ratingOf(v.rating))
    }

    // ---- orders (built on first use, then shared) -----------------------------------------------------------------------
    private val byAdded: IntArray by lazy {
        items.indices.sortedWith(compareByDescending<Int> { items[it].added }.thenBy { it }).toIntArray()
    }
    private val byRating: IntArray by lazy {
        items.indices.sortedWith(compareByDescending<Int> { titles[it].rating }.thenByDescending { items[it].added }.thenBy { it }).toIntArray()
    }
    private val perCategory: Map<String, IntArray> by lazy {
        val m = HashMap<String, MutableList<Int>>()
        for (i in byAdded) m.getOrPut(items[i].categoryId) { ArrayList() }.add(i)
        m.mapValues { it.value.toIntArray() }
    }

    fun recent(limit: Int): List<VodLite> = byAdded.take(limit).map { items[it] }
    fun topRated(limit: Int): List<VodLite> = byRating.take(limit).map { items[it] }
    fun inCategory(categoryId: String, limit: Int): List<VodLite> = (perCategory[categoryId] ?: IntArray(0)).take(limit).map { items[it] }
    fun categorySize(categoryId: String): Int = perCategory[categoryId]?.size ?: 0

    /** Newest titles whose genre text contains [genre] (case blind). */
    fun byGenre(genre: String, limit: Int): List<VodLite> {
        val out = ArrayList<VodLite>()
        for (i in byAdded) { if (items[i].genre.contains(genre, ignoreCase = true)) { out += items[i]; if (out.size >= limit) break } }
        return out
    }

    companion object {
        /** [plots]: uid + description of the titles that have one (series): holiday words in them count (see [Holidays.maskOf]). */
        fun build(providerId: Long, type: String, items: List<VodLite>, categoryNames: Map<String, String>, plots: List<UidPlot> = emptyList()): VodCatalog {
            val preps = HashMap<String, HashMap<String, RowTitle.Prep>>()
            val titles = ArrayList<RowTitle>(items.size)
            for (v in items) {
                val cat = categoryNames[v.categoryId] ?: ""
                val prep = preps.getOrPut(v.categoryId) { HashMap() }.getOrPut(v.genre) { RowTitle.Prep.of(cat, v.genre) }
                val t = RowTitle(v.uid, v.name, cat, v.genre, Recommender.yearOf(v.year), Recommender.ratingOf(v.rating), v.added, prep)
                t.holidays = Holidays.screen(prep.holidays, TextNorm.prepare(v.name), prep.adult)
                titles += t
            }
            val c = VodCatalog(providerId, type, items, titles, categoryNames)
            for (p in plots) {
                val i = c.indexOf(p.uid)
                if (i >= 0) titles[i].let { t -> t.holidays = Holidays.withPlot(t.holidays, TextNorm.prepare(t.name), t.prep.adult, TextNorm.prepare(p.plot)) }
            }
            return c
        }
    }
}

/** The page of one genre or sub-genre, and the holiday lists, worked out from a [VodCatalog]. Pure Kotlin. */
object Pages {
    const val SUB = "#"

    /** "genre:family" -> main "family", sub null; "genre:family#3" -> ("family", 3). */
    fun parseGenreScope(scope: String): Pair<String, Int?> {
        val rest = scope.removePrefix(Genres.SCOPE_PREFIX)
        val sub = rest.substringAfter(SUB, "").toIntOrNull()
        return rest.substringBefore(SUB) to sub
    }

    fun genreScope(mainId: String, sub: Int? = null): String = Genres.SCOPE_PREFIX + mainId + (if (sub != null) SUB + sub else "")

    /**
     * A main genre, as ONE page: Top Rated, Recently Added, then one carousel per sub-genre that has titles (Action Comedies, Martial Arts ...),
     * then the provider's own categories inside it. (Sub-genres are no longer entries of the Groups list.) A sub-genre ([sub] = index in
     * [Genres.Main.subs]) can still be asked for on its own. Children & Family only keeps titles that pass [Maturity.familyOk] and also takes
     * well-known children's titles ([Maturity.isKidsTitle]) whose panel text says nothing. [known]: uid -> rating the panel gave.
     */
    fun genre(cat: VodCatalog, main: Genres.Main, sub: Int?, known: Map<String, String>): List<RowSpec> {
        val series = cat.type == "series"
        val family = main.id == "family"
        val cache = HashMap<RowTitle.Prep, Genres.Match>()
        val pick = ArrayList<Int>()
        val bySub = HashMap<Int, MutableList<Int>>()
        for (i in cat.titles.indices) {
            val t = cat.titles[i]
            val m = cache.getOrPut(t.prep) { Genres.classify(main, t.prepared) }
            val kidsBrand = family && sub == null && !m.inMain && Maturity.isKidsTitle(t.nameNorm)
            if (!m.inMain && !kidsBrand) continue
            if (sub != null && sub !in m.subs) continue
            if (family && !Maturity.familyOk(t, known[t.uid] ?: "", series)) continue
            pick += i
            if (sub == null) for (s in m.subs) bySub.getOrPut(s) { ArrayList() }.add(i)
        }
        if (pick.isEmpty()) return emptyList()
        val label = if (sub != null) main.subs[sub].name else main.name
        val out = ArrayList<RowSpec>()
        fun uids(l: List<Int>) = l.map { cat.items[it].uid }
        out += RowSpec("Top Rated in $label", uids(pick.sortedWith(compareByDescending<Int> { cat.titles[it].rating }.thenByDescending { cat.items[it].added }).take(40)))
        out += RowSpec("Recently Added in $label", uids(pick.sortedByDescending { cat.items[it].added }.take(40)))
        if (sub == null) {
            // the sub-genres become carousels: the fullest first, a name only once, nothing under MIN_SUB titles
            val seen = HashSet<String>()
            bySub.entries.filter { it.value.size >= MIN_SUB }
                .sortedWith(compareByDescending<Map.Entry<Int, MutableList<Int>>> { it.value.size }.thenBy { it.key })
                .take(MAX_SUB_ROWS).forEach { (si, l) ->
                    val name = main.subs[si].name
                    if (seen.add(name)) out += RowSpec(name, uids(l.sortedWith(compareByDescending<Int> { cat.titles[it].rating }.thenByDescending { cat.items[it].added }).take(40)))
                }
        }
        val byCat = LinkedHashMap<String, MutableList<Int>>()
        for (i in pick) byCat.getOrPut(cat.items[i].categoryId) { ArrayList() }.add(i)
        val have = out.map { it.title }.toHashSet()
        byCat.entries.filter { it.value.size >= 3 }.sortedByDescending { it.value.size }.take(if (sub != null) 8 else 12).forEach { (cid, l) ->
            val name = cat.categoryNames[cid] ?: ""
            if (name.isNotBlank() && name !in have) out += RowSpec(name, uids(l.sortedByDescending { cat.items[it].added }.take(40)))
        }
        return out
    }

    const val MIN_SUB = 3
    const val MAX_SUB_ROWS = 24

    /** The Holidays list: for each holiday (calendar order from the next one) its Top 10 What's Hot; holidays without titles are left out. */
    fun holidayList(cat: VodCatalog, today: Int, canada: Boolean, nowMs: Long): List<Pair<Holidays.Dated, List<String>>> =
        Holidays.order(today, canada).map { d -> d to HomeRows.holidayTop10(d.holiday, cat.titles, nowMs) }.filter { it.second.isNotEmpty() }
}
