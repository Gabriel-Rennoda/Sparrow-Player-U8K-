package com.sparrow.player.data

/**
 * The search list of Movies or Series, built ONCE per catalogue and kept (see Repository.searchIndex), instead of being rebuilt - 100 000 titles,
 * several regular expressions each - every time the search window opened. That rebuild was the long wait on the first (and every) open.
 *
 * What never changes between visits (quality / language / subtitle tags, genre sets, name order, the genre and year pick lists) is worked out here,
 * in the background, right after the catalogue itself. What belongs to the profile (my ratings, watched, Sparrow rating, length / maturity /
 * description remembered from details pages) is only a few hundred entries: [applyState] puts those on the shared candidates in a moment.
 * Pure Kotlin (JUnit tested).
 */
class SearchIndex private constructor(
    private val cat: VodCatalog,
    /** Every title, in name order (A-Z needs no sort afterwards). */
    val items: List<Candidate>,
    private val baseMaturity: Array<String>,                 // by catalogue index
    val genreOptions: List<String>,
    val yearOptions: List<Int>
) {
    private val touched = ArrayList<Candidate>()

    val poster: (String) -> String? = { uid -> cat.lite(uid)?.poster }

    /** Put the profile's state on the candidates (and take back what the previous visit put there). */
    @Synchronized
    fun applyState(
        mine: Map<String, String>, seen: Set<String>, metas: Map<String, MetaCache.Meta>,
        sparrowOf: (String) -> Double, sparrowKnown: Collection<String>
    ) {
        for (c in touched) {
            c.myRating = ""; c.watched = false; c.sparrow = -1.0; c.lengthMin = -1; c.description = ""
            val i = cat.indexOf(c.uid); if (i >= 0) c.maturity = baseMaturity[i]
        }
        touched.clear()
        fun cand(uid: String): Candidate? = byUid[uid]
        for ((uid, r) in mine) cand(uid)?.let { it.myRating = r; touched += it }
        for (uid in seen) cand(uid)?.let { it.watched = true; touched += it }
        for (uid in sparrowKnown) cand(uid)?.let { it.sparrow = sparrowOf(uid); touched += it }
        for ((uid, m) in metas) cand(uid)?.let {
            it.lengthMin = if (m.lengthMin >= 0) m.lengthMin else -1
            it.description = m.plot
            val fromInfo = m.maturity.let { x -> if (x.isBlank()) "" else MediaTags.maturity(x).ifBlank { x } }
            if (fromInfo.isNotBlank()) it.maturity = fromInfo
            touched += it
        }
    }

    private val byUid: HashMap<String, Candidate> by lazy { HashMap<String, Candidate>(items.size * 2).also { m -> items.forEach { m[it.uid] = it } } }

    companion object {
        fun build(cat: VodCatalog): SearchIndex {
            // quality / language / subtitle / maturity tags of a CATEGORY name are worked out once per category, not once per title
            class CatTags(val name: String, val quality: String, val languages: Set<String>, val subs: Boolean, val maturity: String)
            val catTags = HashMap<String, CatTags>()
            val genreKeyed = HashMap<String, HashMap<String, Set<String>>>()          // one genre set per distinct (category, genre) pair
            val rank = HashMap<String, Int>()
            fun order(q: String) = rank.getOrPut(q) { MediaTags.QUALITIES.indexOf(q).let { if (it < 0) 99 else it } }
            val out = ArrayList<Candidate>(cat.size)
            val base = ArrayList<String>(cat.size)
            val genreCount = HashMap<String, Int>()
            var minY = Int.MAX_VALUE; var maxY = 0
            for (v in cat.items) {
                val ct = catTags.getOrPut(v.categoryId) {
                    val n = cat.categoryNames[v.categoryId] ?: ""
                    CatTags(n, MediaTags.quality(n), MediaTags.languages(n), MediaTags.hasSubtitles(n), MediaTags.maturity(n))
                }
                val g = genreKeyed.getOrPut(v.categoryId) { HashMap() }.getOrPut(v.genre) {
                    // the category name stands in for the genre when the panel has none
                    val b = Recommender.genresOf(v.genre)
                    if (ct.name.isBlank()) b else b + ct.name.lowercase()
                }
                val q = MediaTags.quality(v.name)
                val quality = if (order(q) <= order(ct.quality)) q else ct.quality               // the better of the title's and the category's tag
                val langs = MediaTags.languages(v.name).let { if (ct.languages.isEmpty()) it else it + ct.languages }
                val maturity = MediaTags.maturity(v.name).ifBlank { ct.maturity }.ifBlank { "Not Rated" }
                val year = Recommender.yearOf(v.year)
                if (year in 1900..2100) { if (year < minY) minY = year; if (year > maxY) maxY = year }
                out += Candidate(
                    uid = v.uid, name = v.name, group = ct.name, genres = g, year = year, stars = SparrowRating.providerOf(v.rating),
                    added = v.added, maturity = maturity, quality = quality, languages = langs,
                    subtitles = ct.subs || MediaTags.hasSubtitles(v.name)
                )
                base += maturity
            }
            // keep the name order, and the base maturities in step with it
            val idx = out.indices.sortedBy { out[it].nameLower }
            val sorted = idx.map { out[it] }
            for (c in sorted) for (g in c.genres) genreCount[g] = (genreCount[g] ?: 0) + 1
            val genres = genreCount.entries.sortedByDescending { it.value }.take(120).map { it.key }.sorted()
            val years = if (maxY == 0) emptyList() else (minY..maxY).toList()
            // base maturity is looked up by catalogue index (cat.indexOf), so it stays in catalogue order
            return SearchIndex(cat, sorted, base.toTypedArray(), genres, years)
        }
    }
}
