package com.sparrow.player.data

import android.app.Application
import androidx.room.Room
import androidx.room.withTransaction
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import com.sparrow.player.util.TitleCase

/** A channel group as shown in the groups panel. [original] = the provider's name (for "reset"), [custom] = created by the user. */
data class GroupInfo(val id: String, val name: String, val original: String, val custom: Boolean, val hidden: Boolean)

class Repository(app: Application) {
    // Providers (with their logins) live in this database. There is deliberately NO fallbackToDestructiveMigration(): if a
    // schema change ever ships without a Migration, Room must refuse loudly instead of silently deleting the user's providers.
    // Rule: any change to an @Entity => bump AppDb.version AND add a Migration here (see docs/UPGRADE_SAFETY.md).
    val db: AppDb = Room.databaseBuilder(app, AppDb::class.java, "sparrow.db").addMigrations(*Migrations.ALL).build()
    val dao = db.dao()
    val prefs = Prefs(app)

    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .addInterceptor { it.proceed(it.request().newBuilder().header("User-Agent", Prefs.UA).build()) }
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val status = MutableStateFlow("")
    val dataVersion = MutableStateFlow(0)

    /** Bumped when only the TV guide was refreshed: the guide reloads its programmes in place, the selection stays where it is. */
    val epgVersion = MutableStateFlow(0)

    @Volatile var active: Provider? = null
        private set

    suspend fun activeProvider(): Provider? {
        val p = dao.provider(prefs.activeProvider) ?: dao.providers().firstOrNull()
        if (p != null) prefs.activeProvider = p.id
        active = p
        return p
    }

    // ---- URLs -------------------------------------------------------------------------------
    fun liveUrl(c: Channel): String =
        if (c.streamUrl.isNotBlank()) c.streamUrl else Urls.live(active!!, c.remoteId, prefs.liveFormat)

    fun movieUrl(v: VodItem): String =
        if (v.streamUrl.isNotBlank()) v.streamUrl else Urls.movie(active!!, v.remoteId, v.ext.ifBlank { "mp4" })

    fun episodeUrl(e: Episode): String = Urls.episode(active!!, e.id, e.ext)

    suspend fun seriesEpisodes(v: VodItem): List<Episode> = withContext(Dispatchers.IO) {
        val x = XtreamClient(http, active!!)
        val l = x.seriesEpisodes(v.remoteId)
        if (x.maturity.isNotEmpty()) remember(v.uid, -1, x.maturity, v.plot)       // lets Children & Family tell a cartoon for kids from one for adults
        l
    }

    suspend fun vodInfo(v: VodItem): Map<String, Any?> = withContext(Dispatchers.IO) {
        try { XtreamClient(http, active!!).vodInfo(v.remoteId) } catch (e: Exception) { emptyMap() }
    }

    // ---- profiles and My List -----------------------------------------------------------------
    @Synchronized fun profileStore(): ProfileStore = profilesCache ?: ProfileStore.parse(prefs.profilesRaw).also { profilesCache = it }
    @Synchronized fun saveProfiles() { prefs.profilesRaw = profileStore().serialize() }

    /** Set after the "Who's watching?" choice (or when there is only one profile), so the picker shows once per launch. */
    @Volatile var profileConfirmed = false

    @Synchronized fun activeProfile(): Profile {
        val st = profileStore()
        return st.get(prefs.profile) ?: st.profiles.first().also { prefs.profile = it.id }
    }

    /** Switch profile: history, resume points, ratings and My List now come from the new one. */
    @Synchronized fun switchProfile(id: String) {
        prefs.profile = id
        ratingsCache = null; sparrowCache = null; myListCache = null; holidayFavCache = null
        dataVersion.value++
    }

    @Synchronized fun inMyList(uid: String) = myListObj().contains(uid)
    @Synchronized fun myListUids(): List<String> = ArrayList(myListObj().all())
    /** Add / remove a title; returns true if it is in My List afterwards. */
    @Synchronized fun toggleMyList(uid: String): Boolean { val r = myListObj().toggle(uid); prefs.myListRaw = myListObj().serialize(); return r }

    // ---- the catalogue of Movies / Series (kept in memory, see VodCatalog) -------------------------------------
    /** Bumped when the titles in the database change (sync, playlist deleted): the in-memory catalogues are then read again. */
    @Volatile private var catalogVersion = 0
    private val catalogs = LinkedHashMap<String, Deferred<VodCatalog>>()

    /**
     * The catalogue of [type] ("movie" / "series") of provider [pid]. Built once on a background thread and shared: callers that arrive
     * while it is being built wait for the same build. Cancelling a caller (leaving the screen) does not cancel the build.
     */
    suspend fun catalog(pid: Long, type: String): VodCatalog {
        val key = "$pid|$type|$catalogVersion"
        val d = synchronized(catalogs) {
            catalogs[key] ?: scope.async(Dispatchers.Default) { buildCatalog(pid, type) }.also { catalogs[key] = it
                while (catalogs.size > 4) catalogs.remove(catalogs.keys.first()) }
        }
        try { return d.await() } catch (e: CancellationException) { throw e } catch (e: Exception) { synchronized(catalogs) { catalogs.remove(key) }; throw e }
    }

    private suspend fun buildCatalog(pid: Long, type: String): VodCatalog {
        val names = dao.categories(pid, if (type == "movie") "vod" else "series").associate { it.remoteId to TitleCase.of(it.name) }
        val items = dao.vodLite(pid, type)
        val plots = ArrayList(dao.vodPlots(pid, type))
        for ((uid, m) in metaAll()) if (m.plot.isNotBlank() && uid.startsWith("$pid:")) plots += UidPlot(uid, m.plot)     // movies: plots remembered from details pages
        return VodCatalog.build(pid, type, items, names, plots)
    }

    // ---- the search list (see SearchIndex): built once per catalogue, shared by every visit to the search window ---------------
    private val searchIndexes = LinkedHashMap<String, Deferred<SearchIndex>>()

    /** The search list of [cat], with the profile's own state (my ratings, watched, Sparrow ratings, remembered length / plot) applied. */
    suspend fun searchIndex(cat: VodCatalog): SearchIndex {
        val key = "${cat.providerId}|${cat.type}|$catalogVersion"
        val d = synchronized(searchIndexes) {
            searchIndexes[key] ?: scope.async(Dispatchers.Default) { SearchIndex.build(cat) }.also {
                searchIndexes[key] = it
                while (searchIndexes.size > 4) searchIndexes.remove(searchIndexes.keys.first())
            }
        }
        val idx = try { d.await() } catch (e: CancellationException) { throw e } catch (e: Exception) { synchronized(searchIndexes) { searchIndexes.remove(key) }; throw e }
        withContext(Dispatchers.Default) { refreshSearchState(idx) }
        return idx
    }

    private fun refreshSearchState(idx: SearchIndex) {
        val mine = synchronized(this) { myRatings() }
        val metas = synchronized(this) { metaSnapshot() }
        val sp = synchronized(this) { sparrowScores().all() }
        val seen = prefs.history().map { it.uid }.toHashSet()
        idx.applyState(mine, seen, metas, { uid -> sp[uid] ?: -1.0 }, sp.keys)
    }

    /** Read the catalogues of the active playlist ahead of time (app start, after a sync) so Movies / Series / search open at once. */
    fun warmCatalogs() {
        scope.launch {
            delay(2500)                                         // the first screen and the guide come first
            val p = (try { activeProvider() } catch (e: Exception) { null }) ?: return@launch
            for (t in listOf("movie", "series")) {
                try { val c = catalog(p.id, t); searchIndex(c); withContext(Dispatchers.Default) { genreIndex(p.id, t) }; namedRows(c).await() } catch (e: CancellationException) { throw e } catch (e: Exception) { }
            }
        }
    }

    // ---- genre tabs of Movies / Series --------------------------------------------------------
    private val genreCache = HashMap<String, Genres.Index>()

    /** The main genres that have at least one title and, for each, its sub-genres that have titles. Cached until the next sync. */
    suspend fun genreIndex(pid: Long, type: String): Genres.Index {
        val key = "$pid|$type|$catalogVersion"
        synchronized(genreCache) { genreCache[key] }?.let { return it }
        val names = dao.categories(pid, if (type == "movie") "vod" else "series").associate { it.remoteId to it.name }
        val combos = dao.catGenres(pid, type)
        val found = withContext(Dispatchers.Default) {
            Genres.index(combos.map { TextNorm.prepare(it.genre + " " + (names[it.categoryId] ?: "")) }.distinct())
        }
        synchronized(genreCache) { genreCache.clear(); genreCache[key] = found }
        return found
    }

    // ---- the named carousels of the Movies / Series home (Top 10, My List, platforms ...): the heavy part, cached --------
    private val namedCache = HashMap<String, Deferred<List<RowSpec>>>()

    /** What the panel told us about ratings (titles whose details were opened): uid -> "PG-13", "TV-MA" ... */
    @Synchronized fun maturities(): Map<String, String> = metaCache.maturities()
    @Synchronized private fun metaAll(): Map<String, MetaCache.Meta> = metaCache.all()

    /**
     * The named carousels for [cat], worked out in the background once per catalogue, day and state of the profile and then shared:
     * whoever asks while it is being worked out waits for the same result (the screen shows its other rows meanwhile).
     */
    fun namedRows(cat: VodCatalog): Deferred<List<RowSpec>> {
        val movies = cat.type == "movie"
        val hist = prefs.history()
        val finished = hist.mapNotNull { cat.lite(it.uid) }.filter { !prefs.inProgress(cat.type, it.uid) }.map { it.uid }
        val mine = myListUids(); val verdicts = myRatings(); val known = maturities()
        val now = System.currentTimeMillis()
        val key = "${cat.providerId}|${cat.type}|$catalogVersion|${now / 86_400_000L}|${prefs.profile}|${mine.hashCode()}|${finished.hashCode()}|${verdicts.hashCode()}|${known.size}"
        val prefix = "${cat.providerId}|${cat.type}|"
        return synchronized(namedCache) {
            namedCache[key] ?: scope.async(Dispatchers.Default) {
                val country = java.util.Locale.getDefault().displayCountry.ifBlank { "Your Country" }
                HomeRows.build(cat.titles, RowCtx(now, movies, country, activeProfile().name, finished, mine, verdicts, known))
            }.also {
                namedCache.keys.removeAll { k -> k.startsWith(prefix) }
                namedCache[key] = it
            }
        }
    }

    // ---- My Holiday Favourites: titles saved by hand (per profile) --------------------------------------------
    private var holidayFavCache: MyList? = null
    private fun holidayFavObj(): MyList = holidayFavCache ?: MyList.parse(prefs.holidayFavsRaw).also { holidayFavCache = it }
    @Synchronized fun holidayFavUids(): List<String> = ArrayList(holidayFavObj().all())
    @Synchronized fun inHolidayFavs(uid: String) = holidayFavObj().contains(uid)
    /** Add / remove a title; returns true if it is saved afterwards. */
    @Synchronized fun toggleHolidayFav(uid: String): Boolean { val r = holidayFavObj().toggle(uid); prefs.holidayFavsRaw = holidayFavObj().serialize(); return r }

    // ---- the user's own ratings and what search remembers about titles ------------------------
    private val metaPrefs = app.getSharedPreferences("sparrow_meta", android.content.Context.MODE_PRIVATE)     // separate file: the big one loads lazily

    private var ratingsCache: UserRatings? = null
    private var sparrowCache: SparrowScores? = null
    private var myListCache: MyList? = null
    private var profilesCache: ProfileStore? = null
    private fun userRatings(): UserRatings = ratingsCache ?: UserRatings.parse(prefs.ratingsRaw).also { ratingsCache = it }
    private fun sparrowScores(): SparrowScores = sparrowCache ?: SparrowScores.parse(prefs.sparrowRaw).also { sparrowCache = it }
    private fun myListObj(): MyList = myListCache ?: MyList.parse(prefs.myListRaw).also { myListCache = it }
    private val metaCache: MetaCache by lazy { MetaCache.parse(metaPrefs.getString("meta", "")) }

    @Synchronized fun myRating(uid: String): String = userRatings().get(uid)
    @Synchronized fun myRatings(): Map<String, String> = LinkedHashMap(userRatings().all())

    /** Loved / Liked / Disliked; pressing the same one again removes it. Returns the rating now stored ("" = none). */
    @Synchronized fun rate(uid: String, code: String): String {
        userRatings().toggle(uid, code); prefs.ratingsRaw = userRatings().serialize()
        return userRatings().get(uid)
    }

    // ---- the two star ratings on every poster ------------------------------------------------

    /** The provider's own rating (0 - 10, one decimal; -1 = none). */
    fun providerRatingOf(v: VodItem): Double = SparrowRating.providerOf(v.rating)

    /** The user's own Sparrow Rating of a title (0.5 - 10 in half steps; -1 = not rated). Independent of Loved / Liked / Disliked. */
    @Synchronized fun sparrowOf(v: VodItem): Double = sparrowScores().get(v.uid)
    @Synchronized fun sparrowOf(uid: String): Double = sparrowScores().get(uid)

    /** Everything search remembers about titles (length, rating, plot), copied once so 100 000 titles do not each take the lock. */
    @Synchronized fun metaSnapshot(): Map<String, MetaCache.Meta> = metaCache.all()

    /** Set (0.5 - 10) or clear (0 or less) the user's Sparrow Rating. */
    @Synchronized fun setSparrow(uid: String, value: Double) {
        sparrowScores().set(uid, value); prefs.sparrowRaw = sparrowScores().serialize()
    }

    @Synchronized fun meta(uid: String): MetaCache.Meta? = metaCache.get(uid)

    /** Remember length / maturity / plot from a details page, for search. */
    @Synchronized fun remember(uid: String, lengthMin: Int, maturity: String, plot: String) {
        metaCache.put(uid, lengthMin, maturity, plot)
        metaPrefs.edit().putString("meta", metaCache.serialize()).apply()
    }

    // ---- Channel helpers --------------------------------------------------------------------
    private val customCache = HashMap<Long, Customize>()

    /** The user's edits (hidden / renamed channels, own groups ...) for one provider. Edit it, then call [saveCustom]. */
    @Synchronized
    fun custom(pid: Long): Customize = customCache.getOrPut(pid) { Customize.parse(prefs.custom(pid)) }

    fun saveCustom(pid: Long) {
        prefs.setCustom(pid, custom(pid).serialize())
        dataTick.value++
    }

    /** Bumped whenever the user's channel / group edits change (separate from [dataVersion], which reloads everything). */
    val dataTick = MutableStateFlow(0)

    /** Channels of a group with the user's edits applied: hidden ones left out (unless [includeHidden]), renamed ones renamed. */
    suspend fun channelsFor(pid: Long, scope: String, includeHidden: Boolean = false): List<Channel> {
        val cu = custom(pid)
        var list = when (scope) {
            SCOPE_ALL -> dao.channels(pid)
            SCOPE_FAV -> dao.favorites(pid)
            else -> groupChannels(pid, scope, cu)
        }
        if (!includeHidden && cu.hidden.isNotEmpty()) list = list.filter { it.uid !in cu.hidden }
        return named(list, cu)
    }

    private suspend fun groupChannels(pid: Long, gid: String, cu: Customize): List<Channel> {
        val out: Set<String> = cu.removed[gid] ?: emptySet()
        val base = if (cu.isCustom(gid)) emptyList() else dao.channelsIn(pid, gid).let { l -> if (out.isEmpty()) l else l.filter { it.uid !in out } }
        val extra = cu.added[gid]?.toList().orEmpty()
        if (extra.isEmpty()) return base
        val have = base.mapTo(HashSet()) { it.uid }
        val more = ArrayList<Channel>()
        extra.chunked(500).forEach { more += dao.channelsByUids(it) }
        return (base + more.filter { it.uid !in have && it.providerId == pid }).sortedWith(compareBy({ it.number }, { it.name }))
    }

    private fun named(list: List<Channel>, cu: Customize): List<Channel> =
        if (cu.renamed.isEmpty()) list else list.map { c -> cu.renamed[c.uid]?.let { n -> c.copy(name = n) } ?: c }

    /**
     * The channel groups after the user's edits, in the order they are shown (the two built-in ones, All Channels and Favourites,
     * are not part of this list). Hidden groups are included and flagged.
     */
    suspend fun groups(pid: Long): List<GroupInfo> {
        val cu = custom(pid)
        val cats = dao.categories(pid, "live")
        val original = cats.associate { it.remoteId to TitleCase.of(it.name) }
        val natural = cu.customGroups.keys.toList() + cats.map { it.remoteId }
        return cu.arrange(natural.distinct()).map { id ->
            val orig = original[id] ?: cu.customGroups[id] ?: id
            GroupInfo(id, cu.groupName(id, orig), orig, cu.isCustom(id), cu.isGroupHidden(id))
        }
    }

    /** One channel with the user's name applied (null if it no longer exists). */
    suspend fun channel(uid: String): Channel? {
        val c = dao.channel(uid) ?: return null
        return named(listOf(c), custom(c.providerId)).first()
    }

    /** The channels this provider shows by default (hidden ones left out). */
    suspend fun firstChannel(pid: Long): Channel? = channelsFor(pid, SCOPE_ALL).firstOrNull()

    /** Channels the user hid (for Settings -> General -> Hidden). */
    suspend fun hiddenChannels(pid: Long): List<Channel> {
        val cu = custom(pid)
        if (cu.hidden.isEmpty()) return emptyList()
        val out = ArrayList<Channel>()
        cu.hidden.toList().chunked(500).forEach { out += dao.channelsByUids(it) }
        return named(out.filter { it.providerId == pid }, cu)
    }

    /** Currently airing programme per epgId. */
    suspend fun nowMap(pid: Long, channels: List<Channel>): Map<String, Programme> {
        val now = System.currentTimeMillis()
        val ids = channels.map { it.epgId }.filter { it.isNotBlank() }.distinct()
        val out = HashMap<String, Programme>()
        ids.chunked(500).forEach { chunk ->
            dao.programmes(pid, chunk, now, now + 1).forEach { out[it.epgId] = it }
        }
        return out
    }

    suspend fun deleteProvider(p: Provider) {
        withContext(Dispatchers.IO) { dao.deleteProgrammes(p.id) }
        db.withTransaction {
            dao.deleteChannels(p.id); dao.deleteVod(p.id); dao.deleteCategories(p.id)
            dao.deleteProvider(p.id)
        }
        // Deleting a playlist that is not the active one must not switch the user away from the one they are watching.
        if (prefs.activeProvider == p.id) { prefs.activeProvider = -1; active = null }
        forgetCustom(p.id)
        catalogVersion++
        dataVersion.value++
    }

    @Synchronized
    private fun forgetCustom(pid: Long) { customCache.remove(pid); prefs.setCustom(pid, ""); prefs.setLastEpgSync(pid, 0L) }

    // ---- Sync -------------------------------------------------------------------------------
    private val syncing = AtomicBoolean(false)

    /** Run [block] unless another sync is already running; failures show in the status line and never crash the app. */
    private suspend fun guarded(block: suspend () -> Unit) {
        if (!syncing.compareAndSet(false, true)) {
            status.value = "A sync is already running"; delay(2500)
            if (status.value == "A sync is already running") status.value = ""
            return
        }
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            status.value = "Sync failed: ${e.message}"
            delay(8000)
            status.value = ""
        } finally {
            syncing.set(false)
        }
    }

    /** Full sync: channels, movies, series and the guide ("Sync Now", a new playlist). */
    fun syncAsync(p: Provider) {
        scope.launch { guarded { sync(p) } }
    }

    /** Guide only (automatic EPG sync). */
    fun syncEpgAsync(p: Provider) {
        scope.launch { guarded { syncEpgOnly(p) } }
    }

    private var scheduler: Job? = null

    /**
     * Automatic guide sync: once when the app starts (if "Sync EPG On App Start" is on and the last sync is older than ten minutes),
     * then whenever the chosen interval (24 / 12 / 6 / 3 / 2 hours) has passed. Checked every five minutes while the app is running.
     */
    fun startScheduler() {
        if (scheduler != null) return
        scheduler = scope.launch {
            delay(4_000)                                          // let the screen come up first
            var first = true
            while (true) {
                val p = try { activeProvider() } catch (e: Exception) { null }
                if (p != null) {
                    val age = System.currentTimeMillis() - prefs.lastEpgSync(p.id)
                    val due = age >= prefs.epgHours * 3_600_000L
                    val atStart = first && prefs.epgOnStart && age >= START_GAP_MS
                    if (due || atStart) guarded { syncEpgOnly(p) }
                }
                first = false
                delay(5 * 60_000L)
            }
        }
    }

    private suspend fun syncEpgOnly(p: Provider) = withContext(Dispatchers.IO) {
        val st = { s: String -> status.value = s }
        try {
            if (syncEpg(p, st)) {
                prefs.setLastEpgSync(p.id, System.currentTimeMillis())
                epgVersion.value++
                st("Guide updated"); delay(2000); st("")
            } else st("")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            st("TV guide failed: ${e.message}"); delay(5000); st("")
        }
    }

    private suspend fun sync(p0: Provider) = withContext(Dispatchers.IO) {
        var p = p0
        val st = { s: String -> status.value = s }
        if (p.type == "xtream") syncXtream(p, st) else p = syncM3u(p, st)
        try {
            if (syncEpg(p, st)) prefs.setLastEpgSync(p.id, System.currentTimeMillis())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            st("TV guide failed: ${e.message}"); delay(5000)
        }
        dao.updateProvider(p.copy(lastSync = System.currentTimeMillis()))
        dataVersion.value++
        st("Ready"); delay(2000); st("")
    }

    private suspend fun syncXtream(p: Provider, st: (String) -> Unit) {
        val x = XtreamClient(http, p)
        st("Signing in…")
        if (!x.authenticate()) error("Login failed – check server, username and password")
        val favs = dao.favoriteKeys(p.id)

        st("Loading categories…")
        val cats = ArrayList<Category>()
        for ((action, type) in listOf("get_live_categories" to "live", "get_vod_categories" to "vod", "get_series_categories" to "series")) {
            x.list(action) { m -> cats += Category(providerId = p.id, remoteId = m.str("category_id"), name = m.str("category_name"), type = type) }
        }

        st("Loading live channels…")
        val ch = ArrayList<Channel>(); var n = 0
        x.list("get_live_streams") { m ->
            n++
            val id = m.str("stream_id")
            ch += Channel("${p.id}:$id", p.id, id, m.str("num").toIntOrNull() ?: n, m.str("name"),
                m.str("stream_icon"), "", m.str("category_id"), m.str("epg_channel_id"), false)
        }

        st("Loading movies…")
        val vod = ArrayList<VodItem>()
        x.list("get_vod_streams") { m ->
            val id = m.str("stream_id")
            vod += VodItem("${p.id}:m:$id", p.id, id, "movie", m.str("name"), m.str("stream_icon"), m.str("stream_icon"),
                m.str("category_id"), m.str("rating"), m.str("year"), "", m.str("added").toLongOrNull() ?: 0,
                m.str("container_extension"), "", "")
        }

        st("Loading series…")
        x.list("get_series") { m ->
            val id = m.str("series_id")
            val bd = (m["backdrop_path"] as? List<*>)?.firstOrNull()?.toString() ?: ""
            vod += VodItem("${p.id}:s:$id", p.id, id, "series", m.str("name"), m.str("cover"), bd.ifBlank { m.str("cover") },
                m.str("category_id"), m.str("rating"), m.str("year").ifBlank { m.str("releaseDate").take(4) },
                m.str("plot"), m.str("last_modified").toLongOrNull() ?: 0, "", m.str("genre"), "")
        }
        st("Saving…")
        store(p, cats, ch, vod, favs)
    }

    private suspend fun syncM3u(p: Provider, st: (String) -> Unit): Provider {
        st("Downloading playlist…")
        val favs = dao.favoriteKeys(p.id)
        val ch = ArrayList<Channel>(); val vod = ArrayList<VodItem>()
        val liveGroups = LinkedHashSet<String>(); val vodGroups = LinkedHashSet<String>()
        var n = 0
        var epg = ""
        http.newCall(Request.Builder().url(p.m3uUrl).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            epg = M3uParser.parse(r.body!!.byteStream()) { e ->
                n++
                val id = Integer.toHexString(e.url.hashCode())
                if (e.url.contains("/movie/")) {
                    vodGroups += e.group
                    vod += VodItem("${p.id}:m:$id", p.id, id, "movie", e.name, e.logo, e.logo, e.group, "", "", "",
                        n.toLong(), "", "", e.url)
                } else {
                    liveGroups += e.group
                    ch += Channel("${p.id}:$id", p.id, id, e.chno ?: n, e.name, e.logo, e.url, e.group, e.tvgId, false)
                }
            }
        }
        val cats = liveGroups.map { Category(providerId = p.id, remoteId = it, name = it, type = "live") } +
            vodGroups.map { Category(providerId = p.id, remoteId = it, name = it, type = "vod") }
        st("Saving…")
        store(p, cats, ch, vod, favs)
        return if (p.epgUrl.isBlank() && epg.isNotBlank()) p.copy(epgUrl = epg) else p
    }

    private suspend fun store(p: Provider, cats: List<Category>, ch: List<Channel>, vod: List<VodItem>, favs: List<String>) {
        db.withTransaction {
            dao.deleteCategories(p.id); dao.deleteChannels(p.id); dao.deleteVod(p.id)
            dao.insertCategories(cats)
            ch.chunked(2000).forEach { dao.insertChannels(it) }
            vod.chunked(2000).forEach { dao.insertVod(it) }
            favs.chunked(500).forEach { dao.restoreFavorites(it) }
        }
        catalogVersion++
        dataVersion.value++
        warmCatalogs()
    }

    /** @return true if a guide was downloaded and imported (false = nothing to do: no EPG source / no channel with a guide id). */
    private suspend fun syncEpg(p: Provider, st: (String) -> Unit): Boolean {
        val url = when {
            p.epgUrl.isNotBlank() -> p.epgUrl
            p.type == "xtream" -> Urls.xmltv(p)
            else -> return false
        }
        val ids = dao.channels(p.id).map { it.epgId }.filter { it.isNotBlank() }.toHashSet()
        if (ids.isEmpty()) return false
        st("Downloading TV guide…")
        val now = System.currentTimeMillis()
        val from = now - 3 * 3600_000L; val to = now + 36 * 3600_000L
        http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("EPG HTTP ${r.code}")      // old guide data is only replaced once the server answered OK
            dao.deleteProgrammes(p.id)
            val input = XmltvParser.maybeGunzip(r.body!!.byteStream())
            val buf = ArrayList<Programme>(); var count = 0
            XmltvParser.parse(input, ids, from, to) { pr ->
                buf += pr.copy(providerId = p.id); count++
                if (buf.size >= 1500) {
                    dao.insertProgrammes(ArrayList(buf)); buf.clear(); st("Importing TV guide… $count")
                }
            }
            if (buf.isNotEmpty()) dao.insertProgrammes(buf)
        }
        return true
    }

    companion object {
        const val START_GAP_MS = 10 * 60_000L          // "sync on app start" is skipped if the guide was updated less than 10 minutes ago
        const val SCOPE_HOLIDAY_FAVS = "__holidayfavs"
        const val SCOPE_HOLIDAYS = "__holidays"
        const val SCOPE_ALL = "__all"
        const val SCOPE_FAV = "__fav"
    }
}
