package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class SearchIndexTest {
    private fun v(i: Int, name: String, cat: String = "1", genre: String = "Action", year: String = "2015") =
        VodLite("1:m:$i", cat, name, "http://p/$i.jpg", "7", year, i.toLong(), genre)

    private val names = mapOf("1" to "EN | Action 4K", "2" to "FR | Drame")
    private fun build() = SearchIndex.build(VodCatalog.build(1, "movie", listOf(v(1, "Zulu", year = "1964"), v(2, "alpha", cat = "2", genre = "Drama", year = "2020"), v(3, "Beta [PG-13]")), names, emptyList()))

    @Test fun builtOnceInNameOrderWithPickLists() {
        val idx = build()
        assertEquals(listOf("alpha", "Beta [PG-13]", "Zulu"), idx.items.map { it.name })
        assertEquals((1964..2020).toList(), idx.yearOptions)
        assertTrue("drama" in idx.genreOptions && "action" in idx.genreOptions)
        val beta = idx.items[1]
        assertEquals("PG-13", beta.maturity); assertEquals("4K", beta.quality); assertTrue("en" in beta.languages)       // tags of the title and of its category
        assertEquals("http://p/1.jpg", idx.poster("1:m:1"))
    }

    @Test fun stateIsAppliedAndTakenBackOnTheNextVisit() {
        val idx = build()
        val meta = mapOf("1:m:1" to MetaCache.Meta(110, "R", "a long plot"))
        idx.applyState(mapOf("1:m:2" to "loved"), setOf("1:m:3"), meta, { if (it == "1:m:1") 4.5 else -1.0 }, listOf("1:m:1"))
        val by = idx.items.associateBy { it.uid }
        assertEquals("loved", by["1:m:2"]!!.myRating); assertTrue(by["1:m:3"]!!.watched)
        assertEquals(110, by["1:m:1"]!!.lengthMin); assertEquals("R", by["1:m:1"]!!.maturity); assertEquals(4.5, by["1:m:1"]!!.sparrow, 0.0)
        assertEquals("a long plot", by["1:m:1"]!!.description); assertTrue(by["1:m:1"]!!.descLower.contains("long plot"))
        // next visit: nothing set any more -> everything is back to the base values
        idx.applyState(emptyMap(), emptySet(), emptyMap(), { -1.0 }, emptyList())
        val c = idx.items.associateBy { it.uid }
        assertEquals("", c["1:m:2"]!!.myRating); assertFalse(c["1:m:3"]!!.watched)
        assertEquals(-1, c["1:m:1"]!!.lengthMin); assertEquals("Not Rated", c["1:m:1"]!!.maturity); assertEquals(-1.0, c["1:m:1"]!!.sparrow, 0.0); assertEquals("", c["1:m:1"]!!.description)
    }

    @Test fun sharedListWorksWithTheEngine() {
        val idx = build()
        idx.applyState(emptyMap(), emptySet(), emptyMap(), { -1.0 }, emptyList())
        val r = SearchEngine.apply(idx.items, SearchFilters(SearchKind.MOVIE, text = "alp", yearFrom = 2000), presortedByName = true)
        assertEquals(listOf("alpha"), r.map { it.name })
    }
}
