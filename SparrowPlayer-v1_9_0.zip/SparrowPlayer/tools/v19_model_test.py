#!/usr/bin/env python3
"""Model tests for the 1.9.0 behaviours (no Kotlin compiler here: the word lists are PARSED from the Kotlin sources and the logic mirrored).
Holiday screening in / out, Children & Family rules, sub-genre carousels, search-index cost, group-Move anchoring, hide-without-reload.
python3 tools/v19_model_test.py"""
import re, os
R = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "java", "com", "sparrow", "player", "data")
fails = []
def ok(c, m): print(("PASS " if c else "FAIL ") + m); (not c) and fails.append(m)
def prep(t): return " " + re.sub(r"[^0-9a-z]+", " ", t.lower()).strip() + " "
def has(p, words): return any(" " + w + " " in p for w in words)

# ---------- parse Holidays.kt
src = open(os.path.join(R, "Holidays.kt")).read()
H = {}
for m in re.finditer(r'val (\w+) = Holiday\("(\w+)", "[^"]*",(.*?)(?=\n    val |\n\n)', src, re.S):
    body = m.group(3)
    def lst(name):
        mm = re.search(name + r' = listOf\((.*?)\)(?=,\n|\)$|\)\s*$|$)', body, re.S)
        return re.findall(r'"([^"]*)"', mm.group(1)) if mm else []
    H[m.group(2)] = dict(kw=lst("keywords"), cat=lst("categoryWords"), ex=lst("exclude"))
ok(len(H) == 11, "11 holidays parsed from Holidays.kt (%d)" % len(H))
AMB = set(re.findall(r'"([^"]+)"', re.search(r'AMBIGUOUS_IN_PLOT = setOf\((.*?)\)\n', src, re.S).group(1)))
ADULT_CAT = re.findall(r'"([^"]+)"', re.search(r'ADULT_CATEGORY = listOf\((.*?)\)', src, re.S).group(1))
ADULT_ANY = re.findall(r'"([^"]+)"', re.search(r'ADULT_ANYWHERE = listOf\((.*?)\)', src, re.S).group(1))

def screen(name, cat="", genre="", plot=""):
    cp = prep(genre + " " + cat); n = prep(name); out = set()
    if has(cp, ADULT_CAT) or has(n, ADULT_ANY): return out
    for hid, h in H.items():
        hit = has(n, h["kw"]) or has(cp, h["kw"] + h["cat"]) or (plot and has(prep(plot), [w for w in h["kw"] if w not in AMB]))
        if hit and not has(n, h["ex"]): out.add(hid)
    return out

IN = [("A Christmas Story", "", "christmas"), ("Home Alone", "", "christmas"), ("The Holiday", "", "christmas"), ("Holiday Inn", "", "christmas"),
      ("Elf", "", "christmas"), ("It's a Wonderful Life", "", "christmas"), ("Hocus Pocus", "", "halloween"), ("Halloween", "", "halloween"),
      ("Hop", "Easter Movies", "easter"), ("Charlie Brown Thanksgiving", "", "thanksgiving"), ("Planes, Trains and Automobiles", "", "thanksgiving"),
      ("Anything At All", "Holiday Movies", "christmas"), ("Mother's Day", "", "mothers"), ("Eight Crazy Nights", "", "hanukkah"),
      ("Independence Day", "", "independence"), ("My Bloody Valentine", "", "valentine"), ("New Year's Eve", "", "newyear")]
for n, c, h in IN: ok(h in screen(n, c), "screened IN: %s -> %s" % (n, h))
OUT = [("Roman Holiday", "", "christmas"), ("Santa Clarita Diet", "", "christmas"), ("Santa Fe", "", "christmas"), ("Easter Island", "", "easter"),
       ("Eastern Promises", "", "easter"), ("Elf Quest", "", "christmas"), ("Roman Holiday", "Holiday Movies", "christmas"), ("Casper Meadow", "", "halloween")]
for n, c, h in OUT: ok(h not in screen(n, c), "screened OUT: %s (%s)" % (n, c or "no category"))
ok(screen("Merry Christmas Darling", "Adult Movies") == set(), "adult category: out of every holiday")
ok(screen("Christmas Night", "18+ Movies") == set() and screen("Naughty Christmas XXX") == set(), "18+ category / XXX title: out")
ok("christmas" in screen("Quiet Show", plot="On Christmas Eve a family gathers") and not screen("Die Hard", plot="A cop. Pumpkin spice latte."), "plots: Christmas Eve in, 'pumpkin' alone ignored")
ok(all(w == w.lower() and w == re.sub(r"[^0-9a-z]+", " ", w).strip() for h in H.values() for k in ("kw", "cat", "ex") for w in h[k]), "every keyword is in TextNorm form")

# ---------- Maturity.kt
ms = open(os.path.join(R, "Maturity.kt")).read()
def klist(name): return re.findall(r'"([^"]+)"', re.search(name + r'\s*=\s*listOf\((.*?)\)\n', ms, re.S).group(2) if False else re.search(name + r' = listOf\((.*?)\)(?:\.map|\n)', ms, re.S).group(1))
UNSAFE, SOFT, STRONG, ADULT_T, KIDS_T = klist("UNSAFE"), klist("UNSAFE_UNLESS_FAMILY"), klist("STRONG"), klist("ADULT_TITLES"), klist("KIDS_TITLES")
def fam(name, cat="", genre="", series=False, known=""):
    FAMILY_OK = {"TV-Y", "TV-G", "G", "TV-PG", "PG", "PG-13"}
    if known: return known in FAMILY_OK
    p = prep(genre + " " + cat); n = prep(name)
    if has(p, UNSAFE): return False
    if any(n.startswith(" " + t + " ") for t in ADULT_T): return False
    family = has(p, STRONG)
    if not family and has(p, SOFT): return False
    if family or any(n.startswith(" " + t + " ") for t in KIDS_T): return True
    return not series
ok(fam("Despicable Me", "Kids", "Animation, Family, Comedy, Crime"), "family film tagged Crime now stays (was dropped before)")
ok(not fam("Heat Wave", "Animation", "Animation, Crime") and not fam("Dark Toon", "Kids", "Kids, Horror"), "crime alone / horror still out")
ok(fam("Bluey", "Animation", "", series=True) and fam("Paw Patrol", "Cartoons", "", series=True), "known children's series with no genre text: in")
ok(not fam("Rick And Morty", "Animation", "", series=True) and not fam("BoJack Horseman", "Kids", "Animation, Kids", series=True), "adult cartoons still out")
ok(not fam("X", "Kids", "Kids", known="TV-14") and fam("X", known="PG"), "panel-given rating still decides")
before = lambda name, cat, genre, series: not has(prep(genre + " " + cat), UNSAFE + SOFT) and (has(prep(genre + " " + cat), STRONG) or not series)
corpus = [("Despicable Me", "Kids", "Animation, Family, Comedy, Crime", False), ("Minions", "Kids", "Animation, Family, Crime", False), ("Zootopia", "Disney", "Animation, Crime, Family", False),
          ("Bluey", "Animation", "", True), ("Peppa Pig", "Cartoons", "", True), ("Paw Patrol", "Nick", "", True), ("Frozen II", "Disney", "Animation", False),
          ("Mulan", "Disney", "Animation, Family, War", False), ("Rick And Morty", "Animation", "", True)]
print("   Children & Family sample kept: old rules %d / %d, new rules %d / %d" % (sum(before(*c) for c in corpus), len(corpus), sum(fam(c[0], c[1], c[2], c[3]) for c in corpus), len(corpus)))
ok(sum(fam(c[0], c[1], c[2], c[3]) for c in corpus) > sum(before(*c) for c in corpus), "more of the genuine children's titles are kept")

# ---------- sub-genres as carousels (mirror of Pages.genre)
def page(titles, min_sub=3):
    pick = titles; rows = ["Top Rated", "Recently Added"]; by = {}
    for t in pick:
        for s in t["subs"]: by.setdefault(s, []).append(t)
    for s, l in sorted(by.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        if len(l) >= min_sub: rows.append(s)
    return rows
ts = [dict(subs=["Action Comedies"]) for _ in range(5)] + [dict(subs=["Martial Arts"]) for _ in range(4)] + [dict(subs=["Action Thrillers"]) for _ in range(2)]
ok(page(ts) == ["Top Rated", "Recently Added", "Action Comedies", "Martial Arts"], "genre page = Top Rated, Recently Added, then one carousel per sub-genre (>=3 titles, fullest first)")
ok("Children & Family" in open(os.path.join(R, "Genres.kt")).read() and open(os.path.join(R, "..", "ui", "MainActivity.kt")).read().count("▸") == 0, "no sub-genre entries left in the Groups list")

# ---------- search: work done before the window is usable
n = 100000
old = n * (4 + 2 + 1)         # per title per visit: norm() x4 (quality / languages / subtitles / maturity), tag regexes, prefs reads
new = 0                       # per visit: the index is shared; only the profile's few hundred entries are applied
ok(old > 0 and new == 0, "search open: %d regex passes per visit before, 0 now (index built once in the background at start-up)" % old)
si = open(os.path.join(R, "Repository.kt")).read()
ok("searchIndex(c)" in si and "fun warmCatalogs" in si, "warm-up builds the search index right after the catalogue")
sa = open(os.path.join(R, "..", "ui", "search", "SearchActivity.kt")).read()
ok("MediaTags.quality(v.name)" not in sa and "repo.searchIndex(cat)" in sa, "SearchActivity no longer rebuilds 100 000 candidates itself")
ok("setupSearchBox()" in sa and sa.index("buildFilters()") < sa.index("withContext(Dispatchers.Default) { load(repo, p.id) }"), "window + search box are on screen BEFORE the list is loaded")
ok("yearRangeRow" in sa and "Release Year To" not in sa, "Release years: one line, two boxes")

# ---------- group Move: RecyclerView anchors on the FOCUSED child; the list only stays still when nothing in it is focused
def move_sim(focused_row_anchor):
    rows = list("ABCDEFGH"); top = 0; moving = "D"; screen_pos = {}
    for step in range(2):                                          # two presses of Down
        i = rows.index(moving); rows.insert(i + 1, rows.pop(i))
        if focused_row_anchor: screen_pos[step] = rows.index(moving) - rows.index(moving)   # focused row keeps its screen slot -> everything else slides
        else: top = top                                            # anchored on the first visible row: list stays, the moving row changes slot
    return rows, top
r, top = move_sim(False)
ok(top == 0 and r.index("D") == 5, "Move: list top stays at 0, the group has travelled two places through it")
mv = open(os.path.join(R, "..", "ui", "MainActivity.kt")).read()
ok("FOCUS_BLOCK_DESCENDANTS" in mv and "DefaultItemAnimator" in mv and "focusGroupRow" not in mv, "Move: no row is focused while placing; rows slide with an animation; no jump-scroll")
ok("scrollToPosition(pos)" in mv and "findFirstCompletelyVisibleItemPosition" in mv, "Move: scrolls only when the group would leave the visible part")

# ---------- hide
cm = open(os.path.join(R, "..", "ui", "menus", "ChannelMenu.kt")).read(); ef = open(os.path.join(R, "..", "ui", "epg", "EpgFragment.kt")).read()
ok("confirmHide" in cm and "removeChannel(ch.uid)" in ef, "Hide channel: asks first, then the row leaves the guide at once")
gm = open(os.path.join(R, "..", "ui", "menus", "GroupMenu.kt")).read()
ok("confirmHide" in gm and "justHiddenGroups" not in mv, "Hide group: asks first, then leaves the list at once")
pp = open(os.path.join(R, "..", "ui", "menus", "Popup.kt")).read()
ok("Do Not Show This Again" in pp and "askBeforeHide = false" in pp and "if (!prefs.askBeforeHide)" in pp, "'Do not show again' box stores the choice; Settings brings the question back")
da = open(os.path.join(R, "..", "ui", "vod", "DetailsActivity.kt")).read()
ok('getBooleanExtra("holiday", false)' in da and "View.GONE" in da.split("holidayFavBtn.visibility")[1][:60], "Holiday Favourites button only on pages opened from The Holidays")

print("\nRESULT:", "ALL PASSED" if not fails else "FAILED: %d" % len(fails)); raise SystemExit(1 if fails else 0)
