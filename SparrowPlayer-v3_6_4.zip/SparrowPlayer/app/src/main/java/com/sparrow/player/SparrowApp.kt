package com.sparrow.player

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.sparrow.player.data.Repository
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.TimeFmt

class SparrowApp : Application(), ImageLoaderFactory {
    lateinit var repo: Repository
        private set

    override fun onCreate() {
        super.onCreate()
        installErrorLog()
        repo = Repository(this)
        TimeFmt.is24h = repo.prefs.clock24
        Theme.init(this)
        com.sparrow.player.util.StartupLauncher.registerWakeReceiver(this)
        repo.startScheduler()          // automatic guide sync (Settings -> EPG)
        repo.warmCatalogs()            // Movies / Series are read into memory in the background, so those tabs and search open at once
    }

    /** The error log (Settings -> Data, Backup & About -> Error Log): crashes are written to it before the app closes. */
    private fun installErrorLog() {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }
        com.sparrow.player.data.ErrorLog.init(filesDir, "Sparrow Player " + ver + "  |  " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + "  |  Android " + android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + ")")
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { com.sparrow.player.data.ErrorLog.addThrowable("CRASH", e, "thread " + t.name) } catch (x: Throwable) { }
            previous?.uncaughtException(t, e)
        }
    }

    /**
     * One image loader for the whole app, tuned for poster browsing on a TV: a big memory cache (posters are RGB565 JPEGs),
     * a 300 MB disk cache that ignores the panel's "no-cache" headers, and no fade-in (a fade is what looked like posters
     * "changing" while browsing).
     */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.30).build() }
        .diskCache { DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizeBytes(300L * 1024 * 1024).build() }
        // Images go through the app's own HTTP client (the VLC user agent the panel API already needs): hosts that refuse an unknown
        // "okhttp" agent were what left many posters showing only the Sparrow logo.
        .okHttpClient {
            // more parallel downloads per image host (the default is 5): the first pass along a row is limited by posters arriving, not by drawing
            val d = okhttp3.Dispatcher().apply { maxRequests = 64; maxRequestsPerHost = 16 }
            repo.http.newBuilder().dispatcher(d).readTimeout(25, java.util.concurrent.TimeUnit.SECONDS).build()
        }
        .allowRgb565(true)
        .respectCacheHeaders(false)
        .crossfade(false)
        .build()
}
