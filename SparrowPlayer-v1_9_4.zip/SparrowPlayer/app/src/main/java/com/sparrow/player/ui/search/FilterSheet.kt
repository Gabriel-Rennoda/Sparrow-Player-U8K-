package com.sparrow.player.ui.search

import android.app.Activity
import android.app.Dialog
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.sparrow.player.data.Langs
import com.sparrow.player.data.MediaTags
import com.sparrow.player.data.SearchFilters
import com.sparrow.player.data.SearchKind
import com.sparrow.player.data.SortBy
import com.sparrow.player.data.SparrowRating
import com.sparrow.player.data.SubsFilter
import com.sparrow.player.data.UserRatings
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.TitleCase
import com.sparrow.player.util.dp

/**
 * "Filters & sort": the filters as a two-column grid of drop-downs (OK on one opens its list), then Sort by / Order and "❤️ / 👍 / 👎 first, then by",
 * Reset and Apply at the bottom, ✕ (or Back) to leave without changing anything. Fields that do not apply to the chosen Type are dimmed and skipped
 * by the remote. Changing Type switches between Live channel / Movie / Series; it takes effect with Apply.
 *
 * Release years and the title text are NOT here: they stay on the search window itself, so they can be typed before searching.
 */
class FilterSheet(
    private val a: Activity,
    private val startKind: SearchKind,
    start: SearchFilters,
    private val genreOptions: List<String>,
    private val typeLocked: Boolean = false,                 // "choose a channel" mode: Type stays Live channel
    private val onApply: (SearchKind, SearchFilters) -> Unit
) {
    private var kind = startKind
    private var w = start
    private lateinit var d: Dialog
    private lateinit var body: LinearLayout
    private val updaters = ArrayList<() -> Unit>()
    private var firstFocus: View? = null

    fun show() {
        if (a.isFinishing) return
        d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(24), a.dp(18), a.dp(24), a.dp(18)) }

        val head = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(a).apply { text = "Filters & sort"; textSize = 26f; tag = "t:text"; setTypeface(typeface, Typeface.BOLD) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(button("✕", false) { d.dismiss() }, LinearLayout.LayoutParams(a.dp(52), a.dp(44)))
        root.addView(head)

        body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(a).apply { isFillViewport = false; clipToPadding = false; addView(body) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = a.dp(8) })

        val foot = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        foot.addView(button("Reset", false) { w = SearchFilters(kind, text = w.text, yearFrom = w.yearFrom, yearTo = w.yearTo); build() },
            LinearLayout.LayoutParams(a.dp(130), a.dp(48)).apply { marginEnd = a.dp(12) })
        foot.addView(button("Apply", true) { d.dismiss(); onApply(kind, w) }, LinearLayout.LayoutParams(a.dp(130), a.dp(48)))
        root.addView(foot, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = a.dp(10) })

        build()
        Theme.applyTree(root)
        d.setContentView(root)
        d.show()
        d.window?.apply {
            setBackgroundDrawable(GradientDrawable().apply { setColor(Theme.surface); cornerRadius = a.dp(20).toFloat() })
            setLayout(a.dp(780), (a.resources.displayMetrics.heightPixels * 0.94f).toInt())
            setDimAmount(0.7f)
        }
        firstFocus?.requestFocus()
    }

    // ---- the grid -------------------------------------------------------------------------------------------------------
    private fun build() {
        body.removeAllViews(); updaters.clear(); firstFocus = null
        val live = kind == SearchKind.LIVE
        val vod = !live
        val sameKind = kind == startKind                      // genre lists are only loaded for the kind the window was opened with
        val steps = (0..20).map { it * 0.5 }
        fun stars(v: Double) = if (v <= 0) "Any" else SparrowRating.format(v) + " & up"
        fun summarize(set: Set<String>, label: (String) -> String, out: Boolean = false, any: String = "Any"): String {
            if (set.isEmpty()) return any
            val t = if (set.size <= 2) set.joinToString(", ") { label(it) } else "${set.size} selected"
            return if (out) "Hide: $t" else t
        }

        row(
            field("Minimum star rating", vod, { if (w.minStars <= 0) "Any star rating" else stars(w.minStars) }) {
                Popup.choose(a, "Minimum star rating", steps.map { if (it <= 0) "Any star rating" else stars(it) }, steps.indexOf(w.minStars)) { i -> w = w.copy(minStars = steps[i]); refreshValues() }
            },
            field("Genre", vod && sameKind, { if (vod && !sameKind) "After Apply" else summarize(w.genres, { TitleCase.of(it) }, any = "Any genre") }) {
                if (genreOptions.isEmpty()) return@field
                Popup.multi(a, "Genre", genreOptions.map { it to TitleCase.of(it) }, w.genres) { s, _ -> w = w.copy(genres = s); refreshValues() }
            }
        )
        row(
            field("Channel type", live, { summarize(w.channelTypes, { it }, any = "Any channel type") }) {
                Popup.multi(a, "Channel type", MediaTags.CHANNEL_TYPES.map { it to it }, w.channelTypes) { s, _ -> w = w.copy(channelTypes = s); refreshValues() }
            },
            field("Type", !typeLocked, { when (kind) { SearchKind.LIVE -> "Live channel"; SearchKind.MOVIE -> "Movie"; SearchKind.SERIES -> "Series" } }) {
                val kinds = listOf(SearchKind.LIVE, SearchKind.MOVIE, SearchKind.SERIES)
                Popup.choose(a, "Type", listOf("Live channel", "Movie", "Series"), kinds.indexOf(kind)) { i ->
                    if (kinds[i] != kind) { kind = kinds[i]; w = SearchFilters(kind, text = w.text, yearFrom = w.yearFrom, yearTo = w.yearTo); build() }
                }
            }
        )
        row(
            ratingToggles("My rating", vod),
            field("Quality", true, { summarize(w.qualities, { it }, any = "Any quality") }) {
                Popup.multi(a, "Quality", MediaTags.QUALITIES.map { it to it }, w.qualities) { s, _ -> w = w.copy(qualities = s); refreshValues() }
            }
        )
        val langOptions = Langs.ALL + (MediaTags.UNKNOWN_LANGUAGE to MediaTags.UNKNOWN_LANGUAGE)
        row(
            field("Language", true, { summarize(w.languages, { c -> Langs.label(langOptions, c) }, w.languagesOut, "Any language") }) {
                Popup.multi(a, "Language", langOptions, w.languages, "Show only selected", "Hide selected", w.languagesOut) { s, out ->
                    w = w.copy(languages = s, languagesOut = out); refreshValues()
                }
            },
            field("Subtitles", true, { if (w.subtitles == SubsFilter.ANY) "Any" else w.subtitles.label }) {
                val l = SubsFilter.values().toList()
                Popup.choose(a, "Subtitles", l.map { it.label }, l.indexOf(w.subtitles)) { i -> w = w.copy(subtitles = l[i]); refreshValues() }
            }
        )
        // Length: one full-width field, ready-made ranges
        val lengths = listOf("Any length" to (0 to 0), "Under 30 min" to (0 to 30), "30 – 60 min" to (30 to 60), "60 – 90 min" to (60 to 90),
            "90 – 120 min" to (90 to 120), "120 – 150 min" to (120 to 150), "150 – 180 min" to (150 to 180), "Over 180 min" to (180 to 0))
        row(field("Length", vod, { lengths.firstOrNull { it.second == (w.lengthMin to w.lengthMax) }?.first ?: "${w.lengthMin} – ${w.lengthMax} min" }) {
            Popup.choose(a, "Length", lengths.map { it.first }, lengths.indexOfFirst { it.second == (w.lengthMin to w.lengthMax) }) { i ->
                w = w.copy(lengthMin = lengths[i].second.first, lengthMax = lengths[i].second.second); refreshValues()
            }
        }, null)
        // the filters the search window already had and that are not in the picture: kept, in the same grid
        row(
            field("Sparrow rating", vod, { if (w.minSparrow <= 0) "Any" else stars(w.minSparrow) }) {
                Popup.choose(a, "Sparrow rating", steps.map { if (it <= 0) "Any" else stars(it) }, steps.indexOf(w.minSparrow)) { i -> w = w.copy(minSparrow = steps[i]); refreshValues() }
            },
            field("Maturity rating", vod, { summarize(w.maturities, { it }, w.maturitiesOut) }) {
                Popup.multi(a, "Maturity rating", MediaTags.MATURITIES.map { it to it }, w.maturities, "Show only selected", "Hide selected", w.maturitiesOut) { s, out ->
                    w = w.copy(maturities = s, maturitiesOut = out); refreshValues()
                }
            }
        )
        row(
            field("Unwatched only", vod, { if (w.unwatchedOnly) "Yes" else "No" }) { w = w.copy(unwatchedOnly = !w.unwatchedOnly); refreshValues() },
            field("Also search descriptions", true, { if (w.inDescription) "Yes" else "No" }) { w = w.copy(inDescription = !w.inDescription); refreshValues() }
        )

        // Hide: Movies / Series = leave out titles I rated (👎 ...); Live = keep the channels / groups I hid out of the results
        row(if (live) hideLiveToggles("Hide") else hideRatingToggles("Hide my rating", true), null)

        body.addView(View(a).apply { setBackgroundColor(Theme.accent); alpha = 0.5f },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, a.dp(2)).apply { topMargin = a.dp(6); bottomMargin = a.dp(6) })

        val sorts = SortBy.forKind(kind)
        row(
            field("Sort by", true, { (if (w.sortBy in sorts) w.sortBy else SortBy.NAME).label }) {
                Popup.choose(a, "Sort by", sorts.map { it.label }, sorts.indexOf(w.sortBy)) { i -> w = w.copy(sortBy = sorts[i]); refreshValues() }
            },
            field("Order", true, { if (w.descending) "Descending" else "Ascending" }) { w = w.copy(descending = !w.descending); refreshValues() }
        )
        row(field("❤️ / 👍 / 👎 first, then by", vod, { w.ratingsFirst?.label ?: "Same as Sort by" }) {
            Popup.choose(a, "Ratings first, then by", listOf("Same as Sort by") + sorts.map { it.label }, (w.ratingsFirst?.let { sorts.indexOf(it) + 1 } ?: 0)) { i ->
                w = w.copy(ratingsFirst = if (i == 0) null else sorts[i - 1]); refreshValues()
            }
        }, null)
        body.addView(TextView(a).apply {
            text = "Switch on ❤️, 👍 and/or 👎 to show only titles you rated that way (any combination); they are listed Loved, Liked, Disliked, each group sorted by the field chosen here. " +
                "Subtitle, length, maturity and genre details come from your provider and are read as you open titles."
            textSize = 14f; tag = "t:dim"; setPadding(a.dp(4), a.dp(10), a.dp(4), a.dp(4))
        })
        Theme.applyTree(body)
        refreshValues()
        if (this::d.isInitialized && d.isShowing) firstFocus?.requestFocus()       // after a Type change the old boxes are gone
    }

    private fun refreshValues() = updaters.forEach { it() }

    /** One line of the grid: two fields side by side, or one full-width field when [right] is null. */
    private fun row(left: View, right: View?) {
        val line = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        line.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = if (right != null) a.dp(12) else 0 })
        if (right != null) line.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        body.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = a.dp(6) })
    }

    /** A small label over a drop-down box showing the current value with a chevron. [enabled] false: dimmed and not focusable. */
    private fun field(label: String, enabled: Boolean, value: () -> String, onClick: () -> Unit): View {
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(a).apply { text = label; textSize = 15f; tag = "t:dim"; setSingleLine(true) })
        fun shape(stroke: Int, width: Int) = GradientDrawable().apply { setColor(Theme.bg); cornerRadius = a.dp(12).toFloat(); setStroke(a.dp(width), stroke) }
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8)); minimumHeight = a.dp(50)
            isFocusable = enabled; isClickable = enabled; alpha = if (enabled) 1f else 0.4f
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_focused), shape(Theme.text, 3))
                addState(intArrayOf(), shape(Theme.accent, 2))
            }
        }
        val v = TextView(a).apply { textSize = 19f; setTextColor(Theme.text); setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END }
        box.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(TextView(a).apply { text = "⌄"; textSize = 22f; setTextColor(Theme.textDim) })
        updaters += { v.text = value() }
        if (enabled) { box.setOnClickListener { onClick() }; if (firstFocus == null) firstFocus = box }
        col.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = a.dp(3) })
        return col
    }

    /** My rating: three toggles - ❤️ Loved, 👍 Liked, 👎 Disliked - any one or any combination; none on = no filter. A rating is either shown-only or hidden, never both. */
    private fun ratingToggles(label: String, enabled: Boolean): View = chips(label, enabled, RATINGS, 24f,
        { it in w.myRatings && !w.myRatingsOut },
        { code ->
            val s = LinkedHashSet(w.myRatings); if (!s.add(code)) s.remove(code)
            w = w.copy(myRatings = s, myRatingsOut = false, hideRatings = w.hideRatings - code)
        })

    /** "Hide": for Movies / Series the same three ratings, here meaning "leave these out" (👎 = hide what I disliked). */
    private fun hideRatingToggles(label: String, enabled: Boolean): View = chips(label, enabled, RATINGS, 24f,
        { it in w.hideRatings },
        { code ->
            val s = LinkedHashSet(w.hideRatings); if (!s.add(code)) s.remove(code)
            w = w.copy(hideRatings = s, myRatings = w.myRatings - code)
        })

    /** "Hide" for Live TV: switched ON = channels / groups I hid stay out of the search (the default); OFF = they are searched too. */
    private fun hideLiveToggles(label: String): View = chips(label, true, listOf("channels" to "Hidden channels", "groups" to "Hidden groups"), 17f,
        { if (it == "channels") !w.showHiddenChannels else !w.showHiddenGroups },
        { if (it == "channels") w = w.copy(showHiddenChannels = !w.showHiddenChannels) else w = w.copy(showHiddenGroups = !w.showHiddenGroups) })

    private val RATINGS = listOf(UserRatings.LOVED to "❤️", UserRatings.LIKED to "👍", UserRatings.DISLIKED to "👎")

    /** A label over a row of toggle buttons that share the width; the focused one is flipped with OK. [isOn] / [flip] read and change [w]. */
    private fun chips(label: String, enabled: Boolean, items: List<Pair<String, String>>, size: Float, isOn: (String) -> Boolean, flip: (String) -> Unit): View {
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(a).apply { text = label; textSize = 15f; tag = "t:dim"; setSingleLine(true) })
        fun shape(fill: Int, stroke: Int, width: Int) = GradientDrawable().apply { setColor(fill); cornerRadius = a.dp(12).toFloat(); setStroke(a.dp(width), stroke) }
        val line = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; alpha = if (enabled) 1f else 0.4f }
        items.forEachIndexed { i, (id, text) ->
            val chip = TextView(a).apply {
                this.text = text; textSize = size; gravity = Gravity.CENTER; isFocusable = enabled; isClickable = enabled
                setTextColor(Theme.text); setSingleLine(true)
                background = StateListDrawable().apply {                       // first match wins: ring + on, ring, on, off
                    addState(intArrayOf(android.R.attr.state_focused, android.R.attr.state_selected), shape(Theme.accent, Theme.text, 3))
                    addState(intArrayOf(android.R.attr.state_focused), shape(Theme.bg, Theme.text, 3))
                    addState(intArrayOf(android.R.attr.state_selected), shape(Theme.accent, Theme.accent, 2))
                    addState(intArrayOf(), shape(Theme.bg, Theme.accent, 2))
                }
                if (enabled) setOnClickListener { flip(id); refreshValues() }
                updaters += { isSelected = isOn(id); setTextColor(if (isOn(id)) Theme.onAccent else Theme.text) }
            }
            if (enabled && firstFocus == null) firstFocus = chip
            line.addView(chip, LinearLayout.LayoutParams(0, a.dp(50), 1f).apply { if (i > 0) marginStart = a.dp(8) })
        }
        col.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = a.dp(3) })
        return col
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        fun shape(fill: Int, stroke: Int, width: Int) = GradientDrawable().apply { setColor(fill); cornerRadius = a.dp(12).toFloat(); if (width > 0) setStroke(a.dp(width), stroke) }
        val fill = if (primary) Theme.accent else Theme.surface2
        return TextView(a).apply {
            this.text = text; textSize = 19f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (primary) Theme.onAccent else Theme.text); isFocusable = true; isClickable = true
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_focused), shape(fill, Theme.text, 3))
                addState(intArrayOf(), shape(fill, fill, 0))
            }
            setOnClickListener { onClick() }
        }
    }
}
