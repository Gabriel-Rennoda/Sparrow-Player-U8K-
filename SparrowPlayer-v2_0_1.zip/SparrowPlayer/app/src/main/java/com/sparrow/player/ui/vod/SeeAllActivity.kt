package com.sparrow.player.ui.vod

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sparrow.player.data.VodItem
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * "See All": every title of one row in a poster grid. Columns are equal in width and the posters sit in the middle of their column, so the horizontal
 * spacing between posters is the same everywhere. The grid stays still while the selector moves inside what is on screen; it only scrolls when the
 * selector leaves the screen (new titles come in). The selected poster gets the white halo and grows a little (and shrinks back when the selector leaves).
 * The title of the selected poster is shown in the bar on top. Back returns to the row it came from, selector where it was.
 */
/** One cell of the See All grid (a class of its own: Kotlin does not allow a class inside an inner class). */
class SeeAllHolder(val cell: FrameLayout, val card: PosterCard) : RecyclerView.ViewHolder(cell)

class SeeAllActivity : FragmentActivity() {
    private lateinit var grid: RecyclerView
    private lateinit var selected: TextView
    private var entry: SeeAllStore.Entry? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val e = SeeAllStore.get(intent.getStringExtra("token") ?: "")
        if (e == null || e.uids.isEmpty()) { finish(); return }          // the list is gone (the app was restarted): nothing to show
        entry = e

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(36), dp(10), dp(36), 0)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = e.title + "   •   " + e.uids.size + " Titles"; textSize = 22f; tag = "t:text"; setSingleLine(true)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        selected = TextView(this).apply { textSize = 16f; tag = "t:accent"; setSingleLine(true); text = " " }
        root.addView(selected, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(2) })

        grid = RecyclerView(this).apply {
            clipChildren = false; clipToPadding = false
            setPadding(0, dp(10), 0, dp(24))
            itemAnimator = null
            setItemViewCacheSize(12)
            isFocusable = false
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.clipChildren = false
        Theme.applyAll(this, root)
        setContentView(root)

        // columns: as many as fit; every column is an equal share of the width
        val cardW = PosterSize.width(this) + dp(28)
        val avail = resources.displayMetrics.widthPixels - dp(72)
        val span = maxOf(3, avail / (cardW + dp(8)))
        grid.layoutManager = GridLayoutManager(this, span)

        lifecycleScope.launch {
            val repo = applicationContext.repo
            val p = repo.activeProvider() ?: run { finish(); return@launch }
            val type = if (e.uids.first().split(':').getOrNull(1) == "s") "series" else "movie"
            val cat = repo.catalog(p.id, type)
            val items = cat.items(e.uids)
            if (items.isEmpty()) { finish(); return@launch }
            grid.adapter = Adapter(items)
            grid.post { grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
        }
    }

    private inner class Adapter(val items: List<VodItem>) : RecyclerView.Adapter<SeeAllHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeeAllHolder {
            val ctx = parent.context
            val cell = FrameLayout(ctx).apply { clipChildren = false; clipToPadding = false }
            val card = PosterCard(ctx)
            cell.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            cell.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            val z = ctx.dp(10).toFloat()
            card.setOnFocusChangeListener { _, has ->
                // grows a little and is drawn above its neighbours while selected; back to normal size when the selector leaves
                cell.translationZ = if (has) z else 0f
                card.animate().cancel()
                card.animate().scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f).setDuration(110).start()
                if (has) { val pos = cell.tag as? Int; if (pos != null && pos in items.indices) selected.text = items[pos].name + metaOf(items[pos]) }
            }
            return SeeAllHolder(cell, card)
        }

        private fun metaOf(v: VodItem): String = listOf(v.year, CardPresenter.ratingText(v)).filter { it.isNotBlank() }.let { if (it.isEmpty()) "" else "   •   " + it.joinToString("   ") }

        override fun onBindViewHolder(h: SeeAllHolder, position: Int) {
            val v = items[position]
            val repo = h.card.context.repo
            h.cell.tag = position
            val poster = v.poster.ifBlank { repo.knownPoster(v.uid) ?: "" }
            h.card.bind(v.name, v.year, poster, repo.prefs.vodPercent(v), repo.providerRatingOf(v), repo.sparrowOf(v), v.uid) { u ->
                repo.fetchPoster(v) { url -> if (url != v.poster) h.card.latePoster(u, url) }
            }
            h.card.setOnClickListener {
                val en = entry
                startActivity(DetailsActivity.intent(this@SeeAllActivity, v.uid, en?.holiday ?: false, en?.holidayId ?: ""))
            }
        }

        override fun onViewRecycled(h: SeeAllHolder) { h.card.animate().cancel(); h.card.scaleX = 1f; h.card.scaleY = 1f; h.cell.translationZ = 0f; h.card.clear() }

        override fun getItemCount() = items.size
    }

    companion object {
        fun intent(ctx: Context, token: String) = Intent(ctx, SeeAllActivity::class.java).putExtra("token", token)
    }
}
