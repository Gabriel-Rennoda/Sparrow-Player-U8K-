# Round 4 (v1.4.0) - investigated BEFORE changing code

Same limits as rounds 1-3: no Android SDK, Gradle, Kotlin compiler or TV were available, so every item was traced through the code,
the logic was kept in pure-Kotlin classes, and Python mirrors in `tools/` were run. **CI is the first real compile - check the Actions
run, then walk the v1.4.0 section of `TV_TEST_CHECKLIST.md` on the U8K.**

| # | Request | Finding (root cause) | Change |
|---|---|---|---|
| 1 | Audio track / subtitles in the settings gear | Live full screen only had the Menu key (the U8K remote may not send it); movies relied on Media3's own bar. | Own gear button (movies / series: Up from the bar, OK; live: OK a second time) opening a themed Audio / Subtitles / Video Quality pop-up (language names, 5.1 / Stereo, tick on the current track). Also preferred audio / subtitle language in Settings -> General, applied in `PlayerFactory`. *Interpretation: I covered both readings of "settings gear".* |
| 2 | Highlighted tab text unreadable | `item_nav`: label and icon are children of the focusable row. Children do not get the *focused* state, so on a focused tab the label kept its normal colour, and on the current (selected) tab it was **accent on an accent block**. | `duplicateParentState` on label and icon. |
| 3 | Back opens the two side panels | `onBackPressed` closed panels, then exited. | `PanelState.backPress()`: content -> groups -> tabs; tabs -> exit prompt. RIGHT still closes. |
| 4 | OK on credentials starts verify + sync | Only the "Connect & load" row did; the keyboard action was Next. | Go / Done on Server URL (and the optional fields) runs `save()` when Username, Password and URL are filled; otherwise moves to the next field. |
| 5 | New settings headings | One long list of buttons. | Five headings, each a pop-up (`ui/menus/Popup`). EPG Sync interval + sync-on-start are real: `Repository.startScheduler()`. Sync Now = full sync. |
| 6 | Hold OK on a channel | Hold OK only toggled the favourite. | `ChannelMenu`. Edits live in `Customize` (preference string), **not** Room: a schema change would risk the stored logins, and a sync deletes / re-inserts channel rows. Keyed by channel uid / category id so they survive syncs. |
| 7 | Hold OK on a group | none | `GroupMenu` (rename, move up / down, hide, delete own, new group). |
| 8 | Back from any tab -> main tab list | see 3 | same change |
| 9 | Poster background black on details | `activity_details`: backdrop at 55 % alpha under a scrim of 94 % / 60 % / 80 % -> about 3-6 % of the picture showed. Movies without a backdrop got nothing better. | Backdrop 100 %, scrim 60 -> 88 % (measured: light text >= 4.2:1 at the title, >= 5.7:1 on body text even over a pure white picture); poster used when there is no backdrop. |
| 10 | Title case | mixed | All app headings changed; provider category / row names go through `TitleCase` (only all-lower-case words change: NBA, iPlayer untouched). |
| 11 | Remove Leafs White; no white for Random / Custom | Random picked a light theme 15 % of the time; custom brightness went to 100 %; `fromBase` kept light backgrounds. | Removed. `fromBase` darkens any background to luminance <= 0.10 (white text >= 7:1); Random is dark only; the custom brightness bar stops at 40 %; a light theme saved by an older version is dropped on start. |
| 12 | Add Playlist layout | - | Order Username, Password, Server URL, Playlist Name (Optional), XMLTV EPG URL (Optional); starts on Username; grey "(Optional)" hint goes while the line is selected, returns if empty. M3U stays available via the *Playlist Type* row at the bottom. |

## Interpretations (tell me if any is wrong)
* The sub-menu list in the request was placed as: **General** = Add or Switch Playlist, Delete Playlist, Hidden, Channel Numbers, 12 Hr Clock (+ audio / subtitle language); **EPG** = EPG Sync, Sync EPG on App Start, Sync Now; **Network and Buffering** = Live Stream Format; **Appearance** = Theme; **About** = version + remote tips.
* "12 Hr Clock" On = 12-hour (the default), Off = 24-hour.
* Hide keeps the channel / group on screen (dimmed, "Hidden") until you leave the list, so a mistaken Hide can be undone from the same menu; afterwards it lives under Settings -> General -> Hidden.
* "Sync EPG on App Start" is skipped if the guide was updated < 10 minutes ago.
* Automatic syncs refresh the guide only; the old guide is kept if the server does not answer OK (previously it was deleted first).
* All Channels and Favourites are built in: only "Create New Group" is offered on them.

## Also fixed on the way
* Deleting a playlist that is not the active one no longer switches the active playlist.
* Two syncs can no longer run at once (Sync Now during an automatic sync).
* Hold OK no longer toggles the favourite directly (it is in the menu), so a stray long press cannot change favourites.

## Not verified (needs the TV)
Everything visual / remote-related. The pop-up focus handling, the hold-OK menus on the custom guide view, the gear focus path in the Media3 player and the on-screen keyboard in the rename / add pages are the first things to try.
