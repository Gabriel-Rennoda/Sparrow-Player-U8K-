# Investigation (before any code was changed)

## #1 Sizing  (root cause confirmed numerically from the screenshot)
U8K = 3840x2160 px at 640 dpi (density 4.0)  ->  the app sees a 960 x 540 dp viewport (Google's TV design size).
fragment_live.xml hard-codes: 40 + 240(categories) + 12 + 500(channels) + 28 + 40 = 860 dp
-> only 960 - 860 = ~100 dp is left for the preview/info column.
Screenshot check: preview box = 232 px of a 2170 px-wide screen = 232/2170*960 = 102 dp (predicted 100 dp)
                  preview height 583 px of 1230 px = 256 dp (layout says 260 dp)       => matches.
Also: EpgView has a fixed 220 dp channel column; main header, hero (520 dp end padding) all use fixed dp.
Fix: weight/percentage based layouts that adapt to any dp viewport (tested 960x540, 1280x720, 1920x1080).

## #2 Player position / info
LiveTvFragment shows a *preview* of whatever is focused (after 1.2 s) and OK launches full-screen immediately.
There is no "current channel" concept in the browse screen, and info always follows focus.

## #3 Movies / Series focus bumping  (static code trace - cannot run on a TV here)
a) MainActivity tab OnFocusChangeListener => select(i) 180 ms after a tab merely *receives focus* (swaps the fragment).
b) repo.dataVersion.collect => select(current, force=true) REPLACES the visible fragment whenever a sync / provider
   change finishes. The focused card is destroyed, Android hands focus to the first focusable view = the "Live TV" tab,
   and (a) then switches back to Live TV.  => "selector automatically bumps out of the tab".
c) VodFragment extends BrowseSupportFragment (headers machinery, title view, back-transition handling) inside another
   container; rows are set asynchronously after the fragment is shown, so focus handed over from the tab is lost.
d) The rebuild in (b) also re-queries every row on each tab visit.
Fix: no focus-driven fragment swaps, in-place refresh, RowsSupportFragment (rows only), explicit focus hand-off.

## #4 Navigation model
Tabs were a horizontal bar; EpgView swallows LEFT at the first programme; category list was inside the Live screen.
Needs a 3-level panel stack (content -> channel groups -> tab rail) with Back unwinding + focus memory.

## #5 Language
UI strings use US spellings: Favorites (tab, group, toasts, hints), "programme" (Canadian = "program").
