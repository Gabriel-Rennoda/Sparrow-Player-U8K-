# Version 1.8.0 – investigation and changes

Every item was traced in the code (and, where possible, reproduced with a mirror of the logic) BEFORE anything was changed.
**Not compiled here** (no Kotlin compiler / Gradle / network on the build box): the first real compile is GitHub Actions. What was run here:
`tools/kt_balance.py` (bracket balance of all 85 Kotlin files), `tools/kt_static_check.py` (imports, types, layout ids), `tools/upgrade_check.py`
against the 1.7.0 zip (schema, DB name, every pref key kept), `tools/v18_model_test.py` and the older model tests. New JUnit tests
(`CatalogTest`, `MaturityTest`, `HolidayMaskTest`, additions to `HomeRowsTest`, `CustomizeTest`) run in the workflow's informational test step.

## Findings → changes (in the order they were built)

| # | Report | Root cause found | Change |
|---|---|---|---|
| 1 | Profile settings return | every profile sub-window (rename, icon, PIN, delete) closed the whole popup chain | `Popup.onBack`, `Popup.ask(onCancel)`, `Popup.confirm(onNo)`, `PinDialog(onCancel)`; confirm **or** cancel lands back on that profile's window; Back there = list of profiles |
| 2 | Group "Move" | two rows moved one step per press, popup reopened each time | one **Move** row: popup closes, Up/Down move the group, **OK places it**, Back puts it back; All Channels / Favourites never move; hidden groups keep their slot |
| 3 | Opening Channel / wake | wake launch only `SINGLE_TOP` → resumed the old screen; Settings tab plays nothing; guide picked its first row from the *old* last channel | wake/start-up launch carries `EXTRA_FRESH` (+`CLEAR_TOP`): Live TV, guide + mini player on the Opening Channel (or last watched); request used up only when a channel was tuned |
| 3b | Opening Channel "custom" | popup never showed which option was active; picker re-used remembered filters | popup shows ✓ on *Last Watched* or *Custom: name*; the row reads `Custom: <channel>`; picker starts with clean filters |
| 4 | Movies/Series like wet concrete | each open re-read **every column of every title** (`vodAll`), then ran one query per category before showing anything; `RowTitle` normalised the same text for each of 100 000 titles; 6 regexes built per title in search | in-memory `VodCatalog` (light columns only, built in the background at start-up and after sync, shared by Movies, Series, search, Random); rows from memory; first 10 rows at once, rest in batches; heavy carousels cached per day/profile state and slotted in when ready; shared per-(category, genre) work |
| 4b | repeating wrong posters | a poster still loading for the card's *previous* title was never cancelled (blank/failed paths did not replace the request) | `dispose()` + clear on bind and recycle |
| 5 | Children & Family has TV-14 / TV-MA | `animation / animated / cartoon` were treated as "family" | `Maturity` rules (see below) |
| 6 | Random / Search | Left from Search used a stale "content at left edge" flag → opened the side panels; Random opened the search screen | explicit focus links; Random Pick goes straight to one unwatched title's information page |
| 7 | Search 30 s | whole table loaded + 6 regex compilations per title + lower-casing on every key press | catalogue, tags per category, precompiled regexes, name-sorted once, cached lower-case |
| 8 | Sub-genres | rows inside the genre page | sub-genres are entries in the Movies / Series **Groups** list, listed under the open genre; genre pages = Top Rated, Recently Added, then the provider categories inside it |
| 9 | Holidays "See All" | pool searched title + category only (1 of 7 typical Christmas titles hit); Top Picks needs history (0 for a new profile) | pool also reads **descriptions** (series plots + remembered plots) and more words (holiday, festive, Home Alone…); the five carousels you listed, never empty while the holiday has titles |
| 9b | My Holiday Favourites | was a filter of My List | its own group in Movies / Series: titles saved by hand with **＋ My Holiday Favourites** on the details page (per profile) |

## Children & Family – what is and is not possible
IPTV lists carry **no age rating**. Rules (`Maturity.kt`): a rating the panel gave (remembered when a details page is opened – now also read from
series info) is trusted; only TV-Y, TV-G, G, TV-PG, PG, PG-13 pass. **TV-14 is kept out on purpose** (you listed Rick & Morty, TV-14, as wrong;
change `FAMILY_OK` if you want TV-14 in). Otherwise: adult words in category/genre, a `[TV-MA]` tag, or ~48 well-known adult cartoons keep a title out;
what is left needs a kids/family word. A film that is only "animation" stays; a *series* that is only "animation" waits for a known rating.
Honest limit: an adult cartoon that is not on the list, sits in a plain "Animation" category and has no rating still cannot be recognised.

## Behaviour decisions you may want to change
* Move: Back cancels the move (restores the saved order).
* Wake launch always goes to Live TV even if you were in full screen / Movies.
* Holiday words in descriptions ignore ambiguous words (pumpkin, santa, new year…); in titles/categories they count.
* "Holiday Classics" = year ≤ 2000 (or "classic"); "Cult Followings" = cult tag, else rating ≥ 7 and year ≤ 2012.
* Memory: ~35–60 MB for a 100 000 title catalogue kept while the app runs.
