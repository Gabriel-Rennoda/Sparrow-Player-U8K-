# Installing a new version over the old one (no data / login loss)

## What was wrong (found by investigation)
1. **Signing key.** The project signed with Gradle's *debug* key. A GitHub Actions runner starts empty, so each run generates a
   brand-new random debug key. Android only installs an APK over an existing app if both carry the **same signature**; with a
   different one it refuses ("App not installed") and the only way forward is uninstalling - which deletes the app's data and logins.
2. **Database.** Providers (server, username, password) are stored in the same Room database as the channel / movie cache, and the
   database was opened with `fallbackToDestructiveMigration()`: any future schema change would have silently wiped it all.

## What v1.3.0 does
* One **fixed signing key** is committed (`app/sparrow-signing.jks`) and used for debug *and* release builds, so every CI build is
  recognised as an update of the previous one. Never replace, regenerate or delete it, never change its alias / passwords.
  (The key is in the repository so CI needs no secrets. If the repo is public, anyone could sign an APK that installs over yours -
  fine for a personal sideloaded app; if you ever publish the repo, move the key into GitHub Secrets.)
* `applicationId` stays `com.sparrow.player`; `versionCode` rises every release (5 -> 6 ...; `build.yml` already picks the highest).
* No destructive database fallback. `data/Migrations.kt` is the place for future schema changes (bump `AppDb.version` + add a
  `Migration`). Without one the app refuses to open rather than delete the providers.
* This release changes **no entity and no preference key** (history and theme are new keys only). `tools/upgrade_check.py <old zip>`
  proves it (identical @Entity text, DB name/version, prefs file, no key removed, higher versionCode, signing configured).

## The one thing that cannot be fixed from here - read this
Whatever is installed on the TV today was signed with an unknown earlier CI key. Android will not allow an update signed with a
*different* key. So **if installing v1.3.0 over your current app says "App not installed" / "signature conflict", uninstall once
and install again** (you will have to re-enter the provider once). From v1.3.0 on, every following version installs over the
previous one. (If your current install happens to come from a build with the same key as this one - e.g. v1.3.0 itself - nothing is lost.)
Tip: do not wipe the app data by hand between versions.
