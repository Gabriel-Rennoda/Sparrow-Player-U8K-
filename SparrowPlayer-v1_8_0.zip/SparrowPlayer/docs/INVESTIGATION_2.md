# Round 2 investigation (done BEFORE changing code)

Method: no Android SDK / TV is available off-device, so every item was traced statically through the code and the
suspected mechanism written down; the logic of the fixes is then checked by `tools/guide_logic_test.py` (+ the older
`nav_model_test.py`, `layout_sim.py`) and by JUnit tests (`gradle testDebugUnitTest`). On-TV behaviour is in TV_TEST_CHECKLIST.md.

| # | Report | Root cause found | Fix |
|---|---|---|---|
| 1 | Episode browsing "breaks" the app, lands on the season row | `TextAdapter` called `notifyItemChanged(old/new)` on EVERY focus change. RecyclerView's default change animation swaps the row for a copy, the focused view disappears and focus falls to the nearest other focusable (the season tabs), whose focus handler then reloads the list. | Focus only flips `isSelected` on the views; item animators off; no notify on focus. |
| 2 | OK on an episode does nothing | Same mechanism: the row is mid-animation / unfocused when OK arrives, so the key goes nowhere. (The click wiring itself was correct.) Also the layout left room for only ~1.5 episode rows. | Fix #1 + explicit clickable rows + Play/Seasons on one row, shorter plot, 1-line title => 3+ rows visible. |
| 3 | No per-episode info | Details screen only ever showed series text. | Focus on an episode shows its title, duration/air date/rating, plot and still (falls back to series text). |
| 4 | Guide: "no information" rows cannot enter time mode | Old `EpgView` selection was programme-based; a row with no programmes had nothing to select/scroll from. | Rows are cut into blocks that tile the window; gaps / empty rows become selectable "No information" blocks. |
| 5 | Live list vs Guide formats differ | Two separate fragments (`ChannelListFragment`, `EpgFragment`). | One guide fragment for Live TV, Guide and Favourites. List + its progress bars removed. |
| 6 | Group change only on OK | `GroupAdapter` only had a click callback. | Focus callback with 250 ms debounce previews the group; OK commits; Back keeps what is shown. `notifyDataSetChanged` is avoided while focused (it would drop focus). |
| 7 | Back exits immediately | Default `onBackPressed`. | Hint on first press, Yes/No dialog on second (within 2.5 s). |
| 8 | Movies/Series background | First poster is auto-selected on load, so its backdrop appeared immediately and stayed under the side panels. | Solid theme colour until the user moves to a title; solid again while a side panel has focus. Switch: `VodFragment.BACKDROP_ON_ENTRY`. |
| 9 | Resume | Position saved every 10 s but resumed exactly there, ended-video reset was overwritten on exit. | Resume = saved - 30 s; finished (last minute / 95 %) stored as FINISHED; series Play continues last episode (or next if finished). |
