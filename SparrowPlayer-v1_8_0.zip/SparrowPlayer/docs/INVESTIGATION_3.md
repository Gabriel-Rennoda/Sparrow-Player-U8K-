# Round 3 (v1.2.0) - investigation done BEFORE changing code

Same method as rounds 1-2: no Android SDK / TV / Gradle was available where this was written, so each item was traced through
the code first, the logic was put in pure-Kotlin classes, and those were verified by Python mirrors (`tools/`) and JUnit tests.
**CI (`build.yml`) is the first real compile - check the Actions run, then walk `TV_TEST_CHECKLIST.md` on the U8K.**

| # | Request | What the code did | Change |
|---|---|---|---|
| 1 | Movies / Series tabs: solid theme background | `VodFragment` used Leanback `BackgroundManager` and swapped the highlighted poster in as the *window* background as soon as the user moved (round 2 only hid it for the first auto-selected title). | `BackgroundManager` removed. Tabs show the theme background always. The details screen keeps its own backdrop (unchanged, preferred). |
| 2 | Resume time next to Resume | Position (`pos_<key>`) and duration were already stored, only the button label was shown. | New label right of the button: `Resumes at 1:12:04 • 53 min left` (movie, or the series' continue-episode). It shows the real start point (saved position - 30 s, the existing rule). Hidden when there is nothing to resume. |
| 3 | First press only shows player controls | Media3's `PlayerView` already swallows a D-pad press while its bar is hidden, but **Back and CH+/- were not covered**, the timeout was 5 s, and **live TV had no such behaviour** (Up/Down zapped at once). | `FirstPressGate` in `PlayerActivity.dispatchKeyEvent`: D-pad, OK/Enter, Back, CH+/- are swallowed when controls are hidden (they only show them); while visible they act normally. Held key = one press. Controls = Media3 bar (movies/series) or info bar (live). Timeout 3 s (re-armed by use). All other keys untouched. |
| 4 | Selected title must stand out | Leanback `ZOOM_FACTOR_MEDIUM` (1.1x), `shadowEnabled=false`: no shadow, no halo, neighbours not overlapped visibly. | New `PosterCard` + `SparrowRowPresenter`: zoom LARGE (wider *and* taller), grid draws the focused card last and doesn't clip, so it covers both neighbours; behind the poster a black shadow band falls onto them, edged by a thin white ring. Also a watch-progress bar on posters. |
| 5 | Recommendations | No history existed (only resume positions). | `History` (last 150 watched, a preference string - NOT a Room table, a schema bump would wipe providers via destructive migration). Counts as watched after 40 % played (changed in v1.3.0; originally 2 min) or at the end. `Recommender` rows: *Continue watching*, *Because you watched X* (x2, different tastes), *Recommended for you*, *New in <favourite category>*, *Top rated*, then the provider's rows. Movies have no genre in most panels, so the provider category is the main signal for them; series also use genre text, year and rating. |
| 6 | Image preloading | Posters were requested only when a card was bound, with a fade-in and a placeholder = visible loading/changing. | `Prefetcher`: 10 posters ahead in the direction of travel (3 behind), neighbouring rows up/down, first 3 rows on open; cancelled when you turn around. Same request builder as the card (same size + scale) so the memory-cache key matches. App-wide Coil loader: 30 % memory cache (RGB565), 300 MB disk cache that ignores no-cache headers, no crossfade; 14 cached views per row. |
| 7 | Themes | Colours were fixed XML resources. | `ui/theme`: `Palette` (pure), `Theme` (tags in layouts: `t:text;b:surface`...), `ThemeActivity` (Settings -> Theme). 7 stock themes (3 Leafs jerseys, 3 pictures, Sparrow Classic = the old look, still the default), 12 solid colours, custom background / accent (hue-saturation-brightness bars), Random. |

## Legibility (themes)
Text colour is never chosen by the user - it is derived. `tools/theme_check.py` (mirror) and `ThemeTest` enforce, for every stock
theme, solid, 1,008 custom-picker positions and 5,000 random themes: text/bg >= 7:1, text/panels >= 4.5:1, dim text >= 4.5:1,
accent >= 4.5:1 on bg/panels, text on the accent >= 4.5:1, text on the "airing now" guide cell >= 4.5:1.
That check found one real bug (the airing-now tint for mid-tone custom colours) - fixed.
Pictures: the three JPGs had an EXIF rotation (Android ignores it) - rotated and trimmed of their screenshot border. Measured on the
pixels: Smoke needs >= 46 % scrim, Satin >= 34 %, Ink Wash >= 71 % (it is a bright picture); shipped at 55 / 47 / 75 %.
Ink Wash is therefore the faintest picture. Overlays on video / dark scrims (player bar, toasts, status) stay light in every theme.
`docs/theme_preview.png` is a mock-up of all seven.

## Not done / judgement calls
* Recommendations refresh when the Movies / Series tab is opened (or after a sync), not while you browse - a refresh would reset your scroll position.
* A title enters history once 40 % has been played (v1.3.0; accidental starts don't skew suggestions).
* "Continue watching" for a series shows it only while its last episode is part-watched.
* Custom colour: one colour (background) + optional accent; text is automatic.
* Not verified on hardware (see above). Focus-zoom overlap relies on Leanback's focused-child-last drawing, which I set explicitly - first thing to eyeball.
