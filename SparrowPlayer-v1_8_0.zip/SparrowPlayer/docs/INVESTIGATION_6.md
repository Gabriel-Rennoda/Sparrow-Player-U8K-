# Round 6 (v1.6.0) - investigated BEFORE changing code

Same limits as before (no Android SDK / Gradle / Kotlin compiler / TV here): traced through the code, logic kept in pure Kotlin with JUnit tests,
Python mirrors run (`search_check.py`, `genres_check.py` - which parses the real `Genres.kt` table -, `nav_model_test.py` ...), and the badge drawing was
rendered with the same geometry to check proportions. **CI is the first real compile; then walk the v1.6.0 section of `TV_TEST_CHECKLIST.md`.**

| Request | Finding | Change |
|---|---|---|
| Sparrow Rating in half steps (7.5, 8, 8.5 ...) | The examples are on a 10-point scale; v1.5.0 used 0 - 5. | Whole rating system is now 0 - 10. **Correction in v1.6.1:** the Sparrow Rating is the user's OWN rating, picked from a 0.5 - 10 drop down on the details screen ("Not Rated" clears it); it sits next to the provider's rating. The taste-based calculation from v1.6.0 was removed. Search filters (Star / Sparrow rating) run 0.5 - 10. |
| Loved It / Liked It / Disliked It | Was feeding the (wrong) Sparrow calculation. | A separate three-step (Likert) scale, simpler than the 0 - 10 ratings but a stronger statement of taste. It drives recommendations: Loved +3 / Liked +1.5 / Disliked -3 on the title's category and genres (one watched title counts 1, older ones less); Disliked titles are never recommended; the newest Loved title gets a "Because You Loved ..." row. The "My Ratings" search filter still uses it. |
| Sparrow logo + rating in one tight black pill, top right of every poster | Cards had no badge; the provider rating was text in the line under the poster. | `RatedImageView` draws it: Sparrow logo (left) + number (right) inside ONE black pill, top right. |
| Provider rating top left, one decimal, no ".0" | - | Star + number, same view, top left: 7.3, 8.7, 9. Removed from the line under the poster (it now only shows the year). Unknown ratings are not drawn. |
| Both stay in the same place on the details screen | The details poster was a plain image. | The details poster is the same `RatedImageView` (and search results too), so the corners never move. Pressing Loved / Liked / Disliked updates the Sparrow badge at once. |
| "The Holidays" | spelled with an apostrophe | renamed everywhere |
| Holidays as a genre tab; other genre tabs from the Netflix list | Movies / Series groups had All + Holidays only. | Groups panel: All, **The Holidays**, then the MAIN genres that have titles. |
| Main genres only; sub-genres as rows inside | The gist has ~270 genre codes, many overlapping ("Action Comedies", "Action Thrillers", "Action Sci-Fi & Fantasy", ...). | `Genres`: 23 main genres with 249 sub-genres folded from the list. In a main genre: Top Rated, Recently Added, then one row per sub-genre that has titles, then "More ...". A title can be in several (Action Comedies is under Action AND Comedies). |

## How a title gets its genre
Panels rarely supply a clean genre for movies, so a title is matched from its **genre text and category name only (never the title)**, with whole-word keywords
(`TextNorm`: "Sci-Fi & Fantasy" -> " sci fi fantasy "). Genre tabs shown = main genres where at least one (category, genre) pair of your playlist matches
(one cheap `SELECT DISTINCT`, cached until the next sync). **How rich the sub-genre rows are depends on your provider's categories**: a category simply called
"Action" fills "Top Rated", "Recently Added" and "More Action & Adventure"; a category called "Action Comedy" or "Martial Arts" also fills those sub-genre rows.

## Not verified (needs the TV)
Badge look on a real poster, the long genre list in the groups panel (it scrolls), row building speed on a very large playlist (a genre opens with one pass over
that playlist's movies / series, off the main thread).
