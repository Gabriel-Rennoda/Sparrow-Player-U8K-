#!/usr/bin/env python3
"""Mirror of data/Holidays.kt, data/Search.kt and data/Ratings.kt with the same test cases as HolidaysTest / SearchTest / RatingsTest,
so the logic is executed here (no JVM available).   python3 tools/search_check.py"""
import re, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from _hol_mirror import *
fails=0
def check(n,c,detail=""):
    global fails
    print(("PASS " if c else "FAIL ")+n+("" if c else "  -> "+str(detail))); fails+=0 if c else 1

# ---------------- Holidays
H={"newyear":["new year","new years","new years eve","nye"],"valentine":["valentine","valentines","galentine","galentines","cupid"],
"patrick":["st patrick","st patricks","saint patrick","saint patricks","patricks day","leprechaun","shamrock"],"easter":["easter","peter cottontail","easter bunny"],
"mothers":["mothers day","mother s day"],"fathers":["fathers day","father s day"],"independence":["independence day","fourth of july","4th of july","july 4th","july fourth"],
"halloween":["halloween","trick or treat","trick r treat","hocus pocus","pumpkin","spooky","haunted house","addams family","casper","goosebumps"],
"thanksgiving":["thanksgiving","turkey day","friendsgiving"],"hanukkah":["hanukkah","chanukah","festival of lights","menorah"],
"christmas":["christmas","xmas","santa","santa claus","noel","grinch","north pole","nutcracker","rudolph","jingle","frosty","polar express","krampus","scrooge","yule","reindeer"]}
ORDER=["newyear","valentine","patrick","easter","mothers","fathers","independence","halloween","thanksgiving","hanukkah","christmas"]
def date_of(h,y,canada=False):
    return {"newyear":lambda:days_from_civil(y,1,1),"valentine":lambda:days_from_civil(y,2,14),"patrick":lambda:days_from_civil(y,3,17),"easter":lambda:easter(y),
    "mothers":lambda:nth_weekday(y,5,0,2),"fathers":lambda:nth_weekday(y,6,0,3),"independence":lambda:days_from_civil(y,7,4),"halloween":lambda:days_from_civil(y,10,31),
    "thanksgiving":lambda:(nth_weekday(y,10,1,2) if canada else nth_weekday(y,11,4,4)),"hanukkah":lambda:hanukkah(y),"christmas":lambda:days_from_civil(y,12,25)}[h]()
def order(today,canada=False):
    y=civil_from_days(today)[0]; up=[];rec=[]
    for h in ORDER:
        ds=sorted(date_of(h,yy,canada) for yy in (y-1,y,y+1))
        nxt=[d for d in ds if d>=today][0]; last=[d for d in ds if d<today][-1]
        if 1<=today-last<=7: rec.append((h,last,True))
        else: up.append((h,nxt,False))
    up.sort(key=lambda t:t[1]); rec.sort(key=lambda t:-t[1])
    return ([up[0]]+rec+up[1:]) if up else rec
def hnorm(s):
    out=" "
    for ch in s.lower(): out+= " " if ch in "'\u2019" else (ch if ch.isalnum() else " ")
    return re.sub(" +"," ",out+" ")
def hmatch(h,t): n=hnorm(t); return any(" %s "%k in n for k in H[h])
d=days_from_civil; ids=lambda l:[t[0] for t in l]
check("civil round trip",all(d(*civil_from_days(x))==x for x in (0,1,-1,18000,20000,25000)) and weekday(0)==4)
check("easter",[easter(y) for y in (2025,2026,2027,2030)]==[d(2025,4,20),d(2026,4,5),d(2027,3,28),d(2030,4,21)])
check("hanukkah",[hanukkah(y) for y in (2024,2025,2026,2027,2028)]==[d(2024,12,26),d(2025,12,15),d(2026,12,5),d(2027,12,25),d(2028,12,13)])
check("movable",date_of("thanksgiving",2026)==d(2026,11,26) and date_of("thanksgiving",2026,True)==d(2026,10,12) and date_of("mothers",2026)==d(2026,5,10) and date_of("fathers",2026)==d(2026,6,21))
o=order(d(2026,10,1)); check("rolling order from 1 Oct",ids(o)==["halloween","thanksgiving","hanukkah","christmas","newyear","valentine","patrick","easter","mothers","fathers","independence"] and not any(t[2] for t in o),ids(o))
o=order(d(2026,11,7)); check("Halloween stays below Thanksgiving for 7 days",ids(o)[:4]==["thanksgiving","halloween","hanukkah","christmas"] and o[1][2] and o[1][1]==d(2026,10,31),ids(o))
o=order(d(2026,11,8)); check("...then returns to sequence",o[0][0]=="thanksgiving" and o[-1][0]=="halloween" and not any(t[2] for t in o),ids(o))
o=order(d(2026,10,31)); check("holiday today is upcoming + first",o[0][0]=="halloween" and not o[0][2] and o[0][1]==d(2026,10,31))
o=order(d(2027,1,2)); check("year wrap",o[0][0]=="valentine" and o[1][0]=="newyear" and o[1][2] and o[-1][0]=="christmas",ids(o))
check("27 Dec",ids(order(d(2026,12,27)))[:2]==["newyear","christmas"],ids(order(d(2026,12,27))))
check("keywords",hmatch("christmas","A Christmas Story (1983)") and hmatch("christmas","EN | Home for XMAS") and hmatch("valentine","My Bloody Valentine's Day")
 and hmatch("patrick","St. Patrick's Day Parade") and hmatch("mothers","Mother's Day") and hmatch("hanukkah","Eight Crazy Nights - Chanukah")
 and not hmatch("christmas","Chrismas Eve") and not hmatch("easter","Eastern Promises") and not hmatch("halloween","Caspers Mountain Hike"))

# ---------------- tags
def norm(s): return " "+re.sub(r"[^a-z0-9+]+"," ",s.lower()).strip()+" "
def has(n,*w): return any(" %s "%x in n for x in w)
def quality(t):
    n=norm(t)
    if has(n,"4k","2160p","2160"): return "4K"
    if has(n,"uhd"): return "UHD"
    if has(n,"fhd","1080p","1080"): return "FHD"
    if has(n,"hd","720p","720"): return "HD"
    return "SD"
NAMES={"english":"en","french":"fr","spanish":"es","german":"de","italian":"it","portuguese":"pt","dutch":"nl","arabic":"ar","hindi":"hi","chinese":"zh","japanese":"ja","korean":"ko","russian":"ru"}
C="en|fr|es|de|it|pt|nl|ar|hi|zh|ja|ko|ru"
LP=re.compile(r"^\s*[\[(|]?\s*(%s)\s*[\])|:]|^\s*(%s)\s+-\s"%(C,C),re.I); LB=re.compile(r"[\[(|]\s*(%s)\s*[\])|]"%C,re.I)
def languages(t):
    out=[]
    m=LP.search(t)
    if m: out.append((m.group(1) or m.group(2)).lower())
    for m in LB.finditer(t): out.append(m.group(1).lower())
    n=norm(t)
    for k,v in NAMES.items():
        if " %s "%k in n: out.append(v)
    return set(out)
def subs(t): return has(norm(t),"sub","subs","subbed","subtitled","subtitles","multisub","msub","multi sub","cc","sdh","vostfr","vost","eng sub")
MAT=["G","PG","PG-13","R","NC-17","TV-Y","TV-G","TV-PG","TV-14","TV-MA"]
def maturity(t):
    n=norm(t)
    for k,v in (("tv ma","TV-MA"),("tv 14","TV-14"),("tv pg","TV-PG")):
        if has(n,k): return v
    if has(n,"tv y7","tv y"): return "TV-Y"
    if has(n,"tv g"): return "TV-G"
    if has(n,"nc 17"): return "NC-17"
    if has(n,"pg 13"): return "PG-13"
    if re.search(r"[\[(]\s*pg\s*[\])]|rated pg(?![-\w])",t,re.I): return "PG"
    if re.search(r"[\[(]\s*r\s*[\])]|rated r(?![-\w])",t,re.I): return "R"
    if re.search(r"[\[(]\s*g\s*[\])]|rated g(?![-\w])",t,re.I): return "G"
    for m in MAT:
        if m.lower()==t.strip().lower(): return m
    return ""
RANK={"TV-Y":0,"TV-G":1,"G":1,"TV-PG":2,"PG":2,"PG-13":3,"TV-14":3,"R":4,"TV-MA":4,"NC-17":5}
TW=[("Sports",["sport","sports","espn","nba","nfl","nhl","mlb","soccer","football","golf","tennis","ufc","wwe","f1","tsn","dazn","racing"]),("News",["news","cnn","msnbc","bloomberg","al jazeera","weather"]),
("Kids",["kids","kid","cartoon","cartoons","children","disney","nick","nickelodeon","junior","baby"]),("Music",["music","mtv","vevo","hits","concert"])]
def ctype(g,n):
    x=norm(g+" "+n)
    for t,ws in TW:
        if any(" %s "%w in x for w in ws): return t
    return "Other"
check("quality",[quality(x) for x in ("Dune (2021) 4K HDR","Movie 2160p","UHD | Movie","Movie FHD","Movie 1080p HD","Sports HD","Plain Title","SHD Channel")]==["4K","4K","UHD","FHD","FHD","HD","SD","SD"])
check("languages",languages("EN | The Movie")=={"en"} and languages("[FR] Le Film")=={"fr"} and languages("Pelicula (ES)")=={"es"} and languages("DE - Der Film")=={"de"}
 and languages("French Movies")=={"fr"} and languages("EN | Film | French")=={"en","fr"} and languages("It Follows")==set() and languages("Plain")==set(),
 [languages(x) for x in ("EN | The Movie","[FR] Le Film","Pelicula (ES)","DE - Der Film","French Movies","EN | Film | French","It Follows")])
check("subtitles",subs("Movie (SUB)") and subs("Film VOSTFR") and subs("Multi-Sub Movie") and not subs("Submarine"))
check("maturity",[maturity(x) for x in ("Show [TV-MA]","Rated PG-13","Movie (R)","R","[PG]","Plain","NC-17")]==["TV-MA","PG-13","R","R","PG","","NC-17"],[maturity(x) for x in ("Show [TV-MA]","Rated PG-13","Movie (R)","R","[PG]","Plain","NC-17")])
check("channel types",ctype("US Sports","ESPN 2")=="Sports" and ctype("","CNN International")=="News" and ctype("Kids","Nick Jr")=="Kids" and ctype("","Channel 7")=="Other")

# ---------------- engine
class Cd:
    def __init__(s,uid,name,genres=(),year=0,stars=-1.0,sparrow=-1.0,added=0,length=-1,maturity="Not Rated",quality="SD",languages=(),subtitles=False,description="",my=""):
        s.uid,s.name,s.genres,s.year,s.stars,s.sparrow,s.added,s.length,s.maturity,s.quality,s.languages,s.subs,s.desc,s.my=uid,name,set(genres),year,stars,sparrow,added,length,maturity,quality,set(languages),subtitles,description,my
M=[Cd("a","Alpha Quest",["action"],2019,4.0,4.5,300,120,"PG-13","4K",["en"],True,"a hero journey","loved"),Cd("b","Beta Love",["romance","drama"],2005,3.0,2.5,100,95,"R","HD",["fr"]),
 Cd("c","Gamma Ray",["action"],2021,2.0,-1.0,200,-1,"Not Rated","SD"),Cd("d","delta force",["war"],0,-1.0,-1.0,0,-1,"Not Rated","FHD",["en","es"],False,"","disliked")]
def apply(all_,text="",indesc=False,quals=(),subf="any",langs=(),lout=False,yf=0,yt=0,genres=(),lmin=0,lmax=0,mine=(),mout=False,stars=0,sp=0,mats=(),matout=False,sort="name",desc=False,dm=()):
    w=text.lower().split(); L={x.lower() for x in langs}; G={x.lower() for x in genres}; out=[]
    for c in all_:
        if w:
            inn=all(x in c.name.lower() for x in w); ind=indesc and (c.uid in dm or all(x in c.desc.lower() for x in w))
            if not inn and not ind: continue
        if quals and c.quality not in quals: continue
        if subf=="with" and not c.subs: continue
        if subf=="without" and c.subs: continue
        if L:
            have=c.languages or {"unknown"}
            if (bool(have&L))==lout: continue
        if yf and (c.year==0 or c.year<yf): continue
        if yt and (c.year==0 or c.year>yt): continue
        if G and not (c.genres&G): continue
        if lmin or lmax:
            if c.length<0: continue
            if lmin and c.length<lmin: continue
            if lmax and c.length>lmax: continue
        if mine and ((c.my in mine)==mout): continue
        if stars and c.stars<stars: continue
        if sp and c.sparrow<sp: continue
        if mats and ((c.maturity in mats)==matout): continue
        out.append(c)
    return srt(out,sort,desc)
def srt(l,sort,desc):
    if sort=="name": return sorted(l,key=lambda c:c.name.lower(),reverse=desc)
    if sort=="genre":
        g=lambda c: min(c.genres) if c.genres else None
        known=sorted([c for c in l if g(c)],key=lambda c:(g(c).lower(),c.name.lower())); unk=sorted([c for c in l if not g(c)],key=lambda c:c.name.lower())
        return (known[::-1] if desc else known)+unk
    key={"star":lambda c:c.stars if c.stars>=0 else None,"maturity":lambda c:RANK.get(c.maturity),"release":lambda c:c.year or None,"added":lambda c:c.added or None,"length":lambda c:c.length if c.length>=0 else None}[sort]
    known=[c for c in l if key(c) is not None]; unk=sorted([c for c in l if key(c) is None],key=lambda c:c.name.lower())
    known=sorted(known,key=lambda c:(key(c),c.name.lower()),reverse=desc)
    return known+unk
nm=lambda l:[c.name for c in l]
check("text",nm(apply(M,"alpha"))==["Alpha Quest"] and nm(apply(M,"A"))[:2]==["Alpha Quest","Beta Love"] and not apply(M,"hero") and nm(apply(M,"hero",True))==["Alpha Quest"] and nm(apply(M,"zzz",True,dm={"a"}))==["Alpha Quest"])
check("quality/subs/language",set(nm(apply(M,quals={"4K","FHD"})))=={"Alpha Quest","delta force"} and nm(apply(M,subf="with"))==["Alpha Quest"] and len(apply(M,subf="without"))==3
 and set(nm(apply(M,langs={"en"})))=={"Alpha Quest","delta force"} and set(nm(apply(M,langs={"en"},lout=True)))=={"Beta Love","Gamma Ray"} and nm(apply(M,langs={"Unknown"}))==["Gamma Ray"])
check("year/genre/length/stars",set(nm(apply(M,yf=2010,yt=2022)))=={"Alpha Quest","Gamma Ray"} and set(nm(apply(M,genres={"Action"})))=={"Alpha Quest","Gamma Ray"}
 and nm(apply(M,lmin=60,lmax=100))==["Beta Love"] and set(nm(apply(M,stars=3.0)))=={"Alpha Quest","Beta Love"} and nm(apply(M,sp=4.0))==["Alpha Quest"])
check("my rating / maturity in-out",nm(apply(M,mine={"loved"}))==["Alpha Quest"] and set(nm(apply(M,mine={"loved"},mout=True)))=={"Beta Love","Gamma Ray","delta force"}
 and nm(apply(M,mats={"R"}))==["Beta Love"] and len(apply(M,mats={"R"},matout=True))==3)
check("sort name",nm(apply(M))==["Alpha Quest","Beta Love","delta force","Gamma Ray"] and nm(apply(M,desc=True))==["Gamma Ray","delta force","Beta Love","Alpha Quest"])
check("sort release",nm(apply(M,sort="release"))==["Beta Love","Alpha Quest","Gamma Ray","delta force"] and nm(apply(M,sort="release",desc=True))==["Gamma Ray","Alpha Quest","Beta Love","delta force"])
check("sort length",nm(apply(M,sort="length"))==["Beta Love","Alpha Quest","delta force","Gamma Ray"] and nm(apply(M,sort="length",desc=True))==["Alpha Quest","Beta Love","delta force","Gamma Ray"])
check("sort genre",nm(apply(M,sort="genre"))==["Alpha Quest","Gamma Ray","Beta Love","delta force"] and nm(apply(M,sort="genre",desc=True))==["delta force","Beta Love","Gamma Ray","Alpha Quest"],nm(apply(M,sort="genre",desc=True)))
check("sort maturity",nm(apply(M,sort="maturity"))==["Alpha Quest","Beta Love","delta force","Gamma Ray"] and nm(apply(M,sort="maturity",desc=True))==["Beta Love","Alpha Quest","delta force","Gamma Ray"])
check("sort added desc",nm(apply(M,sort="added",desc=True))==["Alpha Quest","Gamma Ray","Beta Love","delta force"])

# ---------------- ratings: provider rating (1 decimal), the user's OWN Sparrow Rating (half steps), and the separate Loved / Liked / Disliked scale
import math
def rh(x): return math.floor(x*2+0.5)/2
def provider_of(r):
    try: v=float(r.strip())
    except: return -1.0
    return -1.0 if v<=0 else math.floor(min(v,10.0)*10+0.5)/10
def fmt(v):
    if v<=0: return ""
    t=math.floor(v*10+0.5)
    return str(t//10) if t%10==0 else "%d.%d"%(t//10,t%10)
STEPS=[i*0.5 for i in range(1,21)]
class Scores:
    def __init__(s): s.m={}
    def get(s,u): return s.m.get(u,-1.0)
    def set(s,u,v):
        if v<=0: s.m.pop(u,None)
        else: s.m[u]=rh(min(10.0,max(0.5,v)))
    def ser(s): return "".join("%s\t%s\n"%(k,v) for k,v in s.m.items())
    @staticmethod
    def parse(t):
        r=Scores()
        for line in (t or "").split("\n"):
            f=line.split("\t")
            try: v=float(f[1])
            except: continue
            if len(f)>=2 and v>0: r.m[f[0]]=rh(min(10.0,max(0.5,v)))
        return r
check("provider rating keeps one decimal",[provider_of(x) for x in ("8","7.26","7.2"," 8.7 ","","0","n/a","11")]==[8.0,7.3,7.2,8.7,-1.0,-1.0,-1.0,10.0])
check("format: whole numbers never show .0",[fmt(x) for x in (7.3,8.7,9.0,8.5,10.0,-1.0,0.0,5.96)]==["7.3","8.7","9","8.5","10","","","6"])
check("Sparrow drop down: 0.5 .. 10 in half steps",len(STEPS)==20 and STEPS[0]==0.5 and STEPS[-1]==10.0 and all((x*2)%1==0 for x in STEPS))
sc=Scores(); sc.set("u1",8.5); sc.set("u2",7.3); sc.set("u3",99.0); sc.set("u4",0.1); sc.set("u5",6.0); sc.set("u5",0.0)
check("Sparrow rating is the user's own, half steps, clamped, clearable",sc.get("zz")==-1.0 and sc.get("u1")==8.5 and sc.get("u2")==7.5 and sc.get("u3")==10.0 and sc.get("u4")==0.5 and sc.get("u5")==-1.0)
d=Scores.parse(sc.ser()); j=Scores.parse("junk\nu\tabc\nu2\t-3\nu3\t7.3")
check("Sparrow scores round trip + junk ignored",d.m==sc.m and j.get("u")==-1.0 and j.get("u2")==-1.0 and j.get("u3")==7.5 and Scores.parse(None).get("x")==-1.0)
# Likert verdicts in the recommendation profile (mirror of Recommender.profile / topKeys / score)
VW={"loved":3.0,"liked":1.5,"disliked":-3.0}
def profile(watched,verdicts=()):
    cw={};gw={};w=1.0
    for cat,gens in watched:
        if cat: cw[cat]=cw.get(cat,0)+w
        for g in gens: gw[g]=gw.get(g,0)+w/len(gens)
        w*=0.92
    for (cat,gens),code in verdicts:
        vw=VW.get(code,0)
        if not vw: continue
        if cat: cw[cat]=cw.get(cat,0)+vw
        for g in gens: gw[g]=gw.get(g,0)+vw/len(gens)
    return cw,gw
def top_keys(m,n): return [k for k,v in sorted(((k,v) for k,v in m.items() if v>0),key=lambda kv:(-kv[1],kv[0]))][:n]
def pscore(p,cat,gens,rating=7.0):
    cw,gw=p; ct=sum(v for v in cw.values() if v>0); gt=sum(v for v in gw.values() if v>0); s=0.0
    if ct>0: s+=2.0*cw.get(cat,0)/ct
    if gt>0: s+=3.0*sum(gw.get(g,0) for g in gens)/gt
    return s+0.3*rating/10 if s>0 else 0.0
p=profile([("action",["action"]),("action",["action"])],[(("comedy",["comedy"]),"loved")])
check("Loved It outweighs two watched titles",p[0]["comedy"]>p[0]["action"],p[0])
l=profile([],[(("drama",["drama"]),"liked")]); check("Liked It is weaker than Loved It",0.5<=l[0]["drama"]<=2.0)
p=profile([("horror",["horror"])],[(("horror",["horror"]),"disliked")])
check("Disliked It pushes down, is never a favourite and scores 0",p[0]["horror"]<0 and top_keys(p[0],3)==[] and pscore(p,"horror",["horror"])==0.0)
q=profile([("action",["action"])],[(("horror",["horror"]),"disliked")])
check("Disliked horror leaves action taste intact",pscore(q,"action",["action"])>0 and pscore(q,"horror",["horror"])==0.0)
w=[("comedy",["comedy"]),("action",["action"])]
check("no verdicts = old behaviour",profile(w)==profile(w,[]))
def length(raw):
    s=raw.strip().lower()
    if not s: return -1
    m=re.match(r"^(\d{1,2}):(\d{2}):(\d{2})$",s)
    if m: return int(m[1])*60+int(m[2])
    m=re.match(r"^(\d{1,2}):(\d{2})$",s)
    if m: return int(m[1])*60+int(m[2])
    h=re.search(r"(\d+)\s*h",s); mm=re.search(r"(\d+)\s*m",s)
    if h or mm: return (int(h[1]) if h else 0)*60+(int(mm[1]) if mm else 0)
    return int(s) if s.isdigit() and 1<=int(s)<=1000 else -1
check("length parsing",[length(x) for x in ("01:45:30","105","1h 45min","95 min","1:45","","n/a")]==[105,105,105,95,105,-1,-1])
print("\nRESULT:","ALL PASSED" if not fails else "%d FAILED"%fails); sys.exit(1 if fails else 0)
