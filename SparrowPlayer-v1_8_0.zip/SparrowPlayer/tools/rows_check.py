#!/usr/bin/env python3
"""Mirror of data/Franchises.kt and the Top 10 ranking in data/HomeRows.kt (Java's String.hashCode included) with the expectations of
FranchisesTest / HomeRowsTest, so they are executed here.   python3 tools/rows_check.py"""
import re, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from _hol_mirror import days_from_civil
fails=0
def check(n,c,d=""):
    global fails
    print(("PASS " if c else "FAIL ")+n+("" if c else "  -> "+str(d))); fails+=0 if c else 1
def prep(t):
    w=re.findall(r"[a-z0-9]+",t.lower()); return " "+" ".join(w)+" " if w else " "
STOP={"of","and","the","in","on","for","to","a","an","at","with"}; ROMAN={"ii","iii","iv","v","vi","vii","viii","ix","x"}
def tokens(name):
    s=name.lower(); s=re.sub(r"[(\[][^)\]]*[)\]]"," ",s); s=re.sub(r"^\s*[a-z]{2,3}\s*[|:]\s*","",s)
    t=[x for x in prep(s).strip().split(" ") if x]
    while len(t)>1 and (t[-1].isdigit() or t[-1] in ROMAN): t.pop()
    if t and t[0] in ("the","a","an") and len(t)>2: t.pop(0)
    return t
def key_of(name):
    t=tokens(name)
    if len(t)<2: return ""
    n=3 if (t[1] in STOP and len(t)>=3) else 2
    k=" ".join(t[:n]); return k if len(k)>=7 else ""
def display(key,names):
    cl=[re.sub(r"^\s*[A-Za-z]{2,3}\s*[|:]\s*","",re.sub(r"[(\[][^)\]]*[)\]]","",n)).strip() for n in names]
    p=cl[0]
    for n in cl[1:]:
        i=0
        while i<len(p) and i<len(n) and p[i].lower()==n[i].lower(): i+=1
        p=p[:i]
    words=[w for w in p.split(":")[0].strip().split(" ") if w]
    while len(words)>1 and (words[-1].lower() in STOP or words[-1].isdigit() or words[-1].lower() in ROMAN or words[-1]=="-"): words.pop()
    lcp=" ".join(words)
    if len(lcp)>=len(key): return lcp
    return " ".join(w[:1].upper()+w[1:] for w in key.split(" ") if w)
def detect(titles,minsize=3):
    g={}
    for u,n in titles:
        k=key_of(n)
        if k: g.setdefault(k,[]).append((u,n))
    out=[(k,display(k,[n for _,n in v]),[u for u,_ in sorted(v,key=lambda x:x[1].lower())]) for k,v in g.items() if len(v)>=minsize]
    return sorted(out,key=lambda f:(-len(f[2]),f[1]))
check("franchise keys",[key_of(x) for x in ("Toy Story","Toy Story 2","Toy Story 3 (2010)","The Lord of the Rings: The Two Towers","EN | The Lord of the Rings","Mission: Impossible - Fallout","Die Hard 2")]==
 ["toy story","toy story","toy story","lord of the","lord of the","mission impossible","die hard"],[key_of(x) for x in ("Toy Story","Toy Story 2","Toy Story 3 (2010)","The Lord of the Rings: The Two Towers","EN | The Lord of the Rings","Mission: Impossible - Fallout","Die Hard 2")])
check("single words / roman sequels are not keys",[key_of(x) for x in ("Up","Saw II","It")]==["","",""])
t=[("1","Toy Story"),("2","Toy Story 2"),("3","Toy Story 3"),("4","Toy Story 4"),("5","The Matrix"),("6","Matrix Reloaded"),("7","The Lord of the Rings: The Fellowship of the Ring"),("8","The Lord of the Rings: The Two Towers"),("9","The Lord of the Rings: The Return of the King")]
f=detect(t); check("detects groups, largest first, with natural names",[x[1] for x in f]==["Toy Story","The Lord of the Rings"] and [len(x[2]) for x in f]==[4,3] and detect(t[:2])==[],[(x[1],len(x[2])) for x in f])
f=detect([("1","Mission: Impossible"),("2","Mission: Impossible II"),("3","Mission: Impossible - Fallout")]); check("name falls back to the key",f[0][1]=="Mission Impossible",f)
# ---- Top 10 ranking (HomeRows.trendScore)
def jhash(s):
    h=0
    for ch in s: h=(31*h+ord(ch))&0xFFFFFFFF
    return h-0x100000000 if h&0x80000000 else h
def i32(x): x&=0xFFFFFFFF; return x-0x100000000 if x&0x80000000 else x
DAY=86400000
def trend(uid,rating,added_s,now_ms):
    age=(now_ms-added_s*1000)/DAY if added_s>0 else 99999.0
    rec=3.0 if age<=30 else 2.0 if age<=90 else 1.0 if age<=365 else 0.0
    seed=i32((now_ms//DAY)*31)
    return rating+rec+((i32(jhash(uid)^seed))&0xFF)/255.0*1.2
now=(days_from_civil(2026,11,8))*DAY+12*3600000; nows=now//1000
def titles(n): return [("u%d"%i,5.0+(i%5),nows-i*20*86400) for i in range(1,n+1)]
def top10(ts,now_ms): return [u for u,_,_ in sorted(ts,key=lambda x:-trend(x[0],x[1],x[2],now_ms))][:10]
a=top10(titles(60),now)
check("Top 10: ten distinct titles, stable within a day",len(a)==10 and len(set(a))==10 and a==top10(titles(60),now))
check("Top 10 changes from day to day",a!=top10(titles(60),now+DAY),(a,top10(titles(60),now+DAY)))
print("\nRESULT:","ALL PASSED" if not fails else "%d FAILED"%fails); sys.exit(1 if fails else 0)
