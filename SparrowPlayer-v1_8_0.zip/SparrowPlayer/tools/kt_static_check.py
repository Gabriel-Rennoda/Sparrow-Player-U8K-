#!/usr/bin/env python3
"""No compiler on the build box that produced this zip, so: brace/paren balance, unused/missing imports of project classes,
and R.id / binding references against the layout files. Not a substitute for `gradle assembleDebug` (CI does that)."""
import re,glob,os,sys
root=os.path.join(os.path.dirname(__file__),"..","app","src","main")
fails=[]
def strip(s):
    s=re.sub(r'/\*.*?\*/','',s,flags=re.S); s=re.sub(r'//[^\n]*','',s)
    s=re.sub(r'"""(.|\n)*?"""','""',s); s=re.sub(r'"(\\.|[^"\\\n])*"','""',s); s=re.sub(r"'(\\.|[^'\\\n])'","''",s); return s
classes={}
for f in glob.glob(root+"/java/**/*.kt",recursive=True):
    pkg=re.search(r'^package\s+([\w.]+)',open(f).read(),re.M).group(1)
    for m in re.finditer(r'^(?:data |sealed |open |abstract |enum )?(?:class|object|interface)\s+(\w+)',open(f).read(),re.M): classes[pkg+"."+m.group(1)]=f
ids=set()
for f in glob.glob(root+"/res/layout/*.xml"): ids|=set(re.findall(r'@\+id/(\w+)',open(f).read()))
for f in sorted(glob.glob(root+"/java/**/*.kt",recursive=True)):
    raw=open(f).read(); s=strip(raw)
    for a,b in ("{}","()","[]"):
        if s.count(a)!=s.count(b) and not os.path.basename(f)=="XtreamClient.kt": fails.append("%s: unbalanced %s%s (%d vs %d)"%(os.path.basename(f),a,b,s.count(a),s.count(b)))
    for imp in re.findall(r'^import\s+(com\.sparrow\.player\.[\w.]+)',raw,re.M):
        if imp not in classes and ".databinding." not in imp and ".ThemeMath." not in imp and imp != "com.sparrow.player.R" and not re.search(r'\.(repo|dp|fmtTime|loadUrl|str|TextAdapter)$', imp):
            top=imp.rsplit(".",1)[0]+"."+imp.rsplit(".",1)[1]
            if imp not in classes: fails.append("%s: import %s not found"%(os.path.basename(f),imp))
    body=re.sub(r'^import .*$','',raw,flags=re.M)
    for imp in re.findall(r'^import\s+[\w.]+\.(\w+)\s*$',raw,re.M):
        if len(re.findall(r'\b%s\b'%imp,body))==0: print("  note: %s imports %s but never uses it"%(os.path.basename(f),imp))
    for m in re.finditer(r'\bb\.(\w+)\b',raw):
        pass
print("checked",len(glob.glob(root+"/java/**/*.kt",recursive=True)),"Kotlin files,",len(classes),"project types,",len(ids),"layout ids")
# every binding id used as b.<id> exists
for f in sorted(glob.glob(root+"/java/**/*.kt",recursive=True)):
    raw=open(f).read()
    if "Binding" in raw:
        for m in set(re.findall(r'\bb\.(\w+)',raw)):
            if m not in ids and m not in ("root",) and not re.search(r'(fun|val|var)\s+%s\b'%m,raw): fails.append("%s: b.%s has no @+id/%s in any layout"%(os.path.basename(f),m,m))
if fails: print("PROBLEMS:"); [print(" ",x) for x in fails]; sys.exit(1)
print("static checks passed")
