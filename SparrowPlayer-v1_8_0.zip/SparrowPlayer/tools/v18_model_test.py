#!/usr/bin/env python3
"""Model tests for the 1.8.0 behaviours (no Kotlin compiler here, so the logic is mirrored and exercised): group Move mode, Left from Search,
fresh open on wake, Children & Family rating rules, holiday pool, search tag cost. python3 tools/v18_model_test.py"""
import re, sys
fails = []
def ok(c, m): print(("PASS " if c else "FAIL ") + m); (not c) and fails.append(m)

# ---- 1. Group "Move": pinned groups never move; Up/Down swap; OK keeps; Back restores; hidden groups keep their slot
class Adapter:
    def __init__(s, items): s.items = list(items)            # (id, pinned)
    def move(s, id, d):
        f = next((i for i, x in enumerate(s.items) if x[0] == id), -1); t = f + d
        first = next((i for i, x in enumerate(s.items) if not x[1]), -1)
        if f < 0 or first < 0 or t < first or t >= len(s.items): return False
        s.items.insert(t, s.items.pop(f)); return True
    def movable(s): return [x[0] for x in s.items if not x[1]]
def reorder(full, vis):
    show, it, out = set(vis), iter(vis), []
    for i in full: out.append(next(it) if i in show else i)
    return out
a = Adapter([("all", True), ("fav", True), ("a", False), ("b", False), ("c", False)])
ok(not a.move("a", -1), "cannot move a group above All Channels / Favourites")
ok(a.move("a", +1) and a.movable() == ["b", "a", "c"], "Down moves the group one place")
ok(a.move("a", +1) and not a.move("a", +1) and a.movable() == ["b", "c", "a"], "stops at the bottom")
saved = reorder(["a", "h", "b", "c"], ["c", "a", "b"])
ok(saved == ["c", "h", "a", "b"], "OK: new order saved, the hidden group keeps its slot")
ok(Adapter([("all", True), ("a", False)]).move("a", +1) is False, "single group: nothing to do")

# ---- 2. Left from Search reaches Random Pick (it used to open the side panels because the stale content edge said 'left edge')
def at_left_edge(focus, content_edge): return True if focus == "random" else False if focus == "search" else content_edge
ok(at_left_edge("search", True) is False, "Left on Search: not an edge -> focus moves to Random Pick")
ok(at_left_edge("random", False) is True, "Left on Random Pick: opens the side panels")

# ---- 3. Wake / start-up: always Live TV + guide + Opening Channel tuned, whatever screen the app was left on
def fresh(state, opening, last):
    s = dict(state); s["tab"] = "live"; s["scope"] = "all"; s["playing"] = None; s["panel"] = None
    if opening: s["last"] = opening                      # the guide picks its first selection from 'last channel'
    s["guide_sel"] = s["last"]; s["tuned"] = s["last"]   # ensureLivePlaying tunes the same channel
    return s
st = fresh({"tab": "settings", "last": "ch5", "playing": "ch5"}, "ch99", "ch5")
ok(st["tab"] == "live" and st["tuned"] == "ch99" and st["guide_sel"] == "ch99", "wake from Settings: Live TV, guide on the Opening Channel, playing it")
st = fresh({"tab": "movies", "last": "ch5"}, "", "ch5")
ok(st["tab"] == "live" and st["tuned"] == "ch5", "no Opening Channel: last watched channel plays in the mini player")
# the opening request survives a cancelled first run (consumed only when a channel was found)
pending = True; runs = [None, "ch99"]
for found in runs:
    if found is None: continue
    pending = False
ok(pending is False, "opening request is used up only once a channel was tuned")

# ---- 4. Children & Family: same rules as Maturity.kt (strings from the user's report)
UNSAFE = ["adult","adults","mature","erotic","xxx","18","tv ma","tv 14","nc 17","uncut","uncensored","explicit","after dark","adult swim","horror","crime","true crime","thriller","thrillers","slasher","zombie","zombies","gangster","mafia","war"]
STRONG = ["kids","kid","children","childrens","family","families","disney","pixar","junior","toddler","toddlers","preschool","nick jr","nickelodeon","baby"]
src = open("app/src/main/java/com/sparrow/player/data/Maturity.kt").read()
ADULT = [x.strip('"') for x in re.findall(r'"([a-z0-9 ]+)"', src[src.index("ADULT_TITLES"):src.index("fun isAdultTitle")])]
def prep(t):
    out = [' ']; last = True
    for ch in t.lower():
        if ch.isalnum(): out.append(ch); last = False
        elif not last: out.append(' '); last = True
    if not last: out.append(' ')
    return ''.join(out)
def has(p, ks): return any(' %s ' % k in p for k in ks)
def tag(text):
    n = prep(text)
    for k, v in [("tv ma","TV-MA"),("tv 14","TV-14"),("tv pg","TV-PG"),("tv y","TV-Y"),("tv g","TV-G"),("nc 17","NC-17"),("pg 13","PG-13")]:
        if ' %s ' % k in n: return v
    return ""
def fam_ok(name, cat, genre, known="", series=False):
    if known: return known in {"TV-Y","TV-G","G","TV-PG","PG","PG-13"}
    t = tag(name + " " + cat)
    if t: return t in {"TV-Y","TV-G","G","TV-PG","PG","PG-13"}
    p = prep(genre + " " + cat)
    if has(p, UNSAFE): return False
    if any(prep(name).startswith(" %s " % a) for a in ADULT): return False
    if has(p, STRONG): return True
    return not series
for n, c, g in [("Rick And Morty","Animation","Animation, Comedy, Sci-Fi"),("BoJack Horseman","Adult Animation","Animation, Comedy, Drama"),("Beavis And Butt-Head","Animation","Animation, Comedy")]:
    ok(not fam_ok(n, c, g, series=True), "Children & Family no longer shows %s" % n)
ok(fam_ok("Bluey","Kids","Animation, Kids",series=True) and fam_ok("Frozen","Animation Movies",""), "kids shows and animated films stay")
ok(not fam_ok("Rick And Morty","Animation","Animation", known="TV-14", series=True) and fam_ok("Odd Show","Animation","Animation", known="PG", series=True), "a rating the panel gave is trusted (TV-14 out, PG in)")
ok(len(ADULT) >= 40, "adult-cartoon list parsed from Maturity.kt (%d names)" % len(ADULT))

# ---- 5. Holiday pool: the old title+category words found 1 of 7 typical Christmas titles, now all of them
HOL = ["christmas","xmas","santa","holiday","holidays","home alone","wonderful life","love actually","jingle","festive"]
titles = ["Elf","Home Alone","It's A Wonderful Life","Love Actually","The Holiday","Four Christmases","Jingle All The Way"]
found = [t for t in titles if has(prep(t), HOL)]
ok(len(found) == 5 and "Elf" not in found, "holiday words: %d of %d typical titles by name alone (was 1); Elf / Four Christmases are caught through their category or description" % (len(found), len(titles)))

# ---- 6. search cost (counted from the old code: one Regex built per MediaTags call)
before = 100000 * (1 + 3 + 2 + 3)   # norm() + language regexes + pg/r/g regexes per call, per title
after = 0
ok(after < before, "regex objects built while loading 100 000 titles: %d -> %d (all precompiled)" % (before, after))
print("\nRESULT:", "ALL PASSED" if not fails else "%d FAILED" % len(fails)); sys.exit(1 if fails else 0)
