#!/usr/bin/env python3
"""Line-for-line mirrors of Recommender.kt, History.kt, FirstPressGate.kt and the resume-info text, run on sample data.
(The same cases exist as JUnit tests in app/src/test; this runs without Gradle.)"""
import math
fails=[]
def ok(c,msg):
    print(("  ok   " if c else "  FAIL ")+msg)
    if not c: fails.append(msg)

# ---------------- Recommender ----------------
def genres_of(raw): 
    import re
    return {x.strip().lower() for x in re.split(r"[,/|;&]",raw) if len(x.strip())>1}
def sim(a,b):
    s=0.0
    if a["cat"] and a["cat"]==b["cat"]: s+=2.0
    if a["g"] and b["g"]:
        i=len(a["g"]&b["g"])
        if i>0: s+=3.0*i/len(a["g"]|b["g"])
    if s==0.0: return 0.0
    if a["y"]>0 and b["y"]>0:
        d=abs(a["y"]-b["y"]); s+=0.5 if d<=3 else 0.25 if d<=8 else 0.0
    return s+0.5*b["r"]/10.0
def because(seed,pool,excl,limit):
    l=[(x,sim(seed,x)) for x in pool if x["uid"]!=seed["uid"] and x["uid"] not in excl]
    l=[t for t in l if t[1]>0]
    l.sort(key=lambda t:(-t[1],-t[0]["r"],t[0]["uid"])); return [t[0] for t in l[:limit]]
def profile(w):
    cw={};gw={};k=1.0
    for h in w:
        if h["cat"]: cw[h["cat"]]=cw.get(h["cat"],0)+k
        for g in h["g"]: gw[g]=gw.get(g,0)+k/len(h["g"])
        k*=0.92
    return cw,gw
def top(m,n): return [k for k,_ in sorted(m.items(),key=lambda e:(-e[1],e[0]))[:n]]
def score(p,i):
    cw,gw=p; ct=sum(cw.values()); gt=sum(gw.values()); s=0.0
    if ct>0: s+=2.0*cw.get(i["cat"],0)/ct
    if gt>0: s+=3.0*sum(gw.get(g,0) for g in i["g"])/gt
    return s+0.3*i["r"]/10.0 if s>0 else 0.0
def for_you(p,pool,excl,limit):
    l=[(x,score(p,x)) for x in pool if x["uid"] not in excl]; l=[t for t in l if t[1]>0]
    l.sort(key=lambda t:(-t[1],-t[0]["r"],t[0]["uid"])); return [t[0] for t in l[:limit]]
def it(uid,cat,g="",y=2020,r=7.0): return dict(uid=uid,cat=cat,g=genres_of(g),y=y,r=r)
pool=[it("a1","action","action, thriller",2019,8),it("a2","action","action",2021,6),it("c1","comedy","comedy",2020,9),it("d1","drama","drama, crime",2005,7),it("a3","action","action, adventure",2012,7.5)]
print("Recommender")
ok(genres_of("Drama, Crime / Sci-Fi")=={"drama","crime","sci-fi"},"genre parsing")
seed=it("s","action","action, thriller",2018)
l=[x["uid"] for x in because(seed,pool,set(),10)]
ok(l[0]=="a1" and "c1" not in l and "d1" not in l,"similar first, unrelated never: %s"%l)
ok("a1" not in [x["uid"] for x in because(seed,pool,{"a1"},10)],"watched excluded")
p=profile([it("w1","comedy","comedy"),it("w2","action","action")]); ok(top(p[0],1)==["comedy"],"newest weighs more")
q=profile([it("w1","comedy","comedy"),it("w2","action","action"),it("w3","action","action")]); ok(top(q[0],1)==["action"],"two older beat one newer")
p=profile([it("w1","action","action"),it("w2","action","thriller")]); l=[x["uid"] for x in for_you(p,pool,set(),10)]
ok(l and all(u.startswith("a") for u in l),"for-you follows profile: %s"%l)
tr=sorted([x for x in pool if x["r"]>=6.5],key=lambda x:(-x["r"],x["uid"]))[:3]; ok([x["uid"] for x in tr]==["c1","a1","a3"],"top rated order")
# realistic scenario: movie panel (no genres), only categories
movies=[it("m%d"%i,["action","comedy","horror","drama"][i%4],"",2000+i%24,5+(i%50)/10) for i in range(400)]
hist=[movies[3],movies[7],movies[11],movies[2]]   # three dramas, a horror
pr=profile(hist); recs=for_you(pr,movies,{h["uid"] for h in hist},30)
ok(len(recs)==30 and all(r["cat"]=="drama" or r["cat"]=="horror" for r in recs) and recs[0]["cat"]=="drama","movie-only taste (categories only): top cats %s"%top(pr[0],2))

# ---------------- History ----------------
print("History")
def record(l,uid,ts): return ([(uid,ts)]+[e for e in l if e[0]!=uid])[:150]
l=[]; l=record(l,"a",1); l=record(l,"b",2); l=record(l,"a",3)
ok([e[0] for e in l]==["a","b"] and l[0][1]==3,"newest first, no duplicates")
l=[]; 
for i in range(1,201): l=record(l,"u%d"%i,i)
ok(len(l)==150 and l[0][0]=="u200","capped at 150")

# ---------------- FirstPressGate ----------------
print("FirstPressGate")
class Gate:
    def __init__(s): s.sw=-1
    def swallow(s,k,down,rep,vis):
        if down:
            if rep>0: return k==s.sw
            if not vis: s.sw=k; return True
            s.sw=-1; return False
        if k==s.sw: s.sw=-1; return True
        return False
OK,BACK,UP=23,4,19
g=Gate(); ok(g.swallow(OK,True,0,False) and g.swallow(OK,False,0,False) and not g.swallow(OK,True,0,True) and not g.swallow(OK,False,0,True),"1st press wakes controls, 2nd acts")
g=Gate(); ok(g.swallow(UP,True,0,False) and g.swallow(UP,True,1,False) and g.swallow(UP,True,2,True) and g.swallow(UP,False,0,True) and not g.swallow(UP,True,0,True),"held key = one press")
g=Gate(); a=g.swallow(BACK,True,0,False); g.swallow(BACK,False,0,False); ok(a and not g.swallow(BACK,True,0,True),"Back needs 2 presses")
# 3 s timeline: simulate visibility window
vis_until=0; now=0; g=Gate(); log=[]
def press(t,k):
    global vis_until
    vis=t<vis_until
    s=g.swallow(k,True,0,vis); g.swallow(k,False,0,vis if not s else False) if False else None
    if s: vis_until=t+3000
    elif vis: vis_until=t+3000       # a normal press keeps the bar up (Media3 / showInfo re-arm the 3 s timer)
    log.append((t,k,"WAKE" if s else "NORMAL"))
    g.sw=-1                          # key released between presses
press(0,UP); press(1000,UP); press(2500,UP); press(6000,UP); press(6500,BACK)
ok([x[2] for x in log]==["WAKE","NORMAL","NORMAL","WAKE","NORMAL"],"timeline (3 s window re-arms on use): %s"%[x[2] for x in log])

# ---------------- resume text ----------------
print("Resume info")
def position(ms):
    t=max(0,ms)//1000; h=t//3600; m=(t%3600)//60; s=t%60
    return "%d:%02d:%02d"%(h,m,s) if h>0 else "%d:%02d"%(m,s)
def left(ms):
    m=(max(0,ms)+59999)//60000
    return "%d h %d min left"%(m//60,m%60) if m>=60 else "%d min left"%m
saved=4_354_000; start=saved-30_000 if saved>30_000 else 0; dur=7_500_000
ok(position(start)=="1:12:04" and left(dur-start)=="53 min left" ,"movie saved at 1:12:34 -> '%s • %s'"%(position(start),left(dur-start)))
ok(position(724000)=="12:04" and left(65*60000)=="1 h 5 min left","formats")
print("Watched = 40 %")
def watched(pos,dur): return pos==-1 or (dur>0 and pos>0 and pos*100>=dur*40)
d=100*60000
ok(not watched(39*60000,d) and watched(40*60000,d) and watched(-1,d) and not watched(10*60000,0) and not watched(0,d),"39 % no, 40 % yes, finished yes, unknown duration no")
print()
import sys
if fails: print("FAILURES",fails); sys.exit(1)
print("ALL LOGIC CHECKS PASSED")
