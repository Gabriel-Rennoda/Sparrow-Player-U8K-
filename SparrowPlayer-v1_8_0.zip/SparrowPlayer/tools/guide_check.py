#!/usr/bin/env python3
"""Mirror of GuideMath.segments / ensureVisible / moveHorizontal + the same cases as GuideMathTest (no Gradle needed)."""
import sys
HALF=30*60000; SPAN=4; FUTURE=36*3600000; H=3600000
def wend(ws): return ws+SPAN*HALF
def minS(b): return b
def maxS(b): return b+FUTURE-SPAN*HALF
def clamp(x,lo,hi): return max(lo,min(hi,x))
def align(t,b): return b+((t-b)//HALF)*HALF
def segments(progs,ws,we):
    out=[];cur=ws
    for (s,e,t) in progs:
        if e<=cur: continue
        if s>=we: break
        if s>cur: out.append((cur,s,None))
        end=min(e,we); out.append((max(s,cur),end,t)); cur=end
        if cur>=we: break
    if cur<we: out.append((cur,we,None))
    return out
def idx(segs,t):
    for i,(s,e,_) in enumerate(segs):
        if s<=t<e: return i
    return 0 if t<segs[0][0] else len(segs)-1
def ensure(ws,b,start,stop):
    we=wend(ws)
    if start<ws: tg=align(start,b)
    elif start>=we or (start>=we-HALF and stop>we): tg=align(start,b)-HALF
    else: tg=ws
    return clamp(tg,minS(b),maxS(b))
def move(allseg,ws,b,sel,d):
    cur=idx(allseg,sel); i=cur+d
    if 0<=i<len(allseg):
        s=allseg[i]; return (ensure(ws,b,s[0],s[1]),s[0])
    nw=clamp(ws+d*HALF,minS(b),maxS(b)); c=allseg[cur]
    more=c[1]>wend(ws) if d>0 else ws>b
    return (nw,clamp(sel,nw,wend(nw)-1)) if (more and nw!=ws) else None
b0=10*H
def all_(*p): return segments(list(p),b0,b0+FUTURE)
fails=[]
def ok(c,m):
    print(("  ok   " if c else "  FAIL ")+m)
    if not c: fails.append(m)
a=all_((b0-H,b0+H,"A"),(b0+H,b0+2*H,"B"))
ok(a[0][0]==b0,"running programme clipped to now")
ok(move(a,b0,b0,b0,-1) is None,"LEFT at now: stops (side panels)")
a=all_((b0,b0+3*H,"A"),(b0+3*H,b0+4*H,"B"))
m1=move(a,b0,b0,b0,+1); ok(m1==(b0+3*H-HALF,b0+3*H),"RIGHT scrolls B into column 2")
back=move(a,m1[0],b0,m1[1],-1); ok(back==(b0,b0),"LEFT returns to the current half hour")
ok(move(a,back[0],b0,back[1],-1) is None,"... and stops there")
a=all_((b0,b0+FUTURE,"Movie")); m=move(a,b0,b0,b0,+1); ok(m[0]==b0+HALF,"long last block: window scrolls 30 min, selection stays")
l=move(a,m[0],b0,m[1],-1); ok(l[0]==b0 and move(a,b0,b0,l[1],-1) is None,"long programme: back to now, then stops")
# walk right for a day through half-hour programmes, then all the way back
progs=[(b0+i*HALF,b0+(i+1)*HALF,"p%d"%i) for i in range(72)]; a=all_(*progs)
ws=b0; sel=b0; steps=0
while True:
    r=move(a,ws,b0,sel,+1)
    if r is None: break
    ws,sel=r; steps+=1
    assert minS(b0)<=ws<=maxS(b0)
ok(steps==71 and ws<=maxS(b0) and wend(ws)>=sel,"walk right through 36 h of 30-min shows: %d steps, window ends at +%.1f h"%(steps,(ws-b0)/H))
while True:
    r=move(a,ws,b0,sel,-1)
    if r is None: break
    ws,sel=r; assert ws>=b0
ok(ws==b0 and sel==b0,"walk back: stops at the current half hour")
a=all_(); m=move(a,b0,b0,b0,+1); ok(m and m[0]==b0+HALF,"empty row can be browsed")
ok(move(a,maxS(b0),b0,maxS(b0),+1) is None,"end of data: stops")
ok(ensure(b0,b0,b0+H,b0+H+HALF)==b0 and ensure(b0,b0,b0+3*H//2,b0+2*H)==b0,"visible blocks don't move the window")
print(); sys.exit(1 if fails else 0)
