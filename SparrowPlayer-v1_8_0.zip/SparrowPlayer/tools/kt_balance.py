#!/usr/bin/env python3
"""Bracket balance of every Kotlin file with a real tokenizer (strings, char literals, comments), so text inside strings or comments never
confuses it. No compiler is available on the build box; CI is the first real compile. python3 tools/kt_balance.py"""
import glob, os, sys
def bal(src):
    i = 0; n = len(src); st = []; out = []; line = 1
    while i < n:
        c = src[i]
        if c == "\n": line += 1
        if src.startswith("//", i):
            while i < n and src[i] != "\n": i += 1
            continue
        if src.startswith("/*", i):
            j = src.index("*/", i + 2); line += src[i:j].count("\n"); i = j + 2; continue
        if src.startswith('"""', i):
            j = src.index('"""', i + 3); line += src[i:j].count("\n"); i = j + 3; continue
        if c == '"':
            i += 1
            while src[i] != '"':
                if src[i] == "\\": i += 1
                i += 1
            i += 1; continue
        if c == "'":
            j = i + 1
            if src[j] == "\\": j += 1
            j += 1
            if j < n and src[j] == "'": i = j + 1; continue
        if c in "{([": st.append((c, line))
        if c in "})]":
            if not st: out.append("extra %s line %d" % (c, line))
            else:
                o, l = st.pop()
                if "{([".index(o) != "})]".index(c): out.append("mismatch %s (line %d) vs %s (line %d)" % (o, l, c, line))
        i += 1
    return out + ["unclosed %s line %d" % x for x in st]
root = os.path.join(os.path.dirname(__file__), "..", "app", "src")
bad = 0
for f in sorted(glob.glob(root + "/**/*.kt", recursive=True)):
    r = bal(open(f).read())
    if r: bad += 1; print(os.path.basename(f), r)
print("checked", len(glob.glob(root + "/**/*.kt", recursive=True)), "files;", "PROBLEMS" if bad else "all balanced")
sys.exit(1 if bad else 0)
