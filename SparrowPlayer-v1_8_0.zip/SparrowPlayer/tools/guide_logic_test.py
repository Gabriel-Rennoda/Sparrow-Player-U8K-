"""
Python mirror of the new guide / navigation / resume logic (GuideMath.kt, EpgView.kt key handling, TimeFmt.kt, Resume.kt,
MainActivity back + group-preview flow). No Android SDK is available off-device, so this checks the LOGIC of every
requested behaviour; the Kotlin JUnit tests in app/src/test assert the same numbers and run on your machine / CI.
"""
import datetime as dt
HALF=30*60_000; SPAN=4; PAST=3*3600_000; FUTURE=36*3600_000; VIS=6
def base_start(now,off=0): return ((now+off)//HALF)*HALF-off
def seg(progs,ws,we):
    out=[];cur=ws
    for (s,e,t) in progs:
        if e<=cur: continue
        if s>=we: break
        if s>cur: out.append((cur,s,None))
        end=min(e,we); out.append((max(s,cur),end,t)); cur=end
        if cur>=we: break
    if cur<we: out.append((cur,we,None))
    return out
def idx(segs,t):
    for i,(a,b,_) in enumerate(segs):
        if a<=t<b: return i
    return 0 if t<segs[0][0] else len(segs)-1
H=3600_000; M=60_000
T=lambda h,m: h*H+m*M
fails=0
def check(n,c,d=''):
    global fails; print(('PASS ' if c else 'FAIL ')+n+('' if c else ' -> '+str(d))); fails+=0 if c else 1

# --- grid window start (the 4 examples from the request + edges)
for (h,m,eh,em) in [(4,30,4,30),(4,50,4,30),(4,0,4,0),(4,59,4,30),(4,29,4,0)]:
    check(f'W {h}:{m:02d} -> grid starts {eh}:{em:02d}, ends {(T(eh,em)+SPAN*HALF)//H}:{((T(eh,em)+SPAN*HALF)%H)//M:02d}', base_start(T(h,m))==T(eh,em))
check('W grid is 2 h (4 x 30 min)', SPAN*HALF==2*H)
check('W 45-min-offset zone aligns to LOCAL half hour', (base_start(T(4,50),45*M)+45*M)%HALF==0)

# --- blocks
ws=T(4,30); we=ws+SPAN*HALF
s=seg([(T(4,0),T(5,30),'A'),(T(5,30),T(8,0),'B')],ws,we)
check('B multi-block programmes are ONE block each, clipped to window', len(s)==2 and s[0][:2]==(ws,T(5,30)) and s[1][:2]==(T(5,30),we), s)
s=seg([],ws,we); check('B row with no information = one selectable block spanning the window', len(s)==1 and s[0][2] is None)
s=seg([(T(5,0),T(5,30),'X')],ws,we); check('B gaps are filled with selectable no-info blocks', [x[2] for x in s]==[None,'X',None])

# --- EpgView model (selection, time mode, OK handling)
class Guide:
    def __init__(s,rows,now):                       # rows: list of programme lists
        s.rows=rows; s.base=base_start(now); s.ws=s.base; s.sel=0; s.t=s.base; s.mode=False; s.last_ok=-1
        s.popup=None; s.played=None; s.fav=None; s.exits=0
    def segs(s,r): return seg(s.rows[r],s.ws,s.ws+SPAN*HALF)
    def left_edge(s): return (not s.mode) and idx(s.segs(s.sel),s.t)==0     # == EpgView.atLeftEdge
    def key(s,k,now=0):
        if k=='RIGHT' or k=='LEFT':
            d=1 if k=='RIGHT' else -1
            if s.mode:
                nw=max(s.base-PAST,min(s.base+FUTURE-SPAN*HALF,s.ws+d*HALF))
                if nw!=s.ws: s.ws=nw; s.t=nw
            else:
                sg=s.segs(s.sel); n=idx(sg,s.t)+d
                if 0<=n<len(sg): s.t=sg[n][0]
        elif k=='DOWN': s.sel=min(len(s.rows)-1,s.sel+1)
        elif k=='UP': s.sel=max(0,s.sel-1)
        elif k=='OK':                                # key-up of a short press
            dbl = s.last_ok>=0 and now-s.last_ok<=500; s.last_ok=-1 if dbl else now
            if dbl: s.exit_mode(); s.played=s.sel
            elif not s.mode: s.mode=True; s.popup=now
        elif k=='LONGOK': s.fav=s.sel
    def exit_mode(s):
        s.mode=False
        if s.ws!=s.base: s.ws=s.base; s.t=s.base
    def back(s):
        if s.mode: s.exit_mode(); return True
        return False

now=T(4,50)
rows=[[(T(4,0),T(5,30),'A'),(T(5,30),T(6,0),'B'),(T(6,0),T(9,0),'C')],[],[(T(3,0),T(6,30),'D')]]
g=Guide(rows,now)
check('G grid starts 4:30 at 4:50', g.ws==T(4,30))
check('G initial highlight = program airing at left edge', g.segs(0)[idx(g.segs(0),g.t)][2]=='A')
g.key('RIGHT'); g.key('RIGHT'); g.key('RIGHT'); g.key('RIGHT')
check('G browsing LEFT/RIGHT never shifts the guide window', g.ws==T(4,30), g.ws)
check('G RIGHT stops at last visible block', g.segs(0)[idx(g.segs(0),g.t)][2]=='C')
g.key('LEFT'); g.key('LEFT'); g.key('LEFT')
check('G LEFT stops at first block and reports left edge (-> opens groups)', g.left_edge() and g.ws==T(4,30))
g.key('DOWN'); g.key('RIGHT'); g.key('RIGHT')
check('G "No information" row: normal browsing is fine, window unchanged', g.sel==1 and g.ws==T(4,30))
g.key('OK',1000)
check('G one OK -> time mode + popup', g.mode and g.popup==1000)
check('G in time mode LEFT is NOT treated as left edge (groups stay closed)', not g.left_edge())
g.key('RIGHT'); g.key('RIGHT')
check('G time mode on a NO-INFORMATION row shifts the window (the reported bug)', g.ws==T(5,30), g.ws)
g.key('LEFT'); g.key('LEFT'); g.key('LEFT')
check('G time mode goes into the past', g.ws==T(4,0), g.ws)
for _ in range(10): g.key('LEFT')
check('G past limit', g.ws==g.base-PAST, g.ws)
for _ in range(100): g.key('RIGHT')
check('G future limit', g.ws==g.base+FUTURE-SPAN*HALF)
g.key('DOWN'); g.key('UP'); check('G up/down still change channel in time mode', g.mode and g.sel==1)
ok=g.back()
check('G Back leaves time mode, window snaps to now, same channel kept', ok and not g.mode and g.ws==T(4,30) and g.sel==1)
check('G Back again (not in time mode) is not consumed by the guide', g.back() is False)
g=Guide(rows,now); g.key('OK',1000); g.key('OK',1300)
check('G double OK -> change channel, time mode off', g.played==0 and not g.mode)
g=Guide(rows,now); g.key('OK',1000); g.key('OK',2500)
check('G two slow OKs are two singles (no channel change)', g.played is None and g.mode)
g=Guide(rows,now); g.key('LONGOK'); check('G hold OK = favourite (no time mode side effect)', g.fav==0 and not g.mode)

# --- exit confirmation (MainActivity.backToExit)
class Exit:
    def __init__(s): s.last=0; s.toast=0; s.dialog=0
    def back(s,now):
        if s.last and now-s.last<=2500: s.last=0; s.dialog=1
        else: s.last=now; s.toast+=1
e=Exit(); e.back(1000); check('X first Back = hint only', e.toast==1 and not e.dialog)
e.back(2000); check('X second Back = Yes/No dialog', e.dialog==1)
e=Exit(); e.back(1000); e.back(9000); check('X second Back too late = hint again', e.toast==2 and not e.dialog)

# --- group preview (focus changes the guide, debounced; OK commits; Back keeps)
class Groups:
    def __init__(s): s.scope='all'; s.loaded='all'; s.pending=False; s.loads=0
    def focus(s,g,t):
        if g==s.scope: return
        s.scope=g; s.pending=True; s.due=t+250
    def tick(s,t):
        if s.pending and t>=s.due: s.pending=False; s.loaded=s.scope; s.loads+=1
    def back(s): 
        if s.pending: s.pending=False; s.loaded=s.scope; s.loads+=1
gp=Groups(); gp.focus('all',0); gp.tick(500)
check('P opening the panel (focus on active group) does not reload', gp.loads==0)
gp.focus('uk',0); gp.focus('sports',100); gp.focus('news',200); gp.tick(300); 
check('P fast scrolling is debounced', gp.loads==0); gp.tick(500)
check('P guide shows the focused group', gp.loaded=='news' and gp.loads==1)
gp.focus('uk',1000); gp.back()
check('P Back keeps what is shown and applies a pending preview', gp.loaded=='uk' and gp.scope=='uk')

# --- clock text
import calendar
def clock(ms,h24,tz=0):
    d=dt.datetime.fromtimestamp(ms/1000,dt.timezone.utc); h,m=d.hour,d.minute
    if h24: return f'{h:02d}:{m:02d}'
    return f'{12 if h%12==0 else h%12}:{m:02d} {"am" if h<12 else "pm"}'
DAYS=['Sun','Mon','Tues','Wed','Thurs','Fri','Sat']; MON=['Jan.','Feb.','Mar.','Apr.','May','Jun.','Jul.','Aug.','Sep.','Oct.','Nov.','Dec.']
def header(ms,h24):
    d=dt.datetime.fromtimestamp(ms/1000,dt.timezone.utc)
    return f'{DAYS[(d.weekday()+1)%7]}, {MON[d.month-1]} {d.day:02d}     -    '+clock(ms,h24)
ms=int(dt.datetime(2026,11,5,1,15,tzinfo=dt.timezone.utc).timestamp()*1000)
check('C header 12h matches requested format', header(ms,False)=='Thurs, Nov. 05     -    1:15 am', header(ms,False))
check('C header 24h', header(ms+12*H,True)=='Thurs, Nov. 05     -    13:15')
check('C noon / midnight', clock(T(12,0),False)=='12:00 pm' and clock(T(0,5),False)=='12:05 am')

# --- resume
BACK=30_000; FIN=-1
resume=lambda s: 0 if s<=BACK else s-BACK
def store(p,d): return 0 if d<=0 or p<=0 else (FIN if d-p<60_000 or p*100>=d*95 else p)
check('R resume 30 s before stop point', resume(600_000)==570_000 and resume(20_000)==0 and resume(FIN)==0)
check('R finished / nothing-to-keep rules', store(7_000_000,7_100_000)==FIN and store(1_000_000,7_100_000)==1_000_000 and store(0,7_100_000)==0 and store(500,-1)==0)
# series Play button: continue last episode, or the next if finished
def target(eps,last,pos):
    if last not in eps: return eps[0]
    i=eps.index(last); return eps[i+1] if pos.get(last)==FIN and i+1<len(eps) else eps[i]
eps=['e1','e2','e3']
check('R series Play: nothing watched -> first episode', target(eps,'',{})=='e1')
check('R series Play: partly watched -> same episode', target(eps,'e2',{'e2':900_000})=='e2')
check('R series Play: finished -> next episode', target(eps,'e2',{'e2':FIN})=='e3' and target(eps,'e3',{'e3':FIN})=='e3')
print('\nRESULT:', 'ALL PASSED' if not fails else f'{fails} FAILED'); raise SystemExit(1 if fails else 0)
