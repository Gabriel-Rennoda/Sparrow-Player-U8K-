"""
Mini Android layout engine (LinearLayout / FrameLayout / weights / margins / padding / RatioFrameLayout) that reads the
REAL layout XML from the project and renders the result. Text size is estimated (0.55em per char, 1.25em line height).
Checks that nothing is clipped / overlapping at several dp viewports. Not a pixel-exact Android render.
"""
import re, sys
from lxml import etree
from PIL import Image, ImageDraw, ImageFont
A='{http://schemas.android.com/apk/res/android}'
import os; RES=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','app','src','main','res')+'/'
DIM={'rail_collapsed':64,'rail_expanded':232,'groups_width':250,'page_pad':28}

def dp(v,default=0):
    if v is None: return default
    if v.startswith('@dimen/'): return DIM[v[7:]]
    m=re.match(r'(-?[\d.]+)(dp|sp|dip)?$',v); return float(m.group(1)) if m else default
def attr(n,k,d=None): return n.get(A+k,d)
def pad(n):
    p=dp(attr(n,'padding'),0)
    return [dp(attr(n,'paddingStart'),dp(attr(n,'paddingLeft'),p)), dp(attr(n,'paddingTop'),p),
            dp(attr(n,'paddingEnd'),dp(attr(n,'paddingRight'),p)), dp(attr(n,'paddingBottom'),p)]
def mar(n):
    m=dp(attr(n,'layout_margin'),0)
    return [dp(attr(n,'layout_marginStart'),m), dp(attr(n,'layout_marginTop'),m), dp(attr(n,'layout_marginEnd'),m), dp(attr(n,'layout_marginBottom'),m)]
def tag(n): return n.tag.split('.')[-1] if isinstance(n.tag,str) else ''
def gone(n): return attr(n,'visibility')=='gone' or n.get('_gone')=='1'
def kids(n): return [c for c in n if isinstance(c.tag,str) and not gone(c)]

class Box:
    def __init__(s,n,x,y,w,h): s.n=n;s.x=x;s.y=y;s.w=w;s.h=h;s.kids=[]
def text_size(n):
    sz=dp(attr(n,'textSize'),14); t=attr(n,'text','') or 'Sample text xx'
    ml=1 if attr(n,'singleLine')=='true' else int(attr(n,'maxLines','1'))
    return sz,t,ml
def intrinsic(n,maxw,maxh):
    t=tag(n); p=pad(n)
    if t=='TextView':
        sz,txt,ml=text_size(n); w=min(len(txt)*sz*0.55,maxw)+p[0]+p[2]; h=ml*sz*1.25+p[1]+p[3]; return w,max(h,dp(attr(n,'minHeight'),0))
    if t in('ImageView',): return dp(attr(n,'layout_width'),24),dp(attr(n,'layout_height'),24)
    if t=='ProgressBar': return maxw,dp(attr(n,'layout_height'),4)
    if t in('LinearLayout','FrameLayout','RatioFrameLayout'):
        b=layout(n,0,0,None,None,measure_only=True); return min(b.w,maxw),min(b.h,maxh)
    return dp(attr(n,'minHeight'),0),dp(attr(n,'minHeight'),0)
def dim(n,which,avail,parent_exact=True):
    v=attr(n,'layout_'+which)
    if v=='match_parent': return avail
    if v=='wrap_content': return None
    return dp(v,0)

def layout(n,x,y,w,h,measure_only=False):
    """w,h: size decided by parent (None = wrap)."""
    t=tag(n); p=pad(n); box=Box(n,x,y,w,h)
    cs=kids(n)
    if t=='RatioFrameLayout':
        h=h; w=(h-p[1]-p[3])*16/9+p[0]+p[2]; box.w=w
    if t in('FrameLayout','RatioFrameLayout'):
        iw=(w if w is not None else 4000)-p[0]-p[2]; ih=(h if h is not None else 4000)-p[1]-p[3]
        mw=mh=0
        for c in cs:
            m=mar(c); cw=dim(c,'width',iw-m[0]-m[2]); ch=dim(c,'height',ih-m[1]-m[3])
            if cw is None or ch is None:
                iw2,ih2=intrinsic(c,iw-m[0]-m[2],ih-m[1]-m[3]); cw=iw2 if cw is None else cw; ch=ih2 if ch is None else ch
            g=attr(c,'layout_gravity','')
            cx=x+p[0]+m[0]; cy=y+p[1]+m[1]
            if 'end' in g or 'right' in g: cx=x+(w or 0)-p[2]-m[2]-cw
            if 'center' in g: cx=x+p[0]+(iw-cw)/2; cy=y+p[1]+(ih-ch)/2
            cb=layout(c,cx,cy,cw,ch); box.kids.append(cb); mw=max(mw,cw+m[0]+m[2]); mh=max(mh,ch+m[1]+m[3])
        if w is None: box.w=mw+p[0]+p[2]
        if h is None: box.h=mh+p[1]+p[3]
        return box
    if t=='LinearLayout':
        horiz=attr(n,'orientation','horizontal')=='horizontal'
        iw=(w if w is not None else 4000)-p[0]-p[2]; ih=(h if h is not None else 4000)-p[1]-p[3]
        main=iw if horiz else ih; cross=ih if horiz else iw
        sizes=[];tot=0;wsum=0
        for c in cs:
            m=mar(c); wt=float(attr(c,'layout_weight','0'))
            cw=dim(c,'width',iw-m[0]-m[2]); ch=dim(c,'height',ih-m[1]-m[3])
            mm=(m[0]+m[2]) if horiz else (m[1]+m[3])
            if wt>0 and ((horiz and attr(c,'layout_width')=='0dp') or (not horiz and attr(c,'layout_height')=='0dp')):
                wsum+=wt; sizes.append(['w',wt,mm,m]); tot+=mm; continue
            if cw is None or ch is None:
                rem_w=iw-m[0]-m[2]; rem_h=ih-m[1]-m[3]
                if tag(c)=='RatioFrameLayout':   # width derived from the (exact) height
                    c.set('_h',str(ch if ch is not None else rem_h))
                    hh=ch if ch is not None else rem_h; cw=(hh-pad(c)[1]-pad(c)[3])*16/9+pad(c)[0]+pad(c)[2]; ch=hh
                else:
                    iw2,ih2=intrinsic(c,rem_w,rem_h); cw=iw2 if cw is None else cw; ch=ih2 if ch is None else ch
            sizes.append(['f',cw,ch,m]); tot+=(cw if horiz else ch)+mm
        left=max(0,main-tot); pos=(x+p[0]) if horiz else (y+p[1]); maxcross=0
        for c,sz in zip(cs,sizes):
            m=sz[3]
            if sz[0]=='w':
                ms=left*sz[1]/wsum
                cw,ch=(ms,dim(c,'height',ih-m[1]-m[3])) if horiz else (dim(c,'width',iw-m[0]-m[2]),ms)
                if ch is None: ch=intrinsic(c,cw,ih)[1]
                if cw is None: cw=intrinsic(c,iw,ch)[0]
            else: cw,ch=sz[1],sz[2]
            if horiz: cb=layout(c,pos+m[0],y+p[1]+m[1],cw,ch); pos+=cw+m[0]+m[2]; maxcross=max(maxcross,ch+m[1]+m[3])
            else:     cb=layout(c,x+p[0]+m[0],pos+m[1],cw,ch); pos+=ch+m[1]+m[3]; maxcross=max(maxcross,cw+m[0]+m[2])
            box.kids.append(cb)
        used=pos-((x+p[0]) if horiz else (y+p[1]))
        if w is None: box.w=(used if horiz else maxcross)+p[0]+p[2]
        if h is None: box.h=(maxcross if horiz else used)+p[1]+p[3]
        return box
    return box   # leaf

def load(name): return etree.parse(RES+'layout/'+name+'.xml').getroot()
def find(n,i):
    for e in n.iter():
        if isinstance(e.tag,str) and e.get(A+'id')=='@+id/'+i: return e
def collect(b,out,depth=0):
    out.append((b,depth)); [collect(k,out,depth+1) for k in b.kids]

def render_state(vw,vh,state,tab='live',fname=None):
    root=load('activity_main')
    base=find(root,'base'); groups=find(root,'groupsPanel'); rail=find(root,'navRail'); live=find(root,'liveHeader'); hero=find(root,'hero')
    for e,gone_ in ((groups,not state.get('groups')),(live,tab!='live'),(hero,tab!='vod')): e.set('_gone','1' if gone_ else '0'); 
    groups.set(A+'visibility','visible') if state.get('groups') else None
    live.set(A+'visibility','visible') if tab=='live' else None
    hero.set(A+'visibility','visible') if tab=='vod' else None
    rail.set(A+'layout_width','232dp' if state.get('nav') else '64dp')
    # tabs are inflated at runtime from item_nav: inject the six real rows
    tabs=find(root,'tabs')
    for i in range(6):
        row=load('item_nav'); row.set('_gone','0')
        lab=find(row,'navLabel'); lab.set(A+'text',['Live TV','Movies','Series','Guide','Favourites','Settings'][i])
        if state.get('nav'): lab.set(A+'visibility','visible')
        tabs.append(row)
    nt=find(root,'navTitle')
    if state.get('nav'): nt.set(A+'visibility','visible')
    b=layout(root,0,0,vw,vh)
    return b,root
def check(b,vw,vh):
    out=[];collect(b,out); problems=[]
    for bx,d in out:
        nid=bx.n.get(A+'id','') if hasattr(bx.n,'get') else ''
        if bx.x<-0.5 or bx.y<-0.5 or bx.x+bx.w>vw+0.5 or bx.y+bx.h>vh+0.5:
            problems.append(f'OFF-SCREEN {tag(bx.n)} {nid} x={bx.x:.0f} y={bx.y:.0f} w={bx.w:.0f} h={bx.h:.0f}')
    return problems
def draw(b,vw,vh,path,scale):
    im=Image.new('RGB',(int(vw*scale),int(vh*scale)),(14,10,7)); d=ImageDraw.Draw(im)
    f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',int(11*scale)) if True else None
    out=[];collect(b,out)
    col={'LinearLayout':(60,45,30),'FrameLayout':(40,30,22),'RatioFrameLayout':(0,0,0),'TextView':(120,90,50),'RecyclerView':(70,50,35),'PlayerView':(25,25,30),'ImageView':(200,200,200),'ProgressBar':(217,142,74)}
    for bx,dep in out:
        t=tag(bx.n); nid=(bx.n.get(A+'id','') or '').replace('@+id/','')
        if t in('LinearLayout','FrameLayout') and not nid: continue
        c=col.get(t,(80,80,80))
        if nid in('navRail','groupsPanel'): c=(28,20,14)
        d.rectangle([bx.x*scale,bx.y*scale,(bx.x+bx.w)*scale,(bx.y+bx.h)*scale],fill=c if t not in('LinearLayout','FrameLayout') or nid in('navRail','groupsPanel') else None,outline=(217,142,74) if nid in('playerBox','infoPane','content','liveHeader','groupsPanel','navRail','contentCol') else (90,70,50),width=max(1,int(scale/2)))
        if nid and nid in('playerBox','infoPane','content','groupsPanel','navRail','liveHeader','hero','status','contentCol'): d.text((bx.x*scale+6,bx.y*scale+4),nid+f' {bx.w:.0f}x{bx.h:.0f}dp',fill=(255,255,255),font=f)
    im.save(path)
if __name__=='__main__':
    cases=[(960,540,'U8K as reported (3840x2160 @ 640dpi)'),(1280,720,'1280x720dp'),(1920,1080,'1920x1080dp')]
    states=[('live',{} ,'L0 live, panels closed'),('live',{'groups':1},'L1 groups open'),('live',{'groups':1,'nav':1},'L2 groups + tab list'),('vod',{},'Movies hero'),('vod',{'nav':1},'Movies + tab list')]
    allp=0
    for vw,vh,label in cases:
        for tab,st,sl in states:
            b,root=render_state(vw,vh,st,tab)
            pr=check(b,vw,vh); allp+=len(pr)
            info=''
            if tab=='live':
                pb=[x for x,_ in (lambda o:(collect(b,o),o)[1])([]) if x.n.get(A+'id')=='@+id/playerBox'][0]
                ip=[x for x,_ in (lambda o:(collect(b,o),o)[1])([]) if x.n.get(A+'id')=='@+id/infoPane'][0]
                ct=[x for x,_ in (lambda o:(collect(b,o),o)[1])([]) if x.n.get(A+'id')=='@+id/content'][0]
                info=f'player {pb.w:.0f}x{pb.h:.0f}dp @({pb.x:.0f},{pb.y:.0f}) | info {ip.w:.0f}x{ip.h:.0f} | body {ct.w:.0f}x{ct.h:.0f}'
            print(f'{vw}x{vh} {sl:28s} {"OK " if not pr else "BAD"} {info}'); [print('   ',x) for x in pr]
            if vw==960: draw(b,vw,vh,f'/tmp/layout_{tab}_{"".join(k for k in st) or "closed"}.png',4)
    print('\nproblems:',allp)
