# civil <-> epoch days (1970-01-01 = 0)
def days_from_civil(y,m,d):
    y -= m<=2
    era = (y if y>=0 else y-399)//400
    yoe = y-era*400
    doy = (153*(m+(-3 if m>2 else 9))+2)//5+d-1
    doe = yoe*365+yoe//4-yoe//100+doy
    return era*146097+doe-719468
def civil_from_days(z):
    z += 719468
    era = (z if z>=0 else z-146096)//146097
    doe = z-era*146097
    yoe = (doe-doe//1460+doe//36524-doe//146096)//365
    y = yoe+era*400
    doy = doe-(365*yoe+yoe//4-yoe//100)
    mp = (5*doy+2)//153
    d = doy-(153*mp+2)//5+1
    m = mp+(3 if mp<10 else -9)
    return (y+(m<=2),m,d)
def weekday(z): return (z+4)%7   # 0=Sunday (1970-01-01 was Thursday=4)
def easter(y):
    a=y%19;b=y//100;c=y%100;d=b//4;e=b%4;f=(b+8)//25;g=(b-f+1)//3
    h=(19*a+b-d-g+15)%30;i=c//4;k=c%4;l=(32+2*e+2*i-h-k)%7;m=(a+11*h+22*l)//451
    mo=(h+l-7*m+114)//31; da=(h+l-7*m+114)%31+1
    return days_from_civil(y,mo,da)
HEB_EPOCH_RD=-1373427   # fixed (RD) date of 1 Tishri AM 1;  RD of 1970-01-01 = 719163
def elapsed(y):
    me=(235*y-234)//19
    pe=12084+13753*me
    d=29*me+pe//25920
    return d+1 if (3*(d+1))%7<3 else d
def corr(y):
    n0,n1,n2=elapsed(y-1),elapsed(y),elapsed(y+1)
    return 2 if n2-n1==356 else (1 if n1-n0==382 else 0)
def new_year_rd(y): return HEB_EPOCH_RD+elapsed(y)+corr(y)
def hanukkah(gy):
    hy=gy+3761
    ny=new_year_rd(hy); ln=new_year_rd(hy+1)-ny
    hesh=30 if ln%10==5 else 29
    rd=ny+30+hesh+24
    return rd-719163
def nth_weekday(y,m,wd,n):   # n-th (1..) weekday wd (0=Sun) of month
    first=days_from_civil(y,m,1); off=(wd-weekday(first))%7
    return first+off+7*(n-1)
if __name__=="__main__":
    for y,exp in [(2024,(2024,12,26)),(2025,(2025,12,15)),(2026,(2026,12,5)),(2027,(2027,12,25)),(2028,(2028,12,13))]:
        print("hanukkah",y,civil_from_days(hanukkah(y)),"exp",exp)
    print("RH 5786",civil_from_days(new_year_rd(5786)-719163),"exp 2025-9-23")
    print("RH 5787",civil_from_days(new_year_rd(5787)-719163),"exp 2026-9-12")
    for y,exp in [(2024,(2024,3,31)),(2025,(2025,4,20)),(2026,(2026,4,5)),(2027,(2027,3,28)),(2030,(2030,4,21))]:
        print("easter",y,civil_from_days(easter(y)),"exp",exp)
    print("thanksgiving 2026",civil_from_days(nth_weekday(2026,11,4,4)),"exp 2026-11-26")
    print("mothers day 2026",civil_from_days(nth_weekday(2026,5,0,2)),"exp 2026-5-10")
    print("fathers day 2026",civil_from_days(nth_weekday(2026,6,0,3)),"exp 2026-6-21")
    print("cdn thanksgiving 2026",civil_from_days(nth_weekday(2026,10,1,2)),"exp 2026-10-12")
