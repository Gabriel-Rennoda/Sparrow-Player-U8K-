#!/usr/bin/env python3
"""Proves a new build installs over an old one without touching user data.
  python3 tools/upgrade_check.py path/to/SparrowPlayer-v1_1_2.zip     (the previously released zip)
Checks: same applicationId; versionCode higher; ONE committed signing key is used by debug + release; database name, version
and every @Entity byte-identical (so Room needs no migration and nothing is wiped); no destructive-migration call; shared
preferences file name unchanged and no preference key removed / renamed (providers, favourites, positions, settings, theme)."""
import re,sys,zipfile,os
here=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
def read(root,rel):
    return open(os.path.join(root,rel)).read()
old=zipfile.ZipFile(sys.argv[1]); P="SparrowPlayer/"
def oldf(rel): return old.read(P+rel).decode()
def newf(rel): return read(here,rel)
fails=[]
def ok(c,m):
    print(("  ok   " if c else "  FAIL ")+m)
    if not c: fails.append(m)
g_old,g_new=oldf("app/build.gradle.kts"),newf("app/build.gradle.kts")
ai=lambda s: re.search(r'applicationId\s*=\s*"([^"]+)"',s).group(1)
vc=lambda s: int(re.search(r'versionCode\s*=\s*(\d+)',s).group(1))
ok(ai(g_old)==ai(g_new),"applicationId unchanged: "+ai(g_new))
ok(vc(g_new)>vc(g_old),"versionCode %d > installed %d"%(vc(g_new),vc(g_old)))
ok('create("sparrow")' in g_new and 'debug { signingConfig = signingConfigs.getByName("sparrow") }' in g_new and g_new.count('signingConfigs.getByName("sparrow")')>=2,"debug and release both signed with the fixed key")
ok(os.path.getsize(os.path.join(here,"app/sparrow-signing.jks"))>1000,"signing key file is in the project (app/sparrow-signing.jks)")
ent=lambda s: s[s.index("@Entity"):s.index("@Dao")]
e_old,e_new=oldf("app/src/main/java/com/sparrow/player/data/Entities.kt"),newf("app/src/main/java/com/sparrow/player/data/Entities.kt")
ok(ent(e_old)==ent(e_new),"all @Entity definitions identical to the installed version (schema unchanged, no migration needed)")
dbv=lambda s: re.search(r'version\s*=\s*(\d+),\s*exportSchema',s).group(1)
ok(dbv(e_old)==dbv(e_new),"database version unchanged (%s)"%dbv(e_new))
r_old,r_new=oldf("app/src/main/java/com/sparrow/player/data/Repository.kt"),newf("app/src/main/java/com/sparrow/player/data/Repository.kt")
nm=lambda s: re.search(r'databaseBuilder\([^"]*"([^"]+)"',s).group(1)
ok(nm(r_old)==nm(r_new)=="sparrow.db","database file name unchanged: "+nm(r_new))
bad=[]
for dp,_,fs in os.walk(os.path.join(here,"app/src/main")):
    for f in fs:
        if f.endswith(".kt") and re.search(r'\.fallbackToDestructiveMigration\w*\(',open(os.path.join(dp,f)).read()): bad.append(f)
ok(not bad,"no destructive-migration fallback in the app %s"%bad)
p_old,p_new=oldf("app/src/main/java/com/sparrow/player/data/Prefs.kt"),newf("app/src/main/java/com/sparrow/player/data/Prefs.kt")
fn=lambda s: re.search(r'getSharedPreferences\("([^"]+)"',s).group(1)
ok(fn(p_old)==fn(p_new),"shared-preferences file unchanged: "+fn(p_new))
# keys are read through k("name") since profiles (v1.7.0); profile "1" must still use the unprefixed original key
keys=lambda s: set(re.findall(r'(?:get\w+|put\w+)\("([A-Za-z_]+)"',s))|set(re.findall(r'"((?:pos|dur|last|ep)_?)"',s))|set(re.findall(r'\bk\("([A-Za-z_]+)',s))
ok("fun k(name: String) = if (profile == \"1\") name else" in p_new.replace("private ","") or 'if (profile == "1") name else' in p_new,"profile 1 keeps the original (unprefixed) preference keys")
k_old,k_new=keys(p_old),keys(p_new)
ok(k_old<=k_new,"no preference key removed or renamed (old %d, new %d, added: %s)"%(len(k_old),len(k_new),sorted(k_new-k_old)))
print(); sys.exit(1 if fails else 0)
