#!/usr/bin/env python3
"""Mirror of data/Customize.kt and util/TitleCase.kt (same rules, same test cases as CustomizeTest / TitleCaseTest) so the new
channel / group edit logic can be exercised without a JVM.   python3 tools/customize_check.py"""
import sys
fails=0
def check(n,c):
    global fails
    print(('PASS ' if c else 'FAIL ')+n); fails+=0 if c else 1

class Customize:
    def __init__(s):
        s.hidden=[]; s.renamed={}; s.custom={}; s.gnames={}; s.ghidden=[]; s.added={}; s.removed={}; s.order=[]
    def set_hidden(s,u,h):
        if h and u not in s.hidden: s.hidden.append(u)
        if not h and u in s.hidden: s.hidden.remove(u)
    def rename(s,u,n,orig):
        n=n.strip()
        if not n or n==orig: s.renamed.pop(u,None)
        else: s.renamed[u]=n
    def name_of(s,u,o): return s.renamed.get(u,o)
    def create_group(s,name,id_): s.custom[id_]=name.strip() or "New Group"; return id_
    def group_name(s,g,o): return s.gnames.get(g) or s.custom.get(g) or o
    def rename_group(s,g,n,orig):
        n=n.strip()
        if not n or n==orig: s.gnames.pop(g,None)
        else: s.gnames[g]=n
        if g in s.custom and n: s.custom[g]=n; s.gnames.pop(g,None)
    def delete_group(s,g):
        if g not in s.custom: return
        del s.custom[g]; s.gnames.pop(g,None); s.added.pop(g,None); s.removed.pop(g,None)
        if g in s.ghidden: s.ghidden.remove(g)
        if g in s.order: s.order.remove(g)
    def is_member(s,g,u,home):
        if g in s.custom: return u in s.added.get(g,[])
        return (home==g and u not in s.removed.get(g,[])) or u in s.added.get(g,[])
    def add_to(s,g,u,home):
        if g not in s.custom and home==g:
            if u in s.removed.get(g,[]): s.removed[g].remove(u)
            return
        s.added.setdefault(g,[]); 
        if u not in s.added[g]: s.added[g].append(u)
    def remove_from(s,g,u,home):
        if g not in s.custom and home==g:
            s.removed.setdefault(g,[]); 
            if u not in s.removed[g]: s.removed[g].append(u)
        elif u in s.added.get(g,[]): s.added[g].remove(u)
    def move(s,u,f,t,home):
        if f==t: return
        s.remove_from(f,u,home); s.add_to(t,u,home)
    def arrange(s,nat):
        first=[]; 
        for o in s.order:
            if o in nat and o not in first: first.append(o)
        return first+[n for n in nat if n not in first]
    def move_group(s,nat,g,d):
        l=s.arrange(nat); i=l.index(g) if g in l else -1; j=i+d
        if i<0 or j<0 or j>=len(l): return False
        l[i],l[j]=l[j],l[i]; s.order=l; return True
    def serialize(s):
        out=[]
        e=lambda x: x.replace('\\','\\\\').replace('\t','\\t').replace('\n','\\n').replace('\r','\\r')
        for u in s.hidden: out.append("H\t"+e(u))
        for k,v in s.renamed.items(): out.append("N\t%s\t%s"%(e(k),e(v)))
        for k,v in s.custom.items(): out.append("G\t%s\t%s"%(e(k),e(v)))
        for k,v in s.gnames.items(): out.append("GN\t%s\t%s"%(e(k),e(v)))
        for g in s.ghidden: out.append("GH\t"+e(g))
        for g,l in s.added.items():
            for u in l: out.append("A\t%s\t%s"%(e(g),e(u)))
        for g,l in s.removed.items():
            for u in l: out.append("R\t%s\t%s"%(e(g),e(u)))
        for g in s.order: out.append("O\t"+e(g))
        return "\n".join(out)+"\n" if out else ""
    @staticmethod
    def parse(t):
        c=Customize()
        if not t or not t.strip(): return c
        def un(x):
            r=[];i=0
            while i<len(x):
                if x[i]=='\\' and i+1<len(x): r.append({'t':'\t','n':'\n','r':'\r'}.get(x[i+1],x[i+1])); i+=2
                else: r.append(x[i]); i+=1
            return "".join(r)
        for raw in t.split('\n'):
            if not raw: continue
            f=[un(x) for x in raw.split('\t')]; k=f[0]
            if k=="H" and len(f)>=2: c.hidden.append(f[1])
            elif k=="N" and len(f)>=3: c.renamed[f[1]]=f[2]
            elif k=="G" and len(f)>=3: c.custom[f[1]]=f[2]
            elif k=="GN" and len(f)>=3: c.gnames[f[1]]=f[2]
            elif k=="GH" and len(f)>=2: c.ghidden.append(f[1])
            elif k=="A" and len(f)>=3: c.added.setdefault(f[1],[]).append(f[2])
            elif k=="R" and len(f)>=3: c.removed.setdefault(f[1],[]).append(f[2])
            elif k=="O" and len(f)>=2: c.order.append(f[1])
        return c
    def empty(s): return not(s.hidden or s.renamed or s.custom or s.gnames or s.ghidden or s.added or s.removed or s.order)

SMALL={"a","an","and","as","at","but","by","for","in","nor","of","on","or","per","the","to","vs","via","with"}
def word(w):
    if any(ch.isupper() for ch in w): return w
    out=[]; start=True
    for ch in w:
        if start and ch.isalpha(): out.append(ch.upper()); start=False
        else:
            out.append(ch)
            if ch in '-/|("[': start=True
            elif ch.isalnum(): start=False
    return "".join(out)
def title(s):
    if not s.strip(): return s
    ws=s.split(' '); real=[i for i,w in enumerate(ws) if w]; f,l=real[0],real[-1]
    return " ".join(w if not w else (w if (i not in(f,l) and w in SMALL) else word(w)) for i,w in enumerate(ws))

# ---- CustomizeTest
c=Customize(); c.set_hidden("a",True); ok=("a" in c.hidden); c.set_hidden("a",False)
c.rename("a","  My News ","News"); check("hide / rename",ok and "a" not in c.hidden and c.name_of("a","News")=="My News")
c.rename("a","News","News"); check("rename to original drops the rename",not c.renamed)
c=Customize(); g=c.create_group("Mine","c:1"); c.add_to(g,"a","10")
check("copy keeps home membership",c.is_member(g,"a","10") and c.is_member("10","a","10") and not c.is_member(g,"b","10"))
c=Customize(); c.move("a","10","20","10")
check("move: out of source, into target",(not c.is_member("10","a","10")) and c.is_member("20","a","10"))
c.move("a","20","10","10"); check("move back home restores",c.is_member("10","a","10") and not c.is_member("20","a","10"))
c=Customize(); g=c.create_group("Mine","c:1"); c.add_to(g,"a","10"); c.move("a",g,"20","10")
check("move out of a custom group",(not c.is_member(g,"a","10")) and c.is_member("20","a","10"))
c=Customize(); c.remove_from("10","a","10"); check("remove from provider group",not c.is_member("10","a","10") and c.is_member("10","b","10"))
c=Customize(); g=c.create_group("Mine","c:1"); c.add_to(g,"a","10"); c.ghidden.append(g); c.delete_group("10"); keep=bool(c.custom); c.delete_group(g)
check("delete only own groups",keep and not c.custom and not c.added and g not in c.ghidden)
c=Customize(); g=c.create_group("Mine","c:1"); c.rename_group("10","Sports HD","Sports"); a1=c.group_name("10","Sports")
c.rename_group("10","","Sports"); c.rename_group(g,"Kids","Mine")
check("rename group",a1=="Sports HD" and c.group_name("10","Sports")=="Sports" and c.group_name(g,"Mine")=="Kids")
c=Customize(); n=list("abcd")
r=[c.arrange(n)==n, c.move_group(n,"c",-1), c.arrange(n)==list("acbd"), c.move_group(n,"a",1), c.arrange(n)==list("cabd"),
   not c.move_group(n,"c",-1), not c.move_group(n,"d",1), c.arrange(n+["e"])==list("cabde"), c.arrange(list("acd"))==list("cad")]
check("ordering and moving",all(r)); 
c=Customize(); g=c.create_group("Tab\there\nand \\ slash","c:9"); c.set_hidden("a",True); c.rename("b","Line1\nLine2\tx","B"); c.add_to(g,"a","10")
c.remove_from("10","z","10"); c.ghidden.append("20"); c.rename_group("20","Twenty","20"); c.move_group(["10","20",g],"20",-1)
d=Customize.parse(c.serialize())
check("serialize round trip incl. tabs / newlines / backslashes",d.serialize()==c.serialize() and d.renamed["b"]=="Line1\nLine2\tx" and d.custom[g]=="Tab\there\nand \\ slash" and d.is_member(g,"a","10") and not d.is_member("10","z","10"))
check("garbage input harmless",Customize.parse(None).empty() and Customize.parse("").empty() and Customize.parse("X\tfoo\nH\n\nN\tonly").empty())
# ---- TitleCaseTest
for i,o in [("continue watching","Continue Watching"),("recently added","Recently Added"),("recommended for you","Recommended for You"),
 ("new in action movies","New in Action Movies"),("the lord of the rings","The Lord of the Rings"),("in the mood for","In the Mood For"),
 ("NBA playoffs","NBA Playoffs"),("iPlayer shows","iPlayer Shows"),("UK | sports","UK | Sports"),("sci-fi / fantasy","Sci-Fi / Fantasy"),
 ("news (live)","News (Live)"),("4k movies","4k Movies"),("","")]:
    check("title case: %r -> %r"%(i,o), title(i)==o)
print("\nRESULT:","ALL PASSED" if not fails else "%d FAILED"%fails); sys.exit(1 if fails else 0)
