#!/usr/bin/env python3
"""Runs the GenresTest cases against the REAL taxonomy: the table is parsed out of data/Genres.kt, so a typo there fails here.
python3 tools/genres_check.py"""
import re, sys, os
here=os.path.dirname(__file__)
src=open(os.path.join(here,'..','app/src/main/java/com/sparrow/player/data/Genres.kt')).read()
fails=0
def check(n,c,d=""):
    global fails
    print(("PASS " if c else "FAIL ")+n+("" if c else "  -> "+str(d))); fails+=0 if c else 1
def prep(t):
    return " "+" ".join(re.findall(r"[a-z0-9]+",t.lower()))+" " if re.findall(r"[a-z0-9]+",t.lower()) else " "
strs=lambda s: re.findall(r'"((?:[^"\\]|\\.)*)"',s)
MAIN=[]; cur=None
for line in src.split("\n"):
    t=line.strip()
    m=re.match(r'm\("([^"]+)", "([^"]+)", listOf\((.*?)\),?$',t)
    if m: cur={"id":m[1],"name":m[2],"kw":strs(m[3]),"subs":[]}; MAIN.append(cur); continue
    s=re.match(r'"([^"]+)" to listOf\((.*?)\),?$',t)
    if s and cur is not None: cur["subs"].append((s[1],strs(s[2])))
def has(p,k): return (" %s "%k) in p
def classify(m,text):
    p=prep(text); subs=[i for i,(n,ks) in enumerate(m["subs"]) if any(has(p,k) for k in ks)]
    return (bool(subs) or any(has(p,k) for k in m["kw"])), subs
M={m["id"]:m for m in MAIN}
cls=lambda i,t: classify(M[i],t); names=lambda i,t:[M[i]["subs"][x][0] for x in cls(i,t)[1]]
check("parsed table",len(MAIN)>=20 and sum(len(m["subs"]) for m in MAIN)>=200,(len(MAIN),))
check("unique ids",len({m["id"] for m in MAIN})==len(MAIN))
bad=[k for m in MAIN for k in m["kw"]+[k for _,ks in m["subs"] for k in ks] if prep(k).strip()!=k]
check("every keyword is in normalised form",not bad,bad[:5])
check("every main / sub has keywords",all(m["kw"] and m["subs"] and all(ks for _,ks in m["subs"]) for m in MAIN))
check("normaliser",prep("Sci-Fi & Fantasy")==" sci fi fantasy " and prep("Mother's Day")==" mother s day " and prep("EN | Action  Movies (4K)")==" en action movies 4k ")
check("Action: sub-genres",cls("action","Action")[0] and cls("action","Action & Adventure")[0] and names("action","Action Comedies")==["Action Comedies"]
 and cls("comedies","Action Comedies")[0] and "Action Comedies" in names("comedies","Action Comedies") and "Action Thrillers" in names("action","EN | Action Thriller") and "Martial Arts" in names("action","Martial Arts Movies"),names("action","Action Comedies"))
check("provider style genre text",cls("scifi","Sci-Fi & Fantasy")[0] and cls("family","Kids")[0] and cls("documentaries","Documentary")[0] and cls("dramas","Drama, Crime")[0] and cls("crime","Drama, Crime")[0]
 and cls("horror","EN | Horror Movies")[0] and cls("romance","Romantic Comedy")[0] and names("romance","Romantic Comedy")==["Romantic Comedies"] and names("thrillers","Psychological Thriller")==["Psychological Thrillers"]
 and cls("international","French Movies")[0] and "French Movies" in names("international","French Movies"))
check("unrelated text matches nothing",not any(classify(m,"News | Local Weather")[0] for m in MAIN) and not cls("action","Reaction Videos")[0])
# what a typical panel gives: which genre tabs would a plausible set of categories produce, and how rich are the rows?
cats=["EN | Action","EN | Comedy","EN | Horror","Sci-Fi / Fantasy","Documentaries","Kids","Drama","Thriller","Romance","Christmas Movies","UK | Crime Drama","Action Comedy","FR | Foreign Movies","Animation"]
tabs=[m["name"] for m in MAIN if any(classify(m,c)[0] for c in cats)]
print("   tabs for a sample provider:",", ".join(tabs))
check("sample provider gets the expected main tabs",{"Action & Adventure","Comedies","Horror","Sci-Fi & Fantasy","Documentaries","Children & Family","Dramas","Thrillers","Romance","Crime","International"}<=set(tabs),tabs)
print("\nRESULT:","ALL PASSED" if not fails else "%d FAILED"%fails); sys.exit(1 if fails else 0)
