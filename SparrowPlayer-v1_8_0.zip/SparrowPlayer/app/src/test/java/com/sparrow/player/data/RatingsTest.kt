package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class RatingsTest {
    @Test fun userRatingsToggleAndRoundTrip() {
        val r = UserRatings(); r.toggle("u1", UserRatings.LOVED); r.toggle("u2", UserRatings.DISLIKED)
        assertEquals("loved", r.get("u1")); r.toggle("u1", UserRatings.LOVED); assertEquals("", r.get("u1"))
        r.toggle("u2", UserRatings.LIKED); assertEquals("liked", r.get("u2"))
        val d = UserRatings.parse(r.serialize()); assertEquals("liked", d.get("u2")); assertEquals(1, d.all().size)
        assertTrue(UserRatings.parse("junk\nu\tbogus").all().isEmpty())
    }

    @Test fun providerScoreKeepsOneDecimal() {
        assertEquals(8.0, SparrowRating.providerOf("8"), 0.0); assertEquals(7.3, SparrowRating.providerOf("7.26"), 0.0)
        assertEquals(7.2, SparrowRating.providerOf("7.2"), 0.0); assertEquals(8.7, SparrowRating.providerOf(" 8.7 "), 0.0)
        assertEquals(-1.0, SparrowRating.providerOf(""), 0.0); assertEquals(-1.0, SparrowRating.providerOf("0"), 0.0)
        assertEquals(-1.0, SparrowRating.providerOf("n/a"), 0.0); assertEquals(10.0, SparrowRating.providerOf("11"), 0.0)
    }

    @Test fun formatDropsTheDecimalOnWholeNumbers() {
        assertEquals("7.3", SparrowRating.format(7.3)); assertEquals("8.7", SparrowRating.format(8.7)); assertEquals("9", SparrowRating.format(9.0))
        assertEquals("8.5", SparrowRating.format(8.5)); assertEquals("10", SparrowRating.format(10.0)); assertEquals("", SparrowRating.format(-1.0))
        assertEquals("", SparrowRating.format(0.0)); assertEquals("6", SparrowRating.format(5.96))
    }

    @Test fun sparrowDropDownIsHalfStepsFromHalfToTen() {
        assertEquals(20, SparrowRating.STEPS.size); assertEquals(0.5, SparrowRating.STEPS.first(), 0.0); assertEquals(10.0, SparrowRating.STEPS.last(), 0.0)
        assertTrue(SparrowRating.STEPS.all { (it * 2) % 1.0 == 0.0 })
    }

    @Test fun sparrowScoresAreTheUsersOwnAndSeparateFromLikert() {
        val s = SparrowScores(); assertEquals(-1.0, s.get("u1"), 0.0)
        s.set("u1", 8.5); s.set("u2", 7.3); s.set("u3", 99.0); s.set("u4", 0.1)
        assertEquals(8.5, s.get("u1"), 0.0); assertEquals(7.5, s.get("u2"), 0.0)                       // rounded to a half step
        assertEquals(10.0, s.get("u3"), 0.0); assertEquals(0.5, s.get("u4"), 0.0)                      // clamped
        s.set("u1", 0.0); assertEquals(-1.0, s.get("u1"), 0.0)                                          // Not Rated
        val r = UserRatings(); r.toggle("u2", UserRatings.LOVED)
        assertEquals(7.5, s.get("u2"), 0.0); assertEquals("loved", r.get("u2"))                         // two independent systems
    }

    @Test fun sparrowScoresRoundTripAndIgnoreJunk() {
        val s = SparrowScores(); s.set("u1", 8.5); s.set("u2", 10.0)
        val d = SparrowScores.parse(s.serialize()); assertEquals(8.5, d.get("u1"), 0.0); assertEquals(10.0, d.get("u2"), 0.0)
        val j = SparrowScores.parse("junk\nu\tabc\nu2\t-3\nu3\t7.3"); assertEquals(-1.0, j.get("u"), 0.0); assertEquals(-1.0, j.get("u2"), 0.0); assertEquals(7.5, j.get("u3"), 0.0)
        assertEquals(-1.0, SparrowScores.parse(null).get("x"), 0.0)
    }

    @Test fun metaCacheRoundTripAndMerge() {
        val c = MetaCache(); c.put("u1", 105, "PG-13", "Plot\twith tab\nand newline")
        c.put("u1", -1, "", "")                                                                         // empty update keeps what we know
        val d = MetaCache.parse(c.serialize()); val m = d.get("u1")!!
        assertEquals(105, m.lengthMin); assertEquals("PG-13", m.maturity); assertEquals("Plot\twith tab\nand newline", m.plot)
        assertNull(d.get("nope"))
    }

    @Test fun lengthParsing() {
        assertEquals(105, MetaCache.lengthMinutes("01:45:30")); assertEquals(105, MetaCache.lengthMinutes("105"))
        assertEquals(105, MetaCache.lengthMinutes("1h 45min")); assertEquals(95, MetaCache.lengthMinutes("95 min"))
        assertEquals(105, MetaCache.lengthMinutes("1:45")); assertEquals(-1, MetaCache.lengthMinutes("")); assertEquals(-1, MetaCache.lengthMinutes("n/a"))
    }
}
