package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class RecommenderTest {
    private fun item(uid: String, cat: String, g: String = "", year: Int = 2020, r: Double = 7.0) =
        Recommender.Item(uid, cat, Recommender.genresOf(g), year, r)

    private val pool = listOf(
        item("a1", "action", "action, thriller", 2019, 8.0),
        item("a2", "action", "action", 2021, 6.0),
        item("c1", "comedy", "comedy", 2020, 9.0),
        item("d1", "drama", "drama, crime", 2005, 7.0),
        item("a3", "action", "action, adventure", 2012, 7.5)
    )

    @Test fun parsesGenres() {
        assertEquals(setOf("drama", "crime", "sci-fi"), Recommender.genresOf("Drama, Crime / Sci-Fi"))
        assertTrue(Recommender.genresOf("").isEmpty())
        assertEquals(2019, Recommender.yearOf("2019-05-01")); assertEquals(0, Recommender.yearOf(""))
        assertEquals(10.0, Recommender.ratingOf("12"), 0.0); assertEquals(0.0, Recommender.ratingOf("n/a"), 0.0)
    }

    @Test fun similarTitlesRankFirstAndUnrelatedNever() {
        val seed = item("s", "action", "action, thriller", 2018)
        val l = Recommender.becauseYouWatched(seed, pool, emptySet(), 10).map { it.uid }
        assertEquals("a1", l.first())
        assertFalse("c1" in l); assertFalse("d1" in l)
    }

    @Test fun watchedAreExcluded() {
        val seed = item("s", "action", "action")
        assertFalse("a1" in Recommender.becauseYouWatched(seed, pool, setOf("a1"), 10).map { it.uid })
    }

    @Test fun recentHistoryCountsMore() {
        // newest first: one comedy, then one action -> comedy (1.0) beats action (0.92)
        val p = Recommender.profile(listOf(item("w1", "comedy", "comedy"), item("w2", "action", "action")))
        assertEquals("comedy", Recommender.topKeys(p.categories, 1).first())
        // but two older actions (0.92 + 0.85) outweigh one new comedy
        val q = Recommender.profile(listOf(item("w1", "comedy", "comedy"), item("w2", "action", "action"), item("w3", "action", "action")))
        assertEquals("action", Recommender.topKeys(q.categories, 1).first())
    }

    @Test fun forYouFollowsTheProfile() {
        val p = Recommender.profile(listOf(item("w1", "action", "action"), item("w2", "action", "thriller")))
        val l = Recommender.forYou(p, pool, emptySet(), 10).map { it.uid }
        assertTrue(l.isNotEmpty()); assertTrue(l.all { it.startsWith("a") })
    }

    @Test fun topRatedFilters() {
        assertEquals(listOf("c1", "a1", "a3"), Recommender.topRated(pool, emptySet(), 3).map { it.uid })
        assertTrue(Recommender.topRated(pool, setOf("c1"), 5).none { it.uid == "c1" })
    }

    @Test fun lovedItIsAStrongerSignalThanWatching() {
        val watchedAction = listOf(item("w1", "action", "action"), item("w2", "action", "action"))
        val p = Recommender.profile(watchedAction, listOf(item("l1", "comedy", "comedy") to UserRatings.LOVED))
        assertTrue(p.categories["comedy"]!! > p.categories["action"]!!)                 // one Loved title outweighs two watched ones
        val liked = Recommender.profile(emptyList(), listOf(item("l1", "drama", "drama") to UserRatings.LIKED))
        assertTrue(liked.categories["drama"]!! in 0.5..2.0)                              // Liked is weaker than Loved
    }

    @Test fun dislikedPushesAwayAndIsNeverAFavourite() {
        val p = Recommender.profile(listOf(item("w1", "horror", "horror")), listOf(item("d1", "horror", "horror") to UserRatings.DISLIKED))
        assertTrue(p.categories["horror"]!! < 0.0)
        assertTrue(Recommender.topKeys(p.categories, 3).isEmpty())
        assertEquals(0.0, Recommender.score(p, item("x", "horror", "horror")), 0.0)
        val q = Recommender.profile(listOf(item("w1", "action", "action")), listOf(item("d1", "horror", "horror") to UserRatings.DISLIKED))
        assertTrue(Recommender.score(q, item("a", "action", "action")) > 0.0)           // other taste is unaffected
        assertEquals(0.0, Recommender.score(q, item("h", "horror", "horror")), 0.0)
    }

    @Test fun profileWithoutVerdictsIsUnchanged() {
        val w = listOf(item("w1", "comedy", "comedy"), item("w2", "action", "action"))
        assertEquals(Recommender.profile(w).categories, Recommender.profile(w, emptyList()).categories)
    }
}
