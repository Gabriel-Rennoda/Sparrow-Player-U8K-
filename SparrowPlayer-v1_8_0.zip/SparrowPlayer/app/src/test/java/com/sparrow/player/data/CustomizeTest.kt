package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class CustomizeTest {
    @Test fun hideAndRename() {
        val c = Customize()
        c.setHidden("1:a", true); assertTrue(c.isHidden("1:a")); c.setHidden("1:a", false); assertFalse(c.isHidden("1:a"))
        c.rename("1:a", "  My News ", "News"); assertEquals("My News", c.nameOf("1:a", "News"))
        c.rename("1:a", "News", "News"); assertEquals("News", c.nameOf("1:a", "News"))       // same as original: rename dropped
        assertTrue(c.renamed.isEmpty())
    }

    @Test fun copyKeepsHomeMembership() {
        val c = Customize(); val g = c.createGroup("Mine", "c:1")
        c.copy("1:a", g, "10")
        assertTrue(c.isMember(g, "1:a", "10")); assertTrue(c.isMember("10", "1:a", "10"))
        assertFalse(c.isMember(g, "1:b", "10"))
    }

    @Test fun moveRemovesFromSourceAndAddsToTarget() {
        val c = Customize()
        c.move("1:a", "10", "20", "10")
        assertFalse(c.isMember("10", "1:a", "10")); assertTrue(c.isMember("20", "1:a", "10"))
        c.move("1:a", "20", "10", "10")                                                        // and back home
        assertTrue(c.isMember("10", "1:a", "10")); assertFalse(c.isMember("20", "1:a", "10"))
    }

    @Test fun moveFromCustomGroup() {
        val c = Customize(); val g = c.createGroup("Mine", "c:1")
        c.copy("1:a", g, "10"); c.move("1:a", g, "20", "10")
        assertFalse(c.isMember(g, "1:a", "10")); assertTrue(c.isMember("20", "1:a", "10"))
    }

    @Test fun removeFromProviderGroup() {
        val c = Customize(); c.removeFrom("10", "1:a", "10")
        assertFalse(c.isMember("10", "1:a", "10")); assertTrue(c.isMember("10", "1:b", "10"))
    }

    @Test fun deleteGroupOnlyForOwnGroups() {
        val c = Customize(); val g = c.createGroup("Mine", "c:1"); c.copy("1:a", g, "10"); c.setGroupHidden(g, true)
        c.deleteGroup("10"); assertTrue(c.customGroups.isNotEmpty())
        c.deleteGroup(g)
        assertTrue(c.customGroups.isEmpty()); assertTrue(c.added.isEmpty()); assertFalse(c.isGroupHidden(g))
    }

    @Test fun renameGroup() {
        val c = Customize(); val g = c.createGroup("Mine", "c:1")
        c.renameGroup("10", "Sports HD", "Sports"); assertEquals("Sports HD", c.groupName("10", "Sports"))
        c.renameGroup("10", "", "Sports"); assertEquals("Sports", c.groupName("10", "Sports"))
        c.renameGroup(g, "Kids", "Mine"); assertEquals("Kids", c.groupName(g, "Mine"))
    }

    @Test fun orderingAndMoving() {
        val c = Customize(); val nat = listOf("a", "b", "c", "d")
        assertEquals(nat, c.arrange(nat))
        assertTrue(c.moveGroup(nat, "c", -1)); assertEquals(listOf("a", "c", "b", "d"), c.arrange(nat))
        assertTrue(c.moveGroup(nat, "a", +1)); assertEquals(listOf("c", "a", "b", "d"), c.arrange(nat))
        assertFalse(c.moveGroup(nat, "c", -1)); assertFalse(c.moveGroup(nat, "d", +1))
        assertEquals(listOf("c", "a", "b", "d", "e"), c.arrange(nat + "e"))                    // new group appended
        assertEquals(listOf("c", "a", "d"), c.arrange(listOf("a", "c", "d")))                  // vanished group ignored
    }

    @Test fun serializeRoundTripIncludingAwkwardNames() {
        val c = Customize(); val g = c.createGroup("Tab\there\nand \\ slash", "c:9")
        c.setHidden("1:a", true); c.rename("1:b", "Line1\nLine2\tx", "B"); c.copy("1:a", g, "10"); c.removeFrom("10", "1:z", "10")
        c.setGroupHidden("20", true); c.renameGroup("20", "Twenty", "20"); c.moveGroup(listOf("10", "20", g), "20", -1)
        val d = Customize.parse(c.serialize())
        assertEquals(c.serialize(), d.serialize())
        assertEquals("Line1\nLine2\tx", d.renamed["1:b"]); assertEquals("Tab\there\nand \\ slash", d.customGroups[g])
        assertTrue(d.isHidden("1:a")); assertTrue(d.isMember(g, "1:a", "10")); assertFalse(d.isMember("10", "1:z", "10"))
    }

    @Test fun garbageAndEmptyInputAreHarmless() {
        assertTrue(Customize.parse(null).isEmpty()); assertTrue(Customize.parse("").isEmpty())
        assertTrue(Customize.parse("X\tfoo\nH\n\nN\tonly").isEmpty())
    }

    @Test fun placingGroupsByHand() {
        // "Move": the visible groups were re-ordered; hidden groups (h) keep their slot
        assertEquals(listOf("c", "h", "a", "b"), Customize.reorderVisible(listOf("a", "h", "b", "c"), listOf("c", "a", "b")))
        assertEquals(listOf("a", "b"), Customize.reorderVisible(listOf("a", "b"), listOf("a", "b")))
        val c = Customize(); val nat = listOf("a", "b", "c")
        c.setOrder(Customize.reorderVisible(nat, listOf("c", "b", "a")))
        assertEquals(listOf("c", "b", "a"), c.arrange(nat))
    }
}
