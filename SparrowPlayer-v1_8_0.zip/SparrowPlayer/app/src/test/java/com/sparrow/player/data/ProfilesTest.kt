package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class ProfilesTest {
    @Test fun startsWithOneDefaultProfileThatOwnsOldData() {
        val s = ProfileStore.parse(""); assertEquals(1, s.profiles.size); assertEquals("1", s.profiles[0].id); assertFalse(s.profiles[0].isLocked)
    }

    @Test fun addRenameRemove() {
        val s = ProfileStore.parse(null)
        val a = s.add("  Alex  "); val b = s.add(""); assertEquals("2", a.id); assertEquals("Alex", a.name); assertEquals("Profile 3", b.name)
        s.rename("2", "Alexandra"); assertEquals("Alexandra", s.get("2")!!.name); s.rename("2", "   "); assertEquals("Alexandra", s.get("2")!!.name)
        assertTrue(s.remove("2")); assertEquals(setOf("1", "3"), s.profiles.map { it.id }.toSet())
        assertEquals("4", s.add("New").id)                                                   // ids are never reused while a higher one exists
        s.remove("3"); s.remove("4"); assertFalse(s.remove("1")); assertEquals(1, s.profiles.size)   // the last profile stays
    }

    @Test fun lockIsFourDigitsAndCanBeToggled() {
        val s = ProfileStore.parse(null)
        assertFalse(s.setLock("1", true))                                                    // no PIN yet
        assertFalse(s.setPin("1", "123")); assertFalse(s.setPin("1", "12345")); assertFalse(s.setPin("1", "12a4"))
        assertTrue(s.setPin("1", "0420")); assertFalse(s.get("1")!!.isLocked)                // a PIN alone does not lock
        assertTrue(s.setLock("1", true)); assertTrue(s.get("1")!!.isLocked)
        assertTrue(s.pinMatches("1", "0420")); assertFalse(s.pinMatches("1", "1111"))
        assertTrue(s.setLock("1", false)); assertTrue(s.pinMatches("1", "anything"))        // lock off: no PIN needed
        assertEquals("0420", s.get("1")!!.pin)                                               // ...but the PIN is remembered
        assertTrue(s.setLock("1", true)); assertFalse(s.pinMatches("1", ""))
    }

    @Test fun serializeRoundTripKeepsEverything() {
        val s = ProfileStore.parse(null); s.add("Tab\there"); s.get("2")!!.icon = "file"; s.setPin("2", "9876"); s.setLock("2", true)
        val d = ProfileStore.parse(s.serialize()); assertEquals(s.serialize(), d.serialize())
        assertEquals("Tab\there", d.get("2")!!.name); assertEquals("file", d.get("2")!!.icon); assertTrue(d.get("2")!!.isLocked)
    }

    @Test fun lockWithoutAPinInStoredDataIsIgnored() {
        val d = ProfileStore.parse("5\tKid\tbuiltin:2\t\t1\n"); assertFalse(d.get("5")!!.lockOn)
    }

    @Test fun myListNewestFirstAndToggles() {
        val l = MyList(); assertTrue(l.toggle("a")); assertTrue(l.toggle("b")); assertEquals(listOf("b", "a"), l.all())
        assertFalse(l.toggle("a")); assertFalse(l.contains("a")); assertTrue(l.contains("b"))
        assertEquals(listOf("b"), MyList.parse(l.serialize()).all()); assertTrue(MyList.parse(null).all().isEmpty())
    }
}
