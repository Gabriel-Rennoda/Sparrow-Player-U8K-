package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class FranchisesTest {
    @Test fun keys() {
        assertEquals("toy story", Franchises.keyOf("Toy Story")); assertEquals("toy story", Franchises.keyOf("Toy Story 2")); assertEquals("toy story", Franchises.keyOf("Toy Story 3 (2010)"))
        assertEquals("lord of the", Franchises.keyOf("The Lord of the Rings: The Two Towers")); assertEquals("lord of the", Franchises.keyOf("EN | The Lord of the Rings"))
        assertEquals("mission impossible", Franchises.keyOf("Mission: Impossible - Fallout")); assertEquals("die hard", Franchises.keyOf("Die Hard 2"))
        assertEquals("", Franchises.keyOf("Up")); assertEquals("", Franchises.keyOf("Saw II")); assertEquals("", Franchises.keyOf("It"))
    }

    @Test fun detectsGroupsOfThreeOrMore() {
        val t = listOf("1" to "Toy Story", "2" to "Toy Story 2", "3" to "Toy Story 3", "4" to "Toy Story 4", "5" to "The Matrix", "6" to "Matrix Reloaded",
            "7" to "The Lord of the Rings: The Fellowship of the Ring", "8" to "The Lord of the Rings: The Two Towers", "9" to "The Lord of the Rings: The Return of the King")
        val f = Franchises.detect(t)
        assertEquals(listOf("Toy Story", "The Lord of the Rings"), f.map { it.name }); assertEquals(4, f[0].uids.size); assertEquals(3, f[1].uids.size)
        assertTrue(Franchises.detect(t.take(2)).isEmpty())
    }

    @Test fun nameFallsBackToTheKeyWhenTitlesShareLittle() {
        val f = Franchises.detect(listOf("1" to "Mission: Impossible", "2" to "Mission: Impossible II", "3" to "Mission: Impossible - Fallout"))
        assertEquals("Mission Impossible", f.single().name)
    }
}
