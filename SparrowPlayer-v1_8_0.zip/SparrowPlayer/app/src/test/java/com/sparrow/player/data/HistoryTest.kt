package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class HistoryTest {
    @Test fun roundTrip() {
        val l = listOf(History.Entry("1:m:5", 300L), History.Entry("1:s:9", 200L))
        assertEquals(l, History.parse(History.serialize(l)))
        assertTrue(History.parse(null).isEmpty()); assertTrue(History.parse("junk").isEmpty())
    }
    @Test fun newestFirstNoDuplicates() {
        var l = emptyList<History.Entry>()
        l = History.record(l, "a", 1); l = History.record(l, "b", 2); l = History.record(l, "a", 3)
        assertEquals(listOf("a", "b"), l.map { it.uid }); assertEquals(3L, l.first().ts)
    }
    @Test fun capped() {
        var l = emptyList<History.Entry>()
        for (i in 1..200) l = History.record(l, "u$i", i.toLong())
        assertEquals(History.MAX, l.size); assertEquals("u200", l.first().uid)
    }
}
