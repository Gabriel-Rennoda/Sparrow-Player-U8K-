package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class HomeRowsTest {
    private val now = Holidays.epochDay(2026, 11, 8).toLong() * 86_400_000L + 12 * 3_600_000L
    private val nowSec = now / 1000
    private fun t(i: Int, name: String, cat: String = "Action", genre: String = "", year: Int = 2015, rating: Double = 7.0, ageDays: Int = 500) =
        RowTitle("u$i", name, cat, genre, year, rating, nowSec - ageDays * 86_400L)
    private fun ctx(movies: Boolean = true, finished: List<String> = emptyList(), myList: List<String> = emptyList(), verdicts: Map<String, String> = emptyMap()) =
        RowCtx(now, movies, "Canada", "Sam", finished, myList, verdicts)
    private fun titles(n: Int = 30) = (1..n).map { t(it, "Film $it", "Action", rating = 5.0 + (it % 5), ageDays = it * 20) }
    private fun row(rs: List<RowSpec>, title: String) = rs.firstOrNull { it.title == title }

    @Test fun topTenIsTenTitlesNamedWithTheCountry() {
        val r = row(HomeRows.build(titles(), ctx()), "Top 10 Movies Today in Canada")!!
        assertEquals(10, r.uids.size); assertEquals(10, r.uids.toSet().size)
        assertEquals("Top 10 TV Shows Today in Canada", HomeRows.build(titles(), ctx(movies = false)).first { it.title.startsWith("Top 10") }.title)
    }

    @Test fun topTenChangesFromDayToDayButIsStableWithinADay() {
        val a = HomeRows.build(titles(60), ctx()).first().uids
        assertEquals(a, HomeRows.build(titles(60), ctx()).first().uids)
        val tomorrow = RowCtx(now + 86_400_000L, true, "Canada", "Sam")
        assertNotEquals(a, HomeRows.build(titles(60), tomorrow).first().uids)
    }

    @Test fun smallRowsAreNotShown() {
        val rs = HomeRows.build(titles(4), ctx()); assertNull(row(rs, "Top 10 Movies Today in Canada")); assertNull(row(rs, "Cult Followings"))
    }

    @Test fun myListWatchAgainAndBecauseYouAdded() {
        val all = titles()
        val rs = HomeRows.build(all, ctx(finished = listOf("u3", "u4"), myList = listOf("u9", "u8", "u7"), verdicts = mapOf("u5" to UserRatings.LOVED, "u6" to UserRatings.DISLIKED)))
        assertEquals(listOf("u9", "u8", "u7"), row(rs, "My List")!!.uids)
        assertEquals(setOf("u3", "u4", "u5"), row(rs, "Watch It Again")!!.uids.toSet())
        val because = rs.first { it.title.startsWith("Because You Added") }
        assertEquals("Because You Added Film 9 to Your List", because.title); assertFalse("u9" in because.uids || "u8" in because.uids)
    }

    @Test fun moreLikeUsesTheNewestLikedTitle() {
        val rs = HomeRows.build(titles(), ctx(verdicts = linkedMapOf("u2" to UserRatings.LIKED, "u4" to UserRatings.LIKED)))
        assertTrue(rs.any { it.title == "More Like Film 4" })
    }

    @Test fun platformRowsComeFromCategoryNames() {
        val all = (1..8).map { t(it, "N$it", cat = "NETFLIX Movies", rating = 6.0 + it / 10.0) } + (9..16).map { t(it, "D$it", cat = "Disney+ Hits", rating = 7.0) } +
            (17..20).map { t(it, "H$it", cat = "HBO Classics") }
        val rs = HomeRows.build(all, ctx())
        assertEquals("u8", row(rs, "Popular on Netflix")!!.uids.first())                          // best rated first
        assertEquals(8, row(rs, "Popular on Disney+")!!.uids.size)
        assertNull(row(rs, "Popular on HBO Max"))                                                  // only 4 titles: too few for its own row
        assertEquals(setOf("u17", "u18", "u19", "u20"), row(rs, "Popular on Other Platforms")!!.uids.toSet())
    }

    @Test fun moodAndGenreRows() {
        val all = (1..5).map { t(it, "Rom $it", cat = "Romantic Comedy", rating = 6.0 + it / 10.0) } + (6..10).map { t(it, "Crime $it", cat = "Crime Drama", rating = 8.0) } +
            (11..14).map { t(it, "Space $it", cat = "Sci-Fi", rating = 7.0) } + (15..18).map { t(it, "Kids $it", cat = "Kids", rating = 7.0) }
        val rs = HomeRows.build(all, ctx())
        assertEquals(5, row(rs, "Feel-Good Romantic Comedies")!!.uids.size); assertEquals(5, row(rs, "Dark & Gritty Crime Dramas")!!.uids.size)
        assertNull(row(rs, "Top 10 Kids Titles Today"))                                            // 4 kids titles: not enough for a Top 10
        assertNull(row(rs, "Mind-Bending Sci-Fi"))                                                 // no title says "mind", "twist", "dream" ...
    }

    @Test fun seriesGetBingeRowsAndMoviesGetCollections() {
        val series = (1..5).map { t(it, "Show $it", cat = "Comedy Series", rating = 7.0) }
        assertNotNull(row(HomeRows.build(series, ctx(movies = false)), "30-Minute Laughs")); assertNull(row(HomeRows.build(series, ctx(movies = true)), "30-Minute Laughs"))
        val films = listOf("Toy Story", "Toy Story 2", "Toy Story 3").mapIndexed { i, n -> t(i + 1, n, year = 1995 + i * 4) }
        val rs = HomeRows.build(films, ctx())
        assertEquals(listOf("u1", "u2", "u3"), row(rs, "The Toy Story Collection")!!.uids); assertNotNull(row(rs, "Trilogies"))
    }

    @Test fun holidayTopTenAndPage() {
        val xmas = (1..14).map { t(it, "Christmas Tale $it", cat = "Holiday", rating = 5.0 + it / 5.0, year = if (it < 3) 1960 else 2015) }
        val other = (20..30).map { t(it, "Plain $it") }
        val all = xmas + other
        val top = HomeRows.holidayTop10(Holidays.CHRISTMAS, all, now); assertEquals(10, top.size); assertTrue(top.all { it.removePrefix("u").toInt() <= 14 })
        val page = HomeRows.holiday(Holidays.CHRISTMAS, all, ctx(myList = listOf("u5", "u99")), listOf("u2", "u3")) { if (it.uid == "u7") 2.0 else 0.0 }
        // exactly the five carousels of the holiday page (My Holiday Favourites is a group of its own now, Popular on Other Platforms is gone)
        assertEquals(listOf("What's Hot", "Continue Watching for Sam", "Top Picks for Sam", "Holiday Classics", "Cult Followings"), page.map { it.title })
        assertEquals(14, page.first().uids.size)                                                   // What's Hot: ALL the holiday's titles
        assertEquals(listOf("u2", "u3"), page.first { it.title == "Continue Watching for Sam" }.uids)
        assertEquals(listOf("u7"), page.first { it.title == "Top Picks for Sam" }.uids)
        assertEquals(setOf("u1", "u2"), page.first { it.title == "Holiday Classics" }.uids.toSet())
    }

    @Test fun holidayPageIsNeverEmptyWithoutTasteOrTags() {
        val all = (1..6).map { t(it, "Santa Story $it", cat = "Movies", rating = 5.0 + it, year = 1990 + it) }
        val page = HomeRows.holiday(Holidays.CHRISTMAS, all, ctx(), emptyList()) { 0.0 }            // new profile: no taste, nothing in progress
        assertEquals(6, page.first { it.title == "Top Picks for Sam" }.uids.size)                  // falls back to the best rated
        assertEquals("u6", page.first { it.title == "Top Picks for Sam" }.uids.first())
        assertTrue(page.any { it.title == "Holiday Classics" }); assertTrue(page.any { it.title == "Cult Followings" })
        assertTrue(page.none { it.title == "Continue Watching for Sam" })
    }

    @Test fun holidayMaskComesFromTheCatalogueWhenSet() {
        val a = t(1, "Quiet Film"); a.holidays = Holidays.bit(Holidays.EASTER)                      // e.g. found in its description
        assertEquals(listOf("u1"), HomeRows.holidayPool(Holidays.EASTER, listOf(a, t(2, "Other"))).map { it.uid })
        assertTrue(HomeRows.holidayPool(Holidays.CHRISTMAS, listOf(a)).isEmpty())
    }

    @Test fun kidsTopTenSkipsAdultCartoons() {
        val kids = (1..6).map { t(it, "Kid Show $it", cat = "Kids", genre = "Kids", rating = 7.0) }
        val adult = (7..12).map { t(it, "Rick And Morty $it", cat = "Animation", genre = "Animation, Comedy", rating = 9.0) }
        val r = row(HomeRows.build(kids + adult, ctx(movies = false)), "Top 10 Kids Titles Today")!!
        assertEquals(kids.map { it.uid }.toSet(), r.uids.toSet())
    }
}
