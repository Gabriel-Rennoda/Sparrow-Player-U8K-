package com.sparrow.player.ui.player

import org.junit.Assert.*
import org.junit.Test

class FirstPressGateTest {
    private val ok = FirstPressGate.DPAD_CENTER; private val back = FirstPressGate.BACK; private val up = FirstPressGate.DPAD_UP

    @Test fun firstPressOnlyWakesControls() {
        val g = FirstPressGate()
        assertTrue(g.swallow(ok, true, 0, false))      // hidden: swallowed
        assertTrue(g.swallow(ok, false, 0, false))     // its release too
        assertFalse(g.swallow(ok, true, 0, true))      // visible: normal
        assertFalse(g.swallow(ok, false, 0, true))
    }

    @Test fun heldKeyIsOnePress() {
        val g = FirstPressGate()
        assertTrue(g.swallow(up, true, 0, false))
        assertTrue(g.swallow(up, true, 1, false)); assertTrue(g.swallow(up, true, 2, true))   // repeats stay swallowed
        assertTrue(g.swallow(up, false, 0, true))
        assertFalse(g.swallow(up, true, 0, true))
    }

    @Test fun backNeedsTwoPresses() {
        val g = FirstPressGate()
        assertTrue(g.swallow(back, true, 0, false)); g.swallow(back, false, 0, false)
        assertFalse(g.swallow(back, true, 0, true))    // second press (controls still up) goes through
    }

    @Test fun otherKeysAreNotGated() {
        for (k in listOf(85, 126, 127, 89, 90, 82, 7, 8, 9, 165)) assertFalse(FirstPressGate.isGated(k))
        for (k in listOf(19, 20, 21, 22, 23, 66, 4, 166, 167)) assertTrue(FirstPressGate.isGated(k))
    }
}
