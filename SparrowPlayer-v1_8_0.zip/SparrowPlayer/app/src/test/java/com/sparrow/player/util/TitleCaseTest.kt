package com.sparrow.player.util

import org.junit.Assert.assertEquals
import org.junit.Test

class TitleCaseTest {
    @Test fun capitalisesLowerCaseWords() {
        assertEquals("Continue Watching", TitleCase.of("continue watching"))
        assertEquals("Recently Added", TitleCase.of("recently added"))
    }
    @Test fun smallWordsStayLowerInTheMiddle() {
        assertEquals("Recommended for You", TitleCase.of("recommended for you"))
        assertEquals("New in Action Movies", TitleCase.of("new in action movies"))
        assertEquals("The Lord of the Rings", TitleCase.of("the lord of the rings"))
    }
    @Test fun firstAndLastWordAlwaysCapitalised() { assertEquals("In the Mood For", TitleCase.of("in the mood for")) }
    @Test fun wordsWithCapitalsAreLeftAlone() {
        assertEquals("NBA Playoffs", TitleCase.of("NBA playoffs"))
        assertEquals("iPlayer Shows", TitleCase.of("iPlayer shows"))
        assertEquals("UK | Sports", TitleCase.of("UK | sports"))
    }
    @Test fun hyphensSlashesAndBrackets() {
        assertEquals("Sci-Fi / Fantasy", TitleCase.of("sci-fi / fantasy"))
        assertEquals("News (Live)", TitleCase.of("news (live)"))
    }
    @Test fun digitsAndBlanks() { assertEquals("4k Movies", TitleCase.of("4k movies")); assertEquals("", TitleCase.of("")) }
}
