package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class HolidayMaskTest {
    private val texts = listOf(
        "A Christmas Story (1983)", "EN | Home for XMAS", "Eastern Promises", "The Polar Express", "Santa Claus Is Comin To Town", "x mas movie",
        "Thanksgiving Day Parade", "Plain Title", "Easter Parade Halloween Hocus Pocus", "North Pole Express", "Jingle All The Way", "My Valentine", "", "   ", "Chrismas Eve"
    )

    @Test fun maskAgreesWithTheKeywordSearchForEveryHoliday() {
        for (t in texts) {
            val p = TextNorm.prepare(t); val mask = Holidays.maskOf(p)
            for (h in Holidays.ALL) assertEquals(t + " / " + h.id, Holidays.matchesPrepared(h, p), mask and Holidays.bit(h) != 0)
        }
    }

    @Test fun descriptionsIgnoreAmbiguousWords() {
        val p = TextNorm.prepare("He orders a pumpkin latte, then Santa Monica. On Christmas Eve ...")
        assertEquals(Holidays.bit(Holidays.CHRISTMAS), Holidays.maskOf(p, plot = true))
        assertTrue(Holidays.maskOf(p) and Holidays.bit(Holidays.HALLOWEEN) != 0)                    // in a title the same word counts
    }

    @Test fun christmasKeywordsNowCatchHolidayCategoriesAndClassics() {
        for (t in listOf("The Holiday", "Home Alone", "It's A Wonderful Life", "Miracle on 34th Street", "Love Actually", "Holiday Movies"))
            assertTrue(t, Holidays.maskOf(TextNorm.prepare(t)) and Holidays.bit(Holidays.CHRISTMAS) != 0)
    }
}
