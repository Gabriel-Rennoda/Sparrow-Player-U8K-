package com.sparrow.player.ui.epg

import com.sparrow.player.data.Programme
import org.junit.Assert.*
import org.junit.Test

class GuideMathTest {
    private val H = 3600_000L
    private val M = 60_000L
    private fun t(h: Int, m: Int) = h * H + m * M            // UTC day 0; offset 0 in every call below
    private fun base(h: Int, m: Int) = GuideMath.baseStart(t(h, m), 0)
    private fun prog(s: Long, e: Long, title: String = "p") = Programme(providerId = 1, epgId = "x", start = s, stop = e, title = title, descr = "")

    @Test fun windowStartsAtCurrentHalfHour() {
        assertEquals(t(4, 30), base(4, 30))
        assertEquals(t(4, 30), base(4, 50))
        assertEquals(t(4, 0), base(4, 0))
        assertEquals(t(4, 30), base(4, 59))
        assertEquals(t(4, 0), base(4, 29))
    }

    @Test fun windowSpansTwoHours() = assertEquals(t(6, 30), GuideMath.windowEnd(t(4, 30)))

    @Test fun multiBlockProgrammeIsOneContinuousBlock() {
        val ws = t(4, 30); val we = GuideMath.windowEnd(ws)
        val segs = GuideMath.segments(listOf(prog(t(4, 0), t(5, 30), "A"), prog(t(5, 30), t(8, 0), "B")), ws, we)
        assertEquals(2, segs.size)
        assertEquals(ws, segs[0].start); assertEquals(t(5, 30), segs[0].stop)
        assertEquals(t(5, 30), segs[1].start); assertEquals(we, segs[1].stop)      // clipped to the window end
    }

    @Test fun rowWithoutDataIsOneSelectableNoInformationBlock() {
        val ws = t(4, 30)
        val segs = GuideMath.segments(emptyList(), ws, GuideMath.windowEnd(ws))
        assertEquals(1, segs.size); assertNull(segs[0].prog)
    }

    @Test fun gapsAreFilled() {
        val ws = t(4, 30)
        val segs = GuideMath.segments(listOf(prog(t(5, 0), t(5, 30))), ws, GuideMath.windowEnd(ws))
        assertEquals(listOf(null, "p", null), segs.map { it.prog?.title })
        assertEquals(GuideMath.windowEnd(ws), segs.last().stop)
    }

    // ---- free browsing into the future; never into the past ------------------------------------------------
    private val b0 = t(10, 0)
    private fun all(vararg p: Programme) = GuideMath.segments(p.toList(), b0, b0 + GuideMath.FUTURE)

    @Test fun neverGoesBeforeCurrentHalfHour() {
        assertEquals(b0, GuideMath.minStart(b0))
        val a = all(prog(b0 - H, b0 + H, "A"), prog(b0 + H, b0 + 2 * H, "B"))
        assertEquals(b0, a[0].start)                                           // the running programme is clipped to "now"
        assertNull(GuideMath.moveHorizontal(a, b0, b0, b0, -1))            // LEFT at now: nothing (side panels open)
    }

    @Test fun rightScrollsTheWindowIntoTheFuture() {
        val a = all(prog(b0, b0 + 3 * H, "A"), prog(b0 + 3 * H, b0 + 4 * H, "B"))
        var ws = b0; var sel = b0
        val m1 = GuideMath.moveHorizontal(a, ws, b0, sel, +1)!!
        assertEquals(b0 + 3 * H, m1.selTime)                                   // B starts beyond the 2 h window
        assertEquals(b0 + 3 * H - GuideMath.HALF, m1.windowStart)             // ... so it is scrolled in, starting in column 2
        ws = m1.windowStart; sel = m1.selTime
        val back = GuideMath.moveHorizontal(a, ws, b0, sel, -1)!!
        assertEquals(b0, back.selTime); assertEquals(b0, back.windowStart)  // LEFT returns to the current half hour and stops
    }

    @Test fun longLastBlockScrollsInsteadOfJumping() {
        val a = all(prog(b0, b0 + GuideMath.FUTURE, "Movie"))      // one block for the whole range
        val m = GuideMath.moveHorizontal(a, b0, b0, b0, +1)!!
        assertEquals(b0 + GuideMath.HALF, m.windowStart)
        val l = GuideMath.moveHorizontal(a, m.windowStart, b0, m.selTime, -1)!!
        assertEquals(b0, l.windowStart)
        assertNull(GuideMath.moveHorizontal(a, b0, b0, l.selTime, -1))
    }

    @Test fun emptyRowCanBeBrowsedToo() {
        val a = all()                                                            // one "No information" block for the whole range
        val m = GuideMath.moveHorizontal(a, b0, b0, b0, +1)!!
        assertEquals(b0 + GuideMath.HALF, m.windowStart)
    }

    @Test fun windowNeverPassesTheData() {
        val a = all()
        val ws = GuideMath.maxStart(b0)
        assertNull(GuideMath.moveHorizontal(a, ws, b0, ws, +1))
    }

    @Test fun visibleBlockDoesNotMoveTheWindow() {
        assertEquals(b0, GuideMath.ensureVisible(b0, b0, b0 + H, b0 + H + GuideMath.HALF))
        assertEquals(b0, GuideMath.ensureVisible(b0, b0, b0 + 3 * H / 2, b0 + 2 * H))   // 30 min block in the last column
    }
}
