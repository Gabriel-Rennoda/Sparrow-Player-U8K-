package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class ResumeTest {
    @Test fun resumesThirtySecondsBefore() {
        assertEquals(570_000L, Resume.resumeAt(600_000))
        assertEquals(0L, Resume.resumeAt(20_000))
        assertEquals(0L, Resume.resumeAt(Resume.FINISHED))
    }
    @Test fun storesNearEndAsFinished() {
        assertEquals(Resume.FINISHED, Resume.toStore(7_000_000, 7_100_000))
        assertEquals(1_000_000L, Resume.toStore(1_000_000, 7_100_000))
        assertEquals(0L, Resume.toStore(0, 7_100_000))
        assertEquals(0L, Resume.toStore(500, -1))
    }
    @Test fun progressLabel() { assertTrue(Resume.hasProgress(60_000)); assertFalse(Resume.hasProgress(10_000)) }

    @Test fun watchedAfterFortyPercent() {
        val d = 100 * 60_000L
        assertFalse(Resume.countsAsWatched(39 * 60_000L, d))
        assertTrue(Resume.countsAsWatched(40 * 60_000L, d))
        assertTrue(Resume.countsAsWatched(Resume.FINISHED, d))
        assertFalse(Resume.countsAsWatched(10 * 60_000L, 0)); assertFalse(Resume.countsAsWatched(0, d))
    }
}
