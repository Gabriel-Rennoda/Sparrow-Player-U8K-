package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class GenresTest {
    private fun m(id: String) = Genres.mainOf(id)!!
    private fun cls(id: String, text: String) = Genres.classify(m(id), TextNorm.prepare(text))
    private fun subNames(id: String, text: String) = cls(id, text).subs.map { m(id).subs[it].name }

    @Test fun normaliserTurnsPunctuationIntoSingleSpaces() {
        assertEquals(" sci fi fantasy ", TextNorm.prepare("Sci-Fi & Fantasy"))
        assertEquals(" mother s day ", TextNorm.prepare("Mother's Day"))
        assertEquals(" en action movies 4k ", TextNorm.prepare("EN | Action  Movies (4K)"))
    }

    @Test fun mainGenresAreUniqueAndWellFormed() {
        assertEquals(Genres.MAIN.size, Genres.MAIN.map { it.id }.toSet().size)
        for (g in Genres.MAIN) {
            assertTrue(g.keywords.isNotEmpty()); assertTrue(g.subs.isNotEmpty())
            (g.keywords + g.subs.flatMap { it.keywords }).forEach { k -> assertEquals("keyword not normalised: $k", k, TextNorm.prepare(k).trim()) }
        }
    }

    @Test fun actionWithSubGenres() {
        assertTrue(cls("action", "Action").inMain); assertTrue(cls("action", "Action & Adventure").inMain)
        assertEquals(listOf("Action Comedies"), subNames("action", "Action Comedies"))
        assertTrue(cls("comedies", "Action Comedies").inMain); assertTrue("Action Comedies" in subNames("comedies", "Action Comedies"))
        assertTrue("Action Thrillers" in subNames("action", "EN | Action Thriller")); assertTrue("Martial Arts" in subNames("action", "Martial Arts Movies"))
    }

    @Test fun providerStyleGenreText() {
        assertTrue(cls("scifi", "Sci-Fi & Fantasy").inMain); assertTrue(cls("family", "Kids").inMain)
        assertTrue(cls("documentaries", "Documentary").inMain)
        assertTrue(cls("dramas", "Drama, Crime").inMain); assertTrue(cls("crime", "Drama, Crime").inMain)
        assertTrue(cls("horror", "EN | Horror Movies").inMain); assertTrue(cls("romance", "Romantic Comedy").inMain)
        assertEquals(listOf("Romantic Comedies"), subNames("romance", "Romantic Comedy"))
        assertEquals(listOf("Psychological Thrillers"), subNames("thrillers", "Psychological Thriller"))
        assertTrue(cls("international", "French Movies").inMain); assertTrue("French Movies" in subNames("international", "French Movies"))
    }

    @Test fun unrelatedTextMatchesNothing() {
        for (g in Genres.MAIN) assertFalse(g.name, Genres.classify(g, TextNorm.prepare("News | Local Weather")).inMain)
        assertFalse(cls("action", "Reaction Videos").inMain)                      // whole words only
    }

    @Test fun mainOfFindsByIdAndNullOtherwise() { assertEquals("Comedies", Genres.mainOf("comedies")?.name); assertNull(Genres.mainOf("nope")) }
}
