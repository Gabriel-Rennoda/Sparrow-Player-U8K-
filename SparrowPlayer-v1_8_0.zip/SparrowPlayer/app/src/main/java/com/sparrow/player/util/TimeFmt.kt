package com.sparrow.player.util

import java.util.Calendar
import java.util.Locale

/** Pure (java.util only) clock / date formatting so it can be unit tested on the JVM. */
object TimeFmt {
    /** Set from Settings (and at app start). false = 12 hour clock. */
    @Volatile var is24h = false

    private val DAYS = arrayOf("Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat")
    private val MONTHS = arrayOf("Jan.", "Feb.", "Mar.", "Apr.", "May", "Jun.", "Jul.", "Aug.", "Sep.", "Oct.", "Nov.", "Dec.")

    private fun two(n: Int) = String.format(Locale.US, "%02d", n)

    /** "1:15 am" / "13:15". Written by hand so the locale can never turn am/pm into "a.m." or "AM". */
    fun clock(ms: Long, h24: Boolean = is24h): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val h = c.get(Calendar.HOUR_OF_DAY); val m = c.get(Calendar.MINUTE)
        if (h24) return two(h) + ":" + two(m)
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "$h12:${two(m)} ${if (h < 12) "am" else "pm"}"
    }

    /** Playback position: "1:12:04" or "12:04". */
    fun position(ms: Long): String {
        val t = (ms.coerceAtLeast(0) / 1000)
        val h = t / 3600; val m = (t % 3600) / 60; val sec = t % 60
        return if (h > 0) "$h:${two(m.toInt())}:${two(sec.toInt())}" else "$m:${two(sec.toInt())}"
    }

    /** Time still to watch: "53 min left" / "1 h 5 min left". */
    fun left(ms: Long): String {
        val m = ((ms.coerceAtLeast(0) + 59_999) / 60_000).toInt()
        return if (m >= 60) "${m / 60} h ${m % 60} min left" else "$m min left"
    }

    /** "Thurs, Nov. 05" (corner of the guide header, above the clock). */
    fun guideDate(ms: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return "${DAYS[c.get(Calendar.DAY_OF_WEEK) - 1]}, ${MONTHS[c.get(Calendar.MONTH)]} ${two(c.get(Calendar.DAY_OF_MONTH))}"
    }

    /** "Thurs, Nov. 05     -    1:15 am". */
    fun guideHeader(ms: Long, h24: Boolean = is24h): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return "${DAYS[c.get(Calendar.DAY_OF_WEEK) - 1]}, ${MONTHS[c.get(Calendar.MONTH)]} ${two(c.get(Calendar.DAY_OF_MONTH))}" +
            "     -    " + clock(ms, h24)
    }
}
