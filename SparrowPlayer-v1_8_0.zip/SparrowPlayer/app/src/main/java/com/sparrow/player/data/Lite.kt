package com.sparrow.player.data

/** The columns the Movies / Series screens and search need for EVERY title (no plot, no stream url): ~100 000 of these stay in memory. Not an entity. */
data class VodLite(
    val uid: String, val categoryId: String, val name: String, val poster: String,
    val rating: String, val year: String, val added: Long, val genre: String
)

/** uid + plot, read once to find holiday words in descriptions (the plot itself is not kept). */
data class UidPlot(val uid: String, val plot: String)
