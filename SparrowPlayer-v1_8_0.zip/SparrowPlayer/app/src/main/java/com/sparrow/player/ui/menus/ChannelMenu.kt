package com.sparrow.player.ui.menus

import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Repository
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * The pop-up that opens when OK is held on a channel in the guide: every option for that one channel.
 *
 *  Play · Add To / Remove From Favourites · Hide / Unhide · Copy To Group (or a brand-new group) · Move To Group (asks Yes / No first)
 *  · Remove From This Group · Edit Channel Name · Restore Original Name
 *
 * Hiding does not make the channel vanish at once: the guide keeps showing it (dimmed, marked Hidden) until the user leaves the
 * list, so a mistaken Hide can be undone from this same menu. All edits are saved per provider (see Customize) and survive syncs.
 */
object ChannelMenu {
    class Hooks(
        val play: (Channel) -> Unit,
        val toggleFavorite: (Channel) -> Unit,
        /** The channel was hidden / unhidden. The guide keeps it on screen (marked) until the next reload. */
        val hiddenChanged: (Channel, Boolean) -> Unit,
        /** The channel got another name. */
        val renamed: (Channel) -> Unit,
        /** The channel now belongs to other groups (copy / move / remove): reload the list around it. */
        val membershipChanged: (Channel) -> Unit
    )

    fun show(a: FragmentActivity, c: Channel, scope: String, h: Hooks) {
        val repo = a.applicationContext.repo
        val pid = c.providerId
        val cu = repo.custom(pid)
        val inGroup = scope != Repository.SCOPE_ALL && scope != Repository.SCOPE_FAV
        val hidden = cu.isHidden(c.uid)
        val renamed = cu.renamed.containsKey(c.uid)

        val p = Popup(a, c.name, "Channel Options")
        p.row("Play Channel") { h.play(c) }
        p.row(if (c.isFavorite) "Remove From Favourites" else "Add To Favourites") { h.toggleFavorite(c) }
        p.row(if (hidden) "Unhide Channel" else "Hide Channel") {
            cu.setHidden(c.uid, !hidden); repo.saveCustom(pid)
            h.hiddenChanged(c, !hidden)
            toast(a, if (hidden) "Channel unhidden" else "Channel hidden – open this menu again to unhide it")
        }
        p.row("Copy To Group…") { pickGroup(a, c, scope, copy = true, h = h) }
        p.row("Move To Group…") { pickGroup(a, c, scope, copy = false, h = h) }
        if (inGroup) p.row("Remove From This Group…") {
            Popup.confirm(a, "Remove From Group?", "Remove \"${c.name}\" from this group? It stays in All Channels and in its other groups.", "Yes, Remove") {
                cu.removeFrom(scope, c.uid, c.categoryId); repo.saveCustom(pid)
                h.membershipChanged(c); toast(a, "Removed from group")
            }
        }
        val isOpening = repo.prefs.openChannel == c.uid
        p.row(if (isOpening) "Clear Opening Channel" else "Set As Opening Channel") {
            repo.prefs.openChannel = if (isOpening) "" else c.uid
            toast(a, if (isOpening) "Opening channel cleared – the app opens on the last channel" else "${c.name} is now the opening channel")
        }
        p.row("Edit Channel Name…") {
            a.lifecycleScope.launch {
                val original = repo.dao.channel(c.uid)?.name ?: c.name
                Popup.ask(a, "Edit Channel Name", "Channel name", c.name) { n ->
                    cu.rename(c.uid, n, original); repo.saveCustom(pid)
                    h.renamed(c.copy(name = cu.nameOf(c.uid, original))); toast(a, "Name saved")
                }
            }
        }
        if (renamed) p.row("Restore Original Name") {
            a.lifecycleScope.launch {
                val original = repo.dao.channel(c.uid)?.name ?: c.name
                cu.renamed.remove(c.uid); repo.saveCustom(pid)
                h.renamed(c.copy(name = original)); toast(a, "Original name restored")
            }
        }
        p.show()
    }

    /** Copy / Move: choose the target group. Copy can also create a new one; Move only goes to existing groups and asks first. */
    private fun pickGroup(a: FragmentActivity, c: Channel, scope: String, copy: Boolean, h: Hooks) {
        a.lifecycleScope.launch {
            val repo = a.applicationContext.repo
            val pid = c.providerId
            val cu = repo.custom(pid)
            val groups = repo.groups(pid)
            val inGroup = scope != Repository.SCOPE_ALL && scope != Repository.SCOPE_FAV
            // "current group" of the channel: the group being viewed, else its own provider group, else a group it was copied to
            val from: String? = when {
                inGroup -> scope
                cu.isMember(c.categoryId, c.uid, c.categoryId) -> c.categoryId
                else -> cu.extraGroupsOf(c.uid).firstOrNull()
            }
            val fromName = groups.firstOrNull { it.id == from }?.name ?: "its current group"
            val targets = groups.filter { g -> if (copy) !cu.isMember(g.id, c.uid, c.categoryId) else g.id != from }

            val p = Popup(a, if (copy) "Copy To Group" else "Move To Group", c.name)
            if (copy) p.row("＋  New Group…") {
                Popup.ask(a, "New Group", "Group name", "") { name ->
                    val gid = cu.createGroup(name)
                    cu.copy(c.uid, gid, c.categoryId); repo.saveCustom(pid)
                    h.membershipChanged(c); toast(a, "Added to new group \"${cu.groupName(gid, name)}\"")
                }
            }
            if (!copy && from == null) p.note("This channel is not in a group that it can be moved out of.")
            else for (g in targets) p.row(g.name + if (g.hidden) "  (Hidden)" else "") {
                if (copy) {
                    cu.copy(c.uid, g.id, c.categoryId); repo.saveCustom(pid)
                    h.membershipChanged(c); toast(a, "Copied to ${g.name}")
                } else {
                    Popup.confirm(a, "Move Channel?", "Move \"${c.name}\" from $fromName to ${g.name}? It will be removed from $fromName.", "Yes, Move") {
                        cu.move(c.uid, from!!, g.id, c.categoryId); repo.saveCustom(pid)
                        h.membershipChanged(c); toast(a, "Moved to ${g.name}")
                    }
                }
            }
            if (targets.isEmpty() && !(copy)) p.note("There is no other group to move this channel to.")
            if (targets.isEmpty() && copy) p.note("It is already in every group. Create a new one above.")
            p.show()
        }
    }

    private fun toast(a: FragmentActivity, msg: String) = Toast.makeText(a, msg, Toast.LENGTH_SHORT).show()
}
