package com.sparrow.player.ui.profiles

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import com.sparrow.player.R
import com.sparrow.player.data.Profile
import java.io.File

/** Profile pictures: 12 supplied avatars (an emoji on a coloured circle, the last one is the Sparrow logo) or a custom picture saved per profile. */
object ProfileIcons {
    class Avatar(val name: String, val emoji: String, val color: Int)

    val AVATARS = listOf(
        Avatar("Fox", "🦊", 0xFFE67E22.toInt()), Avatar("Panda", "🐼", 0xFF5D6D7E.toInt()), Avatar("Owl", "🦉", 0xFF8E6E53.toInt()),
        Avatar("Lion", "🦁", 0xFFD4A017.toInt()), Avatar("Frog", "🐸", 0xFF27AE60.toInt()), Avatar("Cat", "🐱", 0xFFAF7AC5.toInt()),
        Avatar("Dog", "🐶", 0xFF2E86C1.toInt()), Avatar("Rocket", "🚀", 0xFFC0392B.toInt()), Avatar("Star", "⭐", 0xFF7D3C98.toInt()),
        Avatar("Robot", "🤖", 0xFF16A085.toInt()), Avatar("Dragon", "🐲", 0xFF117A65.toInt()), Avatar("Sparrow", "", 0xFF1B2631.toInt())
    )

    fun file(ctx: Context, id: String) = File(ctx.filesDir, "profile_$id.png")

    fun avatarIndex(icon: String): Int = icon.removePrefix("builtin:").toIntOrNull()?.coerceIn(0, AVATARS.size - 1) ?: 0

    /** A round picture of [p], [size] px wide. */
    fun bitmap(ctx: Context, p: Profile, size: Int): Bitmap {
        if (p.icon == "file") {
            val f = file(ctx, p.id)
            if (f.exists()) BitmapFactory.decodeFile(f.path)?.let { return circle(it, size) }
        }
        val a = AVATARS[avatarIndex(p.icon)]
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = a.color }
        c.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        if (a.emoji.isEmpty()) {
            BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_circle)?.let { logo ->
                val pad = (size * 0.12f).toInt()
                c.drawBitmap(logo, Rect(0, 0, logo.width, logo.height), Rect(pad, pad, size - pad, size - pad), Paint(Paint.FILTER_BITMAP_FLAG))
            }
        } else {
            paint.textSize = size * 0.55f; paint.textAlign = Paint.Align.CENTER
            c.drawText(a.emoji, size / 2f, size / 2f - (paint.ascent() + paint.descent()) / 2f, paint)
        }
        return out
    }

    /** Centre-crop to a square and cut to a circle. */
    private fun circle(src: Bitmap, size: Int): Bitmap {
        val side = minOf(src.width, src.height)
        val sq = Rect((src.width - side) / 2, (src.height - side) / 2, (src.width + side) / 2, (src.height + side) / 2)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawCircle(size / 2f, size / 2f, size / 2f, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(src, sq, Rect(0, 0, size, size), p)
        return out
    }

    /** Save a picked / downloaded picture as the profile's icon (256 px, centre-cropped square). */
    fun saveCustom(ctx: Context, id: String, src: Bitmap) {
        val side = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(sq, 256, 256, true)
        file(ctx, id).outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun deleteCustom(ctx: Context, id: String) { file(ctx, id).delete() }
}
