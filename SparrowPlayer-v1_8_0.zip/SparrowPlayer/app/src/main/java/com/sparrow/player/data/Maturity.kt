package com.sparrow.player.data

/**
 * Age ratings for the "Children & Family" genre. IPTV lists carry NO age rating, so this is evidence based and says so:
 *
 *  1. A rating the panel told us (remembered when a details page was opened, see [MetaCache]) is trusted: only TV-Y, TV-G, G, TV-PG, PG and PG-13 pass.
 *     TV-14, TV-MA, R and NC-17 never do (TV-14 is kept out on purpose: Rick and Morty is TV-14).
 *  2. A rating written in the title or category ("[TV-MA]") counts the same way.
 *  3. Words that say "not for children" in the category / genre (adult, mature, 18+, horror, crime, thriller ...) or a well-known adult cartoon
 *     in the title keep it out.
 *  4. What is left needs a reason to be here: kids / family / children / Disney ... in its category or genre. A film that is only "animation"
 *     is let through; a SERIES that is only "animation" waits until its rating is known (adult cartoons are mostly series).
 * Pure Kotlin, unit tested.
 */
object Maturity {
    val FAMILY_OK = setOf("TV-Y", "TV-G", "G", "TV-PG", "PG", "PG-13")

    fun familyOk(code: String) = code in FAMILY_OK

    /** Rating code for an age number from a panel (\"16\", \"18+\"); "" when it is not one. */
    fun fromAge(n: Int): String = when {
        n >= 18 -> "TV-MA"; n >= 16 -> "R"; n >= 14 -> "TV-14"; n >= 13 -> "PG-13"; n >= 10 -> "TV-PG"; n >= 1 -> "TV-Y"; else -> ""
    }

    /** "PG-13", "TV-MA", "Rated R", "16", "18+" -> a code of [MediaTags.MATURITIES]; "" if it says nothing. */
    fun normalize(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return ""
        val m = MediaTags.maturity(s)
        if (m.isNotEmpty()) return m
        if (s.length <= 4 && s.all { it.isDigit() || it == '+' }) return fromAge(s.filter { it.isDigit() }.toIntOrNull() ?: 0)
        return ""
    }

    private val STRONG = listOf("kids", "kid", "children", "childrens", "family", "families", "disney", "pixar", "junior", "toddler", "toddlers",
        "preschool", "nick jr", "nickelodeon", "baby")
    private val UNSAFE = listOf("adult", "adults", "mature", "erotic", "xxx", "18", "tv ma", "tv 14", "nc 17", "uncut", "uncensored", "explicit",
        "after dark", "adult swim", "horror", "crime", "true crime", "thriller", "thrillers", "slasher", "zombie", "zombies", "gangster", "mafia", "war")

    /** Well-known cartoons / films for adults, in [TextNorm] form (title starts with one of them). */
    private val ADULT_TITLES = listOf(
        "rick and morty", "rick morty", "bojack horseman", "beavis and butt head", "beavis butt head", "south park", "family guy", "american dad",
        "the cleveland show", "archer", "big mouth", "bob s burgers", "harley quinn", "invincible", "castlevania", "hazbin hotel", "helluva boss",
        "the boondocks", "solar opposites", "disenchantment", "final space", "paradise pd", "robot chicken", "aqua teen hunger force", "metalocalypse",
        "futurama", "king of the hill", "love death and robots", "undone", "arcane", "blue eye samurai", "the legend of vox machina", "primal",
        "sausage party", "team america", "central park", "bless the harts", "the great north", "duncanville", "bordertown", "tuca and bertie",
        "attack on titan", "death note", "hit monkey", "close enough", "king star king", "ren and stimpy adult party cartoon", "drawn together"
    ).map { " $it " }

    fun isAdultTitle(nameNorm: String) = ADULT_TITLES.any { nameNorm.startsWith(it) }

    /**
     * May this title (already in the Children & Family genre) stay there? [known]: a rating the panel gave ("" = unknown),
     * [rawName] / [category] / [genre] as the panel wrote them, [nameNorm] / [prepared] their [TextNorm] forms (prepared = genre + category).
     */
    fun familyOk(known: String, rawName: String, category: String, nameNorm: String, prepared: String, series: Boolean): Boolean {
        if (known.isNotEmpty()) return familyOk(known)
        val tag = MediaTags.maturity("$rawName $category")
        if (tag.isNotEmpty()) return familyOk(tag)
        if (TextNorm.hasAny(prepared, UNSAFE)) return false
        if (isAdultTitle(nameNorm)) return false
        if (TextNorm.hasAny(prepared, STRONG)) return true
        return !series
    }

    fun familyOk(t: RowTitle, known: String, series: Boolean): Boolean =
        familyOk(known, t.name, t.category, t.nameNorm, t.prepared, series)
}
