package com.sparrow.player.data

import androidx.room.migration.Migration

/**
 * Room migrations, oldest first. Version 1 is the schema shipped since v1.0 - it has not changed.
 * When an @Entity changes: bump AppDb.version, add `object : Migration(old, new) { override fun migrate(db: SupportSQLiteDatabase) {...} }`
 * here (ALTER TABLE ... ADD COLUMN ..., keeping every existing row, especially `providers`), and add it to ALL.
 */
object Migrations {
    val ALL: Array<Migration> = emptyArray()
}
