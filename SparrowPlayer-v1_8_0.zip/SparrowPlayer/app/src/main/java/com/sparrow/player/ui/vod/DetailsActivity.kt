package com.sparrow.player.ui.vod

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.sparrow.player.R
import com.sparrow.player.data.Episode
import com.sparrow.player.data.Resume
import com.sparrow.player.data.MetaCache
import com.sparrow.player.data.SparrowRating
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.data.UserRatings
import com.sparrow.player.data.VodItem
import com.sparrow.player.data.str
import com.sparrow.player.databinding.ActivityDetailsBinding
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.TimeFmt
import com.sparrow.player.util.TextAdapter
import com.sparrow.player.util.loadUrl
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

class DetailsActivity : FragmentActivity() {
    private lateinit var b: ActivityDetailsBinding
    private var episodes: List<Episode> = emptyList()
    private var shown: List<Episode> = emptyList()          // episodes of the season on screen
    private var episodeAdapter: TextAdapter<Episode>? = null
    private var item: VodItem? = null
    private var seriesMeta = ""
    private var seriesPlot = ""
    private var seriesBackdrop = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(b.root)
        Theme.applyAll(this, b.root)
        val uid = intent.getStringExtra("uid") ?: return finish()
        val repo = applicationContext.repo
        b.seasonList.itemAnimator = null
        b.episodeList.itemAnimator = null

        lifecycleScope.launch {
            repo.activeProvider()
            val v = repo.dao.vod(uid) ?: return@launch finish()
            item = v
            b.title.text = v.name
            b.poster.loadUrl(v.poster)
            // A real backdrop only. (For movies the list's "backdrop" is just the poster: showing it first and swapping in the real one a
            // moment later was the poster flashing before the background.) A movie waits for the panel's info; a series has nothing more
            // to wait for, so the poster stands in at once if there is no backdrop.
            val real = v.backdrop.takeIf { it.isNotBlank() && it != v.poster } ?: ""
            seriesBackdrop = real.ifBlank { if (v.type == "movie") "" else v.poster }
            if (seriesBackdrop.isNotBlank()) b.backdrop.load(seriesBackdrop)
            seriesMeta = metaOf(v.year, v.rating, v.genre)
            seriesPlot = v.plot
            b.meta.text = seriesMeta
            b.plot.text = seriesPlot
            setupRating(v)

            if (v.type == "movie") {
                b.seasonList.visibility = View.GONE; b.episodeList.visibility = View.GONE
                refreshPlayLabel()
                b.playBtn.setOnClickListener {
                    val m = item ?: return@setOnClickListener
                    startActivity(PlayerActivity.vod(this@DetailsActivity, repo.movieUrl(m), m.name, m.uid, m.uid))
                }
                b.playBtn.requestFocus()
                val info = repo.vodInfo(v)   // enrich with plot / backdrop when the panel provides it
                info.str("plot").ifBlank { info.str("description") }.takeIf { p -> p.isNotBlank() }?.let { p -> b.plot.text = p }
                val infoBackdrop = (info["backdrop_path"] as? List<*>)?.firstOrNull()?.toString()?.takeIf { u -> u.isNotBlank() }
                if (infoBackdrop != null) { seriesBackdrop = infoBackdrop; b.backdrop.load(infoBackdrop) }
                else if (seriesBackdrop.isBlank() && v.poster.isNotBlank()) { seriesBackdrop = v.poster; b.backdrop.load(v.poster) }   // no backdrop anywhere: poster
                b.meta.text = metaOf(v.year.ifBlank { info.str("releasedate").take(4) }, v.rating,
                    v.genre.ifBlank { info.str("genre") }, info.str("duration"))
                // remember what the panel told us, so search can filter on length / maturity / plot
                val mpaa = listOf("mpaa_rating", "mpaa", "age", "rating_mpaa", "certification").map { k -> info.str(k) }.firstOrNull { m -> m.isNotBlank() } ?: ""
                repo.remember(v.uid, MetaCache.lengthMinutes(info.str("duration")), mpaa, info.str("plot").ifBlank { info.str("description") })
            } else {
                setupSeries(v)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Back from the player: refresh the "watched" markers / Resume label in place (no animations, focus is kept).
        episodeAdapter?.let { a -> a.notifyItemRangeChanged(0, a.itemCount) }
        if (item != null) refreshPlayLabel()
    }

    private suspend fun setupSeries(it: VodItem) {
        val repo = applicationContext.repo
        val adapter = TextAdapter<Episode>(
            { e -> episodeLabel(e) },
            { e -> playEpisode(e) },                               // ONE press of OK plays that episode
            { e, _ -> showEpisodeInfo(e) }                         // browsing shows the episode's info on top
        )
        episodeAdapter = adapter
        b.episodeList.layoutManager = LinearLayoutManager(this)
        b.episodeList.adapter = adapter
        episodes = try { repo.seriesEpisodes(it) } catch (e: Exception) { emptyList() }
        if (episodes.isEmpty()) { b.plot.text = it.plot.ifBlank { "No episodes found." }; b.playBtn.requestFocus(); return }
        // typical episode length for the search "Length" filter
        episodes.firstNotNullOfOrNull { e -> MetaCache.lengthMinutes(e.duration).takeIf { m -> m > 0 } }?.let { m -> repo.remember(it.uid, m, "", it.plot) }

        val seasons = episodes.map { e -> e.season }.distinct().sorted()
        val seasonAdapter = TextAdapter<Int>({ s -> "Season $s" }, { s -> showSeason(s) }, { s, _ -> showSeason(s) }, R.layout.item_tab)
        b.seasonList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.seasonList.adapter = seasonAdapter
        seasonAdapter.submit(seasons, 0)
        showSeason(seasons.first())
        refreshPlayLabel()
        b.playBtn.setOnClickListener { continueTarget()?.let { e -> playEpisode(e) } }
        b.playBtn.requestFocus()
    }

    /** Loved It / Liked It / Disliked It: press again to remove. */
    private fun setupRating(v: VodItem) {
        val uid = v.uid
        val repo = applicationContext.repo
        val buttons = listOf(b.loveBtn to UserRatings.LOVED, b.likeBtn to UserRatings.LIKED, b.dislikeBtn to UserRatings.DISLIKED)
        val base = mapOf(UserRatings.LOVED to "♥  Loved It", UserRatings.LIKED to "👍  Liked It", UserRatings.DISLIKED to "👎  Disliked It")
        fun paint() {
            val mine = repo.myRating(uid)
            buttons.forEach { (btn, code) -> btn.text = (if (mine == code) "✓  " else "") + base[code] }
            val sp = repo.sparrowOf(v)
            b.sparrowBtn.text = "Sparrow Rating: " + (if (sp > 0) SparrowRating.format(sp) else "Not Rated") + "  ▾"
            // the two star ratings stay where they are on the poster: provider top left, Sparrow (my own) top right
            b.poster.setRatings(repo.providerRatingOf(v), sp)
        }
        paint()
        buttons.forEach { (btn, code) -> btn.setOnClickListener { repo.rate(uid, code); paint() } }
        // My List: titles saved by hand (feeds the My List and "Because You Added" rows)
        fun paintList() { b.myListBtn.text = if (repo.inMyList(uid)) "✓  In My List" else "＋  My List" }
        paintList()
        b.myListBtn.setOnClickListener { repo.toggleMyList(uid); paintList() }
        // My Holiday Favourites: its own group in Movies / Series (titles the user saved by hand)
        fun paintHoliday() { b.holidayFavBtn.text = if (repo.inHolidayFavs(uid)) "✓  My Holiday Favourites" else "＋  My Holiday Favourites" }
        paintHoliday()
        b.holidayFavBtn.setOnClickListener { repo.toggleHolidayFav(uid); paintHoliday() }
        // Sparrow Rating: my own 0.5 - 10 rating, a drop down in half steps ("Not Rated" clears it)
        b.sparrowBtn.setOnClickListener {
            val labels = listOf("Not Rated") + SparrowRating.STEPS.map { SparrowRating.format(it) }
            val cur = repo.sparrowOf(v)
            val idx = if (cur <= 0) 0 else SparrowRating.STEPS.indexOf(cur) + 1
            Popup.choose(this, "Sparrow Rating", labels, idx) { i -> repo.setSparrow(uid, if (i == 0) 0.0 else SparrowRating.STEPS[i - 1]); paint() }
        }
    }

    private fun showSeason(s: Int) {
        shown = episodes.filter { it.season == s }
        episodeAdapter?.submit(shown)
    }

    private fun episodeLabel(e: Episode): String {
        val saved = applicationContext.repo.prefs.position("ep:${e.id}")
        val mark = when { saved == Resume.FINISHED -> "   ✓"; Resume.hasProgress(saved) -> "   ▶ resume"; else -> "" }
        return "E${e.num}   ${e.title}$mark"
    }

    /** Top info section: details of the focused episode (falls back to the series text for anything missing). */
    private fun showEpisodeInfo(e: Episode) {
        b.epTitle.text = "S${e.season} E${e.num}   ${e.title}"
        b.epTitle.visibility = View.VISIBLE
        val m = metaOf(e.duration.takeIf { it != "00:00:00" } ?: "", e.released, e.rating.takeIf { it != "0" } ?: "")
        b.meta.text = m.ifBlank { seriesMeta }
        b.plot.text = e.plot.ifBlank { seriesPlot }
        showProgress(applicationContext.repo.prefs.percent("ep:${e.id}"))
        if (e.image.isNotBlank()) b.backdrop.load(e.image)
    }

    /** Which episode the Play button continues: the last one watched (or the next one if it was finished). */
    private fun continueTarget(): Episode? {
        val it = item ?: return null
        if (episodes.isEmpty()) return null
        val prefs = applicationContext.repo.prefs
        val last = prefs.lastEpisode(it.uid)
        val i = episodes.indexOfFirst { e -> e.id == last }
        if (i < 0) return episodes.first()
        return if (prefs.position("ep:${episodes[i].id}") == Resume.FINISHED) episodes.getOrNull(i + 1) ?: episodes[i] else episodes[i]
    }

    private fun showProgress(percent: Int) {
        b.watchProgress.visibility = if (percent > 0) View.VISIBLE else View.GONE
        b.watchProgress.progress = percent
    }

    /** To the right of the Resume button: where playback will pick up and how much is left. Hidden when there is nothing to resume. */
    private fun setResumeInfo(key: String?) {
        val prefs = applicationContext.repo.prefs
        val pos = if (key == null) 0L else prefs.position(key)
        if (key == null || !Resume.hasProgress(pos)) { b.resumeInfo.visibility = View.GONE; return }
        val start = Resume.resumeAt(pos)
        val dur = prefs.duration(key)
        var t = "Resumes at " + TimeFmt.position(start)
        if (dur > start) t += "   •   " + TimeFmt.left(dur - start)
        b.resumeInfo.text = t
        b.resumeInfo.visibility = View.VISIBLE
    }

    private fun refreshPlayLabel() {
        val it = item ?: return
        val prefs = applicationContext.repo.prefs
        setResumeInfo(if (it.type == "movie") it.uid else continueTarget()?.let { e -> "ep:${e.id}" })
        if (it.type == "movie") showProgress(prefs.percent(it.uid))
        else showProgress(continueTarget()?.let { e -> prefs.percent("ep:${e.id}") } ?: 0)
        if (it.type == "movie") {
            b.playBtn.text = if (Resume.hasProgress(prefs.position(it.uid))) "▶  Resume" else "▶  Play"
        } else {
            val e = continueTarget()
            val started = e != null && prefs.lastEpisode(it.uid).isNotBlank()
            b.playBtn.text = if (started && e != null) "▶  Resume S${e.season} E${e.num}" else "▶  Play"
        }
    }

    private fun playEpisode(e: Episode) {
        val it = item ?: return
        val repo = applicationContext.repo
        repo.prefs.setLastEpisode(it.uid, e.id)
        startActivity(PlayerActivity.vod(this, repo.episodeUrl(e), "${it.name} · S${e.season}E${e.num}  ${e.title}", "ep:${e.id}", it.uid))
    }

    private fun metaOf(vararg parts: String) = parts.filter { it.isNotBlank() && it != "0" }.joinToString("   •   ")

    companion object {
        fun intent(ctx: Context, uid: String) = Intent(ctx, DetailsActivity::class.java).putExtra("uid", uid)
    }
}
