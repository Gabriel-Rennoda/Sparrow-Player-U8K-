package com.sparrow.player.data

/**
 * Watch history: which movies / series the user actually watched, newest first. Stored as one preference string
 * (one "uid<TAB>timestamp" per line) so it needs no database change - a schema bump would wipe the providers
 * (the database uses destructive migration). Pure Kotlin, unit tested.
 */
object History {
    const val MAX = 150

    data class Entry(val uid: String, val ts: Long)

    fun parse(s: String?): List<Entry> {
        if (s.isNullOrBlank()) return emptyList()
        return s.lineSequence().mapNotNull { line ->
            val i = line.indexOf('\t')
            if (i <= 0) null else line.substring(i + 1).trim().toLongOrNull()?.let { Entry(line.substring(0, i), it) }
        }.toList()
    }

    fun serialize(l: List<Entry>): String = l.joinToString("\n") { it.uid + "\t" + it.ts }

    /** [uid] moves to the front (newest) and the list is capped at [MAX]. */
    fun record(l: List<Entry>, uid: String, ts: Long): List<Entry> =
        (listOf(Entry(uid, ts)) + l.filter { it.uid != uid }).take(MAX)
}
