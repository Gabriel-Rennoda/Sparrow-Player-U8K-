package com.sparrow.player.data

/** One distinct (category, genre text) pair of a provider's movies / series; there are only a few hundred, so genre tabs are cheap to work out. */
data class CatGenre(val categoryId: String, val genre: String)
