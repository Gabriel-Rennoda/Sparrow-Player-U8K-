package com.sparrow.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.sparrow.player.util.StartupLauncher
import com.sparrow.player.util.repo

/** Starts Sparrow Player after the device boots, if "Open On Device Start-Up / Wake-Up" is on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (context.applicationContext.repo.prefs.startOnBoot) StartupLauncher.launch(context.applicationContext)
    }
}
