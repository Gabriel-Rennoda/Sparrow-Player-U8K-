package com.sparrow.player.ui.vod

import android.view.ViewGroup
import androidx.leanback.widget.Presenter
import com.sparrow.player.data.VodItem
import com.sparrow.player.util.repo

/** Poster card (2:3) in the Netflix / Disney+ manner; see [PosterCard] for the focus effect. */
class CardPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(PosterCard(parent.context))

    override fun onBindViewHolder(vh: ViewHolder, item: Any?) {
        val v = item as? VodItem ?: return
        val card = vh.view as PosterCard
        val repo = card.context.repo
        // the ratings are on the poster itself (top left: provider, top right: Sparrow), so the line below only needs the year
        card.bind(v.name, v.year, v.poster, repo.prefs.vodPercent(v), repo.providerRatingOf(v), repo.sparrowOf(v))
    }

    override fun onUnbindViewHolder(vh: ViewHolder) { (vh.view as PosterCard).clear() }

    companion object {
        fun ratingText(v: VodItem): String {
            val r = v.rating.toDoubleOrNull() ?: return ""
            return if (r > 0) "★ " + String.format("%.1f", r) else ""
        }
    }
}
