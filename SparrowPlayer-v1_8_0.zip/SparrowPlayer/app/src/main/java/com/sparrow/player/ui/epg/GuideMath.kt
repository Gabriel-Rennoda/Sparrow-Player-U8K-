package com.sparrow.player.ui.epg

import com.sparrow.player.data.Programme
import java.util.TimeZone

/** Pure guide-grid maths (no Android) so it is unit tested: window start, programme blocks, browsing into the future. */
object GuideMath {
    const val HALF = 30 * 60_000L
    const val SPAN = 4                       // visible half-hour columns = 2 hours
    const val PAST = 0L                      // the guide never goes before the current half hour
    const val FUTURE = 36 * 3600_000L        // ... and may be browsed this far ahead

    /** Start of the current half hour in LOCAL time: 4:00->4:00, 4:29->4:00, 4:30->4:30, 4:50->4:30, 4:59->4:30. */
    fun baseStart(now: Long, offsetMs: Long = TimeZone.getDefault().getOffset(now).toLong()): Long =
        Math.floorDiv(now + offsetMs, HALF) * HALF - offsetMs

    fun windowEnd(ws: Long) = ws + SPAN * HALF
    fun minStart(base: Long) = base - PAST
    fun maxStart(base: Long) = base + FUTURE - SPAN * HALF

    /** [t] rounded down to a half-hour boundary on the grid that starts at [base]. */
    fun alignDown(t: Long, base: Long): Long = base + Math.floorDiv(t - base, HALF) * HALF

    /**
     * Where the window must start so that the block [start, stop) is on screen: unchanged if it already is; scrolled left
     * (never before [base]) when the block starts before the window; scrolled right when it starts beyond the window or
     * in the last column but runs on, so that it begins in the second column.
     */
    fun ensureVisible(ws: Long, base: Long, start: Long, stop: Long): Long {
        val we = windowEnd(ws)
        val target = when {
            start < ws -> alignDown(start, base)
            start >= we || (start >= we - HALF && stop > we) -> alignDown(start, base) - HALF
            else -> ws
        }
        return target.coerceIn(minStart(base), maxStart(base))
    }

    /** Result of a LEFT / RIGHT press: the new window start and the new selection time (start of the selected block). */
    class Move(val windowStart: Long, val selTime: Long)

    /**
     * LEFT / RIGHT over a row cut into blocks for the WHOLE browsable range ([all] = segments(progs, base, base + FUTURE)).
     * Moves to the neighbouring block and scrolls the window as needed. null = nothing to do (left edge at the current half
     * hour: the caller opens the side panels; or the end of the data).
     * When there is no further block (the selected one is the last and longer than the window) the selection stays and the window
     * scrolls by one half hour instead.
     */
    fun moveHorizontal(all: List<Seg>, ws: Long, base: Long, selTime: Long, dir: Int): Move? {
        val cur = indexAt(all, selTime)
        val i = cur + dir
        if (i in all.indices) {
            val s = all[i]
            return Move(ensureVisible(ws, base, s.start, s.stop), s.start)
        }
        val nw = (ws + dir * HALF).coerceIn(minStart(base), maxStart(base))
        val c = all[cur]
        val more = if (dir > 0) c.stop > windowEnd(ws) else ws > base
        return if (more && nw != ws) Move(nw, selTime.coerceIn(nw, windowEnd(nw) - 1)) else null
    }

    /** One block of a row. start/stop are VISUAL (clipped to the window, never overlapping). prog == null: no information. */
    class Seg(val start: Long, val stop: Long, val prog: Programme?)

    /**
     * Cuts a row into blocks that exactly tile [ws, we). A programme that spans several half hours is ONE block;
     * gaps (and rows with no data at all) become selectable "No information" blocks, so the guide can never dead-end.
     */
    fun segments(progs: List<Programme>, ws: Long, we: Long): List<Seg> {
        val out = ArrayList<Seg>()
        var cursor = ws
        for (p in progs) {
            if (p.stop <= cursor) continue
            if (p.start >= we) break
            if (p.start > cursor) out += Seg(cursor, p.start, null)
            val end = minOf(p.stop, we)
            out += Seg(maxOf(p.start, cursor), end, p)
            cursor = end
            if (cursor >= we) break
        }
        if (cursor < we) out += Seg(cursor, we, null)
        return out
    }

    fun indexAt(segs: List<Seg>, t: Long): Int {
        val i = segs.indexOfFirst { t >= it.start && t < it.stop }
        return if (i >= 0) i else if (t < segs.first().start) 0 else segs.lastIndex
    }
}
