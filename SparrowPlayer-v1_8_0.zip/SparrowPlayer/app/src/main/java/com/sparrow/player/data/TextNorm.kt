package com.sparrow.player.data

/**
 * Text prepared for whole-word keyword matching (holidays, genres): lower case, every run of anything that is not a letter or digit
 * (spaces, "&", "-", "/", "|", apostrophes ...) becomes ONE space, with a space at both ends. "Sci-Fi & Fantasy" -> " sci fi fantasy ",
 * "Mother's Day" -> " mother s day ". Keywords are written in that same form and tested as " keyword ".
 */
object TextNorm {
    fun prepare(text: String): String {
        val sb = StringBuilder(text.length + 2).append(' ')
        var lastSpace = true
        for (ch in text.lowercase()) {
            if (ch.isLetterOrDigit()) { sb.append(ch); lastSpace = false }
            else if (!lastSpace) { sb.append(' '); lastSpace = true }
        }
        if (!lastSpace) sb.append(' ')
        return sb.toString()
    }

    fun has(prepared: String, keyword: String): Boolean = prepared.contains(" $keyword ")

    fun hasAny(prepared: String, keywords: List<String>): Boolean = keywords.any { prepared.contains(" $it ") }
}
