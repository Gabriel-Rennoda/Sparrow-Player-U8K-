package com.sparrow.player.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout

/**
 * FrameLayout whose width is derived from its height so the inside (height minus padding) is always 16:9.
 * The parent decides the height (a share of the screen), so the player scales with any screen size / density.
 */
class RatioFrameLayout @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : FrameLayout(ctx, attrs) {
    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val h = MeasureSpec.getSize(heightSpec)
        val w = ((h - paddingTop - paddingBottom) * 16f / 9f).toInt() + paddingLeft + paddingRight
        super.onMeasure(
            MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
        )
    }
}
