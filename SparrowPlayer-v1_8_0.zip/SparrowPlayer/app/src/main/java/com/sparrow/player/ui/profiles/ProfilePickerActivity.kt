package com.sparrow.player.ui.profiles

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import com.sparrow.player.data.Profile
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp
import com.sparrow.player.util.repo

/** "Who's Watching?" - shown once per launch when there is more than one profile. A locked profile asks for its PIN. */
class ProfilePickerActivity : FragmentActivity() {
    private lateinit var row: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        root.addView(TextView(this).apply { text = "Who's Watching?"; textSize = 34f; tag = "t:text"; gravity = Gravity.CENTER; setTypeface(typeface, android.graphics.Typeface.BOLD) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(36) })
        row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        Theme.applyAll(this, root)
        build()
    }

    private fun build() {
        row.removeAllViews()
        val repo = applicationContext.repo
        val store = repo.profileStore()
        val active = repo.activeProfile().id
        var focus: android.view.View? = null
        for (p in store.profiles) {
            val t = tile(ProfileIcons.bitmap(this, p, dp(120)), p.name + if (p.isLocked) "  🔒" else "") { choose(p) }
            if (p.id == active) focus = t
            row.addView(t)
        }
        row.addView(tile(null, "＋ Add Profile") {
            Popup.ask(this, "New Profile", "Profile name", "", "Create") { n -> repo.profileStore().add(n); repo.saveProfiles(); build() }
        })
        (focus ?: row.getChildAt(0)).requestFocus()
    }

    private fun tile(icon: android.graphics.Bitmap?, name: String, go: () -> Unit): android.view.View {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; tag = "bg:item"
            setPadding(dp(18), dp(16), dp(18), dp(14)); isFocusable = true; isClickable = true
            setOnClickListener { go() }
        }
        val img = ImageView(this)
        if (icon != null) img.setImageBitmap(icon)
        else img.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Theme.surface2) }.also { img.setImageResource(com.sparrow.player.R.drawable.ic_nav_settings) }
        v.addView(img, LinearLayout.LayoutParams(dp(120), dp(120)))
        v.addView(TextView(this).apply { text = name; textSize = 19f; tag = "t:item"; gravity = Gravity.CENTER; isDuplicateParentStateEnabled = true; setSingleLine(true); setPadding(0, dp(10), 0, 0) },
            LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.WRAP_CONTENT))
        Theme.applyTree(v)
        v.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(10), 0, dp(10), 0) }
        return v
    }

    private fun choose(p: Profile) {
        val repo = applicationContext.repo
        val go = { repo.switchProfile(p.id); repo.profileConfirmed = true
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)); finish() }
        if (!p.isLocked) go()
        else PinDialog.show(this, "Enter PIN", p.name) { pin ->
            if (repo.profileStore().pinMatches(p.id, pin)) go() else android.widget.Toast.makeText(this, "Wrong PIN", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}
