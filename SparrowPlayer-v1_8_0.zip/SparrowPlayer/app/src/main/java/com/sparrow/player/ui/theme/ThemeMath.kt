package com.sparrow.player.ui.theme

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Pure colour maths (no android.* imports, so JUnit can run it on the JVM). Colours are ARGB ints.
 * Contrast ratios are WCAG 2.x: 4.5 is the "easy to read" bar for normal text.
 */
object ThemeMath {
    const val WHITE = 0xFFFFFFFF.toInt()
    const val BLACK = 0xFF000000.toInt()
    /** Near-black used for text on light colours. */
    const val INK = 0xFF0B0F14.toInt()

    fun red(c: Int) = (c shr 16) and 0xFF
    fun green(c: Int) = (c shr 8) and 0xFF
    fun blue(c: Int) = c and 0xFF

    fun rgb(r: Int, g: Int, b: Int): Int =
        (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    private fun lin(v: Int): Double {
        val c = v / 255.0
        return if (c <= 0.03928) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)
    }

    fun luminance(c: Int): Double = 0.2126 * lin(red(c)) + 0.7152 * lin(green(c)) + 0.0722 * lin(blue(c))

    fun contrast(a: Int, b: Int): Double {
        val la = luminance(a); val lb = luminance(b)
        return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)
    }

    fun minContrast(c: Int, against: List<Int>): Double = against.minOf { contrast(c, it) }

    /** t = 0 -> a, t = 1 -> b (alpha is ignored, result is opaque). */
    fun mix(a: Int, b: Int, t: Double): Int = rgb(
        (red(a) + (red(b) - red(a)) * t).roundToInt(),
        (green(a) + (green(b) - green(a)) * t).roundToInt(),
        (blue(a) + (blue(b) - blue(a)) * t).roundToInt()
    )

    /** h in degrees, s and v in 0..1. */
    fun hsv(h: Double, s: Double, v: Double): Int {
        val hh = ((h % 360.0) + 360.0) % 360.0
        val ss = s.coerceIn(0.0, 1.0); val vv = v.coerceIn(0.0, 1.0)
        val c = vv * ss
        val x = c * (1 - abs((hh / 60.0) % 2 - 1))
        val m = vv - c
        val r: Double; val g: Double; val b: Double
        when {
            hh < 60 -> { r = c; g = x; b = 0.0 }
            hh < 120 -> { r = x; g = c; b = 0.0 }
            hh < 180 -> { r = 0.0; g = c; b = x }
            hh < 240 -> { r = 0.0; g = x; b = c }
            hh < 300 -> { r = x; g = 0.0; b = c }
            else -> { r = c; g = 0.0; b = x }
        }
        return rgb(((r + m) * 255).roundToInt(), ((g + m) * 255).roundToInt(), ((b + m) * 255).roundToInt())
    }

    /** Returns [h (0..360), s (0..1), v (0..1)]. */
    fun toHsv(c: Int): DoubleArray {
        val r = red(c) / 255.0; val g = green(c) / 255.0; val b = blue(c) / 255.0
        val mx = max(r, max(g, b)); val mn = min(r, min(g, b)); val d = mx - mn
        var h = when {
            d == 0.0 -> 0.0
            mx == r -> 60 * (((g - b) / d) % 6)
            mx == g -> 60 * ((b - r) / d + 2)
            else -> 60 * ((r - g) / d + 4)
        }
        if (h < 0) h += 360.0
        val s = if (mx == 0.0) 0.0 else d / mx
        return doubleArrayOf(h, s, mx)
    }

    /** White or near-black, whichever reads better on [bg]. */
    fun bestOn(bg: Int): Int = if (contrast(WHITE, bg) >= contrast(INK, bg)) WHITE else INK

    /**
     * Moves [c] toward white (when [against] is mostly dark) or black (when mostly light) until its contrast with
     * every colour in [against] is at least [ratio]. Returns [c] unchanged if it already passes.
     */
    fun ensureContrast(c: Int, against: List<Int>, ratio: Double): Int {
        if (minContrast(c, against) >= ratio) return c
        val avg = against.map { luminance(it) }.average()
        val target = if (avg < 0.4) WHITE else BLACK
        var t = 0.0
        var out = c
        while (t < 1.0) {
            t = min(1.0, t + 0.04)
            out = mix(c, target, t)
            if (minContrast(out, against) >= ratio) return out
        }
        return out
    }

    fun hex(c: Int): String = String.format("%08X", c)
}
