package com.sparrow.player.ui.profiles

import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Profile
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.util.repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request

/**
 * Settings -> General -> Profiles: switch, add, rename, change icon, lock on / off with a 4-digit PIN, delete.
 * A locked profile asks for its PIN before it can be opened, unlocked, re-coded or deleted.
 */
object ProfileMenus {
    /** [pickImage]: opens the device's picture chooser for the profile id (result handled by the caller via [saveFromUri]). */
    fun show(a: FragmentActivity, pickImage: (String) -> Unit) {
        val repo = a.applicationContext.repo
        val store = repo.profileStore()
        val active = repo.activeProfile().id
        val p = Popup(a, "Profiles", "Each Profile Has Its Own Watch History, Ratings And My List")
        for (pr in store.profiles) p.row(pr.name + if (pr.isLocked) "  🔒" else "", if (pr.id == active) "Active  ✓" else "") { actions(a, pr.id, pickImage) }
        p.row("＋  Add Profile…") {
            Popup.ask(a, "New Profile", "Profile name", "", "Create", onCancel = { show(a, pickImage) }) { n ->
                val np = store.add(n); repo.saveProfiles(); Toast.makeText(a, "Profile ${np.name} created", Toast.LENGTH_SHORT).show()
                show(a, pickImage)
            }
        }
        p.show()
    }

    private fun actions(a: FragmentActivity, id: String, pickImage: (String) -> Unit) {
        val repo = a.applicationContext.repo
        val store = repo.profileStore()
        val pr = store.get(id) ?: return
        val isActive = repo.activeProfile().id == id
        // Every change made from this window (confirmed OR cancelled) comes back to it.
        val again: () -> Unit = { actions(a, id, pickImage) }
        val p = Popup(a, pr.name, if (isActive) "Active Profile" else "Profile")
        p.onBack { show(a, pickImage) }                           // Back on a profile's window = the list of profiles
        if (!isActive) p.row("Switch To This Profile") { whenUnlocked(a, id, again) { switchTo(a, id) } }
        p.row("Edit Name…") {
            whenUnlocked(a, id, again) {
                Popup.ask(a, "Profile Name", "Profile name", pr.name, onCancel = again) { n -> store.rename(id, n); repo.saveProfiles(); again() }
            }
        }
        p.row("Change Icon…") { icons(a, id, pickImage, again) }
        p.row("Profile Lock", if (pr.isLocked) "On" else "Off", keepOpen = true) { r ->
            if (pr.isLocked) PinDialog.show(a, "Enter PIN To Unlock", pr.name) { pin ->
                if (store.pinMatches(id, pin)) { store.setLock(id, false); repo.saveProfiles(); r.setValue("Off") } else wrong(a)
            } else setNewPin(a, id, { ok -> if (ok) r.setValue("On") }, { })
        }
        if (pr.pin.length == Profile.PIN_LENGTH) p.row("Change PIN…") {
            whenUnlocked(a, id, again) { setNewPin(a, id, { again() }, again) }
        }
        if (store.profiles.size > 1) p.row("Delete Profile…") {
            whenUnlocked(a, id, again) {
                Popup.confirm(a, "Delete ${pr.name}?", "Its watch history, ratings and My List stay on this device but the profile is removed.", "Yes, Delete", onNo = again) {
                    store.remove(id); ProfileIcons.deleteCustom(a, id); repo.saveProfiles()
                    if (isActive) { repo.switchProfile(store.profiles.first().id); a.recreate() } else show(a, pickImage)
                }
            }
        }
        p.show()
    }

    /** Runs [then] once the profile's PIN was entered (at once if it has no lock). A wrong PIN or Cancel goes to [back]. */
    private fun whenUnlocked(a: FragmentActivity, id: String, back: () -> Unit, then: () -> Unit) {
        val store = a.applicationContext.repo.profileStore()
        val pr = store.get(id) ?: return
        if (!pr.isLocked) { then(); return }
        PinDialog.show(a, "Enter PIN", pr.name, onCancel = back) { pin -> if (store.pinMatches(id, pin)) then() else { wrong(a); back() } }
    }

    /**
     * Enter a new PIN twice; on success the lock is switched on. [done] gets true when the PIN was set, false when the two did not match;
     * [cancelled] runs when either PIN window is closed without entering a PIN.
     */
    private fun setNewPin(a: FragmentActivity, id: String, done: (Boolean) -> Unit, cancelled: () -> Unit) {
        val repo = a.applicationContext.repo
        PinDialog.show(a, "Choose A 4-Digit PIN", "Press The Number Keys Or Pick The Digits", onCancel = cancelled) { first ->
            PinDialog.show(a, "Enter The PIN Again", onCancel = cancelled) { second ->
                if (first == second && repo.profileStore().setPin(id, first)) {
                    repo.profileStore().setLock(id, true); repo.saveProfiles()
                    Toast.makeText(a, "Profile lock is on", Toast.LENGTH_SHORT).show()
                    done(true)
                } else { Toast.makeText(a, "The two PINs did not match", Toast.LENGTH_SHORT).show(); done(false) }
            }
        }
    }

    private fun wrong(a: FragmentActivity) = Toast.makeText(a, "Wrong PIN", Toast.LENGTH_SHORT).show()

    fun switchTo(a: FragmentActivity, id: String) {
        val repo = a.applicationContext.repo
        repo.switchProfile(id); repo.profileConfirmed = true
        a.recreate()                                              // the screens reload with this profile's history and ratings
    }

    /** Where to go when the picture chooser (another screen) comes back. */
    private var afterPick: (() -> Unit)? = null

    private fun icons(a: FragmentActivity, id: String, pickImage: (String) -> Unit, back: () -> Unit) {
        val repo = a.applicationContext.repo
        val p = Popup(a, "Profile Icon")
        ProfileIcons.AVATARS.forEachIndexed { i, av ->
            p.row((if (av.emoji.isEmpty()) "🐦" else av.emoji) + "   " + av.name) {
                repo.profileStore().get(id)?.icon = "builtin:$i"; repo.saveProfiles(); Toast.makeText(a, "Icon saved", Toast.LENGTH_SHORT).show()
                back()
            }
        }
        p.row("Upload A Custom Icon…") { afterPick = back; pickImage(id) }
        p.row("Icon From A Web Address…") {
            Popup.ask(a, "Icon Web Address", "Picture address", "", "Download", onCancel = back) { url -> download(a, id, url, back) }
        }
        p.onBack(back)
        p.show()
    }

    private fun download(a: FragmentActivity, id: String, url: String, back: () -> Unit) {
        val repo = a.applicationContext.repo
        a.lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try { repo.http.newCall(Request.Builder().url(url.trim()).build()).execute().use { r -> if (r.isSuccessful) BitmapFactory.decodeStream(r.body!!.byteStream()) else null } }
                catch (e: Exception) { null }
            }
            if (bmp == null) Toast.makeText(a, "Could not load a picture from that address", Toast.LENGTH_LONG).show()
            else { ProfileIcons.saveCustom(a, id, bmp); repo.profileStore().get(id)?.icon = "file"; repo.saveProfiles(); Toast.makeText(a, "Icon saved", Toast.LENGTH_SHORT).show() }
            back()
        }
    }

    /** Result of the picture chooser (uri is null when it was cancelled). Always returns to the profile's window afterwards. */
    fun saveFromUri(a: FragmentActivity, id: String, uri: Uri?) {
        val back = afterPick; afterPick = null
        if (uri == null) { back?.invoke(); return }
        val repo = a.applicationContext.repo
        a.lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { try { a.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { null } }
            if (bmp == null) Toast.makeText(a, "Could not read that picture", Toast.LENGTH_LONG).show()
            else { ProfileIcons.saveCustom(a, id, bmp); repo.profileStore().get(id)?.icon = "file"; repo.saveProfiles(); Toast.makeText(a, "Icon saved", Toast.LENGTH_SHORT).show() }
            back?.invoke()
        }
    }
}
