package com.sparrow.player.ui

/** What every tab body (channel list, guide, movie/series rows, settings) offers to MainActivity's navigation. */
interface TabContent {
    /** Move D-pad focus to a sensible default item. Returns false if nothing could take focus yet. */
    fun focusContent(): Boolean

    /** Is the current selection on the left-most item (so a LEFT press should open the side panels)? */
    fun isAtLeftEdge(): Boolean

    /** Is the selection on the first (top) row? Up then moves to the Search button (Movies / Series). */
    fun isAtTop(): Boolean = false

    /** BACK pressed with no side panel open. Return true if the tab used it (e.g. leaving guide time-shifting mode). */
    fun handleBack(): Boolean = false

    /** Data changed (sync finished, provider switched): refresh in place WITHOUT replacing the fragment. */
    fun reload() {}

    /** Only the TV guide data was refreshed (automatic EPG sync): reload programmes in place and keep the selection. */
    fun onGuideUpdated() {}

    /** The user's channel edits changed (hidden / renamed / copied / moved): reload the list in place. */
    fun onChannelsEdited() {}

    /** A different channel group was picked in the groups panel. */
    fun onGroupChanged() {}

    /** The channel playing in the top-left player changed (lists mark it). */
    fun onPlayingChanged() {}
}
