package com.sparrow.player.ui.player

/**
 * "First press only wakes the controls" for the full-screen player (pure Kotlin, unit tested).
 *
 * For the gated keys (D-pad, OK, Back, channel up / down): when the controls are hidden, that press is swallowed and only
 * brings the controls up. While they are visible the same keys act normally. A held key counts as ONE press: its repeats
 * and its release are swallowed with it. Every other key is never touched.
 */
class FirstPressGate {
    private var swallowed = -1

    /** @return true = the event must be consumed (the caller shows the controls on the initial key-down). */
    fun swallow(keyCode: Int, isDown: Boolean, repeatCount: Int, controlsVisible: Boolean): Boolean {
        if (isDown) {
            if (repeatCount > 0) return keyCode == swallowed
            if (!controlsVisible) { swallowed = keyCode; return true }
            swallowed = -1
            return false
        }
        if (keyCode == swallowed) { swallowed = -1; return true }
        return false
    }

    companion object {
        const val SHOW_MS = 3_000L

        // android.view.KeyEvent constants (kept literal so this class stays plain JVM and testable)
        const val DPAD_UP = 19; const val DPAD_DOWN = 20; const val DPAD_LEFT = 21; const val DPAD_RIGHT = 22
        const val DPAD_CENTER = 23; const val ENTER = 66; const val NUMPAD_ENTER = 160
        const val BACK = 4; const val CHANNEL_UP = 166; const val CHANNEL_DOWN = 167

        fun isGated(keyCode: Int) = when (keyCode) {
            DPAD_UP, DPAD_DOWN, DPAD_LEFT, DPAD_RIGHT, DPAD_CENTER, ENTER, NUMPAD_ENTER, BACK, CHANNEL_UP, CHANNEL_DOWN -> true
            else -> false
        }
    }
}
