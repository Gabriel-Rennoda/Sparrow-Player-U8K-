package com.sparrow.player.data

/**
 * A user profile: its own name, icon, optional 4-digit lock, and (through [Prefs]) its own watch history, resume points, ratings and My List.
 * Playlists, channels, favourite channels and settings are shared by all profiles.
 *
 * [icon]: "builtin:<n>" (one of the supplied avatars) or "file" (the custom picture saved for this profile).
 * [lockOn]: the lock can be switched on and off; the 4-digit [pin] is kept while it is off.
 */
class Profile(val id: String, var name: String, var icon: String = "builtin:0", var pin: String = "", var lockOn: Boolean = false) {
    val isLocked: Boolean get() = lockOn && pin.length == PIN_LENGTH

    companion object { const val PIN_LENGTH = 4 }
}

/** All profiles, pure Kotlin (JUnit tested), stored in one preference string. The first profile (id "1") owns the data saved before profiles existed. */
class ProfileStore {
    val profiles = ArrayList<Profile>()

    fun ensureDefault() { if (profiles.isEmpty()) profiles += Profile("1", "Profile 1") }

    fun get(id: String): Profile? = profiles.firstOrNull { it.id == id }

    fun add(name: String, icon: String = "builtin:${profiles.size % ICON_COUNT}"): Profile {
        val id = ((profiles.mapNotNull { it.id.toIntOrNull() }.maxOrNull() ?: 0) + 1).toString()
        return Profile(id, name.trim().ifEmpty { "Profile $id" }.take(MAX_NAME), icon).also { profiles += it }
    }

    /** The last profile cannot be removed. Returns true if one was removed. */
    fun remove(id: String): Boolean = profiles.size > 1 && profiles.removeAll { it.id == id }

    fun rename(id: String, name: String) { get(id)?.let { p -> name.trim().takeIf { it.isNotEmpty() }?.let { p.name = it.take(MAX_NAME) } } }

    /** [pin] must be exactly 4 digits. Setting a PIN does not switch the lock on. */
    fun setPin(id: String, pin: String): Boolean {
        if (pin.length != Profile.PIN_LENGTH || !pin.all { it in '0'..'9' }) return false
        get(id)?.pin = pin; return true
    }

    /** The lock can only be on when a PIN exists. */
    fun setLock(id: String, on: Boolean): Boolean {
        val p = get(id) ?: return false
        if (on && p.pin.length != Profile.PIN_LENGTH) return false
        p.lockOn = on; return true
    }

    fun pinMatches(id: String, entered: String): Boolean { val p = get(id) ?: return false; return !p.isLocked || p.pin == entered }

    fun serialize(): String = profiles.joinToString("") { p -> listOf(p.id, p.name, p.icon, p.pin, if (p.lockOn) "1" else "0").joinToString("\t") { esc(it) } + "\n" }

    companion object {
        const val ICON_COUNT = 12
        const val MAX_NAME = 20

        fun parse(s: String?): ProfileStore {
            val st = ProfileStore()
            for (line in (s ?: "").split('\n')) {
                val f = line.split('\t').map { unesc(it) }
                if (f.size >= 5 && f[0].isNotBlank() && st.get(f[0]) == null) st.profiles += Profile(f[0], f[1].ifBlank { "Profile ${f[0]}" }, f[2], f[3], f[4] == "1" && f[3].length == Profile.PIN_LENGTH)
            }
            st.ensureDefault()
            return st
        }

        private fun esc(s: String) = s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n")
        private fun unesc(s: String): String {
            val sb = StringBuilder(); var i = 0
            while (i < s.length) {
                val ch = s[i]
                if (ch == '\\' && i + 1 < s.length) { sb.append(when (s[i + 1]) { 't' -> '\t'; 'n' -> '\n'; else -> s[i + 1] }); i += 2 } else { sb.append(ch); i++ }
            }
            return sb.toString()
        }
    }
}

/** "My List": titles the user saved by hand, newest first. Pure Kotlin, one preference string per profile. */
class MyList {
    private val uids = ArrayList<String>()

    fun contains(uid: String) = uid in uids
    fun all(): List<String> = uids

    /** Adds (at the front) or removes. Returns true if the title is in the list afterwards. */
    fun toggle(uid: String): Boolean { return if (uids.remove(uid)) false else { uids.add(0, uid); true } }

    fun serialize(): String = uids.joinToString("\n")

    companion object {
        fun parse(s: String?): MyList = MyList().also { l -> (s ?: "").split('\n').filter { it.isNotBlank() }.forEach { if (it !in l.uids) l.uids += it } }
    }
}
