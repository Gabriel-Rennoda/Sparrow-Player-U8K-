package com.sparrow.player.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sparrow.player.R
import com.sparrow.player.ui.theme.Theme

/** One row of the groups panel. [pinned] = built in (All Channels, Favourites); [original] = the provider's name. */
data class GroupItem(
    val id: String,
    val name: String,
    val pinned: Boolean = false,
    val custom: Boolean = false,
    val hidden: Boolean = false,
    val original: String = name
)

/**
 * Channel groups list. Unlike a "selected follows focus" list, the highlighted (active) group only changes when the
 * user presses OK, so browsing the list and pressing Back leaves the guide exactly as it was.
 */
class GroupAdapter(
    private val onPick: (GroupItem) -> Unit,
    private val onFocus: (GroupItem) -> Unit = {},
    private val onLong: (GroupItem) -> Unit = {}
) : RecyclerView.Adapter<GroupAdapter.VH>() {
    class VH(v: View) : RecyclerView.ViewHolder(v)

    private var items: List<GroupItem> = emptyList()
    private var activeId: String = ""
    private var movingId: String? = null

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<GroupItem>, active: String) { items = list; activeId = active; notifyDataSetChanged() }

    @SuppressLint("NotifyDataSetChanged")
    fun setActive(id: String) { activeId = id; notifyDataSetChanged() }

    private var rv: RecyclerView? = null
    override fun onAttachedToRecyclerView(r: RecyclerView) { rv = r }
    override fun onDetachedFromRecyclerView(r: RecyclerView) { rv = null }

    /** Update the highlighted group without notifyDataSetChanged (which would recycle the focused row and lose focus). */
    fun setActiveQuiet(id: String) {
        activeId = id
        val r = rv ?: return
        for (k in 0 until r.childCount) {
            val v = r.getChildAt(k); val pos = r.getChildAdapterPosition(v)
            if (pos in items.indices) v.isSelected = items[pos].id == id
        }
    }

    fun idAt(pos: Int): String? = items.getOrNull(pos)?.id

    // ---- "Move": the group follows Up / Down while it is being placed -----------------------------------------------------
    fun canMove(id: String): Boolean = items.any { it.id == id && !it.pinned }

    /** The ids of the groups that can be moved (not All Channels / Favourites), in the order shown. */
    fun movableIds(): List<String> = items.filter { !it.pinned }.map { it.id }

    fun setMoving(id: String?) {
        val old = movingId
        movingId = id
        for (x in listOf(old, id)) if (x != null) { val p = positionOf(x); if (p >= 0) notifyItemChanged(p) }
    }

    /** One place up (delta -1) or down (+1). The built-in groups at the top never move. False = already at that end. */
    fun move(id: String, delta: Int): Boolean {
        val from = positionOf(id)
        val to = from + delta
        val first = items.indexOfFirst { !it.pinned }
        if (from < 0 || first < 0 || to < first || to >= items.size) return false
        val m = items.toMutableList()
        m.add(to, m.removeAt(from))
        items = m
        notifyItemMoved(from, to)
        return true
    }

    fun positionOf(id: String) = items.indexOfFirst { it.id == id }

    override fun getItemCount() = items.size
    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_text, p, false).also { Theme.applyTree(it) })

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        val label = if (item.hidden) item.name + "  (Hidden)" else item.name
        (h.itemView as TextView).text = if (item.id == movingId) "⇅  " + label else label
        h.itemView.alpha = if (item.hidden) 0.6f else 1f
        h.itemView.isSelected = item.id == activeId
        h.itemView.setOnClickListener { onPick(item) }
        h.itemView.setOnLongClickListener { onLong(item); true }      // hold OK: edit options for this group
        h.itemView.setOnFocusChangeListener { _, f -> if (f) onFocus(item) }
    }
}
