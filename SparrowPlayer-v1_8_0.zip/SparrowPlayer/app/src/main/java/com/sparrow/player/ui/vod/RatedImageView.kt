package com.sparrow.player.ui.vod

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.widget.ImageView
import com.sparrow.player.R
import com.sparrow.player.data.SparrowRating
import kotlin.math.cos
import kotlin.math.sin

/**
 * A poster that carries the two ratings in fixed places, wherever it is shown (browsing rows, search results, a title's details):
 *  - top LEFT:  the provider's star rating, one decimal ("⭐7.3", "⭐8.7", "⭐9" - a whole number never shows ".0")
 *  - top RIGHT: the Sparrow Rating, half steps only ("7.5", "8", "8.5"), as the small Sparrow logo on the left and the number on the right
 *               inside ONE tight black pill.
 * A rating that is unknown is simply not drawn.
 */
class RatedImageView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : ImageView(ctx, attrs) {
    private var provider = ""
    private var sparrow = ""

    fun setRatings(providerRating: Double, sparrowRating: Double) {
        provider = SparrowRating.format(providerRating)
        sparrow = SparrowRating.format(sparrowRating)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (provider.isEmpty() && sparrow.isEmpty() || width == 0) return
        RatingBadges.draw(c, width.toFloat(), provider, sparrow, RatingBadges.logo(context))
    }
}

/** Drawing of the two badges; sizes scale with the poster width so the proportions are the same on every poster. */
object RatingBadges {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEB000000.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD }
    private val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFC107.toInt() }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val star = Path()
    private val box = RectF()
    private val src = Rect()
    private val dst = RectF()
    @Volatile private var logoBmp: Bitmap? = null

    /** The Sparrow logo, decoded once at a small size. */
    fun logo(ctx: Context): Bitmap? {
        logoBmp?.let { return it }
        return try {
            val res = ctx.applicationContext.resources
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeResource(res, R.drawable.logo_circle, o)
            var sample = 1
            while (o.outWidth / (sample * 2) >= 96) sample *= 2
            val bmp = BitmapFactory.decodeResource(res, R.drawable.logo_circle, BitmapFactory.Options().apply { inSampleSize = sample })
            logoBmp = bmp; bmp
        } catch (e: Exception) { null }
    }

    fun draw(c: Canvas, w: Float, provider: String, sparrow: String, logo: Bitmap?) {
        val ts = w * 0.092f                       // text size
        val pad = ts * 0.38f
        val margin = ts * 0.42f
        val bh = ts * 1.5f                        // badge height
        val icon = ts * 1.08f
        val gap = pad * 0.7f
        txt.textSize = ts
        val baseOffset = -(txt.ascent() + txt.descent()) / 2f

        if (provider.isNotEmpty()) {
            val tw = txt.measureText(provider)
            val bw = pad + icon + gap + tw + pad
            box.set(margin, margin, margin + bw, margin + bh)
            c.drawRoundRect(box, bh * 0.32f, bh * 0.32f, bg)
            drawStar(c, box.left + pad + icon / 2f, box.centerY(), icon / 2f)
            c.drawText(provider, box.left + pad + icon + gap, box.centerY() + baseOffset, txt)
        }
        if (sparrow.isNotEmpty()) {
            val tw = txt.measureText(sparrow)
            val bw = pad + icon + gap + tw + pad
            box.set(w - margin - bw, margin, w - margin, margin + bh)
            c.drawRoundRect(box, bh * 0.32f, bh * 0.32f, bg)
            if (logo != null) {
                src.set(0, 0, logo.width, logo.height)
                dst.set(box.left + pad, box.centerY() - icon / 2f, box.left + pad + icon, box.centerY() + icon / 2f)
                c.drawBitmap(logo, src, dst, bmpPaint)
            }
            c.drawText(sparrow, box.left + pad + icon + gap, box.centerY() + baseOffset, txt)
        }
    }

    private fun drawStar(c: Canvas, cx: Float, cy: Float, r: Float) {
        star.reset()
        for (i in 0 until 10) {
            val rad = if (i % 2 == 0) r else r * 0.46f
            val a = Math.toRadians(-90.0 + i * 36.0)
            val x = cx + (rad * cos(a)).toFloat(); val y = cy + (rad * sin(a)).toFloat()
            if (i == 0) star.moveTo(x, y) else star.lineTo(x, y)
        }
        star.close()
        c.drawPath(star, gold)
    }
}
