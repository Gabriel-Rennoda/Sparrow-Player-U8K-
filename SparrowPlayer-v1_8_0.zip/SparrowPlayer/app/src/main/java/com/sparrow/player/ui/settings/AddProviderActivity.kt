package com.sparrow.player.ui.settings

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Provider
import com.sparrow.player.data.XtreamClient
import com.sparrow.player.databinding.ActivityAddProviderBinding
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Add Playlist. Fields in this order: Username, Password, Server URL, Playlist Name (optional), XMLTV EPG URL (optional).
 *  - The selector starts on Username.
 *  - "(Optional)" is a grey hint: it disappears while the field is selected and comes back if the field is left empty.
 *  - Pressing OK / Go on the keyboard with Username, Password and Server URL filled in verifies the login and starts the
 *    sync by itself - no need to find the Connect button. (With a field still empty, OK moves to the next empty field.)
 */
class AddProviderActivity : FragmentActivity() {
    private lateinit var b: ActivityAddProviderBinding
    private var xtream = true
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAddProviderBinding.inflate(layoutInflater)
        setContentView(b.root)
        Theme.applyAll(this, b.root)

        optionalHint(b.name); optionalHint(b.epgUrl)
        val go = TextView.OnEditorActionListener { v, id, e ->
            val enter = e != null && e.keyCode == KeyEvent.KEYCODE_ENTER && e.action == KeyEvent.ACTION_DOWN
            if (id == EditorInfo.IME_ACTION_GO || id == EditorInfo.IME_ACTION_DONE || enter) {
                if (ready()) save() else v.focusSearch(View.FOCUS_DOWN)?.requestFocus()
                true
            } else false
        }
        listOf(b.server, b.name, b.epgUrl, b.m3uUrl).forEach { it.setOnEditorActionListener(go) }
        b.typeBtn.setOnClickListener { setType(!xtream) }
        b.saveBtn.setOnClickListener { save() }
        setType(true)
    }

    /** Grey "(Optional)" hint that goes away when the line is selected and returns if it is left empty. */
    private fun optionalHint(e: EditText) {
        val hint = "(Optional)"
        e.hint = hint
        e.setOnFocusChangeListener { _, focused ->
            e.hint = if (focused || e.text.isNotEmpty()) "" else hint
        }
    }

    private fun setType(x: Boolean) {
        xtream = x
        b.xtreamFields.visibility = if (x) View.VISIBLE else View.GONE
        b.m3uFields.visibility = if (x) View.GONE else View.VISIBLE
        b.typeBtn.text = "Playlist Type: " + if (x) "Xtream Codes" else "M3U Playlist"
        (if (x) b.username else b.m3uUrl).requestFocus()           // the selector always starts on the first field
    }

    private fun ready(): Boolean =
        if (xtream) b.username.text.isNotBlank() && b.password.text.isNotBlank() && b.server.text.isNotBlank()
        else b.m3uUrl.text.isNotBlank()

    private fun save() {
        if (busy) return
        val name = b.name.text.toString().trim().ifBlank { "My IPTV" }
        val epg = b.epgUrl.text.toString().trim()
        val p = if (xtream) Provider(
            name = name, type = "xtream", server = b.server.text.toString().trim(),
            username = b.username.text.toString().trim(), password = b.password.text.toString().trim(), epgUrl = epg
        ) else Provider(name = name, type = "m3u", m3uUrl = b.m3uUrl.text.toString().trim(), epgUrl = epg)

        if (xtream && (p.server.isBlank() || p.username.isBlank() || p.password.isBlank())) {
            showError("Username, password and server URL are required"); return
        }
        if (!xtream && p.m3uUrl.isBlank()) { showError("Playlist URL is required"); return }

        busy = true
        b.saveBtn.isEnabled = false
        b.error.setTextColor(Theme.accent); b.error.text = if (xtream) "Verifying Login…" else "Connecting…"
        lifecycleScope.launch {
            val repo = applicationContext.repo
            try {
                if (xtream) {
                    val ok = withContext(Dispatchers.IO) { XtreamClient(repo.http, p).authenticate() }
                    if (!ok) error("Login failed – check username, password and server URL")
                }
                b.error.text = "Login OK – Loading Channels…"
                val id = repo.dao.insertProvider(p)
                repo.prefs.activeProvider = id
                repo.syncAsync(p.copy(id = id))          // progress shows at the top right of the main screen
                finish()
            } catch (e: Exception) {
                showError(e.message ?: "Could not connect")
                busy = false
                b.saveBtn.isEnabled = true
            }
        }
    }

    private fun showError(m: String) {
        b.error.setTextColor(if (Theme.palette.isLight) 0xFFB3261E.toInt() else 0xFFFF8A80.toInt())
        b.error.text = m
    }
}
