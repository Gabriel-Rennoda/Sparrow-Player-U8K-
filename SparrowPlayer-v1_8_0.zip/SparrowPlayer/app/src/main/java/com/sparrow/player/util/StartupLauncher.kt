package com.sparrow.player.util

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.sparrow.player.ui.MainActivity

/**
 * "Open On Device Start-Up / Wake-Up". After boot a manifest receiver ([com.sparrow.player.BootReceiver]) starts the app; for wake-up a
 * receiver registered by the running app listens for the screen coming on. Android 10+ only lets an app open itself from the background
 * when it has the "Display over other apps" permission, so turning the option on explains / opens that permission. Some TV firmware blocks
 * or does not offer it; the TV's own "power-on behaviour / default app" setting is the fallback.
 */
object StartupLauncher {
    /**
     * Marks a start-up / wake-up launch: MainActivity then behaves like a fresh start - Live TV with the guide, the mini player (top left)
     * playing the Opening Channel (or the last channel) - whatever screen the app was left on (Settings, Movies, full screen ...).
     */
    const val EXTRA_FRESH = "sparrow_fresh_open"
    private var lastLaunch = 0L

    fun launch(ctx: Context) {
        val now = SystemClock.elapsedRealtime()
        if (lastLaunch != 0L && now - lastLaunch < 4000) return          // SCREEN_ON and USER_PRESENT arrive together: one launch
        lastLaunch = now
        try {
            // CLEAR_TOP + SINGLE_TOP: a running app is not duplicated, whatever is on top of it (full screen, details ...) is closed and
            // the existing MainActivity gets onNewIntent; a stopped or killed app starts normally
            ctx.startActivity(
                Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(EXTRA_FRESH, true)
            )
        } catch (e: Exception) { /* blocked by the system: nothing more we can do */ }
    }

    /** Wake-up: while the app process is alive, open it when the screen turns on. */
    fun registerWakeReceiver(app: Context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { if (app.repo.prefs.startOnBoot) launch(app) }
        }
        val filter = IntentFilter(Intent.ACTION_SCREEN_ON).apply { addAction(Intent.ACTION_USER_PRESENT) }
        try { ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED) } catch (e: Exception) { }
    }

    fun canOpenFromBackground(ctx: Context) = Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(ctx)

    /** Called when the option is switched on. */
    fun explainPermission(a: Activity) {
        if (canOpenFromBackground(a)) { Toast.makeText(a, "Sparrow Player will open when the device starts or wakes up", Toast.LENGTH_LONG).show(); return }
        Toast.makeText(a, "Allow \"Display over other apps\" for Sparrow Player so it can open by itself", Toast.LENGTH_LONG).show()
        try {
            a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName)))
        } catch (e: Exception) {
            Toast.makeText(a, "This TV has no such screen. Try the TV's own power-on / default app setting.", Toast.LENGTH_LONG).show()
        }
    }
}
