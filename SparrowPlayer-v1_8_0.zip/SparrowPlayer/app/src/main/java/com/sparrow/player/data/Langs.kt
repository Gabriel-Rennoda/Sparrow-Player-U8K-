package com.sparrow.player.data

/** Languages offered for the preferred audio / subtitle settings (ISO 639-1 codes). Pure Kotlin. */
object Langs {
    val ALL: List<Pair<String, String>> = listOf(
        "en" to "English", "fr" to "French", "es" to "Spanish", "de" to "German", "it" to "Italian", "pt" to "Portuguese",
        "nl" to "Dutch", "ar" to "Arabic", "hi" to "Hindi", "zh" to "Chinese", "ja" to "Japanese", "ko" to "Korean", "ru" to "Russian"
    )

    /** Audio: Automatic + languages. Values: "" or a code. */
    val AUDIO: List<Pair<String, String>> = listOf("" to "Automatic") + ALL

    /** Subtitles: Automatic, Off + languages. Values: "", "off" or a code. */
    val SUBTITLES: List<Pair<String, String>> = listOf("" to "Automatic", "off" to "Off") + ALL

    fun label(list: List<Pair<String, String>>, code: String): String = list.firstOrNull { it.first == code }?.second ?: code
}
