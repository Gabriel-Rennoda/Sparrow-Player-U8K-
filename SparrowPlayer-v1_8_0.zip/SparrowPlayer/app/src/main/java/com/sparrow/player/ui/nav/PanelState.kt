package com.sparrow.player.ui.nav

enum class Panel { NONE, GROUPS, NAV }

/**
 * Pure (Android-free) state machine for the left-hand panels, so it can be unit tested without a TV.
 *
 *   NONE   : only the content (player + info + guide / list / rows) with the minimized icon bar
 *   GROUPS : channel groups list (All channels, Favourites, ...) is open
 *   NAV    : the tab list (Live TV, Movies, Series, Guide, Favourites, Settings) is expanded
 *
 * LEFT from the left edge of the content opens GROUPS (screens that have groups) or NAV (screens that don't);
 * LEFT again from GROUPS opens NAV. RIGHT closes one level at a time in reverse.
 *
 * BACK walks the same way: from the content it opens GROUPS (or NAV on screens without groups), from GROUPS it opens NAV, and
 * from NAV there is nowhere further - the caller then runs the "press Back again to exit" flow.
 */
class PanelState {
    var panel = Panel.NONE
        private set

    /** Which panel was open underneath NAV, so BACK returns to it. */
    var navFrom = Panel.NONE
        private set

    /** Does the current screen have a channel-groups panel? (Live TV and Guide do.) */
    var hasGroups = false

    val navOpen get() = panel == Panel.NAV
    val groupsOpen get() = panel == Panel.GROUPS || (panel == Panel.NAV && navFrom == Panel.GROUPS)

    /** LEFT pressed. [atContentEdge] = focus is on the left-most item of the content. Returns true if consumed. */
    fun left(atContentEdge: Boolean): Boolean = when (panel) {
        Panel.NONE -> if (!atContentEdge) false else {
            navFrom = Panel.NONE
            panel = if (hasGroups) Panel.GROUPS else Panel.NAV
            true
        }
        Panel.GROUPS -> { navFrom = Panel.GROUPS; panel = Panel.NAV; true }
        Panel.NAV -> true // nothing further left
    }

    /**
     * BACK pressed: open the next panel (content -> groups -> tab list). Returns false when the tab list is already open
     * (nothing more to open: the caller shows the exit prompt).
     */
    fun backPress(): Boolean = when (panel) {
        Panel.NONE -> { navFrom = Panel.NONE; panel = if (hasGroups) Panel.GROUPS else Panel.NAV; true }
        Panel.GROUPS -> { navFrom = Panel.GROUPS; panel = Panel.NAV; true }
        Panel.NAV -> false
    }

    /** RIGHT pressed (or a tab / group was chosen elsewhere): close one level. Returns true if a panel was closed. */
    fun back(): Boolean = when (panel) {
        Panel.NONE -> false
        Panel.GROUPS -> { panel = Panel.NONE; true }
        Panel.NAV -> { panel = navFrom; navFrom = Panel.NONE; true }
    }

    /** Close everything (a tab or group was chosen). */
    fun reset() { panel = Panel.NONE; navFrom = Panel.NONE }
}
