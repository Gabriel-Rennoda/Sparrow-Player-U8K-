package com.sparrow.player.ui.player

import android.app.Activity
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.view.WindowManager

/**
 * Tells the TV that content is really playing, so its screensaver / ambient mode / auto-sleep does not start while someone is
 * watching the small live player and browsing the guide (no remote key is pressed for a long time, which is what the TV
 * counts as "idle"). Two independent signals:
 *  1. FLAG_KEEP_SCREEN_ON on the activity window - the standard "do not dim / sleep / daydream" request;
 *  2. an active framework MediaSession in state PLAYING - how Android TV / Google TV recognise a media app that is playing.
 * The session has no callback and no media-button flags, so it never takes the remote's media keys from the app.
 */
class PlaybackSignal(private val activity: Activity) {
    private var session: MediaSession? = null
    private var on = false

    fun set(playing: Boolean, title: String = "") {
        if (playing) {
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        if (playing == on && session != null) return
        on = playing
        try {
            val s = session ?: MediaSession(activity, "SparrowPlayer").also { session = it }
            s.setMetadata(MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title.ifBlank { "Sparrow Player" }).build())
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_STOP)
                    .setState(
                        if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN,
                        if (playing) 1f else 0f
                    ).build()
            )
            s.isActive = playing
        } catch (e: Throwable) {
            // a firmware without MediaSession support still gets the window flag
        }
    }

    fun release() {
        activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { session?.isActive = false; session?.release() } catch (e: Throwable) { }
        session = null; on = false
    }
}
