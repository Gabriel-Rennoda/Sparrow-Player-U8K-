package com.sparrow.player.data

/**
 * Search: what a title / channel is tagged with, the filters the user can set, and the engine that applies them.
 * Pure Kotlin (no Android types) so it is unit tested on the JVM.
 *
 * IPTV panels give very little metadata in their bulk lists (name, category, year, rating, date added; series also genre and plot).
 * So quality, language, subtitles and maturity are read from the tags providers put in titles and category names
 * ("4K", "EN |", "[MULTI-SUB]", "TV-MA" ...). Length and maturity from the panel's own info call are remembered by [MetaCache]
 * whenever a details page is opened. A title with no information for a filter is simply not matched by that filter.
 */
object MediaTags {
    val QUALITIES = listOf("4K", "UHD", "FHD", "HD", "SD")
    val MATURITIES = listOf("G", "PG", "PG-13", "R", "NC-17", "TV-Y", "TV-G", "TV-PG", "TV-14", "TV-MA", "Not Rated")
    val CHANNEL_TYPES = listOf("Sports", "News", "Kids", "Music", "Documentary", "Movies", "Series", "Radio", "Entertainment", "Local", "International", "Other")
    const val UNKNOWN_LANGUAGE = "Unknown"

    private val NON_WORD = Regex("[^a-z0-9+]+")
    private val PG_ONLY = Regex("[\\[(]\\s*pg\\s*[\\])]|rated pg(?![-\\w])", RegexOption.IGNORE_CASE)
    private val R_ONLY = Regex("[\\[(]\\s*r\\s*[\\])]|rated r(?![-\\w])", RegexOption.IGNORE_CASE)
    private val G_ONLY = Regex("[\\[(]\\s*g\\s*[\\])]|rated g(?![-\\w])", RegexOption.IGNORE_CASE)

    private fun norm(s: String): String =
        " " + s.lowercase().replace(NON_WORD, " ").trim() + " "

    private fun has(n: String, vararg words: String) = words.any { n.contains(" $it ") }

    /** Highest quality tag found (4K > UHD > FHD > HD); SD when the title says nothing. */
    fun quality(text: String): String {
        val n = norm(text)
        return when {
            has(n, "4k", "2160p", "2160") -> "4K"
            has(n, "uhd") -> "UHD"
            has(n, "fhd", "1080p", "1080") -> "FHD"
            has(n, "hd", "720p", "720") -> "HD"
            else -> "SD"
        }
    }

    private val LANG_NAMES = mapOf(
        "english" to "en", "french" to "fr", "spanish" to "es", "german" to "de", "italian" to "it", "portuguese" to "pt",
        "dutch" to "nl", "arabic" to "ar", "hindi" to "hi", "chinese" to "zh", "japanese" to "ja", "korean" to "ko", "russian" to "ru"
    )
    private const val CODES = "en|fr|es|de|it|pt|nl|ar|hi|zh|ja|ko|ru"
    // "EN | Title", "FR - Title", "[ES] Title", "(DE) Title", "Title |EN|": a two-letter code only counts when it is set apart like that
    private val LANG_PREFIX = Regex("^\\s*[\\[(|]?\\s*($CODES)\\s*[\\])|:]|^\\s*($CODES)\\s+-\\s", RegexOption.IGNORE_CASE)
    private val LANG_BRACKET = Regex("[\\[(|]\\s*($CODES)\\s*[\\])|]", RegexOption.IGNORE_CASE)

    /** Language codes (en, fr ...) named by the text. */
    fun languages(text: String): Set<String> {
        val out = LinkedHashSet<String>()
        LANG_PREFIX.find(text)?.let { m -> (m.groups[1]?.value ?: m.groups[2]?.value)?.let { out += it.lowercase() } }
        LANG_BRACKET.findAll(text).forEach { m -> out += m.groupValues[1].lowercase() }
        val n = norm(text)
        LANG_NAMES.forEach { (name, code) -> if (n.contains(" $name ")) out += code }
        return out
    }

    fun hasSubtitles(text: String): Boolean =
        has(norm(text), "sub", "subs", "subbed", "subtitled", "subtitles", "multisub", "msub", "multi sub", "cc", "sdh", "vostfr", "vost", "eng sub")

    /** Maturity rating named in a title or in the panel's info ("Rated R", "PG-13", "TV-MA"); "" if none. */
    fun maturity(text: String): String {
        val n = norm(text)
        return when {
            has(n, "tv ma") -> "TV-MA"
            has(n, "tv 14") -> "TV-14"
            has(n, "tv pg") -> "TV-PG"
            has(n, "tv y7", "tv y") -> "TV-Y"
            has(n, "tv g") -> "TV-G"
            has(n, "nc 17") -> "NC-17"
            has(n, "pg 13") -> "PG-13"
            PG_ONLY.containsMatchIn(text) -> "PG"
            R_ONLY.containsMatchIn(text) -> "R"
            G_ONLY.containsMatchIn(text) -> "G"
            else -> MATURITIES.firstOrNull { it != "Not Rated" && it.equals(text.trim(), ignoreCase = true) } ?: ""
        }
    }

    /** Order for sorting by maturity: youngest audience first; unknown last. */
    fun maturityRank(m: String): Int = when (m) {
        "TV-Y" -> 0; "TV-G", "G" -> 1; "TV-PG", "PG" -> 2; "PG-13", "TV-14" -> 3; "R", "TV-MA" -> 4; "NC-17" -> 5; else -> 99
    }

    private val TYPE_WORDS: List<Pair<String, List<String>>> = listOf(
        "Sports" to listOf("sport", "sports", "espn", "nba", "nfl", "nhl", "mlb", "soccer", "football", "golf", "tennis", "ufc", "wwe", "f1", "tsn", "dazn", "racing"),
        "News" to listOf("news", "cnn", "msnbc", "bloomberg", "al jazeera", "weather"),
        "Kids" to listOf("kids", "kid", "cartoon", "cartoons", "children", "disney", "nick", "nickelodeon", "junior", "baby"),
        "Music" to listOf("music", "mtv", "vevo", "hits", "concert"),
        "Documentary" to listOf("documentary", "documentaries", "discovery", "national geographic", "nat geo", "history", "animal planet", "science"),
        "Movies" to listOf("movie", "movies", "cinema", "film", "films", "hbo", "cinemax", "starz", "showtime"),
        "Series" to listOf("series", "tv shows", "shows", "drama"),
        "Radio" to listOf("radio", "fm"),
        "Entertainment" to listOf("entertainment", "comedy", "reality", "general", "lifestyle"),
        "Local" to listOf("local", "regional", "city"),
        "International" to listOf("international", "world", "intl")
    )

    /** Channel type from its group and its name (the first matching type in [CHANNEL_TYPES] order; "Other" if none). */
    fun channelType(group: String, name: String): String {
        val n = norm("$group $name")
        for ((type, words) in TYPE_WORDS) if (words.any { n.contains(" $it ") }) return type
        return "Other"
    }
}

enum class SearchKind(val label: String) { LIVE("Live Channels"), MOVIE("Movies"), SERIES("Series") }

enum class SortBy(val label: String) {
    NAME("Name"), NUMBER("Channel Number"), GENRE("Genre"), STAR("Star Rating"), MATURITY("Maturity Rating"),
    RELEASE("Release Date"), ADDED("Date Added"), LENGTH("Length");

    companion object {
        fun forKind(k: SearchKind): List<SortBy> =
            if (k == SearchKind.LIVE) listOf(NAME, NUMBER, GENRE) else listOf(NAME, GENRE, STAR, MATURITY, RELEASE, ADDED, LENGTH)
    }
}

enum class SubsFilter(val label: String) { ANY("Any"), WITH("With Subtitles"), WITHOUT("Without Subtitles") }

/** Everything the user can set on the search page. Empty / zero values mean "no filter". */
data class SearchFilters(
    val kind: SearchKind,
    val text: String = "",
    val inDescription: Boolean = false,
    val qualities: Set<String> = emptySet(),
    val subtitles: SubsFilter = SubsFilter.ANY,
    val languages: Set<String> = emptySet(),
    val languagesOut: Boolean = false,               // true = hide the ticked languages instead of showing only them
    val channelTypes: Set<String> = emptySet(),
    val yearFrom: Int = 0,
    val yearTo: Int = 0,
    val genres: Set<String> = emptySet(),
    val lengthMin: Int = 0,                          // minutes
    val lengthMax: Int = 0,
    val myRatings: Set<String> = emptySet(),         // "loved" / "liked" / "disliked"
    val myRatingsOut: Boolean = false,
    val minStars: Double = 0.0,
    val minSparrow: Double = 0.0,
    val unwatchedOnly: Boolean = false,              // hide everything this profile has started or finished
    val maturities: Set<String> = emptySet(),
    val maturitiesOut: Boolean = false,
    val sortBy: SortBy = SortBy.NAME,
    val descending: Boolean = false
) {
    /** Number of filters switched on (the text box and the sort do not count). */
    val activeCount: Int get() = listOf(
        qualities.isNotEmpty(), subtitles != SubsFilter.ANY, languages.isNotEmpty(), channelTypes.isNotEmpty(),
        yearFrom > 0 || yearTo > 0, genres.isNotEmpty(), lengthMin > 0 || lengthMax > 0, myRatings.isNotEmpty(),
        minStars > 0, minSparrow > 0, maturities.isNotEmpty(), unwatchedOnly
    ).count { it }
}

/** One channel / movie / series as the engine sees it. Unknown numbers are -1 (or 0 for year / number / added). */
class Candidate(
    val uid: String,
    val name: String,
    val group: String = "",                          // category name
    val genres: Set<String> = emptySet(),            // lower case
    val year: Int = 0,
    val stars: Double = -1.0,                        // provider rating, 0..10
    val sparrow: Double = -1.0,                      // Sparrow Rating, 0..10
    val added: Long = 0,
    val lengthMin: Int = -1,
    val maturity: String = "Not Rated",
    val quality: String = "SD",
    val languages: Set<String> = emptySet(),
    val subtitles: Boolean = false,
    val description: String = "",
    val myRating: String = "",
    val channelType: String = "Other",
    val number: Int = 0,
    val live: Boolean = false,
    val watched: Boolean = false                     // started or finished by the active profile
) {
    /** Lower case once, not on every key press of every search over 100 000 titles. */
    val nameLower: String = name.lowercase()
    private var descLowerV: String? = null
    val descLower: String get() = descLowerV ?: description.lowercase().also { descLowerV = it }
}

object SearchEngine {
    private val SPACES = Regex("\\s+")
    private fun words(q: String) = q.lowercase().split(SPACES).filter { it.isNotEmpty() }

    /**
     * Candidates that pass every active filter, sorted. [descMatches]: uids whose description matched the text (live channels:
     * the guide is searched in the database), used when [SearchFilters.inDescription] is on.
     */
    fun apply(all: List<Candidate>, f: SearchFilters, descMatches: Set<String> = emptySet(), presortedByName: Boolean = false): List<Candidate> {
        val w = words(f.text)
        val langs = f.languages.map { it.lowercase() }.toSet()
        val genres = f.genres.map { it.lowercase() }.toSet()
        val out = all.filter { c ->
            if (w.isNotEmpty()) {
                val n = c.nameLower
                val inName = w.all { n.contains(it) }
                val inDesc = f.inDescription && (c.uid in descMatches || (c.description.isNotEmpty() && w.all { c.descLower.contains(it) }))
                if (!inName && !inDesc) return@filter false
            }
            if (f.qualities.isNotEmpty() && c.quality !in f.qualities) return@filter false
            when (f.subtitles) {
                SubsFilter.WITH -> if (!c.subtitles) return@filter false
                SubsFilter.WITHOUT -> if (c.subtitles) return@filter false
                SubsFilter.ANY -> Unit
            }
            if (langs.isNotEmpty()) {
                val have = if (c.languages.isEmpty()) setOf(MediaTags.UNKNOWN_LANGUAGE.lowercase()) else c.languages
                val hit = have.any { it in langs }
                if (hit == f.languagesOut) return@filter false
            }
            if (f.channelTypes.isNotEmpty() && c.channelType !in f.channelTypes) return@filter false
            if (f.yearFrom > 0 && (c.year == 0 || c.year < f.yearFrom)) return@filter false
            if (f.yearTo > 0 && (c.year == 0 || c.year > f.yearTo)) return@filter false
            if (genres.isNotEmpty() && c.genres.none { it in genres }) return@filter false
            if (f.lengthMin > 0 || f.lengthMax > 0) {
                if (c.lengthMin < 0) return@filter false
                if (f.lengthMin > 0 && c.lengthMin < f.lengthMin) return@filter false
                if (f.lengthMax > 0 && c.lengthMin > f.lengthMax) return@filter false
            }
            if (f.myRatings.isNotEmpty()) {
                val hit = c.myRating in f.myRatings
                if (hit == f.myRatingsOut) return@filter false
            }
            if (f.unwatchedOnly && c.watched) return@filter false
            if (f.minStars > 0 && c.stars < f.minStars) return@filter false
            if (f.minSparrow > 0 && c.sparrow < f.minSparrow) return@filter false
            if (f.maturities.isNotEmpty()) {
                val hit = c.maturity in f.maturities
                if (hit == f.maturitiesOut) return@filter false
            }
            true
        }
        // [all] already sorted by name: A-Z needs no sort at all, Z-A is the same list backwards
        if (presortedByName && f.sortBy == SortBy.NAME) return if (f.descending) out.asReversed() else out
        return sort(out, f)
    }

    /** Sorted by the chosen field; titles that have no value for it always come last, whichever direction. */
    fun sort(list: List<Candidate>, f: SearchFilters): List<Candidate> {
        val byName = compareBy<Candidate, String>(String.CASE_INSENSITIVE_ORDER) { it.name }
        val key: (Candidate) -> Double? = when (f.sortBy) {
            SortBy.NAME -> return list.sortedWith(if (f.descending) byName.reversed() else byName)
            SortBy.GENRE -> { _ -> null }
            SortBy.NUMBER -> { c -> if (c.number > 0) c.number.toDouble() else null }
            SortBy.STAR -> { c -> if (c.stars >= 0) c.stars else null }
            SortBy.MATURITY -> { c -> MediaTags.maturityRank(c.maturity).takeIf { it < 99 }?.toDouble() }
            SortBy.RELEASE -> { c -> if (c.year > 0) c.year.toDouble() else null }
            SortBy.ADDED -> { c -> if (c.added > 0) c.added.toDouble() else null }
            SortBy.LENGTH -> { c -> if (c.lengthMin >= 0) c.lengthMin.toDouble() else null }
        }
        if (f.sortBy == SortBy.GENRE) {
            fun g(c: Candidate): String? = if (c.live) c.channelType.takeIf { it != "Other" } else c.genres.minOrNull()
            val known = list.filter { g(it) != null }.sortedWith(compareBy<Candidate, String>(String.CASE_INSENSITIVE_ORDER) { g(it)!! }.thenBy { it.name.lowercase() })
            val unknown = list.filter { g(it) == null }.sortedBy { it.name.lowercase() }
            return (if (f.descending) known.reversed() else known) + unknown
        }
        val known = list.filter { key(it) != null }
        val unknown = list.filter { key(it) == null }.sortedBy { it.name.lowercase() }
        val cmp = compareBy<Candidate> { key(it)!! }.thenBy { it.name.lowercase() }
        return known.sortedWith(if (f.descending) cmp.reversed() else cmp) + unknown
    }

}
