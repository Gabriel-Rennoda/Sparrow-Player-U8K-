package com.sparrow.player.data

/** Resume rules for movies / episodes (pure, unit tested). Position is stored in ms; FINISHED means "watched to the end". */
object Resume {
    const val BACK_MS = 30_000L
    const val FINISHED = -1L
    private const val END_ZONE_MS = 60_000L
    const val WATCHED_PERCENT = 40

    /** Where to start: 30 s before the saved stop point (0 if that would be the very start). */
    fun resumeAt(saved: Long): Long = if (saved <= BACK_MS) 0L else saved - BACK_MS

    /** 0..100 for a progress bar. */
    fun percent(pos: Long, duration: Long): Int = when {
        pos == FINISHED -> 100
        pos <= 0 || duration <= 0 -> 0
        else -> (pos * 100 / duration).toInt().coerceIn(1, 99)
    }

    fun hasProgress(saved: Long) = saved > BACK_MS

    /** What to store for the current position: FINISHED when it is (nearly) over, 0 when there is nothing to keep. */
    fun toStore(pos: Long, duration: Long): Long = when {
        duration <= 0 || pos <= 0 -> 0L
        duration - pos < END_ZONE_MS || pos * 100 >= duration * 95 -> FINISHED
        else -> pos
    }

    /** A title counts as watched (history -> recommendations) once 40 % of it has been played, or it was finished. */
    fun countsAsWatched(pos: Long, duration: Long): Boolean =
        pos == FINISHED || (duration > 0 && pos > 0 && pos * 100 >= duration * WATCHED_PERCENT)
}
