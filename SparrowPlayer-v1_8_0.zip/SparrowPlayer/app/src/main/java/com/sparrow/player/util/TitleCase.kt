package com.sparrow.player.util

/**
 * Title case for headings (pure Kotlin, unit tested).
 *
 * Words written entirely in lower case get a capital ("recently added" -> "Recently Added"); small joining words stay lower case
 * in the middle ("Recommended for You"); the first and last word always get one. A word that already contains a capital
 * (NBA, iPlayer, HBO, McDonald) is left exactly as it is, so provider names are never mangled.
 */
object TitleCase {
    private val SMALL = setOf("a", "an", "and", "as", "at", "but", "by", "for", "in", "nor", "of", "on", "or", "per", "the", "to", "vs", "via", "with")

    fun of(s: String): String {
        if (s.isBlank()) return s
        val words = s.split(' ')
        val firstReal = words.indexOfFirst { it.isNotEmpty() }
        val lastReal = words.indexOfLast { it.isNotEmpty() }
        return words.mapIndexed { i, w ->
            if (w.isEmpty()) w
            else if (i != firstReal && i != lastReal && w in SMALL) w
            else word(w)
        }.joinToString(" ")
    }

    /** One space-free word: capitalise each hyphen / slash / bar separated piece that is all lower case. */
    private fun word(w: String): String {
        if (w.any { it.isUpperCase() }) return w
        val sb = StringBuilder(w.length)
        var startOfPiece = true
        for (ch in w) {
            if (startOfPiece && ch.isLetter()) { sb.append(ch.uppercaseChar()); startOfPiece = false }
            else {
                sb.append(ch)
                if (ch == '-' || ch == '/' || ch == '|' || ch == '(' || ch == '"' || ch == '[') startOfPiece = true
                else if (ch.isLetterOrDigit()) startOfPiece = false
            }
        }
        return sb.toString()
    }
}
