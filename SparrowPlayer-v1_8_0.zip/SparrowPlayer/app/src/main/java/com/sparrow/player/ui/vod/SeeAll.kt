package com.sparrow.player.ui.vod

import android.view.Gravity
import android.view.ViewGroup
import android.widget.TextView
import androidx.leanback.widget.Presenter
import com.sparrow.player.ui.theme.Theme

/** The first tile of a holiday's "Top 10 What's Hot" row: OK opens that holiday's page ([scope] = "holiday:<id>"). */
class SeeAll(val scope: String, val label: String)

class SeeAllPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val ctx = parent.context
        val v = TextView(ctx).apply {
            layoutParams = ViewGroup.LayoutParams(PosterSize.width(ctx), PosterSize.height(ctx))
            gravity = Gravity.CENTER; textSize = 18f; tag = "t:item;bg:item"
            setPadding(16, 16, 16, 16); isFocusable = true; isClickable = true
        }
        Theme.applyTree(v)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(vh: ViewHolder, item: Any?) {
        (vh.view as TextView).text = "See All\n${(item as? SeeAll)?.label ?: ""}  ▸"
    }

    override fun onUnbindViewHolder(vh: ViewHolder) {}
}
