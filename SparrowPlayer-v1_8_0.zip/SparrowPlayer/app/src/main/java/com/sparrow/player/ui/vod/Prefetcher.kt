package com.sparrow.player.ui.vod

import android.content.Context
import coil.imageLoader
import coil.request.Disposable

/**
 * Loads posters into Coil's memory cache BEFORE the user gets to them. The request is built by [PosterSize.request], the
 * same builder the cards use, so the cache key matches and the card gets its poster instantly (no placeholder, no change).
 * Only the posters currently wanted stay queued: when the user turns around, the old look-ahead is cancelled.
 */
class Prefetcher(private val ctx: Context) {
    private val running = HashMap<String, Disposable>()

    fun want(urls: Collection<String>) {
        val wanted = urls.filter { it.isNotBlank() }.toSet()
        val it = running.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (e.key !in wanted) { e.value.dispose(); it.remove() }
        }
        for (u in wanted) {
            val cur = running[u]
            if (cur != null && !cur.isDisposed) continue      // still loading
            running[u] = ctx.imageLoader.enqueue(PosterSize.request(ctx, u).build())
        }
    }

    fun cancel() { running.values.forEach { it.dispose() }; running.clear() }
}
