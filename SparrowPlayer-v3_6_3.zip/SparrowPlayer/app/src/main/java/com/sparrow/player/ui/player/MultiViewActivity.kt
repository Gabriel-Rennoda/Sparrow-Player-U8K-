package com.sparrow.player.ui.player

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaCodecList
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.ui.PlayerView
import com.sparrow.player.data.Channel
import com.sparrow.player.data.ErrorLog
import com.sparrow.player.data.Repository
import com.sparrow.player.data.XtreamClient
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp
import com.sparrow.player.util.repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Split screen: 2 to 4 live channels at once (picked with Channel menu -> Add To Split Screen).
 *  Arrows move between tiles and the sound follows the highlighted tile (the others have their audio track switched off, which also
 *  saves a decoder). OK = that channel full screen. Back = leave.
 *  Limits: one provider connection per tile (read from the account, Xtream only), each tile capped to 720p (2 tiles) / 540p (3-4).
 */
@OptIn(UnstableApi::class)
class MultiViewActivity : FragmentActivity() {
    private class Tile(val frame: FrameLayout, val view: PlayerView, val label: TextView, val status: TextView, val channel: Channel) {
        var player: ExoPlayer? = null
        var retries = 0
        var software = false
        var decoder = "?"
        var mime: String? = null
        var width = 0
        var height = 0
        var dropped = 0L
        var gaveUp = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tiles = ArrayList<Tile>()
    private var sel = 0
    private var stopped = false
    private var height = 540
    private lateinit var hint: TextView
    private val hideHint = Runnable { hint.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        MainActivity.stopMini()                       // the Live screen's mini player must not keep a stream (and a connection) open
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); keepScreenOn = true }
        setContentView(root)
        hint = TextView(this).apply {
            text = "Arrows: choose a tile (sound follows)   ·   OK: full screen   ·   Back: leave"
            setTextColor(Color.WHITE); textSize = 16f; setBackgroundColor(0xAA000000.toInt()); setPadding(dp(18), dp(8), dp(18), dp(8))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(24) }
        }

        val uids = intent.getStringArrayExtra("uids")?.toList() ?: SplitQueue.uids
        lifecycleScope.launch {
            val r = applicationContext.repo
            val prov = r.activeProvider() ?: return@launch finish()
            val picked = ArrayList<Channel>()
            for (u in uids) {
                val ch = r.dao.channel(u) ?: continue
                picked += ch.copy(name = r.custom(ch.providerId).nameOf(ch.uid, ch.name))
            }
            val limit = if (prov.type == "xtream") withContext(Dispatchers.IO) {
                try { XtreamClient(r.http, prov).maxConnections() } catch (e: Exception) { 0 }
            } else 0
            val n = SplitMath.allowed(picked.size, limit)
            ErrorLog.add("SPLIT", "picked ${picked.size}, provider connection limit " + (if (limit > 0) limit.toString() else "unknown") +
                ", showing $n, hardware H.264 decoder instances reported by this TV: ${decoderInstances()}, decoding mode: ${r.prefs.splitDecode}")
            ErrorLog.add("SPLIT", "video decoders on this TV: " + decoderReport())
            if (n < 2) {
                Toast.makeText(this@MultiViewActivity, if (picked.size < 2) "Pick at least 2 channels first" else "Your account allows only $limit connection – split screen needs 2 or more", Toast.LENGTH_LONG).show()
                return@launch finish()
            }
            if (n < picked.size) Toast.makeText(this@MultiViewActivity, "Your account allows $limit connections – showing the first $n channels", Toast.LENGTH_LONG).show()
            height = SplitMath.tileHeight(n)
            build(root, picked.take(n))
            root.addView(hint)
            handler.postDelayed(hideHint, 6000)
            if (!stopped) startAll()
        }
    }

    /** Best guess of how many hardware H.264 decoders the TV can run at once (diagnostic only - it is logged, never used to block). */
    private fun decoderInstances(): Int = try {
        var best = 0
        for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
            if (info.isEncoder || info.supportedTypes.none { it.equals("video/avc", true) }) continue
            if (Build.VERSION.SDK_INT >= 29 && !info.isHardwareAccelerated) continue
            val n = info.getCapabilitiesForType("video/avc").maxSupportedInstances
            if (n > best) best = n
        }
        best
    } catch (e: Exception) { 0 }

    /** Names of every H.264 / HEVC video decoder with hardware / software and the instance limit it reports. */
    private fun decoderReport(): String = try {
        val out = ArrayList<String>()
        for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
            if (info.isEncoder) continue
            for (m in info.supportedTypes) {
                if (!m.equals("video/avc", true) && !m.equals("video/hevc", true)) continue
                val inst = try { info.getCapabilitiesForType(m).maxSupportedInstances } catch (e: Exception) { -1 }
                val hw = if (Build.VERSION.SDK_INT >= 29) ", hwAccel " + info.isHardwareAccelerated + ", vendor " + info.isVendor else ""
                val fps = try { info.getCapabilitiesForType(m).videoCapabilities?.getSupportedFrameRatesFor(1920, 1080)?.upper?.toInt() ?: -1 } catch (e: Exception) { -1 }
                out += info.name + " [" + m.removePrefix("video/") + ", " + (if (SplitMath.isSoftwareDecoder(info.name)) "software" else "hardware") + ", max " + inst + hw + ", 1080p up to " + fps + " fps]"
            }
        }
        val regular = HashSet<String>()
        for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) regular += info.name
        val extra = ArrayList<String>()
        for (info in MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos) {
            if (info.isEncoder || info.name in regular) continue
            if (info.supportedTypes.any { it.equals("video/avc", true) || it.equals("video/hevc", true) }) extra += info.name
        }
        out.joinToString("; ") + (if (extra.isNotEmpty()) "  |  EXTRA decoders only in the full codec list: " + extra.joinToString(", ") else "")
    } catch (e: Exception) { "unknown" }

    private fun build(root: FrameLayout, list: List<Channel>) {
        val n = list.size
        val cols = SplitMath.cols(n)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var i = 0
        for (r in 0 until SplitMath.rows(n)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                if (i >= n) break
                val ch = list[i]
                val frame = FrameLayout(this)
                val pv = PlayerView(this).apply { useController = false }
                val label = TextView(this).apply {
                    setTextColor(Color.WHITE); textSize = 16f; maxLines = 1
                    setBackgroundColor(0x99000000.toInt()); setPadding(dp(10), dp(4), dp(10), dp(4))
                }
                val status = TextView(this).apply {
                    setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
                    setBackgroundColor(0x99000000.toInt()); setPadding(dp(12), dp(8), dp(12), dp(8)); visibility = View.GONE
                }
                frame.addView(pv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                frame.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
                frame.addView(status, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
                row.addView(frame, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).also { it.setMargins(dp(2), dp(2), dp(2), dp(2)) })
                tiles += Tile(frame, pv, label, status, ch)
                i++
            }
            // a lone tile in the last row (3 channels) takes the whole row
            grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        root.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        paintSelection()
    }

    private fun paintSelection() {
        tiles.forEachIndexed { i, t ->
            val on = i == sel
            t.frame.foreground = if (on) GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(4), Theme.accent) } else null
            t.label.text = (if (on) "♪ " else "") + (if (repoNumbers()) "${t.channel.number}  " else "") + t.channel.name
            t.player?.let { setSound(it, on) }
        }
    }

    private fun repoNumbers(): Boolean = applicationContext.repo.prefs.showNumbers

    /** Sound only on the highlighted tile: the others have their audio track switched off. */
    private fun setSound(p: ExoPlayer, on: Boolean) {
        p.volume = if (on) 1f else 0f
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, !on).build()
    }

    // ---- Playback ----------------------------------------------------------------------------
    private fun startAll() {
        tiles.forEachIndexed { i, t ->
            if (t.player != null || t.gaveUp) return@forEachIndexed
            attach(t, i)
            val p = t.player
            // staggered (3 s apart): tile 1 must be running before the next decoder is created, so a new decoder cannot steal it
            handler.postDelayed({ if (t.player === p) load(t) }, 3000L * i)
        }
        handler.postDelayed({ statsTick(1) }, 6000)
    }

    /** Builds the player for one tile with the decoder type chosen by Settings -> Playback -> Split Screen Decoding. */
    private fun attach(t: Tile, i: Int) {
        t.software = SplitMath.softwareFirst(i, t.retries, applicationContext.repo.prefs.splitDecode)
        t.decoder = "?"; t.mime = null; t.width = 0; t.height = 0
        val p = PlayerFactory.create(this, height, t.software)
        t.player = p
        t.view.player = p
        setSound(p, i == sel)
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onVideoDecoderInitialized(eventTime: AnalyticsListener.EventTime, decoderName: String, initializedTimestampMs: Long, initializationDurationMs: Long) {
                t.decoder = decoderName
                ErrorLog.add("SPLIT", "tile \"${t.channel.name}\" video decoder: $decoderName (software tried first: ${t.software}, is software: ${SplitMath.isSoftwareDecoder(decoderName)})")
                checkConflict(t)
            }
            override fun onVideoInputFormatChanged(eventTime: AnalyticsListener.EventTime, format: Format, decoderReuseEvaluation: DecoderReuseEvaluation?) {
                t.mime = format.sampleMimeType; t.width = format.width; t.height = format.height
                ErrorLog.add("SPLIT", "tile \"${t.channel.name}\" stream: ${format.sampleMimeType} ${format.width}x${format.height} ${if (format.frameRate > 0) format.frameRate.toString() + " fps" else ""}")
                checkConflict(t)
            }
            override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) { t.dropped += droppedFrames }
        })
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) = tileError(t, error)
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { t.retries = 0; if (!t.gaveUp) t.status.visibility = View.GONE }
                else if (state == Player.STATE_BUFFERING && t.retries == 0 && !t.gaveUp) { t.status.text = "Loading…"; t.status.visibility = View.VISIBLE }
            }
        })
    }

    private fun load(t: Tile) {
        val p = t.player ?: return
        p.setMediaItem(MediaItem.fromUri(applicationContext.repo.liveUrl(t.channel)))
        p.prepare(); p.playWhenReady = true
    }

    /** Every 5 s for the first 30 s: what each tile is decoding and how many frames it dropped (a frozen picture = many dropped frames). */
    private fun statsTick(n: Int) {
        if (stopped) return
        tiles.forEach { t ->
            val p = t.player ?: return@forEach
            val st = when (p.playbackState) { Player.STATE_READY -> "ready"; Player.STATE_BUFFERING -> "buffering"; Player.STATE_IDLE -> "idle"; else -> "ended" }
            ErrorLog.add("SPLIT", "tile \"${t.channel.name}\" after ${n * 5}s: $st, ${t.mime ?: "?"} ${t.width}x${t.height}, decoder ${t.decoder}, dropped frames so far ${t.dropped}")
            if (!t.gaveUp && SplitMath.softwareTooSlow(SplitMath.isSoftwareDecoder(t.decoder), t.dropped))
                giveUp(t, "This TV's CPU cannot decode ${t.width}x${t.height} fast enough (software decoder dropped ${t.dropped} frames). Use a lower-resolution channel here.")
        }
        if (n < 6) handler.postDelayed({ statsTick(n + 1) }, 5000)
    }

    private fun mimeLabel(mime: String?) = when (mime) { "video/hevc" -> "4K / HEVC"; "video/avc" -> "H.264"; null -> "video"; else -> mime.orEmpty().removePrefix("video/").uppercase() }

    /**
     * This TV has no software decoder for HEVC (4K) and runs only one hardware decoder per format: a second tile of the same format
     * would steal the first one's decoder and they would break each other in turn. The later tile steps aside; tile 1 keeps playing.
     */
    private fun checkConflict(t: Tile) {
        if (t.gaveUp || applicationContext.repo.prefs.splitDecode == "hardware") return
        val mime = t.mime ?: return
        if (t.decoder == "?" || SplitMath.isSoftwareDecoder(t.decoder)) return
        if (tiles.indexOf(t) <= 0) return
        val other = tiles.any { o -> o !== t && !o.gaveUp && o.player != null && o.mime == mime && o.decoder != "?" && !SplitMath.isSoftwareDecoder(o.decoder) }
        if (other) giveUp(t, "This TV can show only one ${mimeLabel(mime)} channel at a time in split screen. Pick HD (H.264) channels for the other tiles.")
    }

    private fun giveUp(t: Tile, message: String) {
        t.gaveUp = true
        ErrorLog.add("SPLIT", "tile \"${t.channel.name}\" stopped: $message (decoder ${t.decoder}, ${t.mime} ${t.width}x${t.height})")
        t.status.text = message; t.status.visibility = View.VISIBLE
        handler.post { t.view.player = null; t.player?.release(); t.player = null }
    }

    private fun tileError(t: Tile, error: PlaybackException) {
        if (t.gaveUp) return
        t.retries++
        val refused = error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS
        ErrorLog.add("PLAYBACK", "split-screen tile \"${t.channel.name}\" | ${error.errorCodeName} (${error.errorCode}) | ${error.message ?: ""} | cause: ${error.cause?.message ?: "none"} | decoder ${t.decoder} (software first: ${t.software}) | attempt ${t.retries} of 4")
        val decoderFailure = error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED || error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
            error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
        if (decoderFailure && applicationContext.repo.prefs.splitDecode == "hardware") {
            // the TV ran out of hardware decoders: the newest hardware tile of this format steps aside, the others keep (or retry) their decoder
            val loser = tiles.lastOrNull { !it.gaveUp && it.player != null && it.decoder != "?" && !SplitMath.isSoftwareDecoder(it.decoder) && (it.mime == t.mime || it === t) } ?: t
            giveUp(loser, "This TV has no free hardware decoder for another ${mimeLabel(loser.mime)} tile (hardware-only mode). Try Auto, or fewer tiles.")
            if (loser === t) return
        }
        if (t.retries <= 4) {
            t.status.text = "Retrying (${t.retries}/4)…"; t.status.visibility = View.VISIBLE
            val old = t.player
            val i = tiles.indexOf(t)
            // a decoder failure is not fixed by loading again: rebuild the player with the other decoder type (software <-> hardware)
            t.view.player = null; old?.release(); t.player = null
            handler.postDelayed({ if (!stopped && !t.gaveUp && t.player == null) { attach(t, i); load(t) } }, 1500)
        } else {
            t.status.text = if (refused) "The provider refused this stream (connection limit?)" else "Cannot play this channel"
            t.status.visibility = View.VISIBLE
        }
    }

    private fun releaseAll() {
        handler.removeCallbacksAndMessages(null)
        tiles.forEach { t -> t.view.player = null; t.player?.release(); t.player = null }
    }

    // ---- Keys --------------------------------------------------------------------------------
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (tiles.isEmpty()) return super.onKeyDown(keyCode, event)
        val (dx, dy) = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> -1 to 0
            KeyEvent.KEYCODE_DPAD_RIGHT -> 1 to 0
            KeyEvent.KEYCODE_DPAD_UP -> 0 to -1
            KeyEvent.KEYCODE_DPAD_DOWN -> 0 to 1
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> { event.startTracking(); return true }
            else -> return super.onKeyDown(keyCode, event)
        }
        val to = SplitMath.move(sel, tiles.size, dx, dy)
        if (to != sel) { sel = to; paintSelection() }
        hint.visibility = View.GONE
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) &&
            event.isTracking && !event.isCanceled && tiles.isNotEmpty()) {
            startActivity(PlayerActivity.live(this, tiles[sel].channel.uid, Repository.SCOPE_ALL))
            finish(); return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // ---- Lifecycle ---------------------------------------------------------------------------
    override fun onStop() { super.onStop(); stopped = true; releaseAll() }

    override fun onStart() {
        super.onStart()
        if (stopped) { stopped = false; tiles.forEach { it.gaveUp = false; it.dropped = 0 }; if (tiles.isNotEmpty()) startAll() }
    }

    override fun onDestroy() { releaseAll(); super.onDestroy() }

    companion object {
        fun intent(ctx: Context) = Intent(ctx, MultiViewActivity::class.java).putExtra("uids", SplitQueue.uids.toTypedArray())
    }
}
