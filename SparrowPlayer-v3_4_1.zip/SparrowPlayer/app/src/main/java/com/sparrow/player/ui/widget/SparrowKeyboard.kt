package com.sparrow.player.ui.widget

import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp

/**
 * v3.3.0: Sparrow Player's own on-screen keyboard, made for a remote (the TV's keyboard cannot be controlled: Up on its top row always went on to its number
 * row and out into the menu behind). It docks at the bottom of the screen and types straight into the text box [edit]:
 *  - Left / Right / Up / Down move the selector; Up on the top letter row STAYS (nothing leaves the keyboard);
 *  - press and HOLD Up on the top letter row to open the number row; press and HOLD OK on a top-row letter to type its number instead;
 *  - OK types; Done (or Back) closes it. Done also runs the box's own action (Next / Go) like the TV keyboard did.
 */
class SparrowKeyboard private constructor(private val edit: EditText, private val onClosed: () -> Unit) {
    private val ctx = edit.context
    private val numericOnly = (edit.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER
    private val secret = edit.transformationMethod is android.text.method.PasswordTransformationMethod
    private val wantsCaps = (edit.inputType and (InputType.TYPE_TEXT_FLAG_CAP_WORDS or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)) != 0

    private val dialog = Dialog(ctx)
    private val preview = TextView(ctx)
    private val hint = TextView(ctx)
    private val board = LinearLayout(ctx)
    private var symbols = false
    // v3.4.0: 0 = off, 1 = the next letter only, 2 = caps lock (double-click Shift; Shift again turns it off)
    private var shiftState = if (wantsCaps && capitalAtCaret()) 1 else 0
    private var lastShiftAt = 0L
    private val shift: Boolean get() = shiftState != 0
    private var nav = build()
    private val caps = ArrayList<List<TextView>>()          // the key views of the current layer, row by row
    private val altViews = ArrayList<List<TextView>>()      // v3.4.0: the small "hold OK" character at the top right of each key
    private val rowViews = ArrayList<LinearLayout>()
    private var holdFromTop = false                        // the current Up press started on the top letter row
    private var swapPending = false                         // a key with a small alternate was just typed by this OK press: holding OK turns it into that alternate
    private var swapKey: Key? = null

    private fun layout(): List<List<Key>> = if (numericOnly) KeyboardLayouts.numeric() else if (symbols) KeyboardLayouts.symbols() else KeyboardLayouts.letters()
    // v3.4.0: the 123 # layer shows its number row all the time, so only the letter layer has the hidden one
    private fun build() = KeyboardNav(layout(), hasNumberRow = !numericOnly && !symbols)

    /** v3.4.0: a name starts with a capital also when the text is edited (rename): the caret is at the start or right after a space. */
    private fun capitalAtCaret(): Boolean {
        val t = edit.text?.toString() ?: return true
        var a = edit.selectionStart; if (a < 0) a = t.length
        if (a > t.length) a = t.length
        return a == 0 || t[a - 1].isWhitespace()
    }

    fun show() {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(40), ctx.dp(12), ctx.dp(40), ctx.dp(16))
            background = GradientDrawable().apply { setColor(Theme.surface) }
        }
        preview.apply { textSize = 22f; setTextColor(Theme.text); setSingleLine(true); setPadding(ctx.dp(12), ctx.dp(6), ctx.dp(12), ctx.dp(6)); gravity = Gravity.CENTER_VERTICAL
            ellipsize = android.text.TextUtils.TruncateAt.START }
        hint.apply { textSize = 13f; setTextColor(Theme.textDim); setPadding(ctx.dp(12), 0, ctx.dp(12), ctx.dp(6))
            text = if (numericOnly) "OK types  •  Back closes" else "Hold ▲ for numbers  •  hold OK on a key for its small symbol  •  double-click ⇧ = caps lock  •  Back closes" }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        board.orientation = LinearLayout.VERTICAL
        root.addView(board, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dialog.setContentView(root)
        dialog.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.35f)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        }
        dialog.setOnKeyListener { _, code, ev -> onKey(code, ev) }
        dialog.setOnDismissListener { onClosed() }
        rebuild()
        dialog.show()
    }

    fun dismiss() { if (dialog.isShowing) dialog.dismiss() }
    val isShowing: Boolean get() = dialog.isShowing

    // ---- drawing ------------------------------------------------------------------------------------------------------------
    private fun rebuild() {
        board.removeAllViews(); caps.clear(); altViews.clear(); rowViews.clear()
        nav.rows.forEachIndexed { ri, row ->
            val lin = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val views = ArrayList<TextView>()
            val alts = ArrayList<TextView>()
            for (k in row) {
                val cell = FrameLayout(ctx)
                val tv = TextView(ctx).apply { gravity = Gravity.CENTER; textSize = 22f; setTypeface(typeface, Typeface.BOLD); setSingleLine(true) }
                cell.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                val alt = TextView(ctx).apply { textSize = 12f; setTypeface(typeface, Typeface.BOLD); setSingleLine(true); text = k.alt ?: "" }
                cell.addView(alt, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { setMargins(0, ctx.dp(2), ctx.dp(5), 0) })
                lin.addView(cell, LinearLayout.LayoutParams(0, ctx.dp(46), k.w.toFloat()).apply { setMargins(ctx.dp(3), ctx.dp(3), ctx.dp(3), ctx.dp(3)) })
                views += tv; alts += alt
            }
            board.addView(lin, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            rowViews += lin; caps += views; altViews += alts
        }
        refresh()
    }

    private fun refresh() {
        rowViews.forEachIndexed { ri, lin -> lin.visibility = if (ri == 0 && nav.hasNumberRow && !nav.numbersOpen) View.GONE else View.VISIBLE }
        nav.rows.forEachIndexed { ri, row ->
            row.forEachIndexed { ci, k ->
                val tv = caps[ri][ci]
                val selected = ri == nav.r && ci == nav.c
                tv.text = when {
                    k.fn == Fn.SHIFT -> when (shiftState) { 2 -> "CAPS"; 1 -> "⇪"; else -> "⇧" }
                    k.out != null && k.fn == null && k.out.length == 1 && k.out[0].isLetter() && shift -> k.label.uppercase()
                    else -> k.label
                }
                tv.setTextColor(if (selected) Color.BLACK else Theme.text)
                altViews[ri][ci].setTextColor(if (selected) Color.BLACK else Theme.textDim)
                tv.background = GradientDrawable().apply {
                    cornerRadius = ctx.dp(8).toFloat()
                    setColor(if (selected) Theme.accent else if (k.fn != null && k.fn != Fn.SPACE) Theme.surface2 else Color.argb(40, 255, 255, 255))
                }
            }
        }
        val t = edit.text?.toString() ?: ""
        preview.text = (if (secret) "•".repeat(t.length) else t) + "▏"
    }

    // ---- keys ---------------------------------------------------------------------------------------------------------------
    private fun onKey(code: Int, ev: KeyEvent): Boolean {
        if (code == KeyEvent.KEYCODE_BACK) { if (ev.action == KeyEvent.ACTION_UP) dismiss(); return true }
        val down = ev.action == KeyEvent.ACTION_DOWN
        when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { if (down) { nav.left(); refresh() }; return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { if (down) { nav.right(); refresh() }; return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { if (down) { nav.down(); refresh() }; return true }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (down) {
                    // a tap never leaves the letters; only Up HELD on the top letter row (the remote's key repeat) opens the number row
                    if (ev.repeatCount == 0) { holdFromTop = nav.r == 1 && !nav.numbersOpen; nav.up() }
                    else if (holdFromTop && ev.repeatCount >= 1) nav.revealNumbers()
                    refresh()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (down) {
                    if (ev.repeatCount == 0) { val k = nav.key(); press(k); swapKey = k; swapPending = k.fn == null && k.alt != null }
                    else if (ev.repeatCount == 1 && swapPending) { swapToAlt(); swapPending = false }
                }
                return true
            }
            // v3.4.0: the box changed but the line above the keys was not redrawn (an AIR-mouse remote sends Backspace as DEL): redraw it now
            KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_FORWARD_DEL -> { if (down) { backspace(); refresh() }; return true }
        }
        // a real (USB / Bluetooth) keyboard types directly
        if (down) {
            val u = ev.unicodeChar
            if (u > 0 && !ev.isCtrlPressed && !ev.isAltPressed) { type(String(Character.toChars(u))); refresh(); return true }
        }
        return false
    }

    private fun press(k: Key) {
        when (k.fn) {
            Fn.SHIFT -> {
                val now = System.currentTimeMillis()
                shiftState = when {
                    shiftState == 2 -> 0                                  // caps lock off
                    now - lastShiftAt < 500 -> 2                          // double-click: caps lock
                    shiftState == 1 -> 0
                    else -> 1
                }
                lastShiftAt = now
            }
            Fn.SYMBOLS -> { symbols = true; nav = build(); rebuild() ; return }
            Fn.LETTERS -> { symbols = false; nav = build(); rebuild(); return }
            Fn.BACKSPACE -> backspace()
            Fn.DONE -> { finish(); return }
            else -> {
                val out = k.out ?: return
                val t = if (shift && out.length == 1 && out[0].isLetter()) out.uppercase() else out
                type(t)
                if (shiftState != 2) shiftState = if (wantsCaps && t == " ") 1 else 0          // one capital at a time (caps lock stays); names get a capital after each space
            }
        }
        refresh()
    }

    /** Holding OK on a key replaces the character just typed by the key's small alternate (q -> 1, a -> @ ...). */
    private fun swapToAlt() {
        val d = swapKey?.alt ?: return
        backspace(); type(d); refresh()
    }

    private fun type(s: String) {
        val e = edit.text ?: return
        var a = edit.selectionStart; var b = edit.selectionEnd
        if (a < 0) a = e.length; if (b < 0) b = e.length
        if (a > b) { val t = a; a = b; b = t }
        e.replace(a, b, s)
        edit.setSelection((a + s.length).coerceAtMost(e.length))
    }

    private fun backspace() {
        val e = edit.text ?: return
        var a = edit.selectionStart; var b = edit.selectionEnd
        if (a < 0) a = e.length; if (b < 0) b = e.length
        if (a > b) { val t = a; a = b; b = t }
        if (a != b) { e.delete(a, b); edit.setSelection(a) }
        else if (a > 0) { e.delete(a - 1, a); edit.setSelection(a - 1) }
    }

    private fun finish() {
        dismiss()
        // like the TV keyboard's action key: Next moves on, Go / Done run the box's own listener
        val action = edit.imeOptions and EditorInfo.IME_MASK_ACTION
        if (action != EditorInfo.IME_ACTION_UNSPECIFIED && action != EditorInfo.IME_ACTION_NONE) edit.post { edit.onEditorAction(action) }
    }

    companion object {
        fun open(edit: EditText, onClosed: () -> Unit): SparrowKeyboard = SparrowKeyboard(edit, onClosed).also { it.show() }
    }
}
