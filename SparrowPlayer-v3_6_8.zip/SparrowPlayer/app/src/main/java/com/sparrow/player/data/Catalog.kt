package com.sparrow.player.data

/**
 * Everything the Movies / Series screens and search need about ONE kind of title (movies or series) of ONE provider, read from the
 * database once and kept in memory: the light columns of every title ([VodLite], no plot / stream url), the [RowTitle]s the carousel builder
 * works on, and a few orders (newest, best rated, newest per category). For a 30 000 - 100 000 title catalogue the old code read all
 * of it again - every column, several times - each time a tab, a group or the search was opened, which is what made them crawl.
 *
 * Built in the background (see Repository.catalog) when the app starts and after every sync, so by the time a tab is opened it is ready.
 * Pure Kotlin (no Android types): unit tested.
 */
class VodCatalog private constructor(
    val providerId: Long,
    val type: String,
    val items: List<VodLite>,
    val titles: List<RowTitle>,
    val categoryNames: Map<String, String>,
    /** group[i] = index of the first entry that is the same title (name + year): copies of one film listed in several categories share it. */
    val group: IntArray = IntArray(items.size) { it },
    /** kidsOnly[i]: made for children (see [RowTitle.kidsOnly]). */
    val kidsOnly: BooleanArray = BooleanArray(items.size)
) {
    private val pos = HashMap<String, Int>(items.size * 2)
    init { items.forEachIndexed { i, v -> pos[v.uid] = i } }

    val size: Int get() = items.size

    fun indexOf(uid: String): Int = pos[uid] ?: -1
    fun lite(uid: String): VodLite? = pos[uid]?.let { items[it] }
    fun title(uid: String): RowTitle? = pos[uid]?.let { titles[it] }

    /** A card / row item. Plot, backdrop and stream url are left empty: the details screen reads the full row by uid. */
    fun item(v: VodLite): VodItem =
        VodItem(v.uid, providerId, v.uid.substringAfterLast(':'), type, v.name, v.poster, "", v.categoryId, v.rating, v.year, "", v.added, "", v.genre, "")

    fun items(uids: List<String>): List<VodItem> {
        val out = ArrayList<VodItem>(uids.size)
        for (u in uids) { val i = pos[u]; if (i != null) out += item(items[i]) }
        return out
    }

    private val genreSets = HashMap<String, Set<String>>()
    fun rec(v: VodLite): Recommender.Item {
        val g = synchronized(genreSets) { genreSets.getOrPut(v.genre) { Recommender.genresOf(v.genre) } }
        return Recommender.Item(v.uid, v.categoryId, g, Recommender.yearOf(v.year), Recommender.ratingOf(v.rating))
    }

    // ---- orders (built on first use, then shared) -----------------------------------------------------------------------
    private val byAdded: IntArray by lazy {
        items.indices.sortedWith(compareByDescending<Int> { items[it].added }.thenBy { it }).toIntArray()
    }
    private val byRating: IntArray by lazy {
        items.indices.sortedWith(compareByDescending<Int> { titles[it].rating }.thenByDescending { items[it].added }.thenBy { it }).toIntArray()
    }
    private val perCategory: Map<String, IntArray> by lazy {
        val m = HashMap<String, MutableList<Int>>()
        for (i in byAdded) m.getOrPut(items[i].categoryId) { ArrayList() }.add(i)
        m.mapValues { it.value.toIntArray() }
    }

    fun recent(limit: Int): List<VodLite> = byAdded.take(limit).map { items[it] }
    fun topRated(limit: Int): List<VodLite> = byRating.take(limit).map { items[it] }
    fun inCategory(categoryId: String, limit: Int): List<VodLite> = (perCategory[categoryId] ?: IntArray(0)).take(limit).map { items[it] }
    fun categorySize(categoryId: String): Int = perCategory[categoryId]?.size ?: 0

    /** Newest titles whose genre text contains [genre] (case blind). */
    fun byGenre(genre: String, limit: Int): List<VodLite> {
        val out = ArrayList<VodLite>()
        for (i in byAdded) { if (items[i].genre.contains(genre, ignoreCase = true)) { out += items[i]; if (out.size >= limit) break } }
        return out
    }

    companion object {
        /** [plots]: uid + description of the titles that have one (series): holiday words in them count (see [Holidays.maskOf]). */
        fun build(providerId: Long, type: String, items: List<VodLite>, categoryNames: Map<String, String>, plots: List<UidPlot> = emptyList()): VodCatalog {
            val preps = HashMap<String, HashMap<String, RowTitle.Prep>>()
            val titles = ArrayList<RowTitle>(items.size)
            val norms = ArrayList<String>(items.size)
            for (v in items) {
                val cat = categoryNames[v.categoryId] ?: ""
                val prep = preps.getOrPut(v.categoryId) { HashMap() }.getOrPut(v.genre) { RowTitle.Prep.of(cat, v.genre) }
                val nn = TextNorm.prepare(v.name)
                val t = RowTitle(v.uid, v.name, cat, v.genre, Recommender.yearOf(v.year), Recommender.ratingOf(v.rating), v.added, prep)
                t.seedName(nn)
                t.holidays = Holidays.screen(prep.holidays, nn, prep.adult)
                t.genreIn = GenreRules.titleInBits(nn); t.genreOut = GenreRules.titleOutBits(nn)          // keyword filters on the title (see GenreRules)
                titles += t; norms += nn
            }

            // The same film listed in several provider categories (very common: "Action", "Comedy" and "New Releases" all carry it): one title that
            // has the genres of every copy. A title with no year only joins copies that carry the same provider rating.
            val group = IntArray(items.size) { it }
            val lead = HashMap<String, Int>(items.size)
            val members = HashMap<Int, ArrayList<Int>>()
            for (i in items.indices) {
                if (norms[i].length < 5) continue
                val y = titles[i].year
                val key = norms[i] + "|" + (if (y > 0) y.toString() else items[i].rating)
                val first = lead[key]
                if (first == null) lead[key] = i
                else { group[i] = first; members.getOrPut(first) { arrayListOf(first) }.add(i) }
            }
            val merged = HashMap<String, RowTitle.Prep>()
            for ((_, idx) in members) {
                val text = idx.map { titles[it].prep.prepared }.distinct().joinToString("")
                val cats = idx.map { titles[it].prep.categoryNorm }.distinct().joinToString("")
                val p = merged.getOrPut(text + "\u0001" + cats) { RowTitle.Prep.ofPrepared(text, cats) }
                for (i in idx) {
                    val t = titles[i]
                    t.mergePrep(p)
                    t.holidays = Holidays.screen(p.holidays, norms[i], p.adult)
                }
            }
            for (i in items.indices) titles[i].group = group[i]

            // children's titles: a Kids category (or well-known children's name) that passes the age screen
            val kidsMain = Genres.mainOf("kids")!!
            val kidsText = HashMap<RowTitle.Prep, Boolean>()
            val kids = BooleanArray(items.size)
            val series = type == "series"
            for (i in items.indices) {
                val t = titles[i]
                val inKids = kidsText.getOrPut(t.prep) { Genres.classify(kidsMain, t.prepared).inMain } || Maturity.isKidsTitle(norms[i])
                if (inKids && Maturity.kidsEvidence(t, "") && Maturity.familyOk(t, "", series)) { kids[i] = true; t.kidsOnly = true }
            }

            val c = VodCatalog(providerId, type, items, titles, categoryNames, group, kids)
            for (p in plots) {
                val i = c.indexOf(p.uid)
                if (i >= 0) titles[i].let { t ->
                    val pp = TextNorm.prepare(p.plot)
                    t.holidays = Holidays.withPlot(t.holidays, norms[i], t.prep.adult, pp)
                    t.genreIn = t.genreIn or GenreRules.plotInBits(pp)                                       // keyword filters on the description
                    t.genreOut = t.genreOut or GenreRules.plotOutBits(norms[i], pp)
                    // v3.2.0: a description that says it is for children / preschoolers also puts the title in Kids (when the age screen passes it)
                    if (!kids[i] && Maturity.plotKidsSign(pp) && !Maturity.isAdultTitle(norms[i]) && Maturity.familyOk(t, "", series)) { kids[i] = true; t.kidsOnly = true }
                }
            }
            return c
        }
    }
}

/** The page of one genre or sub-genre, and the holiday lists, worked out from a [VodCatalog]. Pure Kotlin. */
object Pages {
    const val SUB = "#"

    /** "genre:family" -> main "family", sub null; "genre:family#3" -> ("family", 3). */
    fun parseGenreScope(scope: String): Pair<String, Int?> {
        val rest = scope.removePrefix(Genres.SCOPE_PREFIX)
        val sub = rest.substringAfter(SUB, "").toIntOrNull()
        return rest.substringBefore(SUB) to sub
    }

    fun genreScope(mainId: String, sub: Int? = null): String = Genres.SCOPE_PREFIX + mainId + (if (sub != null) SUB + sub else "")

    /** Pairs of main genres whose shared titles get a carousel of their own on BOTH pages (an action comedy is in Action, in Comedies and in "Action Comedies"). */
    private val COMBOS: List<Triple<String, String, String>> = listOf(
        Triple("action", "comedies", "Action Comedies"), Triple("action", "scifi", "Action Sci-Fi & Fantasy"), Triple("action", "thrillers", "Action Thrillers"),
        Triple("action", "crime", "Crime Action & Adventure"), Triple("action", "war", "Military Action & Adventure"), Triple("action", "dramas", "Action Dramas"),
        Triple("comedies", "romance", "Romantic Comedies"), Triple("comedies", "horror", "Horror Comedies"), Triple("comedies", "crime", "Crime Comedies"),
        Triple("comedies", "dramas", "Comedy Dramas"), Triple("comedies", "scifi", "Sci-Fi Comedies"), Triple("comedies", "family", "Family Comedies"),
        Triple("crime", "dramas", "Crime Dramas"), Triple("crime", "thrillers", "Crime Thrillers"), Triple("crime", "mysteries", "Crime Mysteries"),
        Triple("crime", "documentaries", "Crime Documentaries"), Triple("dramas", "romance", "Romantic Dramas"), Triple("dramas", "war", "War Dramas"),
        Triple("dramas", "thrillers", "Dramatic Thrillers"), Triple("dramas", "sports", "Sports Dramas"), Triple("horror", "thrillers", "Horror Thrillers"),
        Triple("horror", "scifi", "Sci-Fi Horror"), Triple("horror", "mysteries", "Horror Mysteries"), Triple("scifi", "thrillers", "Sci-Fi Thrillers"),
        Triple("scifi", "dramas", "Sci-Fi Dramas"), Triple("mysteries", "thrillers", "Mystery Thrillers"), Triple("documentaries", "war", "War Documentaries"),
        Triple("documentaries", "music", "Music Documentaries"), Triple("documentaries", "sports", "Sports Documentaries"), Triple("music", "family", "Family Musicals"),
        Triple("family", "scifi", "Family Sci-Fi & Fantasy"), Triple("family", "action", "Family Adventures"), Triple("westerns", "action", "Action Westerns")
    )

    fun standUpName(t: RowTitle) = t.nameNorm.contains(" stand up ") || t.nameNorm.contains(" standup ") || t.nameNorm.contains(" comedy special ")

    /**
     * A main genre, as ONE page: Top Rated, Recently Added, then one carousel per sub-genre that has titles (Action Comedies, Martial Arts ...),
     * one per pair of genres a title is filed under twice (Action + Comedy = "Action Comedies"), then the provider's own categories inside it.
     * A sub-genre ([sub] = index in [Genres.Main.subs]) can still be asked for on its own.
     *
     * Kids and Family are separate pages. Both only keep titles that pass [Maturity.familyOk] (what fails is simply left to the grown-up genres its
     * own text names). Kids also takes well-known children's titles ([Maturity.isKidsTitle]) whose panel text says nothing, and it has a carousel for
     * every genre its titles have (Kids -> Action & Adventure ...). Titles made for children stay out of the other genre pages ([VodCatalog.kidsOnly]).
     * Stand-Up Comedy also finds titles by name and gets its own carousels (new, by decade, specials). A film listed under several provider categories
     * is one card (the copy with a poster). [known]: uid -> rating the panel gave.
     */
    /** Decides which titles are on the page of one genre (or sub-genre): the genre / category text, the keyword filters of [GenreRules], the age screen, the Kids split. */
    class Picker(private val cat: VodCatalog, private val main: Genres.Main, private val sub: Int?, private val known: Map<String, String>) {
        private val series = cat.type == "series"
        val isKids = main.id == "kids"
        val screened = isKids || main.id == "family" || main.id == "kidsanim" || main.id == "familyanim"
        private val standup = main.id == "standup" || main.id == "comedies"
        private val isAnim = main.id == "kidsanim" || main.id == "familyanim"
        private val bit: Int = GenreRules.indexOf(main.id).let { if (it in 0..30) 1 shl it else 0 }
        private val cache = HashMap<RowTitle.Prep, Genres.Match>()

        /**
         * Kids Animation / Family Animation: animated (genre / category text says so, or a title phrase of this page's [GenreRules]) AND passes the age screen.
         * Kids Animation = made for children (a Kids title) or a children's cartoon by name; Family Animation = animated and not Anime / adult animation
         * (children's cartoons may be here too). Anime and "adult animation" never; the OUT phrases of [GenreRules] were applied by the caller.
         */
        private fun acceptAnimation(i: Int, t: RowTitle): Genres.Match? {
            if (sub != null) return null
            if (TextNorm.hasAny(t.prepared, Genres.NOT_ANIM)) return null
            if (!Maturity.familyOk(t, known[t.uid] ?: "", series)) return null
            val byRule = bit != 0 && (t.genreIn and bit) != 0
            val animated = byRule || TextNorm.hasAny(t.prepared, Genres.ANIM_WORDS)
            val ok = if (main.id == "kidsanim") byRule || (animated && cat.kidsOnly[i]) else animated
            return if (ok) Genres.Match(true, emptyList()) else null
        }

        /** The genre match of title [i], or null when the title is not on this page. */
        fun accept(i: Int): Genres.Match? {
            val t = cat.titles[i]
            if (bit != 0 && ((t.genreOut or t.prep.genreOut) and bit) != 0) return null           // a screen-out word / word set of this genre
            if (isAnim) return acceptAnimation(i, t)
            val m = cache.getOrPut(t.prep) { Genres.classify(main, t.prepared) }
            val byRule = bit != 0 && (t.genreIn and bit) != 0                                      // a title phrase / word set / description set of this genre
            val byName = sub == null && !m.inMain && (byRule || (isKids && (Maturity.isKidsTitle(t.nameNorm) || Maturity.animFamilyGenre(t.uid))) || (standup && standUpName(t)))
            if (!m.inMain && !byName) return null
            if (sub != null && sub !in m.subs) return null
            if (screened && !Maturity.familyOk(t, known[t.uid] ?: "", series)) return null
            if (isKids && !Maturity.kidsEvidence(t, known[t.uid] ?: "")) return null                  // v3.7.0: unrated + no kids sign = not Kids
            if (!screened && cat.kidsOnly[i]) return null                                          // made for children: it lives in Kids
            return m
        }
    }

    /** The titles of a genre page (what [genre] shows), for the named carousels of that page. One card per film. */
    fun genrePicks(cat: VodCatalog, main: Genres.Main, sub: Int?, known: Map<String, String>): List<RowTitle> {
        val pk = Picker(cat, main, sub, known)
        val out = ArrayList<RowTitle>()
        val seen = HashSet<Int>()
        for (i in cat.titles.indices) { if (pk.accept(i) != null && seen.add(cat.group[i])) out += cat.titles[i] }
        return out
    }

    fun genre(cat: VodCatalog, main: Genres.Main, sub: Int?, known: Map<String, String>): List<RowSpec> {
        val isKids = main.id == "kids"
        val screened = isKids || main.id == "family" || main.id == "kidsanim" || main.id == "familyanim"
        val standup = main.id == "standup" || main.id == "comedies"
        val picker = Picker(cat, main, sub, known)
        val pick = ArrayList<Int>()
        val bySub = HashMap<Int, MutableList<Int>>()
        val byMain = HashMap<String, MutableList<Int>>()
        for (i in cat.titles.indices) {
            val t = cat.titles[i]
            val m = picker.accept(i) ?: continue
            pick += i
            if (sub == null) {
                for (s in m.subs) bySub.getOrPut(s) { ArrayList() }.add(i)
                if (isKids) for (tag in t.tags) if (!tag.contains(':') && tag != "kids" && tag != "family") byMain.getOrPut(tag) { ArrayList() }.add(i)
            }
        }
        if (pick.isEmpty()) return emptyList()
        val label = if (sub != null) main.subs[sub].name else main.name
        val out = ArrayList<RowSpec>()
        val byRated = Comparator<Int> { x, y ->
            val r = cat.titles[y].rating.compareTo(cat.titles[x].rating)
            if (r != 0) r else cat.items[y].added.compareTo(cat.items[x].added)
        }
        val byNew = Comparator<Int> { x, y -> cat.items[y].added.compareTo(cat.items[x].added) }
        /** Titles of one row: sorted, one card per film (the copy with a poster wins), the first [max]. */
        fun uids(l: List<Int>, order: Comparator<Int>?, max: Int): List<String> {
            val best = LinkedHashMap<Int, Int>()
            for (i in if (order == null) l else l.sortedWith(order)) {
                val g = cat.group[i]; val cur = best[g]
                if (cur == null) best[g] = i
                else if (cat.items[cur].poster.isBlank() && cat.items[i].poster.isNotBlank()) best[g] = i
            }
            return best.values.take(max).map { cat.items[it].uid }
        }
        out += RowSpec("Top Rated in $label", uids(pick, byRated, HomeRows.FULL))
        out += RowSpec("Recently Added in $label", uids(pick, byNew, HomeRows.FULL))
        val seen = HashSet<String>()
        seen += out.map { it.title }
        if (sub == null) {
            // candidate carousels: (name, titles). The same name from two sources keeps the fuller list.
            val cand = LinkedHashMap<String, List<Int>>()
            fun offer(name: String, l: List<Int>) { if (l.size >= MIN_SUB && (cand[name]?.size ?: 0) < l.size) cand[name] = l }
            if (isKids) byMain.forEach { (id, l) -> Genres.mainOf(id)?.let { offer(it.name, l) } }
            if (standup && main.id == "standup") {
                val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
                offer("New Stand-Up", pick.filter { cat.titles[it].year >= year - 2 })
                offer("The 2010s", pick.filter { cat.titles[it].year in 2010..2019 })
                offer("The 2000s", pick.filter { cat.titles[it].year in 2000..2009 })
                offer("The 90s & Earlier", pick.filter { cat.titles[it].year in 1..1999 })
                offer("Comedy Specials", pick.filter { cat.titles[it].prepared.contains(" special ") || cat.titles[it].prepared.contains(" specials ") || standUpName(cat.titles[it]) && cat.titles[it].nameNorm.contains(" special ") })
            }
            for ((si, l) in bySub) offer(main.subs[si].name, l)
            if (!screened) for ((a, b, name) in COMBOS) {
                val other = if (main.id == a) b else if (main.id == b) a else continue
                offer(name, pick.filter { other in cat.titles[it].tags })
            }
            cand.entries.sortedWith(compareByDescending<Map.Entry<String, List<Int>>> { it.value.size }.thenBy { it.key })
                .take(MAX_SUB_ROWS).forEach { (name, l) -> if (seen.add(name)) out += RowSpec(name, uids(l, byRated, HomeRows.FULL)) }
        }
        val byCat = LinkedHashMap<String, MutableList<Int>>()
        for (i in pick) byCat.getOrPut(cat.items[i].categoryId) { ArrayList() }.add(i)
        val cap = if (screened) 600 else HomeRows.FULL                                  // the provider's own Kids / Family sections should show all their titles
        byCat.entries.filter { it.value.size >= 3 }.sortedByDescending { it.value.size }.take(if (sub != null) 8 else 12).forEach { (cid, l) ->
            val name = cat.categoryNames[cid] ?: ""
            if (name.isNotBlank() && seen.add(name)) out += RowSpec(name, uids(l, byNew, cap))
        }
        return out
    }

    const val MIN_SUB = 3
    const val MAX_SUB_ROWS = 24

    /** The Holidays list: for each holiday (calendar order from the next one) its Top 10 What's Hot; holidays without titles are left out. */
    fun holidayList(cat: VodCatalog, today: Int, canada: Boolean, nowMs: Long): List<Pair<Holidays.Dated, List<String>>> =
        Holidays.order(today, canada).map { d -> d to HomeRows.holidayTop10(d.holiday, cat.titles, nowMs) }.filter { it.second.isNotEmpty() }
}
