package com.sparrow.player.ui.player

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaCodecList
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.ui.PlayerView
import com.sparrow.player.data.Channel
import com.sparrow.player.data.ErrorLog
import com.sparrow.player.data.Repository
import com.sparrow.player.data.XtreamClient
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.dp
import com.sparrow.player.util.repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Split screen: 2 to 4 live channels at once (picked with Channel menu -> Add To Split Screen).
 *  Arrows move between tiles and the sound follows the highlighted tile (the others have their audio track switched off, which also
 *  saves a decoder). OK = that channel full screen. Back = leave.
 *  Limits: one provider connection per tile (read from the account, Xtream only), each tile capped to 720p (2 tiles) / 540p (3-4).
 */
class MultiViewActivity : FragmentActivity() {
    private class Tile(val frame: FrameLayout, val view: PlayerView, val label: TextView, val status: TextView, val channel: Channel) {
        var player: ExoPlayer? = null
        var retries = 0
        var software = false
        var decoder = "?"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tiles = ArrayList<Tile>()
    private var sel = 0
    private var stopped = false
    private var height = 540
    private lateinit var hint: TextView
    private val hideHint = Runnable { hint.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        MainActivity.stopMini()                       // the Live screen's mini player must not keep a stream (and a connection) open
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); keepScreenOn = true }
        setContentView(root)
        hint = TextView(this).apply {
            text = "Arrows: choose a tile (sound follows)   ·   OK: full screen   ·   Back: leave"
            setTextColor(Color.WHITE); textSize = 16f; setBackgroundColor(0xAA000000.toInt()); setPadding(dp(18), dp(8), dp(18), dp(8))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(24) }
        }

        val uids = intent.getStringArrayExtra("uids")?.toList() ?: SplitQueue.uids
        lifecycleScope.launch {
            val r = applicationContext.repo
            val prov = r.activeProvider() ?: return@launch finish()
            val picked = ArrayList<Channel>()
            for (u in uids) {
                val ch = r.dao.channel(u) ?: continue
                picked += ch.copy(name = r.custom(ch.providerId).nameOf(ch.uid, ch.name))
            }
            val limit = if (prov.type == "xtream") withContext(Dispatchers.IO) {
                try { XtreamClient(r.http, prov).maxConnections() } catch (e: Exception) { 0 }
            } else 0
            val n = SplitMath.allowed(picked.size, limit)
            ErrorLog.add("SPLIT", "picked ${picked.size}, provider connection limit " + (if (limit > 0) limit.toString() else "unknown") +
                ", showing $n, hardware H.264 decoder instances reported by this TV: ${decoderInstances()}")
            if (n < 2) {
                Toast.makeText(this@MultiViewActivity, if (picked.size < 2) "Pick at least 2 channels first" else "Your account allows only $limit connection – split screen needs 2 or more", Toast.LENGTH_LONG).show()
                return@launch finish()
            }
            if (n < picked.size) Toast.makeText(this@MultiViewActivity, "Your account allows $limit connections – showing the first $n channels", Toast.LENGTH_LONG).show()
            height = SplitMath.tileHeight(n)
            build(root, picked.take(n))
            root.addView(hint)
            handler.postDelayed(hideHint, 6000)
            if (!stopped) startAll()
        }
    }

    /** Best guess of how many hardware H.264 decoders the TV can run at once (diagnostic only - it is logged, never used to block). */
    private fun decoderInstances(): Int = try {
        var best = 0
        for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
            if (info.isEncoder || info.supportedTypes.none { it.equals("video/avc", true) }) continue
            if (Build.VERSION.SDK_INT >= 29 && !info.isHardwareAccelerated) continue
            val n = info.getCapabilitiesForType("video/avc").maxSupportedInstances
            if (n > best) best = n
        }
        best
    } catch (e: Exception) { 0 }

    private fun build(root: FrameLayout, list: List<Channel>) {
        val n = list.size
        val cols = SplitMath.cols(n)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var i = 0
        for (r in 0 until SplitMath.rows(n)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                if (i >= n) break
                val ch = list[i]
                val frame = FrameLayout(this)
                val pv = PlayerView(this).apply { useController = false }
                val label = TextView(this).apply {
                    setTextColor(Color.WHITE); textSize = 16f; maxLines = 1
                    setBackgroundColor(0x99000000.toInt()); setPadding(dp(10), dp(4), dp(10), dp(4))
                }
                val status = TextView(this).apply {
                    setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
                    setBackgroundColor(0x99000000.toInt()); setPadding(dp(12), dp(8), dp(12), dp(8)); visibility = View.GONE
                }
                frame.addView(pv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                frame.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
                frame.addView(status, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
                row.addView(frame, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).also { it.setMargins(dp(2), dp(2), dp(2), dp(2)) })
                tiles += Tile(frame, pv, label, status, ch)
                i++
            }
            // a lone tile in the last row (3 channels) takes the whole row
            grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        root.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        paintSelection()
    }

    private fun paintSelection() {
        tiles.forEachIndexed { i, t ->
            val on = i == sel
            t.frame.foreground = if (on) GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(4), Theme.accent) } else null
            t.label.text = (if (on) "♪ " else "") + (if (repoNumbers()) "${t.channel.number}  " else "") + t.channel.name
            t.player?.let { setSound(it, on) }
        }
    }

    private fun repoNumbers(): Boolean = applicationContext.repo.prefs.showNumbers

    /** Sound only on the highlighted tile: the others have their audio track switched off. */
    private fun setSound(p: ExoPlayer, on: Boolean) {
        p.volume = if (on) 1f else 0f
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, !on).build()
    }

    // ---- Playback ----------------------------------------------------------------------------
    private fun startAll() {
        tiles.forEachIndexed { i, t ->
            if (t.player != null) return@forEachIndexed
            t.software = SplitMath.softwareFirst(i, t.retries)
            val p = PlayerFactory.create(this, height, t.software)
            t.player = p
            t.view.player = p
            setSound(p, i == sel)
            p.addAnalyticsListener(object : AnalyticsListener {
                override fun onVideoDecoderInitialized(eventTime: AnalyticsListener.EventTime, decoderName: String, initializedTimestampMs: Long, initializationDurationMs: Long) {
                    t.decoder = decoderName
                    ErrorLog.add("SPLIT", "tile \"${t.channel.name}\" video decoder: $decoderName (software tried first: ${t.software})")
                }
            })
            p.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) = tileError(t, error)
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) { t.retries = 0; t.status.visibility = View.GONE }
                    else if (state == Player.STATE_BUFFERING && t.retries == 0) { t.status.text = "Loading…"; t.status.visibility = View.VISIBLE }
                }
            })
            // staggered, so the provider does not see four logins in the same instant
            handler.postDelayed({ if (t.player === p) load(t) }, 1200L * i)
        }
    }

    private fun load(t: Tile) {
        val p = t.player ?: return
        p.setMediaItem(MediaItem.fromUri(applicationContext.repo.liveUrl(t.channel)))
        p.prepare(); p.playWhenReady = true
    }

    private fun tileError(t: Tile, error: PlaybackException) {
        t.retries++
        val refused = error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS
        ErrorLog.add("PLAYBACK", "split-screen tile \"${t.channel.name}\" | ${error.errorCodeName} (${error.errorCode}) | ${error.message ?: ""} | cause: ${error.cause?.message ?: "none"} | decoder ${t.decoder} (software first: ${t.software}) | attempt ${t.retries} of 4")
        if (t.retries <= 4) {
            t.status.text = "Retrying (${t.retries}/4)…"; t.status.visibility = View.VISIBLE
            val old = t.player
            val i = tiles.indexOf(t)
            // a decoder failure is not fixed by loading again: rebuild the player with the other decoder type (software <-> hardware)
            t.view.player = null; old?.release(); t.player = null
            handler.postDelayed({ if (!stopped && t.player == null) restart(t, i) }, 1500)
        } else {
            t.status.text = if (refused) "The provider refused this stream (connection limit?)" else "Cannot play this channel"
            t.status.visibility = View.VISIBLE
        }
    }

    private fun restart(t: Tile, i: Int) {
        t.software = SplitMath.softwareFirst(i, t.retries)
        val p = PlayerFactory.create(this, height, t.software)
        t.player = p; t.view.player = p
        setSound(p, i == sel)
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onVideoDecoderInitialized(eventTime: AnalyticsListener.EventTime, decoderName: String, initializedTimestampMs: Long, initializationDurationMs: Long) {
                t.decoder = decoderName
                ErrorLog.add("SPLIT", "tile \"${t.channel.name}\" video decoder: $decoderName (software tried first: ${t.software})")
            }
        })
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) = tileError(t, error)
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { t.retries = 0; t.status.visibility = View.GONE }
            }
        })
        load(t)
    }

    private fun releaseAll() {
        handler.removeCallbacksAndMessages(null)
        tiles.forEach { t -> t.view.player = null; t.player?.release(); t.player = null }
    }

    // ---- Keys --------------------------------------------------------------------------------
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (tiles.isEmpty()) return super.onKeyDown(keyCode, event)
        val (dx, dy) = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> -1 to 0
            KeyEvent.KEYCODE_DPAD_RIGHT -> 1 to 0
            KeyEvent.KEYCODE_DPAD_UP -> 0 to -1
            KeyEvent.KEYCODE_DPAD_DOWN -> 0 to 1
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> { event.startTracking(); return true }
            else -> return super.onKeyDown(keyCode, event)
        }
        val to = SplitMath.move(sel, tiles.size, dx, dy)
        if (to != sel) { sel = to; paintSelection() }
        hint.visibility = View.GONE
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) &&
            event.isTracking && !event.isCanceled && tiles.isNotEmpty()) {
            startActivity(PlayerActivity.live(this, tiles[sel].channel.uid, Repository.SCOPE_ALL))
            finish(); return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // ---- Lifecycle ---------------------------------------------------------------------------
    override fun onStop() { super.onStop(); stopped = true; releaseAll() }

    override fun onStart() {
        super.onStart()
        if (stopped) { stopped = false; if (tiles.isNotEmpty()) startAll() }
    }

    override fun onDestroy() { releaseAll(); super.onDestroy() }

    companion object {
        fun intent(ctx: Context) = Intent(ctx, MultiViewActivity::class.java).putExtra("uids", SplitQueue.uids.toTypedArray())
    }
}
