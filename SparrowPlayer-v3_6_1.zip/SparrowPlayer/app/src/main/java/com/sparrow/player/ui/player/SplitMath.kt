package com.sparrow.player.ui.player

/** Pure split-screen maths (unit-tested): how many tiles may run, how big each is, and where the D-pad moves between them. */
object SplitMath {
    const val MAX = 4

    /** Tiles that may play: what was picked, held back by the provider's connection limit (0 / unknown = no limit). */
    fun allowed(picked: Int, connLimit: Int): Int {
        val cap = if (connLimit > 0) connLimit else MAX
        return picked.coerceAtMost(MAX).coerceAtMost(cap).coerceAtLeast(0)
    }

    /** Tallest picture a tile may decode: 720p with 2 tiles, 540p with 3 or 4. */
    fun tileHeight(tiles: Int): Int = if (tiles <= 2) 720 else 540

    /** Columns: 2 tiles side by side, 3 or 4 tiles in a 2 x 2 grid. */
    fun cols(tiles: Int): Int = if (tiles <= 2) tiles.coerceAtLeast(1) else 2

    fun rows(tiles: Int): Int { val c = cols(tiles); return (tiles + c - 1) / c }

    /**
     * Which video decoder a tile should try first. TVs report many hardware decoder instances but often run only 1 at a time
     * (a new one steals the previous - error 4003 "decoding failed", tiles playing one second each in turn).
     * Tile 0 starts on hardware, every other tile on software; each failed attempt flips the choice for the retry.
     */
    fun softwareFirst(tileIndex: Int, attempt: Int): Boolean {
        val base = tileIndex > 0
        return if (attempt % 2 == 0) base else !base
    }

    /** The tile reached from [sel] by one D-pad step ([dx], [dy] = -1, 0 or 1); [sel] itself at an edge. */
    fun move(sel: Int, tiles: Int, dx: Int, dy: Int): Int {
        val c = cols(tiles)
        val row = sel / c + dy
        val col = sel % c + dx
        if (row < 0 || row >= rows(tiles) || col < 0 || col >= c) return sel
        val idx = row * c + col
        return if (idx < tiles) idx else sel
    }
}

/** The channels picked for split screen (Channel menu -> Add To Split Screen). Kept while the app runs. */
object SplitQueue {
    private val list = ArrayList<String>()
    val uids: List<String> get() = list.toList()
    val size: Int get() = list.size
    fun contains(uid: String) = uid in list
    fun full() = list.size >= SplitMath.MAX
    /** Adds, or removes if already picked. Returns true when it was added. */
    fun toggle(uid: String): Boolean {
        if (list.remove(uid)) return false
        if (list.size < SplitMath.MAX) list += uid
        return true
    }
    fun clear() = list.clear()
}
