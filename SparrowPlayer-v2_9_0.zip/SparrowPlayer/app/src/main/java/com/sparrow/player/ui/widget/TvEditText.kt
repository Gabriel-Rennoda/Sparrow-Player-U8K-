package com.sparrow.player.ui.widget

import android.content.Context
import android.graphics.Rect
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText

/**
 * Every text box of the app (v2.9.0), made for a remote:
 *  - the on-screen keyboard comes up by itself the moment the box is selected (focus) or OK is pressed on it, so letters can be typed straight away;
 *  - once the keyboard was closed (Back / Done) the arrow keys move on to the next control again (right to the titles, down to the filters), instead of
 *    being swallowed by a keyboard that is no longer on screen. OK on the box brings the keyboard back.
 * While the keyboard is open the arrow keys belong to it, as usual.
 */
class TvEditText @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : EditText(context, attrs) {
    private var kbUp = false
    /** false = the keyboard does not come up by itself (the box then behaves like a plain EditText for focus). */
    var autoKeyboard = true

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        if (gainFocus) { if (autoKeyboard) showKeyboard() } else kbUp = false
    }

    fun showKeyboard() {
        kbUp = true
        post {
            if (isAttachedToWindow && hasFocus()) {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(this, 0)
            }
        }
    }

    fun hideKeyboard() {
        kbUp = false
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

    override fun onKeyPreIme(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) kbUp = false            // the keyboard closes itself on this Back
            return super.onKeyPreIme(keyCode, event)
        }
        if (!kbUp && event.action == KeyEvent.ACTION_DOWN) {
            val dir = when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> View.FOCUS_UP
                KeyEvent.KEYCODE_DPAD_DOWN -> View.FOCUS_DOWN
                KeyEvent.KEYCODE_DPAD_LEFT -> View.FOCUS_LEFT
                KeyEvent.KEYCODE_DPAD_RIGHT -> View.FOCUS_RIGHT
                else -> 0
            }
            if (dir != 0) {
                val next = focusSearch(dir)
                if (next != null && next !== this) { next.requestFocus(dir); return true }
            }
            if ((keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) && event.repeatCount == 0) { showKeyboard(); return true }
        }
        return super.onKeyPreIme(keyCode, event)
    }
}
