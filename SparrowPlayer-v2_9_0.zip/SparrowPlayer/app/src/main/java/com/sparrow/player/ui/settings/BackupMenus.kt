package com.sparrow.player.ui.settings

import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Backup
import com.sparrow.player.data.ErrorLog
import com.sparrow.player.data.LanTransfer
import com.sparrow.player.data.Provider
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.util.repo
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Settings -> Data, Backup & About -> Backup Now / Restore From Backup. A backup is saved in the shared Documents/SparrowPlayer folder (visible to any
 * file manager / USB copy; Android 10+ needs no permission for this), and, only when that fails, in the app's own folder (not reachable by file managers).
 * "Share / Email" sends the file through any app that accepts it; Restore lists this app's own backups and has "Browse For Backup File…" (the system
 * file picker) for a file copied from another device.
 * Restoring only adds (see [Backup]); conflicts are listed and approved or denied one by one, or all at once.
 */
object BackupMenus {
    private fun dir(a: Activity): File = (a.getExternalFilesDir(null) ?: a.filesDir).also { it.mkdirs() }
    private fun version(a: Activity): String = try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }
    private fun toast(a: Activity, m: String) = Toast.makeText(a, m, Toast.LENGTH_LONG).show()

    /** A backup that can be read again: shown in the list ([label]) and read by [read]. */
    private class Src(val label: String, val read: () -> String)

    /** Where a saved backup ended up: [where] for the person, [uri] (null when it only is in the app folder) for sharing. */
    private class Saved(val where: String, val uri: Uri?)

    private const val SHARED_DIR = "Documents/SparrowPlayer"

    private fun saveShared(a: Activity, name: String, text: String, mime: String = "application/json"): Saved? {
        val bytes = text.toByteArray(Charsets.UTF_8)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, SHARED_DIR)
                }
                val uri = a.contentResolver.insert(MediaStore.Files.getContentUri("external"), values) ?: return null
                val out = a.contentResolver.openOutputStream(uri) ?: return null
                out.use { it.write(bytes) }
                return Saved("$SHARED_DIR/$name", uri)
            }
            // Android 7-9: the public Documents folder needs the storage permission; without it this fails and the app folder is used
            val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "SparrowPlayer")
            d.mkdirs()
            val f = File(d, name)
            f.writeBytes(bytes)
            return Saved(f.absolutePath, null)
        } catch (e: Exception) { return null }
    }

    fun backupNow(a: FragmentActivity) {
        val repo = a.applicationContext.repo
        a.lifecycleScope.launch {
            val name = "SparrowBackup-" + SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date()) + ".json"
            val saved: Saved? = withContext(Dispatchers.IO) {
                try {
                    val text = Backup.export(repo.prefs.rawAll(), repo.dao.providers(), version(a))
                    saveShared(a, name, text) ?: run { File(dir(a), name).writeText(text); Saved(File(dir(a), name).absolutePath, null) }
                } catch (e: Exception) { null }
            }
            val p = Popup(a, if (saved != null) "Backup Saved" else "Backup Failed")
            if (saved != null) {
                p.note(name)
                p.note("Saved in: " + saved.where)
                if (saved.uri == null) p.note("This copy is in the app's own folder, which file managers cannot open. Use Share / Email to send it, or try again after allowing storage access in Android settings.")
                else p.note("Open your file manager and look in Documents → SparrowPlayer to copy it to a USB stick or another device.")
                p.note("It holds every profile, watch history, resume points, ratings, My List, favourites, channel and group edits, theme and settings, and your playlist logins. Keep the file private.")
                if (saved.uri != null) p.row("Share / Email This File…") { share(a, saved.uri) }
            } else p.note("The file could not be written on this device.")
            p.row("Close") { }
            p.show()
        }
    }

    // ---- Error Log: playback errors and crashes (data/ErrorLog.kt), saved to the device or sent by e-mail ------------------------------------
    fun errorLog(a: FragmentActivity) {
        val empty = ErrorLog.isEmpty()
        val p = Popup(a, "Error Log", if (empty) "Nothing recorded yet" else "Playback errors and crashes")
        p.note("Every playback error (which title, which error code, what the player was doing) and every crash is written here. Save it to the device or send it, so it can be looked into. Web addresses are shortened: no logins or passwords are kept.")
        p.row("Save To Device…", desc = "Saves one text file in Documents / SparrowPlayer (a file manager or USB stick can copy it).") { saveLog(a, false) }
        p.row("Send By E-mail…", desc = "Opens an e-mail app addressed to " + ErrorLog.SUPPORT_EMAIL + ". Many TVs have no e-mail app: then use Save To Device.") { saveLog(a, true) }
        if (!empty) p.row("View Latest Entries") { viewLog(a) }
        if (!empty) p.row("Clear Log") { ErrorLog.clear(); toast(a, "Error log cleared") }
        p.row("Close") { }
        p.show()
    }

    private fun viewLog(a: FragmentActivity) {
        val lines = ErrorLog.read().trimEnd().split('\n').takeLast(12)
        val p = Popup(a, "Latest Entries", lines.size.toString() + " shown (newest last)")
        for (l in lines) p.note(if (l.length > 420) l.take(420) + "…" else l)
        p.row("Close") { }
        p.show()
    }

    private fun saveLog(a: FragmentActivity, mail: Boolean) {
        a.lifecycleScope.launch {
            val name = "SparrowErrorLog-" + SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.US).format(Date()) + ".txt"
            val text = ErrorLog.export()
            val saved: Saved? = withContext(Dispatchers.IO) {
                saveShared(a, name, text, "text/plain") ?: try { File(dir(a), name).writeText(text); Saved(File(dir(a), name).absolutePath, null) } catch (e: Exception) { null }
            }
            if (!mail) {
                toast(a, if (saved != null) "Saved: " + saved.where else "The file could not be written on this device")
                return@launch
            }
            try {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(ErrorLog.SUPPORT_EMAIL))
                    putExtra(Intent.EXTRA_SUBJECT, "Sparrow Player error log")
                    putExtra(Intent.EXTRA_TEXT, ErrorLog.trim(text, 30_000))
                    if (saved?.uri != null) { putExtra(Intent.EXTRA_STREAM, saved.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                }
                a.startActivity(Intent.createChooser(send, "Send error log with"))
            } catch (e: Exception) {
                toast(a, "No e-mail app on this device." + (if (saved != null) " The log is saved: " + saved.where else ""))
            }
        }
    }

    private fun share(a: Activity, uri: Uri) {
        try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Sparrow Player backup")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            a.startActivity(Intent.createChooser(send, "Send backup with"))
        } catch (e: Exception) { toast(a, "No app on this device can send files. Copy the file from Documents/SparrowPlayer instead.") }
    }

    /** Backups this app made in Documents/SparrowPlayer (Android 10+: only files this app created are visible to it), newest first. */
    private fun sharedBackups(a: Activity): List<Src> {
        if (Build.VERSION.SDK_INT < 29) return emptyList()
        val out = ArrayList<Src>()
        try {
            val base = MediaStore.Files.getContentUri("external")
            val cols = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val sel = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ? AND " + MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?"
            a.contentResolver.query(base, cols, sel, arrayOf("Documents/SparrowPlayer%", "SparrowBackup-%.json"), MediaStore.MediaColumns.DATE_MODIFIED + " DESC")?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(base, c.getLong(0))
                    val n = c.getString(1) ?: continue
                    out += Src(n) { a.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "" }
                }
            }
        } catch (e: Exception) { }
        return out
    }

    private var pickerSeq = 0

    /** The system file picker (Android TV usually has one) for a backup file copied from another device. */
    private fun browse(a: FragmentActivity) {
        try {
            val key = "sparrow_backup_pick_" + (pickerSeq++)
            var launcher: androidx.activity.result.ActivityResultLauncher<Array<String>>? = null
            launcher = a.activityResultRegistry.register(key, ActivityResultContracts.OpenDocument()) { uri: Uri? ->
                launcher?.unregister()
                if (uri != null) review(a, Src(uri.lastPathSegment ?: "Backup file") { a.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "" })
            }
            launcher?.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*"))
        } catch (e: Exception) { toast(a, "This device has no file picker. Put the backup in Documents/SparrowPlayer and use Restore again.") }
    }

    fun restore(a: FragmentActivity) {
        val own: List<Src> = (dir(a).listFiles()?.filter { it.name.endsWith(".json") } ?: emptyList()).sortedByDescending { it.lastModified() }
            .map { f -> Src(f.name) { f.readText() } }
        val srcs = sharedBackups(a) + own
        val p = Popup(a, "Restore From Backup", "Saved by this app in Documents/SparrowPlayer or the app folder")
        p.row("Browse For Backup File…", desc = "Pick a SparrowBackup-….json file copied from another device (needs a file picker app).") { browse(a) }
        if (srcs.isEmpty()) p.note("No backups made by this app were found. Use Browse For Backup File… to pick one copied from another device.")
        for (s in srcs) p.row(s.label.removePrefix("SparrowBackup-").removeSuffix(".json")) { review(a, s) }
        p.row("Close") { }
        p.show()
    }

    // ---- Send / Receive over the home network (the engine is data/LanTransfer.kt; the backup file route stays as the fall back) -----------
    /** Shows a 4-digit code and waits (up to 5 minutes) for the other device; closing the window stops it. */
    fun sendLan(a: FragmentActivity) {
        a.lifecycleScope.launch {
            val repo = a.applicationContext.repo
            val code = LanTransfer.newCode()
            val blob = withContext(Dispatchers.IO) { LanTransfer.sealText(code, Backup.export(repo.prefs.rawAll(), repo.dao.providers(), version(a))) }
            val sender = LanTransfer.Sender(a, blob, Build.MODEL ?: "Sparrow Player")
            val p = Popup(a, "Code:  $code", "Waiting for the other device…")
            p.note("On the other device open Settings → Data, Backup & About → Receive Setup From Another Device and type this code. Both devices must be on the same Wi-Fi / network with Sparrow Player open.")
            p.row("Stop Sending") { }
            p.onDismiss { sender.stop() }
            p.show()
            val timeout = a.lifecycleScope.launch { delay(5 * 60 * 1000L); sender.stop() }
            val ok = withContext(Dispatchers.IO) { sender.run() }
            timeout.cancel()
            p.dismiss()
            toast(a, if (ok) "Sent. Approve it on the other device." else "Sending stopped.")
        }
    }

    /** Asks for the code, finds the sender on the network, and hands the text to the normal Restore review (Use Backup / Keep Mine). */
    fun receiveLan(a: FragmentActivity) {
        Popup.ask(a, "Receive Setup", "The 4-digit code shown on the other device", "", "Find") { code0 ->
            val code = code0.trim()
            if (code.length != 4 || code.any { c -> !c.isDigit() }) { toast(a, "The code is 4 digits"); return@ask }
            toast(a, "Looking for the other device…")
            a.lifecycleScope.launch {
                when (val r = withContext(Dispatchers.IO) { LanTransfer.receive(a, code) }) {
                    is LanTransfer.Result.Ok -> review(a, Src("From another device") { r.text })
                    LanTransfer.Result.NoDevice -> toast(a, "No device found. On the other device pick Send My Setup first; both must be on the same Wi-Fi / network.")
                    LanTransfer.Result.WrongCode -> toast(a, "Wrong code")
                    LanTransfer.Result.Failed -> toast(a, "The other device did not answer. Try again.")
                }
            }
        }
    }

    private fun review(a: FragmentActivity, f: Src) {
        val repo = a.applicationContext.repo
        a.lifecycleScope.launch {
            val parsed = withContext(Dispatchers.IO) { try { Backup.parse(f.read()) } catch (e: Exception) { null } }
            if (parsed == null) { toast(a, "That file is not a Sparrow Player backup"); return@launch }
            val changes = Backup.diff(repo.prefs.rawAll(), parsed.prefs)
            val auto = changes.filter { it.kind != "conflict" }
            val conflicts = changes.filter { it.kind == "conflict" }
            val have: List<Provider> = withContext(Dispatchers.IO) { repo.dao.providers() }
            val addProviders: List<Provider> = if (have.isEmpty()) parsed.providers else emptyList()
            val approved = HashSet<String>()

            val p = Popup(a, "Restore", f.label)
            p.note("Added by themselves (nothing is removed): " + auto.size + " item(s) - new settings, merged lists, furthest resume points." +
                (if (addProviders.isNotEmpty()) " This device has no playlist yet: " + addProviders.size + " playlist(s) from the backup are added." else ""))
            val shown = conflicts.take(MAX_LISTED)
            val rows = ArrayList<Pair<Backup.Change, Popup.Row>>()
            if (conflicts.isEmpty()) p.note("No conflicts: nothing on this device differs from the backup.")
            else {
                p.note(conflicts.size.toString() + " conflict(s): this device and the backup hold different values. Keep Mine = deny, Use Backup = approve.")
                p.row("Approve All Conflicts", keepOpen = true) {
                    approved.clear(); conflicts.forEach { approved += it.key }
                    rows.forEach { (_, r) -> r.setValue("Use Backup") }
                }
                p.row("Deny All Conflicts", keepOpen = true) {
                    approved.clear(); rows.forEach { (_, r) -> r.setValue("Keep Mine") }
                }
                for (c in shown) {
                    val r = p.row(c.label, "Keep Mine", keepOpen = true) { row ->
                        if (!approved.add(c.key)) approved.remove(c.key)
                        row.setValue(if (c.key in approved) "Use Backup" else "Keep Mine")
                    }
                    rows += c to r
                }
                if (conflicts.size > shown.size) p.note("The other " + (conflicts.size - shown.size) + " follow Approve All / Deny All.")
            }
            p.row("Apply Restore") {
                val chosen = auto + conflicts.filter { it.key in approved }
                val ed = repo.prefs.rawEdit()
                Backup.apply(ed, chosen); ed.apply()
                a.lifecycleScope.launch {
                    if (addProviders.isNotEmpty()) {
                        withContext(Dispatchers.IO) { for (pv in addProviders) repo.dao.insertProvider(pv) }
                        repo.prefs.activeProvider = addProviders.first().id
                        repo.syncAsync(addProviders.first())
                    }
                    repo.reloadAfterRestore()
                    toast(a, "Restored " + chosen.size + " item(s). Restart the app to see every change.")
                }
            }
            p.row("Cancel") { }
            p.show()
        }
    }

    private const val MAX_LISTED = 40
}
