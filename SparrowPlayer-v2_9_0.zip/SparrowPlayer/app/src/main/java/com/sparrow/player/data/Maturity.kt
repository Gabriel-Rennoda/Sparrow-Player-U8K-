package com.sparrow.player.data

/**
 * Age ratings for the "Children & Family" genre. IPTV lists carry NO age rating, so this is evidence based and says so:
 *
 *  1. A rating the panel told us (remembered when a details page was opened, see [MetaCache]) is trusted: only TV-Y, TV-G, G, TV-PG, PG and PG-13 pass.
 *     TV-14, TV-MA, R and NC-17 never do (TV-14 is kept out on purpose: Rick and Morty is TV-14).
 *  2. A rating written in the title or category ("[TV-MA]") counts the same way.
 *  3. Words that say "not for children" in the category / genre (adult, mature, 18+, horror ...) or a well-known adult cartoon in the title keep
 *     it out. Crime / thriller / war only do so when nothing says "family" or "kids" (Despicable Me is tagged Crime on many panels).
 *  4. What is left needs a reason to be here: kids / family / children / Disney ... in its category or genre, or a well-known children's title. A film that is only "animation"
 *     is let through; a SERIES that is only "animation" waits until its rating is known (adult cartoons are mostly series).
 * Pure Kotlin, unit tested.
 */
object Maturity {
    val FAMILY_OK = setOf("TV-Y", "TV-G", "G", "TV-PG", "PG", "PG-13")

    fun familyOk(code: String) = code in FAMILY_OK

    // ---- age limits of a profile (Content Preferences) ----------------------------------------------------------------
    /** (limit code, label): the highest rating a profile may see. "" = no limit. */
    val LIMITS: List<Pair<String, String>> = listOf(
        "" to "No Limit",
        "R" to "Up To R  (Hides NC-17 / Adults Only)",
        "TV-14" to "Up To TV-14",
        "PG-13" to "Up To PG-13",
        "PG" to "Up To PG",
        "G" to "G / TV-G Only"
    )
    private val SET_G = setOf("TV-Y", "TV-G", "G")
    private val SET_PG = SET_G + setOf("TV-PG", "PG")
    private val SET_PG13 = SET_PG + "PG-13"
    private val SET_TV14 = SET_PG13 + "TV-14"
    private val SET_R = SET_TV14 + setOf("R", "TV-MA")

    /** The ratings a limit lets through; null = no limit. */
    fun ratingsFor(limit: String): Set<String>? = when (limit) {
        "G" -> SET_G; "PG" -> SET_PG; "PG-13" -> SET_PG13; "TV-14" -> SET_TV14; "R" -> SET_R; else -> null
    }

    /** Words that put a title with no rating out of even the mildest limit (Up To R / Up To TV-14). */
    private val ADULT_ONLY = listOf("xxx", "erotic", "porn", "adults only", "adult only", "nc 17", "uncut", "uncensored", "explicit")

    /**
     * May a profile with age [limit] see this title? A rating the panel gave, or written in the title / category, decides. When nothing says what it is rated
     * the Kids filter's evidence is used: for PG-13 and under the title must pass [familyOk] (no adult words, no well-known adult cartoon; a series also needs a family
     * / kids sign), for Up To TV-14 / R only adults-only words and (TV-14) well-known adult cartoons keep it out.
     */
    fun allowed(limit: String, known: String, rawName: String, category: String, nameNorm: String, prepared: String, series: Boolean, strict: Boolean = false): Boolean {
        val ok = ratingsFor(limit) ?: return true
        val code = if (known.isNotEmpty()) known else MediaTags.maturity("$rawName $category")
        if (code.isNotEmpty()) return code in ok
        // Strict (Child profiles): nothing says what it is rated, so it only shows when something says "kids / family" (category, genre or a well-known children's title).
        if (strict && limit in STRICT_LIMITS) return hasKidsSign(nameNorm, prepared) && familyOk("", rawName, category, nameNorm, prepared, series)
        if (limit == "R") return !TextNorm.hasAny(prepared, ADULT_ONLY)
        if (limit == "TV-14") return !TextNorm.hasAny(prepared, ADULT_ONLY) && !isAdultTitle(nameNorm)
        return familyOk("", rawName, category, nameNorm, prepared, series)
    }

    fun allowed(limit: String, t: RowTitle, known: String, series: Boolean, strict: Boolean = false): Boolean =
        allowed(limit, known, t.name, t.category, t.nameNorm, t.prepared, series, strict)

    /** The limits Strict applies to (the ones a Child profile can have). */
    private val STRICT_LIMITS = setOf("PG-13", "PG", "G")

    /** Does the category / genre text or the title say "kids / family" (and is it not a well-known adult cartoon)? */
    fun hasKidsSign(nameNorm: String, prepared: String): Boolean = TextNorm.hasAny(prepared, STRONG) || isKidsTitle(nameNorm)

    /** Rating code for an age number from a panel (\"16\", \"18+\"); "" when it is not one. */
    fun fromAge(n: Int): String = when {
        n >= 18 -> "TV-MA"; n >= 16 -> "R"; n >= 14 -> "TV-14"; n >= 13 -> "PG-13"; n >= 10 -> "TV-PG"; n >= 1 -> "TV-Y"; else -> ""
    }

    /** "PG-13", "TV-MA", "Rated R", "16", "18+" -> a code of [MediaTags.MATURITIES]; "" if it says nothing. */
    fun normalize(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty()) return ""
        val m = MediaTags.maturity(s)
        if (m.isNotEmpty()) return m
        if (s.length <= 4 && s.all { it.isDigit() || it == '+' }) return fromAge(s.filter { it.isDigit() }.toIntOrNull() ?: 0)
        return ""
    }

    private val STRONG = listOf("kids", "kid", "children", "childrens", "family", "families", "disney", "pixar", "junior", "toddler", "toddlers",
        "preschool", "nick jr", "nickelodeon", "baby")
    /** Never for children, whatever else the text says. */
    private val UNSAFE = listOf("adult", "adults", "mature", "erotic", "xxx", "18", "tv ma", "tv 14", "nc 17", "uncut", "uncensored", "explicit",
        "after dark", "adult swim", "horror", "slasher")
    /** Genre words that are common on family films too (Despicable Me is "Animation, Family, Comedy, Crime"): they only keep a title out when nothing says "family". */
    private val UNSAFE_UNLESS_FAMILY = listOf("crime", "true crime", "thriller", "thrillers", "zombie", "zombies", "gangster", "mafia", "war")

    /** Well-known children's titles and brands (title starts with one of them): let through even when the panel's genre text is poor or missing. */
    private val KIDS_TITLES = listOf(
        "paw patrol", "bluey", "peppa pig", "sesame street", "dora the explorer", "spongebob", "sponge bob", "mickey mouse", "mickey and", "winnie the pooh",
        "toy story", "finding nemo", "finding dory", "moana", "shrek", "madagascar", "kung fu panda", "how to train your dragon", "despicable me", "minions",
        "cocomelon", "pj masks", "blue s clues", "thomas and friends", "thomas the tank engine", "barbie", "lego", "trolls", "ice age", "encanto", "zootopia",
        "paddington", "the lion king", "aladdin", "beauty and the beast", "the little mermaid", "tangled", "cinderella", "snow white", "lilo and stitch", "monsters inc",
        "the incredibles", "inside out", "wall e", "ratatouille", "kung fu panda", "puss in boots", "the secret life of pets", "hotel transylvania",
        "the garfield", "garfield", "scooby doo", "tom and jerry", "looney tunes", "the smurfs", "alvin and the chipmunks", "curious george", "arthur",
        "daniel tiger", "octonauts", "wonder pets", "dragon tales", "caillou", "max and ruby", "pokemon", "teenage mutant ninja turtles", "the magic school bus",
        "ben and holly", "hey duggee", "numberblocks", "gabby s dollhouse", "miraculous", "the loud house", "the amazing world of gumball", "adventure time", "steven universe",
        "phineas and ferb", "gravity falls", "doc mcstuffins", "sofia the first", "elena of avalor", "puppy dog pals", "the wiggles", "veggietales", "chip n dale"
    ).map { " $it " }

    fun isKidsTitle(nameNorm: String) = KIDS_TITLES.any { nameNorm.startsWith(it) }

    /** Well-known cartoons / films for adults, in [TextNorm] form (title starts with one of them). */
    private val ADULT_TITLES = listOf(
        "rick and morty", "rick morty", "bojack horseman", "beavis and butt head", "beavis butt head", "south park", "family guy", "american dad",
        "the cleveland show", "archer", "big mouth", "bob s burgers", "harley quinn", "invincible", "castlevania", "hazbin hotel", "helluva boss",
        "the boondocks", "solar opposites", "disenchantment", "final space", "paradise pd", "robot chicken", "aqua teen hunger force", "metalocalypse",
        "futurama", "king of the hill", "love death and robots", "undone", "arcane", "blue eye samurai", "the legend of vox machina", "primal",
        "sausage party", "team america", "central park", "bless the harts", "the great north", "duncanville", "bordertown", "tuca and bertie",
        "madagascar skin", "cinderella man", "herpers", "lies and ex wives", "occupied", "a prayer for compassion", "the curse of the voodoo child", "attack on titan", "death note", "hit monkey", "close enough", "king star king", "ren and stimpy adult party cartoon", "drawn together"
    ).map { " $it " }

    fun isAdultTitle(nameNorm: String) = ADULT_TITLES.any { nameNorm.startsWith(it) }

    /**
     * May this title (already in the Children & Family genre) stay there? [known]: a rating the panel gave ("" = unknown),
     * [rawName] / [category] / [genre] as the panel wrote them, [nameNorm] / [prepared] their [TextNorm] forms (prepared = genre + category).
     */
    fun familyOk(known: String, rawName: String, category: String, nameNorm: String, prepared: String, series: Boolean): Boolean {
        if (known.isNotEmpty()) return familyOk(known)
        val tag = MediaTags.maturity("$rawName $category")
        if (tag.isNotEmpty()) return familyOk(tag)
        if (TextNorm.hasAny(prepared, UNSAFE)) return false
        if (isAdultTitle(nameNorm)) return false
        val family = TextNorm.hasAny(prepared, STRONG)
        if (!family && TextNorm.hasAny(prepared, UNSAFE_UNLESS_FAMILY)) return false
        if (family || isKidsTitle(nameNorm)) return true
        return !series
    }

    fun familyOk(t: RowTitle, known: String, series: Boolean): Boolean =
        familyOk(known, t.name, t.category, t.nameNorm, t.prepared, series)
}
