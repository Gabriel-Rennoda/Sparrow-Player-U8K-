package com.sparrow.player.ui.vod

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.widget.TextView
import android.view.View
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import coil.load
import com.sparrow.player.R
import com.sparrow.player.data.Episode
import com.sparrow.player.data.Resume
import com.sparrow.player.data.MetaCache
import com.sparrow.player.data.SparrowRating
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.data.UserRatings
import com.sparrow.player.data.VodItem
import com.sparrow.player.data.str
import com.sparrow.player.databinding.ActivityDetailsBinding
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.TimeFmt
import com.sparrow.player.util.TextAdapter
import com.sparrow.player.util.loadUrl
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

class DetailsActivity : FragmentActivity() {
    private lateinit var b: ActivityDetailsBinding
    private var episodes: List<Episode> = emptyList()       // the episodes that are not hidden
    private var baseEpisodes: List<Episode> = emptyList()   // every episode of the series (after the holiday filter), hidden ones included
    private var seasonAdapter: TextAdapter<Int>? = null
    private var tmdbDone = false
    private var shown: List<Episode> = emptyList()          // episodes of the season on screen
    private var episodeAdapter: TextAdapter<Episode>? = null
    private var item: VodItem? = null
    private var seriesMeta = ""
    private var seriesPlot = ""
    private var seriesBackdrop = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        com.sparrow.player.ui.MainActivity.stopMini()          // the mini player (kept alive behind Search / Settings) must not play under this screen
        super.onCreate(savedInstanceState)
        b = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(b.root)
        Theme.applyAll(this, b.root)
        val uid = intent.getStringExtra("uid") ?: return finish()
        val repo = applicationContext.repo
        b.seasonList.itemAnimator = null
        b.episodeList.itemAnimator = null

        // The about text shows 5 lines. When it is longer it can be focused (a soft box shows it) and OK opens all of it.
        b.plot.viewTreeObserver.addOnGlobalLayoutListener {
            val l = b.plot.layout
            val cut = l != null && l.lineCount > 0 && l.getEllipsisCount(l.lineCount - 1) > 0
            if (b.plot.isFocusable != cut) { b.plot.isFocusable = cut; b.plot.isClickable = cut }
        }
        b.plot.setOnFocusChangeListener { v, has -> v.setBackgroundColor(if (has) Theme.surface2 else 0) }
        b.plot.setOnClickListener {
            val pp = Popup(this, b.title.text.toString(), "About")
            pp.note(b.plot.text.toString())
            pp.row("Close") { }
            pp.show()
        }

        lifecycleScope.launch {
            repo.activeProvider()
            val v = repo.dao.vod(uid) ?: return@launch finish()
            item = v
            b.title.text = v.name
            b.poster.loadUrl(v.poster)
            // A real backdrop only. (For movies the list's "backdrop" is just the poster: showing it first and swapping in the real one a
            // moment later was the poster flashing before the background.) A movie waits for the panel's info; a series has nothing more
            // to wait for, so the poster stands in at once if there is no backdrop.
            val real = v.backdrop.takeIf { it.isNotBlank() && it != v.poster } ?: ""
            seriesBackdrop = real.ifBlank { if (v.type == "movie") "" else v.poster }
            if (seriesBackdrop.isNotBlank()) b.backdrop.load(seriesBackdrop)
            seriesMeta = metaOf(v.year, v.rating, v.genre)
            seriesPlot = v.plot
            b.meta.text = seriesMeta
            b.plot.text = seriesPlot
            setupRating(v)

            if (v.type == "movie") {
                b.seasonList.visibility = View.GONE; b.episodeList.visibility = View.GONE
                refreshPlayLabel()
                b.playBtn.setOnClickListener {
                    val m = item ?: return@setOnClickListener
                    startActivity(PlayerActivity.vod(this@DetailsActivity, repo.movieUrl(m), m.name, m.uid, m.uid))
                }
                b.playBtn.requestFocus()
                val info = repo.vodInfo(v)   // enrich with plot / backdrop when the panel provides it
                info.str("plot").ifBlank { info.str("description") }.takeIf { p -> p.isNotBlank() }?.let { p -> b.plot.text = p }
                val infoBackdrop = (info["backdrop_path"] as? List<*>)?.firstOrNull()?.toString()?.takeIf { u -> u.isNotBlank() }
                if (infoBackdrop != null) { seriesBackdrop = infoBackdrop; b.backdrop.load(infoBackdrop) }
                else if (seriesBackdrop.isBlank() && v.poster.isNotBlank()) { seriesBackdrop = v.poster; b.backdrop.load(v.poster) }   // no backdrop anywhere: poster
                b.meta.text = metaOf(v.year.ifBlank { info.str("releasedate").take(4) }, v.rating,
                    v.genre.ifBlank { info.str("genre") }, info.str("duration"))
                // remember what the panel told us, so search can filter on length / maturity / plot
                val mpaa = listOf("mpaa_rating", "mpaa", "age", "rating_mpaa", "certification").map { k -> info.str(k) }.firstOrNull { m -> m.isNotBlank() } ?: ""
                repo.remember(v.uid, MetaCache.lengthMinutes(info.str("duration")), mpaa, info.str("plot").ifBlank { info.str("description") })
                cAge = mpaa.ifBlank { repo.maturities()[v.uid].orEmpty() }          // the panel's age rating, else the one TMDB gave
                cDirector = info.str("director"); cCast = info.str("cast").ifBlank { info.str("actors") }
                provGenre = v.genre.ifBlank { info.str("genre") }.isNotBlank()
                refreshCredits()
                if (cDirector.isBlank() || cCast.isBlank() || !provGenre || cAge.isBlank()) fillFromTmdb(v) else tmdbDone = true
            } else {
                setupSeries(v)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Back from the player: refresh the "watched" markers / Resume label in place (no animations, focus is kept).
        episodeAdapter?.let { a -> a.notifyItemRangeChanged(0, a.itemCount) }
        if (item != null) { refreshPlayLabel(); refreshCredits() }
    }

    // ---- the line under the plot: "✓ Watched  •  Rated PG-13  •  Director: ...  •  Cast: ..." ---------------------------------
    private var cAge = ""
    private var cDirector = ""
    private var cCast = ""
    private var cGenre = ""
    private var cDirLabel = "Director"
    private var provGenre = true                     // the provider already gave a genre (it is in the line under the title)

    /** What the provider left empty (genre, director / creator, cast) comes from TMDB a moment later; the page is usable meanwhile. */
    private fun fillFromTmdb(v: VodItem) {
        lifecycleScope.launch {
            val d = applicationContext.repo.tmdbDetails(v)
            tmdbDone = true
            if (d == null) { if (item?.uid == v.uid) refreshCredits(); return@launch }
            if (item?.uid != v.uid) return@launch
            if (cAge.isBlank()) cAge = d.cert
            if (cDirector.isBlank()) { cDirector = d.director; cDirLabel = d.directorLabel }
            if (cCast.isBlank()) cCast = d.cast
            if (!provGenre) cGenre = d.genres
            refreshCredits()
        }
    }

    /** Movie: watched to the end. Series: every episode watched, or "N of M watched". Nothing is typed in: it follows what the player saved. */
    private fun watchedNote(): String {
        val it = item ?: return ""
        val prefs = applicationContext.repo.prefs
        if (it.type == "movie") return if (prefs.position(it.uid) == Resume.FINISHED) "✓ Watched" else ""
        if (episodes.isEmpty()) return ""
        val n = episodes.count { e -> prefs.position("ep:${e.id}") == Resume.FINISHED }
        return if (n == episodes.size) "✓ Watched" else if (n > 0) "$n of ${episodes.size} watched" else ""
    }

    /** The badge look shared by Watched and the age rating: off-white, rounded, a thin outline and bold text in the accent colour (tight fit, a little more room under the text for the check mark's tip). */
    private fun styleBadge(tv: TextView) {
        val d = resources.displayMetrics.density
        tv.background = GradientDrawable().apply { setColor(0xFFF7F5EE.toInt()); cornerRadius = 8 * d; setStroke(Math.max(1, (1.5f * d).toInt()), Theme.accent) }
        tv.setTextColor(Theme.accent)
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.textSize = 17f
        tv.setPadding((10 * d).toInt(), (3 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
    }

    /** "•  Director: names": the bullet is larger and the bullet and the label are bold; the names stay as they are. */
    private fun labelled(label: String, value: String): CharSequence {
        val sb = SpannableStringBuilder("•  $label: $value")
        sb.setSpan(RelativeSizeSpan(1.6f), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, label.length + 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun refreshCredits() {
        val w = watchedNote()
        if (w.isBlank()) b.watchedBadge.visibility = View.GONE
        else {
            styleBadge(b.watchedBadge)
            val sp = SpannableString(w)
            if (w.startsWith("✓")) sp.setSpan(RelativeSizeSpan(1.2f), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            b.watchedBadge.text = sp; b.watchedBadge.visibility = View.VISIBLE
        }
        val age = if (cAge.isNotBlank()) "Rated $cAge" else if (tmdbDone) "Not Rated" else ""
        if (age.isBlank()) b.ageBadge.visibility = View.GONE else { styleBadge(b.ageBadge); b.ageBadge.text = age; b.ageBadge.visibility = View.VISIBLE }
        fun line(tv: TextView, text: CharSequence?) { if (text == null) tv.visibility = View.GONE else { tv.text = text; tv.visibility = View.VISIBLE } }
        val cast = cCast.split(",").map { s -> s.trim() }.filter { s -> s.isNotEmpty() }.take(4).joinToString(", ")
        line(b.genreLine, if (cGenre.isNotBlank()) labelled("Genre", cGenre) else null)
        line(b.directorLine, if (cDirector.isNotBlank()) labelled(cDirLabel, cDirector) else null)
        line(b.castLine, if (cast.isNotBlank()) labelled("Cast", cast) else null)
    }

    private suspend fun setupSeries(it: VodItem) {
        val repo = applicationContext.repo
        val adapter = TextAdapter<Episode>(
            { e -> episodeLabel(e) },
            { e -> playEpisode(e) },                               // ONE press of OK plays that episode
            { e, _ -> showEpisodeInfo(e) },                        // browsing shows the episode's info on top
            onLong = { e -> episodeMenu(e) }                       // hold OK: hide this episode / this season
        )
        episodeAdapter = adapter
        b.episodeList.layoutManager = LinearLayoutManager(this)
        b.episodeList.adapter = adapter
        baseEpisodes = try { repo.seriesEpisodes(it) } catch (e: Exception) { emptyList() }
        episodes = baseEpisodes
        cAge = repo.maturities()[it.uid].orEmpty(); cDirector = repo.seriesPeopleOf(it.uid).first; cCast = repo.seriesPeopleOf(it.uid).second
        provGenre = it.genre.isNotBlank()
        refreshCredits()
        if (cDirector.isBlank() || cCast.isBlank() || !provGenre || cAge.isBlank()) fillFromTmdb(it) else tmdbDone = true
        if (episodes.isEmpty()) { b.plot.text = it.plot.ifBlank { "No episodes found." }; b.playBtn.requestFocus(); return }
        // opened from a holiday's row / page: the series poster stays, but only that holiday's episodes are listed (when some episodes name it)
        val hid = intent.getStringExtra("holidayId") ?: ""
        if (hid.isNotEmpty() && repo.prefs.holidayEpisodesOnly) {                // Settings -> General -> Holiday Episodes Only (Lite)
            val hol = com.sparrow.player.data.Holidays.ALL.firstOrNull { h -> h.id == hid }
            if (hol != null) {
                val only = episodes.filter { e -> com.sparrow.player.data.Holidays.matches(hol, e.title) || com.sparrow.player.data.Holidays.matches(hol, e.plot) }
                if (only.isNotEmpty() && only.size < episodes.size) {
                    episodes = only
                    seriesMeta = (seriesMeta + "   •   " + hol.name + " Episodes").trim(' ', '•')
                    b.meta.text = seriesMeta
                }
            }
        }
        // typical episode length for the search "Length" filter
        episodes.firstNotNullOfOrNull { e -> MetaCache.lengthMinutes(e.duration).takeIf { m -> m > 0 } }?.let { m -> repo.remember(it.uid, m, "", it.plot) }

        baseEpisodes = episodes                                   // (after the holiday filter)
        val hid = repo.hiddenVod()
        episodes = baseEpisodes.filter { e -> "ep:${e.id}" !in hid }
        if (episodes.isEmpty()) { b.plot.text = "Every episode of this series is hidden (hold OK on a season / use Unhide in Settings → EPG → Hidden)."; b.playBtn.requestFocus(); return }
        val seasons = episodes.map { e -> e.season }.distinct().sorted()
        val sa = TextAdapter<Int>({ s -> "Season $s" }, { s -> showSeason(s) }, { s, _ -> showSeason(s) }, R.layout.item_tab)
        seasonAdapter = sa
        b.seasonList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.seasonList.adapter = sa
        sa.submit(seasons, 0)
        showSeason(seasons.first())
        refreshPlayLabel()
        b.playBtn.setOnClickListener { continueTarget()?.let { e -> playEpisode(e) } }
        b.playBtn.requestFocus()
    }

    /** Loved It / Liked It / Disliked It: press again to remove. */
    private fun setupRating(v: VodItem) {
        val uid = v.uid
        val repo = applicationContext.repo
        val buttons = listOf(b.loveBtn to UserRatings.LOVED, b.likeBtn to UserRatings.LIKED, b.dislikeBtn to UserRatings.DISLIKED)
        val base = mapOf(UserRatings.LOVED to "♥  Loved It", UserRatings.LIKED to "👍  Liked It", UserRatings.DISLIKED to "👎  Disliked It")
        fun paint() {
            val mine = repo.myRating(uid)
            buttons.forEach { (btn, code) -> btn.text = (if (mine == code) "✓  " else "") + base[code] }
            val sp = repo.sparrowOf(v)
            b.sparrowBtn.text = "Sparrow Rating: " + (if (sp > 0) SparrowRating.format(sp) else "Not Rated") + "  ▾"
            // the two star ratings stay where they are on the poster: provider top left, Sparrow (my own) top right
            b.poster.setRatings(repo.providerRatingOf(v), sp)
        }
        paint()
        buttons.forEach { (btn, code) -> btn.setOnClickListener { repo.rate(uid, code); paint() } }
        // My List: titles saved by hand (feeds the My List and "Because You Added" rows)
        fun paintList() { b.myListBtn.text = if (repo.inMyList(uid)) "✓  In My List" else "＋  My List" }
        paintList()
        b.myListBtn.setOnClickListener { repo.toggleMyList(uid); paintList() }
        // Hide: the title leaves every row, group and search (Settings -> EPG -> Hidden -> Hidden Movies & Series brings it back)
        fun paintHide() { b.hideBtn.text = if (repo.isVodHidden(uid)) "Unhide" else "Hide" }
        paintHide()
        b.hideBtn.setOnClickListener {
            if (repo.isVodHidden(uid)) { repo.unhideVod(listOf(uid)); paintHide() }
            else Popup.confirm(this, "Hide " + v.name + "?", "It leaves every row, group and search. Settings → EPG → Hidden → Hidden Movies & Series brings it back.", "Yes, Hide") { repo.hideVod(listOf(uid)); finish() }
        }
        // My Holiday Favourites: its own group in Movies / Series (titles the user saved by hand)
        // only offered when the page was opened from The Holidays (a holiday's page, My Holiday Favourites); on every ordinary poster it is gone
        val fromHoliday = intent.getBooleanExtra("holiday", false)
        b.holidayFavBtn.visibility = if (fromHoliday) View.VISIBLE else View.GONE
        fun paintHoliday() { b.holidayFavBtn.text = if (repo.inHolidayFavs(uid)) "✓  My Holiday Favourites" else "＋  My Holiday Favourites" }
        paintHoliday()
        b.holidayFavBtn.setOnClickListener { repo.toggleHolidayFav(uid); paintHoliday() }
        // Sparrow Rating: my own 0.5 - 10 rating, a drop down in half steps ("Not Rated" clears it)
        b.sparrowBtn.setOnClickListener {
            val labels = listOf("Not Rated") + SparrowRating.STEPS.map { SparrowRating.format(it) }
            val cur = repo.sparrowOf(v)
            val idx = if (cur <= 0) 0 else SparrowRating.STEPS.indexOf(cur) + 1
            Popup.choose(this, "Sparrow Rating", labels, idx) { i -> repo.setSparrow(uid, if (i == 0) 0.0 else SparrowRating.STEPS[i - 1]); paint() }
        }
    }

    /** Hold OK on an episode: hide it or its whole season; bring back what was hidden in this series. */
    private fun episodeMenu(e: Episode) {
        val repo = applicationContext.repo
        val hid = repo.hiddenVod()
        val hiddenHere = baseEpisodes.filter { x -> "ep:${x.id}" in hid }
        val p = Popup(this, "S${e.season} E${e.num}  ${e.title}", "Episode Options")
        p.row("Play") { playEpisode(e) }
        p.row("Hide This Episode") { repo.hideVod(listOf("ep:${e.id}")); rebuildEpisodes(e.season) }
        p.row("Hide Season ${e.season}…") {
            Popup.confirm(this, "Hide Season ${e.season}?", "Its episodes leave the list and Play Next skips them. Hold OK on an episode and choose Show Hidden Episodes to bring them back.", "Yes, Hide") {
                repo.hideVod(baseEpisodes.filter { x -> x.season == e.season }.map { x -> "ep:${x.id}" }); rebuildEpisodes(e.season)
            }
        }
        if (hiddenHere.isNotEmpty()) p.row("Show ${hiddenHere.size} Hidden Episodes") { repo.unhideVod(hiddenHere.map { x -> "ep:${x.id}" }); rebuildEpisodes(e.season) }
        p.row("Close") { }
        p.show()
    }

    private fun rebuildEpisodes(keepSeason: Int) {
        val hid = applicationContext.repo.hiddenVod()
        episodes = baseEpisodes.filter { x -> "ep:${x.id}" !in hid }
        val seasons = episodes.map { x -> x.season }.distinct().sorted()
        if (seasons.isEmpty()) {
            shown = emptyList(); episodeAdapter?.submit(shown); seasonAdapter?.submit(emptyList(), 0)
            b.plot.text = "Every episode of this series is hidden."
            refreshPlayLabel(); refreshCredits(); return
        }
        val idx = seasons.indexOf(keepSeason).coerceAtLeast(0)
        seasonAdapter?.submit(seasons, idx)
        showSeason(seasons[idx])
        refreshPlayLabel(); refreshCredits()
        b.episodeList.post { b.episodeList.getChildAt(0)?.requestFocus() }
    }

    private fun showSeason(s: Int) {
        shown = episodes.filter { it.season == s }
        episodeAdapter?.submit(shown)
    }

    private fun episodeLabel(e: Episode): String {
        val saved = applicationContext.repo.prefs.position("ep:${e.id}")
        val mark = when { saved == Resume.FINISHED -> "   ✓"; Resume.hasProgress(saved) -> "   ▶ resume"; else -> "" }
        return "E${e.num}   ${e.title}$mark"
    }

    /** Top info section: details of the focused episode (falls back to the series text for anything missing). */
    private fun showEpisodeInfo(e: Episode) {
        b.epTitle.text = "S${e.season} E${e.num}   ${e.title}"
        b.epTitle.visibility = View.VISIBLE
        val m = metaOf(e.duration.takeIf { it != "00:00:00" } ?: "", e.released, e.rating.takeIf { it != "0" } ?: "")
        b.meta.text = m.ifBlank { seriesMeta }
        b.plot.text = e.plot.ifBlank { seriesPlot }
        showProgress(applicationContext.repo.prefs.percent("ep:${e.id}"))
        if (e.image.isNotBlank()) b.backdrop.load(e.image)
    }

    /** Which episode the Play button continues: the last one watched (or the next one if it was finished). */
    private fun continueTarget(): Episode? {
        val it = item ?: return null
        if (episodes.isEmpty()) return null
        val prefs = applicationContext.repo.prefs
        val last = prefs.lastEpisode(it.uid)
        val i = episodes.indexOfFirst { e -> e.id == last }
        if (i < 0) return episodes.first()
        return if (prefs.position("ep:${episodes[i].id}") == Resume.FINISHED) episodes.getOrNull(i + 1) ?: episodes[i] else episodes[i]
    }

    private fun showProgress(percent: Int) {
        b.watchProgress.visibility = if (percent > 0) View.VISIBLE else View.GONE
        b.watchProgress.progress = percent
    }

    /** To the right of the Resume button: where playback will pick up and how much is left. Hidden when there is nothing to resume. */
    private fun setResumeInfo(key: String?) {
        val prefs = applicationContext.repo.prefs
        val pos = if (key == null) 0L else prefs.position(key)
        if (key == null || !Resume.hasProgress(pos)) { b.resumeInfo.visibility = View.GONE; return }
        val start = Resume.resumeAt(pos)
        val dur = prefs.duration(key)
        var t = "Resumes at " + TimeFmt.position(start)
        if (dur > start) t += "   •   " + TimeFmt.left(dur - start)
        b.resumeInfo.text = t
        b.resumeInfo.visibility = View.VISIBLE
    }

    private fun refreshPlayLabel() {
        val it = item ?: return
        val prefs = applicationContext.repo.prefs
        setResumeInfo(if (it.type == "movie") it.uid else continueTarget()?.let { e -> "ep:${e.id}" })
        if (it.type == "movie") showProgress(prefs.percent(it.uid))
        else showProgress(continueTarget()?.let { e -> prefs.percent("ep:${e.id}") } ?: 0)
        if (it.type == "movie") {
            b.playBtn.text = if (Resume.hasProgress(prefs.position(it.uid))) "▶  Resume" else "▶  Play"
        } else {
            val e = continueTarget()
            val started = e != null && prefs.lastEpisode(it.uid).isNotBlank()
            b.playBtn.text = if (started && e != null) "▶  Resume S${e.season} E${e.num}" else "▶  Play"
        }
    }

    private fun playEpisode(e: Episode) {
        val it = item ?: return
        val repo = applicationContext.repo
        repo.prefs.setLastEpisode(it.uid, e.id)
        startActivity(PlayerActivity.vod(this, repo.episodeUrl(e), "${it.name} · S${e.season}E${e.num}  ${e.title}", "ep:${e.id}", it.uid))
    }

    private fun metaOf(vararg parts: String) = parts.filter { it.isNotBlank() && it != "0" }.joinToString("   •   ")

    companion object {
        /** [holiday]: opened from The Holidays / a holiday's page / My Holiday Favourites (only then the "＋ My Holiday Favourites" button shows). */
        fun intent(ctx: Context, uid: String, holiday: Boolean = false, holidayId: String = "") =
            Intent(ctx, DetailsActivity::class.java).putExtra("uid", uid).putExtra("holiday", holiday).putExtra("holidayId", holidayId)
    }
}
