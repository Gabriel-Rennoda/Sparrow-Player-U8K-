# 2.9.0 on the U8K (Y = works, E = error + what you saw)
FIRST: GitHub Actions "Build APK" - if red, send the error lines.
- [ ] Settings -> Appearance opens the theme page at once
- [ ] The ▼ arrow at the bottom of menus / Settings / See All is clearly visible
- [ ] Movies / Series: title name + year / rating on the top line; rows start at its left edge
- [ ] Pick another group / carousel group: always the top row
- [ ] A movie that crashed (Muppets Christmas Carol, Charlie Brown Christmas): note what the screen says; then Settings -> Data -> Error Log -> View / Save To Device and send the file
- [ ] Search: type, press Back (keyboard closes): Right reaches titles, Down reaches filters; OK on the box reopens the keyboard
- [ ] Any text box (Add Playlist, rename, search): keyboard comes up by itself
- [ ] Left at the left edge: selector on the current tab's icon; Right = groups; Left = labelled list; in Search, Left from the filters = magnifying glass
- [ ] Hold OK on channels -> menu reads Copy To / Hide / Select All / Clear All / Cancel
- [ ] Details page: age badge line, Genre / Director / Cast lines, Play with Watched badge to its right
- [ ] Hide: details Hide; episode hold OK; See All hold OK (title, several, carousel); group hold OK; Settings -> EPG -> Hidden -> Hidden Movies & Series unhides; Play Next skips a hidden episode
- [ ] Settings -> EPG -> Hide Side Bar After (default Never)
- [ ] Titles from your list 10 / 11: Kids clean; ratings appear after the page opens
