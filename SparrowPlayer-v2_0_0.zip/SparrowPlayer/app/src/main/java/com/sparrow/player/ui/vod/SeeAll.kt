package com.sparrow.player.ui.vod

import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.leanback.widget.Presenter
import com.sparrow.player.ui.theme.Theme

/** The first tile of a holiday's "Top 10 What's Hot" row: OK opens that holiday's page ([scope] = "holiday:<id>"). */
class SeeAll(val scope: String, val label: String)

/** The last tile of a row that has more titles than a row shows: OK opens the grid of ALL the row's titles (the fragment keeps the full list of every row). */
class GridTile(val rowId: Long, val title: String, val count: Int)

/** A tile the size of a poster card (same padding as [PosterCard]) so it lines up with the posters of its row. */
private fun tile(ctx: android.content.Context): Pair<FrameLayout, TextView> {
    val d = ctx.resources.displayMetrics.density
    val side = (12 * d + 2 * d).toInt(); val vert = (6 * d).toInt()
    val box = FrameLayout(ctx).apply {
        layoutParams = ViewGroup.LayoutParams(PosterSize.width(ctx) + 2 * side, PosterSize.height(ctx) + 2 * vert)
        isFocusable = true; isClickable = true
        setPadding(side, vert, side, vert)
    }
    val label = TextView(ctx).apply {
        gravity = Gravity.CENTER; textSize = 18f; tag = "t:item;bg:item"
        setPadding(16, 16, 16, 16); isDuplicateParentStateEnabled = true
    }
    box.addView(label, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
    Theme.applyTree(box)
    return box to label
}

class SeeAllPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(tile(parent.context).first)

    override fun onBindViewHolder(vh: ViewHolder, item: Any?) {
        ((vh.view as ViewGroup).getChildAt(0) as TextView).text = "See All\n${(item as? SeeAll)?.label ?: ""}  ▸"
    }

    override fun onUnbindViewHolder(vh: ViewHolder) {}
}

class GridTilePresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(tile(parent.context).first)

    override fun onBindViewHolder(vh: ViewHolder, item: Any?) {
        val g = item as? GridTile ?: return
        ((vh.view as ViewGroup).getChildAt(0) as TextView).text = "See All\n${g.count} Titles  ▸"
    }

    override fun onUnbindViewHolder(vh: ViewHolder) {}
}

/**
 * The full lists behind "See All" (a row shows only its first titles). Kept in memory, not in the Intent: a row can hold hundreds of titles.
 * [put] returns a token the grid screen reads back; nothing survives a process restart (the grid then simply closes).
 */
object SeeAllStore {
    class Entry(val title: String, val uids: List<String>, val holiday: Boolean, val holidayId: String)
    private val map = LinkedHashMap<String, Entry>()
    private var next = 0

    @Synchronized fun put(e: Entry): String {
        val t = "g" + (next++)
        map[t] = e
        while (map.size > 8) map.remove(map.keys.first())
        return t
    }

    @Synchronized fun get(token: String): Entry? = map[token]
}
