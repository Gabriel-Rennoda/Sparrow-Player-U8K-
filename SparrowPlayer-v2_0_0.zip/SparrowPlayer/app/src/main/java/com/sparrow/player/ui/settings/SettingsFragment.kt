package com.sparrow.player.ui.settings

import android.content.Intent
import android.os.Bundle
import android.text.format.DateUtils
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.R
import com.sparrow.player.data.Langs
import com.sparrow.player.data.LibraryReport
import com.sparrow.player.data.SyncCounts
import com.sparrow.player.data.Provider
import com.sparrow.player.databinding.FragmentSettingsBinding
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.TabContent
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.profiles.ProfileMenus
import com.sparrow.player.ui.search.SearchActivity
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.ui.theme.ThemeActivity
import com.sparrow.player.util.StartupLauncher
import com.sparrow.player.util.TimeFmt
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * Settings: five headings (General, Appearance, Network and Buffering, EPG, About). Each opens a pop-up window with its options.
 * Headings with nothing to offer yet say so; they will fill up in later versions.
 */
class SettingsFragment : Fragment(R.layout.fragment_settings), TabContent {
    private var b: FragmentSettingsBinding? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val bind = FragmentSettingsBinding.bind(view)
        b = bind
        Theme.applyTree(view)
        val repo = requireContext().repo
        val scope = viewLifecycleOwner.lifecycleScope

        fun refresh() = scope.launch {
            val p = repo.activeProvider()
            bind.info.text = if (p == null) "No Playlist Configured" else
                "Active Playlist: ${p.name} (${p.type})   •   Last Sync: " +
                    if (p.lastSync == 0L) "Never" else DateUtils.getRelativeTimeSpanString(p.lastSync)
        }
        refresh()
        bind.generalBtn.setOnClickListener { general { refresh() } }
        bind.appearanceBtn.setOnClickListener { appearance() }
        bind.networkBtn.setOnClickListener { network() }
        bind.epgBtn.setOnClickListener { epg() }
        bind.aboutBtn.setOnClickListener { about() }
        scope.launch { repo.status.collect { if (it == "Ready") refresh() } }
        (activity as? MainActivity)?.contentReady()
    }

    override fun onDestroyView() { b = null; super.onDestroyView() }

    private fun on(v: Boolean) = if (v) "On" else "Off"
    private fun toast(m: String) = Toast.makeText(requireContext(), m, Toast.LENGTH_SHORT).show()

    // ---- General ------------------------------------------------------------------------------------------------------
    private fun general(refresh: () -> Unit) {
        val repo = requireContext().repo
        val p = Popup(requireActivity(), "General")
        p.row("Profiles", repo.activeProfile().name) { ProfileMenus.show(requireActivity()) { id -> chooseIcon(id) } }
        p.row("Add Or Switch Playlist") { playlists(refresh) }
        p.row("Delete Playlist") { chooseToDelete(refresh) }
        p.row("Hidden") { hidden() }
        p.row("Ask Before Hiding", on(repo.prefs.askBeforeHide), keepOpen = true) { r ->
            repo.prefs.askBeforeHide = !repo.prefs.askBeforeHide; r.setValue(on(repo.prefs.askBeforeHide))
        }
        p.row("Holiday Episodes Only (Lite)", on(repo.prefs.holidayEpisodesOnly), keepOpen = true) { r ->
            repo.prefs.holidayEpisodesOnly = !repo.prefs.holidayEpisodesOnly; r.setValue(on(repo.prefs.holidayEpisodesOnly))
        }
        p.row("Library Counts", "IPTV vs Sparrow") { libraryCounts() }
        p.row("Channel Numbers", on(repo.prefs.showNumbers), keepOpen = true) { r ->
            repo.prefs.showNumbers = !repo.prefs.showNumbers; r.setValue(on(repo.prefs.showNumbers))
        }
        // "12 Hr Clock" On = 12 hour clock (the default), Off = 24 hour.
        p.row("12 Hr Clock", on(!repo.prefs.clock24), keepOpen = true) { r ->
            repo.prefs.clock24 = !repo.prefs.clock24; TimeFmt.is24h = repo.prefs.clock24; r.setValue(on(!repo.prefs.clock24))
        }
        p.row("Open On Device Start-Up / Wake-Up", if (repo.prefs.startOnBoot) "Yes" else "No", keepOpen = true) { r ->
            repo.prefs.startOnBoot = !repo.prefs.startOnBoot
            r.setValue(if (repo.prefs.startOnBoot) "Yes" else "No")
            if (repo.prefs.startOnBoot) StartupLauncher.explainPermission(requireActivity())
        }
        p.row("Audio Language", Langs.label(Langs.AUDIO, repo.prefs.audioLang), keepOpen = true) { r ->
            val idx = Langs.AUDIO.indexOfFirst { it.first == repo.prefs.audioLang }
            Popup.choose(requireActivity(), "Audio Language", Langs.AUDIO.map { it.second }, idx) { i ->
                repo.prefs.audioLang = Langs.AUDIO[i].first; r.setValue(Langs.AUDIO[i].second)
            }
        }
        p.row("Subtitles", Langs.label(Langs.SUBTITLES, repo.prefs.subtitleLang), keepOpen = true) { r ->
            val idx = Langs.SUBTITLES.indexOfFirst { it.first == repo.prefs.subtitleLang }
            Popup.choose(requireActivity(), "Subtitles", Langs.SUBTITLES.map { it.second }, idx) { i ->
                repo.prefs.subtitleLang = Langs.SUBTITLES[i].first; r.setValue(Langs.SUBTITLES[i].second)
            }
        }
        p.note("Holiday Episodes Only: a series opened from a holiday lists just the episodes about that holiday (when it has some). Library Counts: how many titles your IPTV list has and how many Sparrow shows.")
        p.note("Audio language and subtitles are applied when a stream has that track. You can also change them while watching: press OK in full screen.")
        p.show()
    }

    private fun playlists(refresh: () -> Unit) {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val all = repo.dao.providers()
            val active = repo.activeProvider()?.id
            val p = Popup(requireActivity(), "Add Or Switch Playlist", "Choose A Playlist To Switch To Or Delete")
            p.row("＋  Add Playlist…") { startActivity(Intent(requireContext(), AddProviderActivity::class.java)) }
            all.forEach { pr ->
                p.row(pr.name, if (pr.id == active) "Active  ✓" else "") { playlistActions(pr, pr.id == active, refresh) }
            }
            if (all.isEmpty()) p.note("No playlists yet. Add one to get started.")
            p.show()
        }
    }

    private fun playlistActions(pr: Provider, isActive: Boolean, refresh: () -> Unit) {
        val repo = requireContext().repo
        val p = Popup(requireActivity(), pr.name, if (isActive) "Active Playlist" else "Playlist")
        if (!isActive) p.row("Switch To This Playlist") {
            repo.prefs.activeProvider = pr.id
            repo.dataVersion.value++
            if (pr.lastSync == 0L) repo.syncAsync(pr)
            refresh(); toast("Switched to ${pr.name}")
        }
        p.row("Delete Playlist…") { confirmDelete(pr, refresh) }
        p.show()
    }

    private fun chooseToDelete(refresh: () -> Unit) {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val all = repo.dao.providers()
            val active = repo.activeProvider()?.id
            val p = Popup(requireActivity(), "Delete Playlist", "Choose The Playlist To Delete")
            all.forEach { pr -> p.row(pr.name, if (pr.id == active) "Active" else "") { confirmDelete(pr, refresh) } }
            if (all.isEmpty()) p.note("There are no playlists to delete.")
            p.show()
        }
    }

    private fun confirmDelete(pr: Provider, refresh: () -> Unit) {
        val repo = requireContext().repo
        Popup.confirm(requireActivity(), "Delete ${pr.name}?", "Channels, movies, series and guide data for this playlist will be deleted.", "Yes, Delete") {
            viewLifecycleOwner.lifecycleScope.launch {
                repo.deleteProvider(pr)
                if (repo.activeProvider() == null) startActivity(Intent(requireContext(), AddProviderActivity::class.java))
                refresh(); toast("Playlist deleted")
            }
        }
    }

    private fun hidden() {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val pid = repo.activeProvider()?.id ?: run { toast("No playlist yet"); return@launch }
            val chans = repo.hiddenChannels(pid)
            val groups = repo.groups(pid).filter { it.hidden }
            val p = Popup(requireActivity(), "Hidden", "Channels And Groups You Hid")
            p.row("Hidden Channels", chans.size.toString()) { hiddenChannels(pid) }
            p.row("Hidden Groups", groups.size.toString()) { hiddenGroups(pid) }
            p.show()
        }
    }

    private fun hiddenChannels(pid: Long) {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val chans = repo.hiddenChannels(pid)
            val p = Popup(requireActivity(), "Hidden Channels", "Select A Channel To Unhide It")
            if (chans.isEmpty()) p.note("No hidden channels.")
            else {
                p.row("Unhide All Channels") { repo.custom(pid).hidden.clear(); repo.saveCustom(pid); toast("All channels unhidden") }
                chans.forEach { c ->
                    p.row(c.name, "Unhide") { repo.custom(pid).setHidden(c.uid, false); repo.saveCustom(pid); toast("${c.name} unhidden") }
                }
            }
            p.show()
        }
    }

    private fun hiddenGroups(pid: Long) {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val groups = repo.groups(pid).filter { it.hidden }
            val p = Popup(requireActivity(), "Hidden Groups", "Select A Group To Unhide It")
            if (groups.isEmpty()) p.note("No hidden groups.")
            else {
                p.row("Unhide All Groups") { repo.custom(pid).hiddenGroups.clear(); repo.saveCustom(pid); toast("All groups unhidden") }
                groups.forEach { g ->
                    p.row(g.name, "Unhide") { repo.custom(pid).setGroupHidden(g.id, false); repo.saveCustom(pid); toast("${g.name} unhidden") }
                }
            }
            p.show()
        }
    }

    // ---- Appearance ---------------------------------------------------------------------------------------------------
    private fun appearance() {
        val p = Popup(requireActivity(), "Appearance")
        p.row("Theme", Theme.palette.name) { startActivity(Intent(requireContext(), ThemeActivity::class.java)) }
        p.note("Stock themes, solid colours, custom and random. Backgrounds are always dark so text stays easy to read. More appearance options will arrive in future updates.")
        p.show()
    }

    // ---- Network and Buffering ----------------------------------------------------------------------------------------
    private fun network() {
        val repo = requireContext().repo
        val p = Popup(requireActivity(), "Network and Buffering")
        p.row("Live Stream Format", repo.prefs.liveFormat.uppercase(), keepOpen = true) { r ->
            repo.prefs.liveFormat = if (repo.prefs.liveFormat == "ts") "m3u8" else "ts"
            r.setValue(repo.prefs.liveFormat.uppercase())
        }
        p.note("TS is the fastest to start; HLS (m3u8) can be steadier on weak connections. Xtream playlists only. More network and buffering options will arrive in future updates.")
        p.show()
    }

    // ---- EPG ----------------------------------------------------------------------------------------------------------
    private var iconTarget = ""
    private val pickIcon = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        ProfileMenus.saveFromUri(requireActivity(), iconTarget, uri)
    }

    private fun chooseIcon(id: String) {
        iconTarget = id
        try { pickIcon.launch("image/*") }
        catch (e: Exception) {
            toast("This TV has no file chooser – use Icon From A Web Address instead")
            ProfileMenus.saveFromUri(requireActivity(), id, null)            // back to the profile's window
        }
    }

    private var pickRow: Popup.Row? = null
    private val pickChannel = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { res ->
        val uid = res.data?.getStringExtra("uid")
        if (res.resultCode == android.app.Activity.RESULT_OK && !uid.isNullOrBlank()) {
            requireContext().repo.prefs.openChannel = uid
            pickRow?.setValue(customLabel(res.data?.getStringExtra("name")))        // the EPG window now reads "Custom: <channel>"
            toast("Opening channel set to " + (res.data?.getStringExtra("name") ?: "the chosen channel"))
        }
    }

    /** What the Opening Channel row of the EPG window shows: "Last Watched" or "Custom: <channel name>". */
    private fun customLabel(name: String?) = "Custom: " + (name ?: "Unavailable")

    private fun epg() {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val open = repo.prefs.openChannel
            epgPopup(if (open.isBlank()) "Last Watched" else customLabel(repo.channel(open)?.name))
        }
    }

    private fun epgPopup(openName: String) {
        val repo = requireContext().repo
        val hours = listOf(24, 12, 6, 3, 2)
        fun label(h: Int) = "$h Hours"
        val p = Popup(requireActivity(), "EPG")
        p.row("EPG Sync", label(repo.prefs.epgHours) + "  ▾", keepOpen = true) { r ->
            Popup.choose(requireActivity(), "EPG Sync Every", hours.map { label(it) }, hours.indexOf(repo.prefs.epgHours)) { i ->
                repo.prefs.epgHours = hours[i]; r.setValue(label(hours[i]) + "  ▾")
            }
        }
        p.row("Sync EPG On App Start", on(repo.prefs.epgOnStart), keepOpen = true) { r ->
            repo.prefs.epgOnStart = !repo.prefs.epgOnStart; r.setValue(on(repo.prefs.epgOnStart))
        }
        p.row("Opening Channel", openName, keepOpen = true) { r ->
            viewLifecycleOwner.lifecycleScope.launch {
                val open = repo.prefs.openChannel
                val custom = open.isNotBlank()
                val name = if (custom) repo.channel(open)?.name else null
                val m = Popup(requireActivity(), "Opening Channel", "The Channel Sparrow Player Starts On Every Time It Opens")
                m.row("Last Watched (Default)", if (!custom) "✓" else "") {
                    repo.prefs.openChannel = ""; r.setValue("Last Watched"); toast("The app opens on the last channel you watched")
                }
                m.row(if (custom) "Custom: " + (name ?: "Unavailable") else "Custom", if (custom) "✓" else "") {
                    pickRow = r; pickChannel.launch(SearchActivity.pickChannel(requireContext()))
                }
                m.note("Custom opens the guide with the mini player (top left) on the channel you choose. You can also hold OK on any channel in the guide and choose Set As Opening Channel.")
                m.show()
            }
        }
        val delays = listOf(0, 2, 3, 5, 10)
        fun delayLabel(v: Int) = if (v == 0) "Never" else "$v Seconds"
        p.row("Hide Side Bar After", delayLabel(repo.prefs.railHideSeconds) + "  ▾", keepOpen = true) { r ->
            Popup.choose(requireActivity(), "Hide Side Bar After", delays.map { delayLabel(it) }, delays.indexOf(repo.prefs.railHideSeconds)) { i ->
                repo.prefs.railHideSeconds = delays[i]; r.setValue(delayLabel(delays[i]) + "  ▾")
            }
        }
        p.row("Sync Now") {
            viewLifecycleOwner.lifecycleScope.launch {
                val pr = repo.activeProvider()
                if (pr == null) toast("Add a playlist first") else { repo.syncAsync(pr); toast("Sync started") }
            }
        }
        p.note("Hide Side Bar: the Sparrow icon bar hides after this many seconds. Press Left twice (or Back twice) to bring it back; Search is first in it.")
        p.note("Sync Now refreshes channels, movies, series and the TV guide. Automatic syncs update the guide only.")
        p.show()
    }

    // ---- Library Counts: the IPTV provider's numbers next to what Sparrow Player shows ---------------------------------------------------------
    private fun n(v: Int): String = String.format("%,d", v)

    private fun libraryCounts() {
        val repo = requireContext().repo
        viewLifecycleOwner.lifecycleScope.launch {
            val pr = repo.activeProvider() ?: run { toast("No playlist yet"); return@launch }
            toast("Counting titles…")
            val sent = SyncCounts.parse(repo.prefs.syncCounts(pr.id))
            val movies = try { repo.libraryReport(pr.id, "movie") } catch (e: Exception) { null }
            val series = try { repo.libraryReport(pr.id, "series") } catch (e: Exception) { null }
            val live = try { repo.dao.channelCount(pr.id) } catch (e: Exception) { 0 }
            val p = Popup(requireActivity(), "Library Counts", "Your IPTV list vs. what Sparrow Player shows  •  " + pr.name)
            if (sent == null) p.note("This playlist was synced before the counts existed: use Settings → EPG → Sync Now once, then the IPTV numbers show here.")
            else p.note("IPTV = what the panel sent at the last sync (" + DateUtils.getRelativeTimeSpanString(sent.at) + ").")
            p.row("Live Channels", "IPTV " + (sent?.let { n(it.liveSent) } ?: "?") + "   •   Sparrow " + n(live), keepOpen = true) { }
            if (movies != null) section(p, "Movies", movies, sent?.movieSent, sent?.movieUnique, sent?.movieCategories)
            if (series != null) section(p, "Series", series, sent?.seriesSent, sent?.seriesUnique, sent?.seriesCategories)
            if (movies == null && series == null) p.note("The catalogue is not ready yet. Try again in a moment.")
            p.row("Close") { }
            p.show()
        }
    }

    private fun section(p: Popup, label: String, r: LibraryReport, sent: Int?, sentUnique: Int?, cats: Int?) {
        val kind = if (r.type == "movie") "Movies" else "Series"
        p.note(label.uppercase())
        p.row("IPTV List Sent", sent?.let { n(it) } ?: "Sync Needed", keepOpen = true) { }
        p.row("Saved In Sparrow", n(r.stored) + (if (sentUnique != null && sentUnique != r.stored) "   (IPTV unique ids: " + n(sentUnique) + ")" else ""), keepOpen = true) { }
        if (sent != null && sentUnique != null && sent > sentUnique) p.row("Repeated Ids In IPTV List", n(sent - sentUnique), keepOpen = true) { }
        p.row("Different Titles", n(r.unique) + "   (a title in several categories counts once)", keepOpen = true) { }
        p.row("In A Genre Group", n(r.inGenreGroup), keepOpen = true) { }
        p.row("Only In All $kind", n(r.inNoGenreGroup) + "   (no genre found)", keepOpen = true) { }
        p.row("Kids Titles", n(r.kids), keepOpen = true) { }
        p.row("Holiday Titles", n(r.holidays), keepOpen = true) { }
        p.row("Adult (Kept Out Of Holidays)", n(r.adult), keepOpen = true) { }
        p.row("No Poster / Rating / Year", n(r.noPoster) + " / " + n(r.noRating) + " / " + n(r.noYear), keepOpen = true) { }
        if (cats != null) p.row("IPTV Categories", n(cats), keepOpen = true) { }
        p.row("$kind By Genre", r.perGenre.size.toString() + " Genres") { breakdown("$kind By Genre", r.perGenre) }
        p.row("$kind By IPTV Category", r.perCategory.size.toString() + " Categories") { breakdown("$kind By IPTV Category", r.perCategory) }
    }

    private fun breakdown(title: String, l: List<Pair<String, Int>>) {
        val p = Popup(requireActivity(), title, "Titles In Each")
        if (l.isEmpty()) p.note("Nothing to list.")
        l.forEach { (name, c) -> p.row(name, n(c), keepOpen = true) { } }
        p.show()
    }

    // ---- About --------------------------------------------------------------------------------------------------------
    private fun about() {
        val ver = try { requireContext().packageManager.getPackageInfo(requireContext().packageName, 0).versionName } catch (e: Exception) { "?" }
        val p = Popup(requireActivity(), "About", "Sparrow Player $ver   •   Media3 / ExoPlayer   •   Leanback")
        p.note("Guide: OK tunes the channel (OK again for full screen). Hold OK on a channel for its options: favourite, hide, copy, move, rename.")
        p.note("Channel Groups: hold OK on a group to rename, move, hide or delete it.")
        p.note("Back opens Channel Groups, then the Tab List; Right closes them. Back again on the Tab List asks to exit.")
        p.note("Search: the Search entry at the top of the tab list and the channel groups, the Search button above the Movies / Series rows, or the remote's search key.")
        p.note("Full screen: Up / Down = zap, 0-9 = channel number, OK twice = audio and subtitles (gear icon, bottom right).")
        p.row("Close") { }
        p.show()
    }

    // ---- TabContent: a single column of buttons, so every row is on the left edge ---------------
    override fun focusContent(): Boolean = view?.findViewById<View>(R.id.generalBtn)?.requestFocus() ?: false
    override fun isAtLeftEdge() = true
}
