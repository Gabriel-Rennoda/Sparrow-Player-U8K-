package com.sparrow.player.data

/**
 * Age certifications from The Movie Database (TMDB, https://www.themoviedb.org) for the titles of a playlist (personal, non-commercial use; needs the
 * user's own free v3 API key, Settings -> Data, Backup & About -> TMDB Ratings).
 *
 * IPTV lists carry no ratings, so the Child filter ([Maturity]) used to judge by category / name words. A certification found here is stored per title
 * ([TmdbStore]) and treated exactly like a rating the panel gave: [Repository.maturities] merges it in. Titles TMDB cannot match with certainty are
 * simply left to the old word rules. Pure Kotlin (the network part is in [Repository]); unit tested.
 */
object Tmdb {
    /**
     * The owner's free TMDB v3 API key, built in so Child-safety ratings work without typing anything (personal use). It is read from the APK by anyone
     * who can get the file, so it must stay a free key that can be revoked at themoviedb.org -> Settings -> API; Settings can switch to another key or off.
     */
    const val BUILT_IN_KEY = "35c859299f7b389cb96243849b452a71"

    private val MOVIE_RANK = listOf("G", "PG", "PG-13", "R", "NC-17")
    private val TV_RANK = listOf("TV-Y", "TV-G", "TV-PG", "TV-14", "TV-MA")

    /** App rating code for a TMDB movie certification of [country] ("US" / "CA"); "" = not usable. Canadian codes are folded onto the US ones the limits use. */
    fun movieCode(cert: String, country: String): String {
        val c = cert.trim().uppercase()
        if (c.isEmpty()) return ""
        if (country == "CA") return when (c) { "G" -> "G"; "PG" -> "PG"; "14A" -> "PG-13"; "18A", "R", "A" -> "R"; else -> "" }
        return if (c in MOVIE_RANK) c else ""
    }

    /** The same for a series' content rating ("TV-MA", Canadian "C8", "14+" ...). TV-Y7 counts as TV-Y (the limits have no Y7). */
    fun tvCode(rating: String, country: String): String {
        val c = rating.trim().uppercase()
        if (c.isEmpty()) return ""
        if (country == "CA") return when (c) { "C" -> "TV-Y"; "C8" -> "TV-G"; "G" -> "TV-G"; "PG" -> "TV-PG"; "14+" -> "TV-14"; "18+" -> "TV-MA"; else -> "" }
        return when (c) { "TV-Y7", "TV-Y7-FV" -> "TV-Y"; in TV_RANK -> c; else -> "" }
    }

    /** The strictest (highest) of several codes: when the US and Canada differ the stricter one is used, so a Child profile errs on the safe side. */
    fun strictest(codes: List<String>): String {
        var best = ""; var bestRank = -1
        for (c in codes) {
            val r = MOVIE_RANK.indexOf(c).let { if (it >= 0) it else TV_RANK.indexOf(c) }
            if (r > bestRank) { bestRank = r; best = c }
        }
        return best
    }

    /** From the answer of /movie/{id}/release_dates. */
    @Suppress("UNCHECKED_CAST")
    fun movieCertFrom(json: Map<String, Any?>): String {
        val res = json["results"] as? List<Any?> ?: return ""
        val codes = ArrayList<String>()
        for (r in res) {
            val m = r as? Map<String, Any?> ?: continue
            val cc = m.str("iso_3166_1")
            if (cc != "US" && cc != "CA") continue
            val dates = m["release_dates"] as? List<Any?> ?: continue
            for (d in dates) {
                val dm = d as? Map<String, Any?> ?: continue
                val code = movieCode(dm.str("certification"), cc)
                if (code.isNotEmpty()) codes += code
            }
        }
        return strictest(codes)
    }

    /** From the answer of /tv/{id}/content_ratings. */
    @Suppress("UNCHECKED_CAST")
    fun tvCertFrom(json: Map<String, Any?>): String {
        val res = json["results"] as? List<Any?> ?: return ""
        val codes = ArrayList<String>()
        for (r in res) {
            val m = r as? Map<String, Any?> ?: continue
            val cc = m.str("iso_3166_1")
            if (cc != "US" && cc != "CA") continue
            val code = tvCode(m.str("rating"), cc)
            if (code.isNotEmpty()) codes += code
        }
        return strictest(codes)
    }

    /**
     * The TMDB id of the search answer that IS this title: the (normalised) title or original title must equal [name] and the year, when both are
     * known, differ by at most one. Anything less certain returns 0 (no guess).
     */
    @Suppress("UNCHECKED_CAST")
    fun pickId(json: Map<String, Any?>, name: String, year: Int, tv: Boolean): Int {
        val res = json["results"] as? List<Any?> ?: return 0
        val want = TextNorm.prepare(name).trim()
        if (want.isEmpty()) return 0
        for (r in res) {
            val m = r as? Map<String, Any?> ?: continue
            val id = m.str("id").toIntOrNull() ?: continue
            val t1 = TextNorm.prepare(m.str(if (tv) "name" else "title")).trim()
            val t2 = TextNorm.prepare(m.str(if (tv) "original_name" else "original_title")).trim()
            val y = m.str(if (tv) "first_air_date" else "release_date").take(4).toIntOrNull() ?: 0
            val yearOk = year <= 0 || y == 0 || Math.abs(y - year) <= 1
            if ((t1 == want || t2 == want) && yearOk) return id
        }
        return 0
    }

    private val LANG_PREFIX = Regex("^[A-Z]{2,3}\\s*[-|]\\s+")
    private val BRACKETS = Regex("[\\[(].*?[\\])]")
    private val TAGS = Regex("(?i)\\b(4k|uhd|fhd|hd|sd|hevc|x264|x265|1080p|720p|2160p|web-dl|bluray|multi|dubbed|subbed)\\b")
    private val TRAILING_YEAR = Regex("\\s+(19|20)\\d\\d\\s*$")

    /** A provider's title ("EN - The Movie (2019) 4K") as TMDB would know it ("The Movie"). */
    /** Genres, director (a series: its creators) and the first cast names out of /movie/{id}?append_to_response=credits (or /tv/{id}). */
    @Suppress("UNCHECKED_CAST")
    fun detailsFrom(json: Map<String, Any?>, tv: Boolean): TmdbDetails {
        fun names(l: Any?, limit: Int, ok: (Map<String, Any?>) -> Boolean = { true }): String =
            (l as? List<Any?> ?: emptyList()).mapNotNull { e -> e as? Map<String, Any?> }.filter(ok).map { m -> m.str("name") }.filter { n -> n.isNotBlank() }.take(limit).joinToString(", ")
        val credits = json["credits"] as? Map<String, Any?> ?: emptyMap()
        val director = if (tv) names(json["created_by"], 2) else names(credits["crew"], 2) { m -> m.str("job") == "Director" }
        return TmdbDetails(names(json["genres"], 3), director, names(credits["cast"], 5), if (tv) "Creator" else "Director")
    }

    fun cleanTitle(raw: String): String {
        var s = raw.trim()
        s = LANG_PREFIX.replace(s, "")
        s = BRACKETS.replace(s, " ")
        s = TAGS.replace(s, " ")
        s = TRAILING_YEAR.replace(s, "")
        return s.replace(Regex("\\s+"), " ").trim()
    }
}

/** uid -> the certification TMDB gave (code "" = looked up, nothing usable: not asked again) and the TMDB id. One tab separated line per title. Pure Kotlin. */
/** What TMDB knows about one title, for the information page ("" = nothing). */
class TmdbDetails(val genres: String, val director: String, val cast: String, val directorLabel: String)

class TmdbStore {
    class Entry(val code: String, val tmdbId: Int)

    private val map = HashMap<String, Entry>()
    private val codes = HashMap<String, String>()

    fun has(uid: String): Boolean = map.containsKey(uid)
    fun idOf(uid: String): Int = map[uid]?.tmdbId ?: 0
    fun size(): Int = map.size
    fun withCode(): Int = codes.size

    fun put(uid: String, code: String, tmdbId: Int) {
        map[uid] = Entry(code, tmdbId)
        if (code.isNotEmpty()) codes[uid] = code else codes.remove(uid)
    }

    /** uid -> code, only the titles that have one (a copy). */
    fun maturities(): Map<String, String> = HashMap(codes)

    fun serialize(): String {
        val sb = StringBuilder()
        for ((k, e) in map) sb.append(k).append('\t').append(e.code).append('\t').append(e.tmdbId).append('\n')
        return sb.toString()
    }

    companion object {
        fun parse(s: String?): TmdbStore {
            val st = TmdbStore()
            if (s.isNullOrBlank()) return st
            for (line in s.split('\n')) {
                val f = line.split('\t')
                if (f.size >= 3 && f[0].isNotEmpty()) st.put(f[0], f[1], f[2].toIntOrNull() ?: 0)
            }
            return st
        }
    }
}
