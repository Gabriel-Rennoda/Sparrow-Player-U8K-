package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class SearchTest {
    @Test fun qualityTagsAndDefault() {
        assertEquals("4K", MediaTags.quality("Dune (2021) 4K HDR")); assertEquals("4K", MediaTags.quality("Movie 2160p"))
        assertEquals("UHD", MediaTags.quality("UHD | Movie")); assertEquals("FHD", MediaTags.quality("Movie FHD"))
        assertEquals("FHD", MediaTags.quality("Movie 1080p HD")); assertEquals("HD", MediaTags.quality("Sports HD"))
        assertEquals("SD", MediaTags.quality("Plain Title")); assertEquals("SD", MediaTags.quality("SHD Channel"))
    }

    @Test fun languageTags() {
        assertEquals(setOf("en"), MediaTags.languages("EN | The Movie")); assertEquals(setOf("fr"), MediaTags.languages("[FR] Le Film"))
        assertEquals(setOf("es"), MediaTags.languages("Pelicula (ES)")); assertEquals(setOf("de"), MediaTags.languages("DE - Der Film"))
        assertEquals(setOf("fr"), MediaTags.languages("French Movies")); assertEquals(setOf("en", "fr"), MediaTags.languages("EN | Film | French"))
        assertTrue(MediaTags.languages("It Follows").isEmpty()); assertTrue(MediaTags.languages("Plain").isEmpty())
    }

    @Test fun subtitleAndMaturityTags() {
        assertTrue(MediaTags.hasSubtitles("Movie (SUB)")); assertTrue(MediaTags.hasSubtitles("Film VOSTFR")); assertTrue(MediaTags.hasSubtitles("Multi-Sub Movie"))
        assertFalse(MediaTags.hasSubtitles("Submarine"))
        assertEquals("TV-MA", MediaTags.maturity("Show [TV-MA]")); assertEquals("PG-13", MediaTags.maturity("Rated PG-13"))
        assertEquals("R", MediaTags.maturity("Movie (R)")); assertEquals("R", MediaTags.maturity("R")); assertEquals("PG", MediaTags.maturity("[PG]"))
        assertEquals("", MediaTags.maturity("Plain")); assertEquals("NC-17", MediaTags.maturity("NC-17"))
        assertTrue(MediaTags.maturityRank("TV-Y") < MediaTags.maturityRank("R")); assertEquals(99, MediaTags.maturityRank(""))
    }

    @Test fun channelTypes() {
        assertEquals("Sports", MediaTags.channelType("US Sports", "ESPN 2")); assertEquals("News", MediaTags.channelType("", "CNN International"))
        assertEquals("Kids", MediaTags.channelType("Kids", "Nick Jr")); assertEquals("Other", MediaTags.channelType("", "Channel 7"))
    }

    private fun c(name: String, n: Int = 0, f: (Candidate) -> Candidate = { it }) = f(Candidate("u$n$name", name))
    private val movies = listOf(
        Candidate("a", "Alpha Quest", genres = setOf("action"), year = 2019, stars = 4.0, sparrow = 4.5, added = 300, lengthMin = 120, maturity = "PG-13", quality = "4K", languages = setOf("en"), subtitles = true, description = "a hero journey", myRating = "loved"),
        Candidate("b", "Beta Love", genres = setOf("romance", "drama"), year = 2005, stars = 3.0, sparrow = 2.5, added = 100, lengthMin = 95, maturity = "R", quality = "HD", languages = setOf("fr")),
        Candidate("c", "Gamma Ray", genres = setOf("action"), year = 2021, stars = 2.0, added = 200, quality = "SD"),
        Candidate("d", "delta force", genres = setOf("war"), year = 0, stars = -1.0, added = 0, maturity = "Not Rated", quality = "FHD", languages = setOf("en", "es"), myRating = "disliked")
    )
    private fun f(vararg mod: (SearchFilters) -> SearchFilters): SearchFilters = mod.fold(SearchFilters(SearchKind.MOVIE)) { a, m -> m(a) }
    private fun names(l: List<Candidate>) = l.map { it.name }

    @Test fun textInTitleAndDescription() {
        assertEquals(listOf("Alpha Quest"), names(SearchEngine.apply(movies, f({ it.copy(text = "alpha") }))))
        assertEquals(listOf("Alpha Quest", "Beta Love"), names(SearchEngine.apply(movies, f({ it.copy(text = "A") }))).take(2))
        assertTrue(SearchEngine.apply(movies, f({ it.copy(text = "hero") })).isEmpty())
        assertEquals(listOf("Alpha Quest"), names(SearchEngine.apply(movies, f({ it.copy(text = "hero", inDescription = true) }))))
        assertEquals(listOf("Alpha Quest"), names(SearchEngine.apply(movies, f({ it.copy(text = "zzz", inDescription = true) }), descMatches = setOf("a"))))
    }

    @Test fun qualityLanguageSubtitles() {
        assertEquals(setOf("Alpha Quest", "delta force"), names(SearchEngine.apply(movies, f({ it.copy(qualities = setOf("4K", "FHD")) }))).toSet())
        assertEquals(listOf("Alpha Quest"), names(SearchEngine.apply(movies, f({ it.copy(subtitles = SubsFilter.WITH) }))))
        assertEquals(3, SearchEngine.apply(movies, f({ it.copy(subtitles = SubsFilter.WITHOUT) })).size)
        assertEquals(setOf("Alpha Quest", "delta force"), names(SearchEngine.apply(movies, f({ it.copy(languages = setOf("en")) }))).toSet())
        assertEquals(setOf("Beta Love", "Gamma Ray"), names(SearchEngine.apply(movies, f({ it.copy(languages = setOf("en"), languagesOut = true) }))).toSet())
        assertEquals(listOf("Gamma Ray"), names(SearchEngine.apply(movies, f({ it.copy(languages = setOf("Unknown")) }))))
    }

    @Test fun yearGenreLengthRatings() {
        assertEquals(setOf("Alpha Quest", "Gamma Ray"), names(SearchEngine.apply(movies, f({ it.copy(yearFrom = 2010, yearTo = 2022) }))).toSet())
        assertEquals(setOf("Alpha Quest", "Gamma Ray"), names(SearchEngine.apply(movies, f({ it.copy(genres = setOf("Action")) }))).toSet())
        assertEquals(listOf("Beta Love"), names(SearchEngine.apply(movies, f({ it.copy(lengthMin = 60, lengthMax = 100) }))))
        assertEquals(setOf("Alpha Quest", "Beta Love"), names(SearchEngine.apply(movies, f({ it.copy(minStars = 3.0) }))).toSet())
        assertEquals(listOf("Alpha Quest"), names(SearchEngine.apply(movies, f({ it.copy(minSparrow = 4.0) }))))
    }

    @Test fun myRatingsAndMaturityIncludeOrExclude() {
        assertEquals(listOf("Alpha Quest"), names(SearchEngine.apply(movies, f({ it.copy(myRatings = setOf("loved")) }))))
        assertEquals(setOf("Beta Love", "Gamma Ray", "delta force"), names(SearchEngine.apply(movies, f({ it.copy(myRatings = setOf("loved"), myRatingsOut = true) }))).toSet())
        assertEquals(listOf("Beta Love"), names(SearchEngine.apply(movies, f({ it.copy(maturities = setOf("R")) }))))
        assertEquals(3, SearchEngine.apply(movies, f({ it.copy(maturities = setOf("R"), maturitiesOut = true) })).size)
    }

    @Test fun sortingKeepsUnknownLastInBothDirections() {
        assertEquals(listOf("Alpha Quest", "Beta Love", "delta force", "Gamma Ray"), names(SearchEngine.apply(movies, f())))
        assertEquals(listOf("Gamma Ray", "delta force", "Beta Love", "Alpha Quest"), names(SearchEngine.apply(movies, f({ it.copy(descending = true) }))))
        val byYear = SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.RELEASE) })); assertEquals(listOf("Beta Love", "Alpha Quest", "Gamma Ray", "delta force"), names(byYear))
        val byYearDesc = SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.RELEASE, descending = true) })); assertEquals(listOf("Gamma Ray", "Alpha Quest", "Beta Love", "delta force"), names(byYearDesc))
        assertEquals(listOf("Beta Love", "Alpha Quest", "delta force", "Gamma Ray"), names(SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.LENGTH) }))))
        assertEquals(listOf("Alpha Quest", "Beta Love", "delta force", "Gamma Ray"), names(SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.LENGTH, descending = true) }))))
        assertEquals(listOf("Alpha Quest", "Gamma Ray", "Beta Love", "delta force"), names(SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.GENRE) }))))
        assertEquals(listOf("delta force", "Beta Love", "Gamma Ray", "Alpha Quest"), names(SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.GENRE, descending = true) }))))
        assertEquals(listOf("Alpha Quest", "Beta Love", "delta force", "Gamma Ray"), names(SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.MATURITY) }))))
        assertEquals(listOf("Beta Love", "Alpha Quest", "delta force", "Gamma Ray"), names(SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.MATURITY, descending = true) }))))
        assertEquals(listOf("Alpha Quest", "Gamma Ray", "Beta Love", "delta force"), names(SearchEngine.apply(movies, f({ it.copy(sortBy = SortBy.ADDED, descending = true) }))))
    }

    @Test fun activeFilterCountIgnoresTextAndSort() {
        assertEquals(0, f({ it.copy(text = "x", sortBy = SortBy.ADDED) }).activeCount)
        assertEquals(3, f({ it.copy(qualities = setOf("HD"), yearFrom = 1990, minStars = 3.0) }).activeCount)
    }
}
