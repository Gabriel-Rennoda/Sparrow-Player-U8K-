package com.sparrow.player

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.sparrow.player.data.Repository
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.TimeFmt

class SparrowApp : Application(), ImageLoaderFactory {
    lateinit var repo: Repository
        private set

    override fun onCreate() {
        super.onCreate()
        repo = Repository(this)
        TimeFmt.is24h = repo.prefs.clock24
        Theme.init(this)
        repo.startScheduler()          // automatic guide sync (Settings -> EPG)
    }

    /**
     * One image loader for the whole app, tuned for poster browsing on a TV: a big memory cache (posters are RGB565 JPEGs),
     * a 300 MB disk cache that ignores the panel's "no-cache" headers, and no fade-in (a fade is what looked like posters
     * "changing" while browsing).
     */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.30).build() }
        .diskCache { DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizeBytes(300L * 1024 * 1024).build() }
        .allowRgb565(true)
        .respectCacheHeaders(false)
        .crossfade(false)
        .build()
}
