package com.sparrow.player.ui.search

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.doOnLayout
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sparrow.player.R
import com.sparrow.player.data.Candidate
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Langs
import com.sparrow.player.data.MediaTags
import com.sparrow.player.data.Recommender
import com.sparrow.player.data.Repository
import com.sparrow.player.data.SearchEngine
import com.sparrow.player.data.SearchFilters
import com.sparrow.player.data.SearchKind
import com.sparrow.player.data.SortBy
import com.sparrow.player.data.SparrowRating
import com.sparrow.player.data.SubsFilter
import com.sparrow.player.data.UserRatings
import com.sparrow.player.data.VodItem
import com.sparrow.player.databinding.ActivitySearchBinding
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.player.PlayerActivity
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.ui.vod.DetailsActivity
import com.sparrow.player.ui.vod.RatedImageView
import com.sparrow.player.util.TitleCase
import com.sparrow.player.util.dp
import com.sparrow.player.util.loadUrl
import com.sparrow.player.util.repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The search window. Opened from the Search entry at the top of the tab list / channel groups, the Search button on Movies and Series,
 * or the remote's search key, after choosing Live Channels, Movies or Series.
 *
 *  Filters (left): Search In, Search Text (+ include descriptions), Quality, Subtitles, Language (show only / hide), then
 *    Live Channels: Channel Type
 *    Movies and Series: Release Year range, Genre, Length range, My Ratings (Loved / Liked / Disliked, show only / hide),
 *                       Star Rating, Sparrow Rating, Maturity Rating (show only / hide)
 *  Sort: Sort By + Ascending / Descending.
 *  Results (right) update after every change. The last filters of each kind are remembered while the app is open.
 */
class SearchActivity : FragmentActivity() {
    private lateinit var b: ActivitySearchBinding
    private var kind = SearchKind.MOVIE
    private var f = SearchFilters(SearchKind.MOVIE)

    private var all: List<Candidate> = emptyList()
    private var channels: List<Channel> = emptyList()
    private val chanByUid = HashMap<String, Channel>()
    private val vodByUid = HashMap<String, VodItem>()
    private var providerId = -1L
    private var genreOptions: List<String> = emptyList()
    private var yearOptions: List<Int> = emptyList()

    private val updaters = ArrayList<() -> Unit>()
    private var loadJob: Job? = null
    private var refreshJob: Job? = null
    private lateinit var adapter: ResultAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(b.root)
        Theme.applyAll(this, b.root)
        kind = runCatching { SearchKind.valueOf(intent.getStringExtra("kind") ?: "") }.getOrDefault(SearchKind.MOVIE)

        adapter = ResultAdapter({ c -> open(c) }, { c -> imageOf(c) })
        b.results.itemAnimator = null
        b.results.adapter = adapter
        start()
    }

    /** (Re)load the data for [kind] and build the filter list. */
    private fun start() {
        f = remembered[kind] ?: SearchFilters(kind)
        b.title.text = "Search – " + kind.label
        b.count.text = "Loading…"
        b.empty.visibility = View.GONE
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            val repo = applicationContext.repo
            val p = repo.activeProvider()
            if (p == null) { finish(); return@launch }
            providerId = p.id
            withContext(Dispatchers.Default) { load(repo, p.id) }
            genreOptions = all.flatMap { it.genres }.groupingBy { it }.eachCount().entries
                .sortedByDescending { it.value }.take(120).map { it.key }.sorted()
            val years = all.map { it.year }.filter { it in 1900..2100 }
            yearOptions = if (years.isEmpty()) emptyList() else (years.min()..years.max()).toList()

            val vod = kind != SearchKind.LIVE
            adapter.live = !vod
            b.results.layoutManager = if (vod) GridLayoutManager(this@SearchActivity, 3) else LinearLayoutManager(this@SearchActivity)
            if (vod) b.results.doOnLayout { rv ->
                (rv as RecyclerView).layoutManager = GridLayoutManager(this@SearchActivity, maxOf(2, rv.width / dp(160)))
            }
            buildFilters()
            refresh()
            b.filterList.getChildAt(1)?.requestFocus()                 // "Search Text"
        }
    }

    // ---- data -----------------------------------------------------------------------------------------------------
    private suspend fun load(repo: Repository, pid: Long) {
        if (kind == SearchKind.LIVE) {
            val cats = repo.dao.categories(pid, "live").associate { it.remoteId to TitleCase.of(it.name) }
            channels = repo.channelsFor(pid, Repository.SCOPE_ALL)
            chanByUid.clear(); channels.forEach { chanByUid[it.uid] = it }
            vodByUid.clear()
            all = channels.map { c ->
                val g = cats[c.categoryId] ?: ""
                val tagText = c.name + " " + g
                Candidate(
                    uid = c.uid, name = c.name, group = g, quality = MediaTags.quality(tagText), languages = MediaTags.languages(tagText),
                    subtitles = MediaTags.hasSubtitles(c.name), channelType = MediaTags.channelType(g, c.name), number = c.number, live = true
                )
            }
        } else {
            val movies = kind == SearchKind.MOVIE
            val cats = repo.dao.categories(pid, if (movies) "vod" else "series").associate { it.remoteId to TitleCase.of(it.name) }
            val items = repo.dao.vodAll(pid, if (movies) "movie" else "series")
            vodByUid.clear(); items.forEach { vodByUid[it.uid] = it }
            chanByUid.clear(); channels = emptyList()
            val mine = repo.myRatings()
            fun genresOf(v: VodItem): Set<String> {
                val cat = cats[v.categoryId]?.lowercase()                    // the category name stands in for the genre when the panel has none
                return if (cat.isNullOrBlank()) Recommender.genresOf(v.genre) else Recommender.genresOf(v.genre) + cat
            }
            all = items.map { v ->
                val cat = cats[v.categoryId] ?: ""
                val tagText = v.name + " " + cat
                val meta = repo.meta(v.uid)
                val g = genresOf(v)
                val fromInfo = meta?.maturity?.let { m -> MediaTags.maturity(m).ifBlank { m } } ?: ""
                val maturity = fromInfo.ifBlank { MediaTags.maturity(tagText) }.ifBlank { "Not Rated" }
                val stars = SparrowRating.providerOf(v.rating)
                val my = mine[v.uid] ?: ""
                Candidate(
                    uid = v.uid, name = v.name, group = cat, genres = g, year = Recommender.yearOf(v.year), stars = stars,
                    sparrow = repo.sparrowOf(v), added = v.added,
                    lengthMin = meta?.lengthMin ?: -1, maturity = maturity, quality = MediaTags.quality(tagText),
                    languages = MediaTags.languages(tagText), subtitles = MediaTags.hasSubtitles(tagText),
                    description = v.plot.ifBlank { meta?.plot ?: "" }, myRating = my
                )
            }
        }
    }

    private fun imageOf(c: Candidate): String? = if (c.live) chanByUid[c.uid]?.logo else vodByUid[c.uid]?.poster

    private fun open(c: Candidate) {
        if (c.live) startActivity(PlayerActivity.live(this, c.uid, Repository.SCOPE_ALL))
        else startActivity(DetailsActivity.intent(this, c.uid))
    }

    // ---- results ----------------------------------------------------------------------------------------------------
    private fun refresh() {
        remembered[kind] = f
        updaters.forEach { it() }
        val n = f.activeCount
        b.summary.text = if (n == 0) "No Filters On" else "$n Filter${if (n == 1) "" else "s"} On"
        refreshJob?.cancel()
        refreshJob = lifecycleScope.launch {
            val desc: Set<String> =
                if (kind == SearchKind.LIVE && f.inDescription && f.text.isNotBlank()) withContext(Dispatchers.IO) { liveDescriptionMatches() }
                else emptySet()
            val res = withContext(Dispatchers.Default) { SearchEngine.apply(all, f, desc) }
            adapter.submit(res)
            b.count.text = "${res.size} Result${if (res.size == 1) "" else "s"}"
            b.empty.visibility = if (res.isEmpty()) View.VISIBLE else View.GONE
            b.empty.text = if (all.isEmpty()) "Nothing To Search Yet – Sync Your Playlist First" else "No Results – Try Fewer Filters"
        }
    }

    /** Live channels whose guide listing (title or description, anywhere in the downloaded guide) contains the text. */
    private suspend fun liveDescriptionMatches(): Set<String> {
        val ids = applicationContext.repo.dao.epgIdsMatching(providerId, "%" + f.text.trim() + "%").toHashSet()
        return channels.filter { it.epgId in ids }.map { it.uid }.toHashSet()
    }

    // ---- filter rows ------------------------------------------------------------------------------------------------
    private fun row(label: String, value: () -> String, onClick: () -> Unit) {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            tag = "bg:item"
            minimumHeight = dp(50)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            isFocusable = true
            isClickable = true
        }
        val l = TextView(this).apply {
            text = label; textSize = 17f; tag = "t:item"; isDuplicateParentStateEnabled = true
            setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
        }
        val vv = TextView(this).apply {
            textSize = 16f; tag = "t:item"; isDuplicateParentStateEnabled = true
            setTypeface(typeface, Typeface.BOLD)
            setSingleLine(true); ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.END; maxWidth = dp(190); setPadding(dp(12), 0, 0, 0)
        }
        v.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        v.addView(vv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        updaters += { vv.text = value() }
        v.setOnClickListener { onClick() }
        Theme.applyTree(v)
        b.filterList.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) })
    }

    private fun summarize(set: Set<String>, label: (String) -> String, out: Boolean = false): String {
        if (set.isEmpty()) return "Any"
        val txt = if (set.size <= 2) set.joinToString(", ") { label(it) } else "${set.size} Selected"
        return if (out) "Hide: $txt" else txt
    }

    private fun starsLabel(v: Double) = if (v <= 0) "Any" else SparrowRating.format(v) + " & Up"

    private fun buildFilters() {
        b.filterList.removeAllViews(); updaters.clear()
        val live = kind == SearchKind.LIVE
        val kinds = listOf(SearchKind.LIVE, SearchKind.MOVIE, SearchKind.SERIES)

        row("Search In", { kind.label }) {
            Popup.choose(this, "Search In", kinds.map { it.label }, kinds.indexOf(kind)) { i ->
                if (kinds[i] != kind) { remembered[kind] = f; kind = kinds[i]; start() }
            }
        }
        row("Search Text", { f.text.ifBlank { "Any" } }) {
            Popup.ask(this, "Search Text", "Title", f.text, "Search", allowEmpty = true) { t -> f = f.copy(text = t); refresh() }
        }
        row("Include Descriptions", { if (f.inDescription) "Yes" else "No" }) { f = f.copy(inDescription = !f.inDescription); refresh() }
        row("Quality", { summarize(f.qualities, { it }) }) {
            Popup.multi(this, "Quality", MediaTags.QUALITIES.map { it to it }, f.qualities) { s, _ -> f = f.copy(qualities = s); refresh() }
        }
        row("Subtitles", { f.subtitles.label }) {
            val l = SubsFilter.values().toList()
            Popup.choose(this, "Subtitles", l.map { it.label }, l.indexOf(f.subtitles)) { i -> f = f.copy(subtitles = l[i]); refresh() }
        }
        val langOptions = Langs.ALL + (MediaTags.UNKNOWN_LANGUAGE to MediaTags.UNKNOWN_LANGUAGE)
        row("Language", { summarize(f.languages, { c -> Langs.label(langOptions, c) }, f.languagesOut) }) {
            Popup.multi(this, "Language", langOptions, f.languages, "Show Only Selected", "Hide Selected", f.languagesOut) { s, out ->
                f = f.copy(languages = s, languagesOut = out); refresh()
            }
        }

        if (live) {
            row("Channel Type", { summarize(f.channelTypes, { it }) }) {
                Popup.multi(this, "Channel Type", MediaTags.CHANNEL_TYPES.map { it to it }, f.channelTypes) { s, _ -> f = f.copy(channelTypes = s); refresh() }
            }
        } else {
            row("Release Year From", { if (f.yearFrom == 0) "Any" else f.yearFrom.toString() }) { pickYear("Release Year From", f.yearFrom) { y -> f = f.copy(yearFrom = y); refresh() } }
            row("Release Year To", { if (f.yearTo == 0) "Any" else f.yearTo.toString() }) { pickYear("Release Year To", f.yearTo) { y -> f = f.copy(yearTo = y); refresh() } }
            row("Genre", { summarize(f.genres, { TitleCase.of(it) }) }) {
                if (genreOptions.isEmpty()) toast("No genre information yet")
                else Popup.multi(this, "Genre", genreOptions.map { it to TitleCase.of(it) }, f.genres) { s, _ -> f = f.copy(genres = s); refresh() }
            }
            val minutes = listOf(0, 30, 60, 90, 120, 150, 180, 240)
            fun lenLabel(m: Int) = if (m == 0) "Any" else "$m Min"
            row("Length From", { lenLabel(f.lengthMin) }) {
                Popup.choose(this, "Length From", minutes.map { lenLabel(it) }, minutes.indexOf(f.lengthMin)) { i -> f = f.copy(lengthMin = minutes[i]); refresh() }
            }
            row("Length To", { lenLabel(f.lengthMax) }) {
                Popup.choose(this, "Length To", minutes.map { lenLabel(it) }, minutes.indexOf(f.lengthMax)) { i -> f = f.copy(lengthMax = minutes[i]); refresh() }
            }
            row("My Ratings", { summarize(f.myRatings, { UserRatings.label(it) }, f.myRatingsOut) }) {
                Popup.multi(this, "My Ratings", UserRatings.CODES.map { it to UserRatings.label(it) }, f.myRatings, "Show Only Selected", "Hide Selected", f.myRatingsOut) { s, out ->
                    f = f.copy(myRatings = s, myRatingsOut = out); refresh()
                }
            }
            val steps = (0..20).map { it * 0.5 }            // 0 (any) to 10 in half steps
            row("Star Rating", { starsLabel(f.minStars) }) {
                Popup.choose(this, "Star Rating", steps.map { starsLabel(it) }, steps.indexOf(f.minStars)) { i -> f = f.copy(minStars = steps[i]); refresh() }
            }
            row("Sparrow Rating", { starsLabel(f.minSparrow) }) {
                Popup.choose(this, "Sparrow Rating", steps.map { starsLabel(it) }, steps.indexOf(f.minSparrow)) { i -> f = f.copy(minSparrow = steps[i]); refresh() }
            }
            row("Maturity Rating", { summarize(f.maturities, { it }, f.maturitiesOut) }) {
                Popup.multi(this, "Maturity Rating", MediaTags.MATURITIES.map { it to it }, f.maturities, "Show Only Selected", "Hide Selected", f.maturitiesOut) { s, out ->
                    f = f.copy(maturities = s, maturitiesOut = out); refresh()
                }
            }
        }

        val sorts = SortBy.forKind(kind)
        row("Sort By", { f.sortBy.label.takeIf { f.sortBy in sorts } ?: SortBy.NAME.label }) {
            Popup.choose(this, "Sort By", sorts.map { it.label }, sorts.indexOf(f.sortBy)) { i -> f = f.copy(sortBy = sorts[i]); refresh() }
        }
        row("Order", { if (f.descending) "Descending" else "Ascending" }) { f = f.copy(descending = !f.descending); refresh() }
        row("Reset Filters", { "" }) { f = SearchFilters(kind); refresh() }
    }

    private fun pickYear(title: String, current: Int, onPick: (Int) -> Unit) {
        if (yearOptions.isEmpty()) { toast("No release dates yet"); return }
        val labels = listOf("Any") + yearOptions.map { it.toString() }
        val idx = if (current == 0) 0 else yearOptions.indexOf(current) + 1
        Popup.choose(this, title, labels, idx) { i -> onPick(if (i == 0) 0 else yearOptions[i - 1]) }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---- adapter ----------------------------------------------------------------------------------------------------
    class ResultAdapter(
        private val onPick: (Candidate) -> Unit,
        private val image: (Candidate) -> String?
    ) : RecyclerView.Adapter<ResultAdapter.VH>() {
        var live = false
        private var items: List<Candidate> = emptyList()

        fun submit(l: List<Candidate>) { items = l; notifyDataSetChanged() }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val poster: ImageView = v.findViewById(R.id.poster)
            val name: TextView = v.findViewById(R.id.name)
            val sub: TextView = v.findViewById(R.id.sub)
        }

        override fun getItemViewType(position: Int) = if (live) 1 else 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(if (viewType == 1) R.layout.item_result_row else R.layout.item_result_poster, parent, false)
            Theme.applyTree(v)
            return VH(v)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val c = items[position]
            h.name.text = c.name
            h.sub.text = subtitle(c)
            h.poster.loadUrl(image(c))
            (h.poster as? RatedImageView)?.setRatings(c.stars, c.sparrow)        // provider top left, Sparrow top right
            h.itemView.setOnClickListener { onPick(c) }
        }

        override fun getItemCount() = items.size

        private fun subtitle(c: Candidate): String =
            if (c.live) listOf(if (c.number > 0) "#${c.number}" else "", c.group).filter { it.isNotBlank() }.joinToString("  •  ")
            else listOf(
                if (c.year > 0) c.year.toString() else "", if (c.quality != "SD") c.quality else ""
            ).filter { it.isNotBlank() }.joinToString("  •  ")
    }

    companion object {
        /** Filters stay as the user left them (per kind) while the app is running. */
        private val remembered = HashMap<SearchKind, SearchFilters>()

        fun intent(ctx: Context, kind: SearchKind) = Intent(ctx, SearchActivity::class.java).putExtra("kind", kind.name)
    }
}
