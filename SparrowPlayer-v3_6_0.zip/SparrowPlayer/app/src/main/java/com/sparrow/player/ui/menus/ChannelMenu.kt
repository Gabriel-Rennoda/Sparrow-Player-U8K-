package com.sparrow.player.ui.menus

import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Repository
import com.sparrow.player.util.repo
import kotlinx.coroutines.launch

/**
 * The pop-up that opens when OK is held on a channel in the guide: every option for that one channel.
 *
 *  Play · Add To / Remove From Favourites · Hide / Unhide · Copy To Group (or a brand-new group) · Move To Group (asks Yes / No first)
 *  · Remove From This Group · Edit Channel Name · Restore Original Name
 *
 * Hide asks "Are you sure?" first (with a "Do Not Show This Again" box) and then the channel leaves the guide at once; Settings -> General
 * -> Hidden brings it back. All edits are saved per provider (see Customize) and survive syncs.
 */
object ChannelMenu {
    class Hooks(
        val play: (Channel) -> Unit,
        val toggleFavorite: (Channel) -> Unit,
        /** The channel was hidden / unhidden. A hidden one is taken out of the list at once. */
        val hiddenChanged: (Channel, Boolean) -> Unit,
        /** The channel got another name. */
        val renamed: (Channel) -> Unit,
        /** The channel now belongs to other groups (copy / move / remove): reload the list around it. */
        val membershipChanged: (Channel) -> Unit,
        /** "Copy To Group": the guide goes into tick-box mode with this channel ticked (see EpgView.startSelecting). */
        val startCopySelect: (Channel) -> Unit,
        /** "Hide Several Channels": the same tick-box mode, opened for hiding. */
        val startHideSelect: (Channel) -> Unit,
        /** "Move To Group" (only while viewing a group of the user's own): the same tick-box mode. */
        val startMoveSelect: (Channel) -> Unit
    )

    fun show(a: FragmentActivity, c: Channel, scope: String, h: Hooks) {
        val repo = a.applicationContext.repo
        val pid = c.providerId
        val cu = repo.custom(pid)
        val inGroup = scope != Repository.SCOPE_ALL && scope != Repository.SCOPE_FAV
        val inMine = cu.customGroups.containsKey(scope)                       // provider groups are never changed: Move / Remove only inside my own groups
        val hidden = cu.isHidden(c.uid)
        val renamed = cu.renamed.containsKey(c.uid)

        val p = Popup(a, c.name, "Channel Options")
        p.row("Play Channel") { h.play(c) }
        val picked = com.sparrow.player.ui.player.SplitQueue.contains(c.uid)
        p.row(if (picked) "Remove From Split Screen" else "Add To Split Screen",
            desc = "Pick 2 to 4 live channels, then choose Watch Split Screen. (" + com.sparrow.player.ui.player.SplitQueue.size + " of 4 picked)") {
            if (!picked && com.sparrow.player.ui.player.SplitQueue.full()) toast(a, "Split screen is full (4) – remove one first")
            else {
                val added = com.sparrow.player.ui.player.SplitQueue.toggle(c.uid)
                toast(a, (if (added) "Added" else "Removed") + " – " + com.sparrow.player.ui.player.SplitQueue.size + " of 4 picked")
            }
        }
        if (com.sparrow.player.ui.player.SplitQueue.size >= 2) p.row("Watch Split Screen (" + com.sparrow.player.ui.player.SplitQueue.size + ")") {
            a.startActivity(com.sparrow.player.ui.player.MultiViewActivity.intent(a))
        }
        if (com.sparrow.player.ui.player.SplitQueue.size > 0) p.row("Clear Split Screen Picks") {
            com.sparrow.player.ui.player.SplitQueue.clear(); toast(a, "Split screen picks cleared")
        }
        p.row(if (c.isFavorite) "Remove From Favourites" else "Add To Favourites") { h.toggleFavorite(c) }
        p.row(if (hidden) "Unhide Channel" else "Hide Channel") {
            fun doHide(hide: Boolean) {
                cu.setHidden(c.uid, hide); repo.saveCustom(pid)
                h.hiddenChanged(c, hide)
                toast(a, if (hide) "Channel hidden – Settings → General → Hidden brings it back" else "Channel unhidden")
            }
            if (hidden) doHide(false) else Popup.confirmHide(a, "Channel", c.name) { doHide(true) }
        }
        p.row("Copy To Group…", desc = "Ticks boxes in this list so you can copy one or many channels at once.") { h.startCopySelect(c) }
        p.row("Hide Several Channels…", desc = "Ticks boxes in this list so you can hide many channels at once.") { h.startHideSelect(c) }
        if (inMine) p.row("Move To Group…", desc = "Ticks boxes in this group so you can move one or many channels out of it.") { h.startMoveSelect(c) }
        if (inMine) p.row("Remove From This Group…") {
            Popup.confirm(a, "Remove From Group?", "Remove \"${c.name}\" from this group? It stays in All Channels and in its other groups.", "Yes, Remove") {
                cu.removeFrom(scope, c.uid, c.categoryId); repo.saveCustom(pid)
                h.membershipChanged(c); toast(a, "Removed from group")
            }
        }
        val isOpening = repo.prefs.openChannel == c.uid
        p.row(if (isOpening) "Clear Opening Channel" else "Set As Opening Channel") {
            repo.prefs.openChannel = if (isOpening) "" else c.uid
            toast(a, if (isOpening) "Opening channel cleared – the app opens on the last channel" else "${c.name} is now the opening channel")
        }
        p.row("Edit Channel Name…") {
            a.lifecycleScope.launch {
                val original = repo.dao.channel(c.uid)?.name ?: c.name
                Popup.ask(a, "Edit Channel Name", "Channel name", c.name) { n ->
                    cu.rename(c.uid, n, original); repo.saveCustom(pid)
                    h.renamed(c.copy(name = cu.nameOf(c.uid, original))); toast(a, "Name saved")
                }
            }
        }
        if (renamed) p.row("Restore Original Name") {
            a.lifecycleScope.launch {
                val original = repo.dao.channel(c.uid)?.name ?: c.name
                cu.renamed.remove(c.uid); repo.saveCustom(pid)
                h.renamed(c.copy(name = original)); toast(a, "Original name restored")
            }
        }
        p.show()
    }

    /**
     * The second half of "Copy To Group": [list] = the ticked channels. Choose an existing group, or make a new one (it goes to the top of the groups,
     * just below Favourites) and copy into it. [onDone] runs after a copy so the guide can reload on the same group and channel.
     */
    fun copyMany(a: FragmentActivity, list: List<Channel>, onDone: () -> Unit) {
        if (list.isEmpty()) return
        a.lifecycleScope.launch {
            val repo = a.applicationContext.repo
            val pid = list[0].providerId
            val cu = repo.custom(pid)
            val groups = repo.groups(pid)
            val n = list.size
            val noun = if (n == 1) "1 Channel" else "$n Channels"
            val p = Popup(a, "Copy $noun To…", "Pick a group, or make a new one")
            p.row("＋  New Group…") {
                Popup.ask(a, "New Group", "Group name", "", onCancel = { copyMany(a, list, onDone) }) { name ->
                    val gid = cu.createGroup(name)
                    for (ch in list) cu.copy(ch.uid, gid, ch.categoryId)
                    repo.saveCustom(pid); onDone()
                    toast(a, "$noun copied to new group \"${cu.groupName(gid, name)}\"")
                }
            }
            // a provider group stays as the provider defined it: only groups you created (or a channel's own group) take copies
            val targets = groups.filter { g -> list.all { cu.canReceive(g.id, it.categoryId) } && list.any { !cu.isMember(g.id, it.uid, it.categoryId) } }
            for (g in targets) p.row(g.name + if (g.hidden) "  (Hidden)" else "") {
                var added = 0
                for (ch in list) if (!cu.isMember(g.id, ch.uid, ch.categoryId)) { cu.copy(ch.uid, g.id, ch.categoryId); added++ }
                repo.saveCustom(pid); onDone()
                toast(a, (if (added == 1) "1 channel" else "$added channels") + " copied to ${g.name}")
            }
            p.note("Groups from your provider keep exactly their own channels. Make a new group above to collect channels.")
            p.show()
        }
    }

    /** Hide the ticked channels after one Yes / No; [onDone] lets the guide reload on the same group. */
    fun hideMany(a: FragmentActivity, list: List<Channel>, onDone: () -> Unit) {
        if (list.isEmpty()) return
        val noun = if (list.size == 1) "1 channel" else "${list.size} channels"
        Popup.confirm(a, "Hide $noun?", "They leave the guide at once. Settings → General → Hidden brings them back.", "Yes, Hide") {
            val repo = a.applicationContext.repo
            val pid = list[0].providerId
            val cu = repo.custom(pid)
            for (ch in list) cu.setHidden(ch.uid, true)
            repo.saveCustom(pid); onDone()
            toast(a, "$noun hidden")
        }
    }

    /**
     * The second half of "Move To Group": only inside groups YOU made (a provider group is never changed). [from] = the group being viewed.
     * Asks Yes / No, then the ticked channels leave [from] and appear in the target (an existing group of yours or a new one).
     */
    fun moveMany(a: FragmentActivity, list: List<Channel>, from: String, onDone: () -> Unit) {
        if (list.isEmpty()) return
        a.lifecycleScope.launch {
            val repo = a.applicationContext.repo
            val pid = list[0].providerId
            val cu = repo.custom(pid)
            val groups = repo.groups(pid)
            val fromName = groups.firstOrNull { it.id == from }?.name ?: "this group"
            val noun = if (list.size == 1) "1 Channel" else "${list.size} Channels"
            fun go(toName: String, target: () -> String) {
                Popup.confirm(a, "Move $noun?", "Move $noun from $fromName to $toName? They are removed from $fromName.", "Yes, Move") {
                    val to = target()
                    for (ch in list) cu.move(ch.uid, from, to, ch.categoryId)
                    repo.saveCustom(pid); onDone()
                    toast(a, "$noun moved to $toName")
                }
            }
            val p = Popup(a, "Move $noun To…", "Out of $fromName")
            p.row("＋  New Group…") {
                Popup.ask(a, "New Group", "Group name", "", onCancel = { moveMany(a, list, from, onDone) }) { name ->
                    go(name.trim().ifEmpty { "New Group" }) { cu.createGroup(name) }
                }
            }
            for (g in groups.filter { it.id != from && cu.customGroups.containsKey(it.id) }) p.row(g.name + if (g.hidden) "  (Hidden)" else "") { go(g.name) { g.id } }
            p.show()
        }
    }

    private fun toast(a: FragmentActivity, msg: String) = Toast.makeText(a, msg, Toast.LENGTH_SHORT).show()
}
