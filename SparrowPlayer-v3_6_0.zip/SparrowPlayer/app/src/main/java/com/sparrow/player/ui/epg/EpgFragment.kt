package com.sparrow.player.ui.epg

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.R
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Programme
import com.sparrow.player.data.Repository
import com.sparrow.player.databinding.FragmentEpgBinding
import com.sparrow.player.ui.MainActivity
import com.sparrow.player.ui.TabContent
import com.sparrow.player.ui.menus.ChannelMenu
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.ui.theme.Theme
import com.sparrow.player.util.repo
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * The guide (Live TV, Guide and Favourites tabs all use it). The channel group comes from the groups panel
 * (Favourites tab: fixed to favourites); the player and the info pane live in MainActivity's header.
 * Programmes are loaded lazily for the rows around the selection.
 */
class EpgFragment : Fragment(R.layout.fragment_epg), TabContent {
    private var _b: FragmentEpgBinding? = null
    private val b get() = _b!!
    private val host get() = requireActivity() as MainActivity
    private val favOnly get() = arguments?.getBoolean("favs") == true
    private var scope = Repository.SCOPE_ALL
    private var loadJob: Job? = null
    private var providerId = -1L
    private var dataFrom = 0L
    private var dataTo = 0L
    private val loading = HashSet<String>()
    private val handler = Handler(Looper.getMainLooper())

    private val clockTick = object : Runnable {
        override fun run() {
            if (_b == null) return
            val now = System.currentTimeMillis()
            b.epgView.tick(now)
            handler.postDelayed(this, 60_000 - now % 60_000 + 50)     // next minute boundary
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _b = FragmentEpgBinding.bind(view)
        Theme.applyTree(view)
        val repo = requireContext().repo
        b.epgView.showNumbers = repo.prefs.showNumbers
        b.epgView.onSelect = { row, p, next -> host.browseProgramme(row.channel, p, next) }
        b.epgView.onPlay = { c -> host.onChannelClicked(c, scope) }
        b.epgView.onMenu = { c -> showMenu(c) }
        b.epgView.onNeedData = { f, l -> fetch(f, l) }
        b.epgView.playingUid = host.playing?.uid ?: ""
        clockTick.run()
        load()
    }

    /** Channels unhidden while still listed (only in the hidden-and-listed state; hiding removes the row at once). */
    private val justHidden = HashSet<String>()
    private var keepUid: String? = null
    private var keepIndex = 0

    private fun load() {
        loadJob?.cancel()
        loading.clear()
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val base = GuideMath.baseStart(System.currentTimeMillis())
            val p = repo.activeProvider()
            if (p == null) { b.epgView.setData(emptyList(), base); host.contentReady(); return@launch }
            providerId = p.id
            scope = if (favOnly) Repository.SCOPE_FAV else host.groupScope
            val channels = repo.channelsFor(p.id, scope)
            if (_b == null) return@launch
            dataFrom = GuideMath.minStart(base); dataTo = base + GuideMath.FUTURE
            val rows = channels.map { EpgView.Row(it, if (it.epgId.isBlank()) emptyList() else null) }
            justHidden.clear(); b.epgView.hiddenUids = emptySet()
            val sel = keepUid ?: (host.playing?.uid ?: repo.prefs.lastChannel)
            b.epgView.setData(rows, base, sel, if (keepUid != null) keepIndex else 0)
            keepUid = null
            host.contentReady()
        }
    }

    /** Load programmes for the visible rows plus a margin (rows already loaded / loading are skipped). */
    private fun fetch(first: Int, last: Int) {
        val view = _b?.epgView ?: return
        val list = view.rowList
        if (list.isEmpty()) return
        val from = (first - 4).coerceAtLeast(0); val to = (last + 10).coerceAtMost(list.size - 1)
        val need = (from..to).map { list[it] }.filter { it.programmes == null && it.channel.epgId !in loading }
        if (need.isEmpty()) return
        val ids = need.map { it.channel.epgId }.distinct()
        loading.addAll(ids)
        val pid = providerId; val df = dataFrom; val dt = dataTo
        viewLifecycleOwner.lifecycleScope.launch {
            val byId = HashMap<String, MutableList<Programme>>()
            ids.chunked(400).forEach { chunk ->
                requireContext().repo.dao.programmes(pid, chunk, df, dt).forEach { byId.getOrPut(it.epgId) { ArrayList() }.add(it) }
            }
            loading.removeAll(ids.toSet())
            val v = _b?.epgView ?: return@launch
            if (v.rowList !== list) return@launch                  // group changed while loading: that load will ask again
            need.forEach { it.programmes = byId[it.channel.epgId] ?: emptyList() }
            v.dataArrived()
        }
    }

    /** Hold OK on a channel: all options for it (see ChannelMenu). */
    private fun showMenu(c: Channel) {
        ChannelMenu.show(requireActivity(), c, scope, ChannelMenu.Hooks(
            play = { ch -> host.onChannelClicked(ch, scope) },
            toggleFavorite = { ch -> toggleFavorite(ch) },
            hiddenChanged = { ch, hide ->
                if (hide) {
                    // gone from the list at once (no need to change group and come back); the selector moves to the next channel
                    _b?.epgView?.removeChannel(ch.uid)
                    if (_b?.epgView?.rowList?.isEmpty() == true) { host.wantFocus(); host.contentReady() }
                } else {
                    justHidden -= ch.uid
                    _b?.epgView?.hiddenUids = HashSet(justHidden)
                }
            },
            renamed = { ch -> _b?.epgView?.let { it.updateChannel(ch); it.reselect() }; host.onChannelRenamed(ch) },
            membershipChanged = { ch -> reloadKeeping(ch.uid) },
            startCopySelect = { ch -> startSelect(ch, "Copy From") },
            startHideSelect = { ch -> startSelect(ch, "Hide In") },
            startMoveSelect = { ch -> startSelect(ch, "Move From") }
        ))
    }

    // ---- Copy To Group in bulk: tick boxes on every channel of the group being viewed ---------------------------------
    /** The list stays EXACTLY the group on screen (nothing from outside it can be ticked); the banner names that group. */
    private fun startSelect(c: Channel, label: String) {
        val v = _b?.epgView ?: return
        viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().repo
            val gname = when (scope) {
                Repository.SCOPE_ALL -> "All Channels"
                Repository.SCOPE_FAV -> "Favourites"
                else -> repo.groups(c.providerId).firstOrNull { it.id == scope }?.name ?: ""
            }
            if (_b == null) return@launch
            v.onSelectMenu = { showSelectMenu() }
            v.onSelectBack = { stopSelectingAsk() }
            v.startSelecting(c.uid, (label + " " + gname.take(22)).trim())
            Toast.makeText(requireContext(), "OK ticks / unticks a channel · hold OK for Copy, Move, Hide · Back cancels", Toast.LENGTH_LONG).show()
        }
    }

    private fun showSelectMenu() {
        val v = _b?.epgView ?: return
        val n = v.pickedCount; val total = v.rowList.size
        val p = Popup(requireActivity(), "Selected Channels", "$n of $total channels ticked")
        if (n > 0) {
            p.row("Copy To") { ChannelMenu.copyMany(requireActivity(), v.pickedChannels()) { finishCopy() } }
            if (requireContext().repo.custom(providerId).customGroups.containsKey(scope))        // only inside my own groups: a provider group never loses a channel
                p.row("Move To") { ChannelMenu.moveMany(requireActivity(), v.pickedChannels(), scope) { finishCopy() } }
            p.row("Hide") { ChannelMenu.hideMany(requireActivity(), v.pickedChannels()) { finishCopy() } }
        } else p.note("Tick channels with OK first.")
        p.row("Select All") { v.selectAll() }
        if (n > 0) p.row("Clear All") { v.clearPicked() }
        p.row("Cancel") { v.stopSelecting() }
        p.show()
    }

    /** Back while ticking: with more than one tick it asks first, so a slip of the thumb does not throw the work away. */
    private fun stopSelectingAsk() {
        val v = _b?.epgView ?: return
        if (v.pickedCount < 2) { v.stopSelecting(); return }
        Popup.confirm(requireActivity(), "Stop Selecting?", "Your " + v.pickedCount + " ticks will be cleared.", "Yes, Stop") { _b?.epgView?.stopSelecting() }
    }

    /** After the copy: back on the same group and the same channel, with the ticks gone. */
    private fun finishCopy() {
        val v = _b?.epgView ?: return
        val uid = v.selectedChannel?.uid ?: ""
        v.stopSelecting()
        reloadKeeping(uid)
    }

    /** Reload the list after a copy / move; the highlight stays on this channel (or on the same row if it left the list). */
    private fun reloadKeeping(uid: String) {
        keepUid = uid; keepIndex = _b?.epgView?.selectedIndex ?: 0
        host.wantFocus()
        load()
    }

    private fun toggleFavorite(c: Channel) {
        viewLifecycleOwner.lifecycleScope.launch {
            val nv = !c.isFavorite
            requireContext().repo.dao.setFavorite(c.uid, nv)
            val updated = c.copy(isFavorite = nv)
            if (favOnly && !nv) b.epgView.removeChannel(c.uid) else { b.epgView.updateChannel(updated); b.epgView.reselect() }
            host.onFavoriteChanged(updated)
            Toast.makeText(requireContext(), if (nv) "Added to favourites" else "Removed from favourites", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- TabContent ---------------------------------------------------------------------------
    override fun focusContent(): Boolean = _b != null && b.epgView.rowList.isNotEmpty() && b.epgView.requestFocus()

    override fun isAtLeftEdge(): Boolean = _b == null || b.epgView.atLeftEdge()

    override fun scrollView(): View? = _b?.epgView          // "more below" arrow on the guide (15)

    override fun handleBack(): Boolean = _b != null && b.epgView.handleBack()

    override fun reload() {
        val hadFocus = _b?.epgView?.isFocused == true
        load()
        if (hadFocus) host.wantFocus()
    }

    override fun onGroupChanged() { if (!favOnly) load() }

    override fun onGuideUpdated() { _b?.let { loading.clear(); it.epgView.invalidateData() } }

    override fun onPlayingChanged() { if (_b != null) b.epgView.playingUid = host.playing?.uid ?: "" }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacksAndMessages(null); loadJob?.cancel(); _b = null
    }

    companion object {
        fun newInstance(favs: Boolean) = EpgFragment().apply { arguments = Bundle().apply { putBoolean("favs", favs) } }
    }
}
