package com.sparrow.player.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sparrow", Context.MODE_PRIVATE)

    /**
     * The active profile ("1" = the first one). Watch history, resume points, ratings and My List are kept per profile: profile "1" uses the
     * original keys (so everything saved before profiles existed belongs to it), every other profile adds a "p<id>_" prefix.
     */
    var profile: String = sp.getString("profileActive", "1") ?: "1"
        set(v) { field = v; sp.edit().putString("profileActive", v).apply() }

    private fun k(name: String) = if (profile == "1") name else "p${profile}_$name"

    /** All profiles (see ProfileStore). */
    var profilesRaw: String
        get() = sp.getString("profiles", "") ?: ""
        set(v) { sp.edit().putString("profiles", v).apply() }

    /** Ask "Are you sure?" before a channel or group is hidden (the pop-up's "Do not show this again" box turns it off; Settings -> General turns it back on). */
    var askBeforeHide: Boolean
        get() = sp.getBoolean("askBeforeHide", true)
        set(v) { sp.edit().putBoolean("askBeforeHide", v).apply() }

    /** Seconds the left icon bar stays on screen before it hides itself (0 = never: the bar is fixed, the default). It comes back when the selector goes onto it (Left from the content) or the tab list opens. A new key: the old 3 s default of earlier versions is not inherited. */
    var railHideSeconds: Int
        get() = sp.getInt("railHideSec2", 0)
        set(v) { sp.edit().putInt("railHideSec2", v).apply() }

    /** Which round of "try the titles without a rating again" has run (see Repository.TMDB_RETRY_VERSION). */
    var tmdbRetryDone: Int
        get() = sp.getInt("tmdbRetryDone", 0)
        set(v) { sp.edit().putInt("tmdbRetryDone", v).apply() }

    /** The TMDB v3 API key (age certifications for the Child filter): the built-in one until the user chooses another; an EMPTY saved value = TMDB lookups off. */
    var tmdbKey: String
        get() = if (sp.contains("tmdbKey")) (sp.getString("tmdbKey", "") ?: "") else Tmdb.BUILT_IN_KEY
        set(v) { sp.edit().putString("tmdbKey", v).apply() }

    /** Hero banner (Movies, Series and every group / genre / favourites list): a band above the rows with the selected title's name, year, rating, genre and description. Off by default. */
    var heroBanner: Boolean
        get() = sp.getBoolean("heroBanner", false)
        set(v) { sp.edit().putBoolean("heroBanner", v).apply() }

    /** A series opened from a holiday lists only the episodes that are about that holiday ("lite"), when some are. Off = every episode. */
    var holidayEpisodesOnly: Boolean
        get() = sp.getBoolean("holEpOnly", true)
        set(v) { sp.edit().putBoolean("holEpOnly", v).apply() }

    /** What the panel sent at the last sync of a playlist (see SyncCounts). */
    fun syncCounts(providerId: Long): String = sp.getString("syncCounts_$providerId", "") ?: ""
    fun setSyncCounts(providerId: Long, v: String) = sp.edit().putString("syncCounts_$providerId", v).apply()

    /** "My Holiday Favourites" of the active profile: titles saved by hand (same format as My List). */
    var holidayFavsRaw: String
        get() = sp.getString(k("holidayFavs"), "") ?: ""
        set(v) { sp.edit().putString(k("holidayFavs"), v).apply() }

    /** Movies / Series the active profile hid: titles, episodes, groups and carousels (see VodHide). */
    var vodHiddenRaw: String
        get() = sp.getString(k("vodHidden"), "") ?: ""
        set(v) { sp.edit().putString(k("vodHidden"), v).apply() }

    /** "My List" of the active profile (see MyList). */
    var myListRaw: String
        get() = sp.getString(k("myList"), "") ?: ""
        set(v) { sp.edit().putString(k("myList"), v).apply() }

    /** v3.3.0: set by "Yes, Restart" after a restore: the restarted app syncs the playlist by itself (the sync started before the restart dies with the old process). */
    var syncAfterRestart: Boolean
        get() = sp.getBoolean("syncAfterRestart", false)
        set(v) { sp.edit().putBoolean("syncAfterRestart", v).commit() }

    var activeProvider: Long
        get() = sp.getLong("active", -1L)
        set(v) { sp.edit().putLong("active", v).apply() }

    /** "ts" (raw MPEG-TS, lowest latency, most compatible) or "m3u8" (HLS). Xtream providers only. */
    var liveFormat: String
        get() = sp.getString("fmt", "ts") ?: "ts"
        set(v) { sp.edit().putString("fmt", v).apply() }

    var lastChannel: String
        get() = sp.getString("lastCh", "") ?: ""
        set(v) { sp.edit().putString("lastCh", v).apply() }

    /** The channel the app tunes to every time it opens ("" = the last one watched). */
    var openChannel: String
        get() = sp.getString("openCh", "") ?: ""
        set(v) { sp.edit().putString("openCh", v).apply() }

    /**
     * The profile the device start-up / wake-up opens straight into ("" = nobody: the app does not open by itself and Who's Watching? shows as usual).
     * Settings written before profiles had this (just "on") belong to the first profile.
     */
    var bootProfile: String
        get() = sp.getString("bootProfile", null) ?: if (sp.getBoolean("startOnBoot", false)) "1" else ""
        set(v) { sp.edit().putString("bootProfile", v).putBoolean("startOnBoot", v.isNotBlank()).apply() }

    /** Open Sparrow Player when the device starts / wakes up (true when some profile owns that option). */
    val startOnBoot: Boolean get() = bootProfile.isNotBlank()

    /** false = 12 hour clock (default), true = 24 hour. */
    /** v3.3.0: true (default) = the app's own remote-first keyboard (Up never leaves the letters; hold Up for the number row); false = the TV's own keyboard. */
    var sparrowKeyboard: Boolean
        get() = sp.getBoolean("sparrowKeyboard", true)
        set(v) { sp.edit().putBoolean("sparrowKeyboard", v).apply() }

    var clock24: Boolean
        get() = sp.getBoolean("clock24", false)
        set(v) { sp.edit().putBoolean("clock24", v).apply() }

    var showNumbers: Boolean
        get() = sp.getBoolean("showNum", true)
        set(v) { sp.edit().putBoolean("showNum", v).apply() }

    /** EPG auto-sync interval in hours (24, 12, 6, 3 or 2). */
    var epgHours: Int
        get() = sp.getInt("epgHours", 24)
        set(v) { sp.edit().putInt("epgHours", v).apply() }

    /** Download the guide when the app starts. */
    var epgOnStart: Boolean
        get() = sp.getBoolean("epgOnStart", true)
        set(v) { sp.edit().putBoolean("epgOnStart", v).apply() }

    fun lastEpgSync(providerId: Long): Long = sp.getLong("epgSync_$providerId", 0L)
    fun setLastEpgSync(providerId: Long, v: Long) = sp.edit().putLong("epgSync_$providerId", v).apply()

    /** Preferred audio language code ("" = automatic, e.g. "en", "fr"). */
    var audioLang: String
        get() = sp.getString("audioLang", "") ?: ""
        set(v) { sp.edit().putString("audioLang", v).apply() }

    /** Subtitles: "" = automatic (player default), "off", or a language code. */
    var subtitleLang: String
        get() = sp.getString("subLang", "") ?: ""
        set(v) { sp.edit().putString("subLang", v).apply() }

    // ---- Playback (Settings -> Playback) -----------------------------------------------------------------------------------
    /** Movies / episodes start where they were stopped (30 s before). Off = always from the start. */
    var resumeEnabled: Boolean
        get() = sp.getBoolean("resumeOn", true)
        set(v) { sp.edit().putBoolean("resumeOn", v).apply() }

    /** Highest picture size: "best" (no limit), "2160", "1080", "720", "480" (SD). */
    var videoQuality: String
        get() = sp.getString("vidQ", "best") ?: "best"
        set(v) { sp.edit().putString("vidQ", v).apply() }

    /** Most audio channels wanted: "best" (no limit), "6" (5.1 surround), "2" (stereo). */
    var audioQuality: String
        get() = sp.getString("audQ", "best") ?: "best"
        set(v) { sp.edit().putString("audQ", v).apply() }

    // ---- Network and Buffering ----------------------------------------------------------------------------------------------
    /** "auto" (follows the last connection check), "fast", "balanced", "stable", "max". See PlayerFactory.bufferFor. */
    var bufferMode: String
        get() = sp.getString("bufMode", "auto") ?: "auto"
        set(v) { sp.edit().putString("bufMode", v).apply() }

    /** Result of "Optimise For My Connection": 0 = not measured, 1 = very steady, 2 = steady, 3 = unsteady, 4 = poor. */
    var connectionClass: Int
        get() = sp.getInt("connClass", 0)
        set(v) { sp.edit().putInt("connClass", v).apply() }

    /** A stream that drops is reconnected by itself (a few tries, a little longer apart each time). */
    var autoRetry: Boolean
        get() = sp.getBoolean("autoRetry", true)
        set(v) { sp.edit().putBoolean("autoRetry", v).apply() }

    // ---- Location ----------------------------------------------------------------------------------------------------------------
    /** "CA" (default) or "US": which holiday calendar (Thanksgiving, Independence Day ...) and which country name the carousels use. */
    var country: String
        get() = sp.getString("country", "CA") ?: "CA"
        set(v) { sp.edit().putString("country", v).apply() }

    val isCanada: Boolean get() = country == "CA"

    /** Every saved setting, for Backup / Restore (see Backup). */
    fun rawAll(): Map<String, Any?> = HashMap<String, Any?>(sp.all)
    fun rawEdit(): android.content.SharedPreferences.Editor = sp.edit()

    /** Clears watch history, resume points and "last episode" of the ACTIVE profile only. */
    fun clearWatchHistory() {
        val prefix = if (profile == "1") "" else "p${profile}_"
        val e = sp.edit()
        for (key in sp.all.keys) {
            val name = if (prefix.isEmpty()) key else if (key.startsWith(prefix)) key.removePrefix(prefix) else continue
            if (name == "history" || name.startsWith("pos_") || name.startsWith("dur_") || name.startsWith("lastEp_")) e.remove(key)
        }
        e.apply()
    }

    /** The user's own Sparrow Ratings, 0.5 - 10 (see SparrowScores). */
    var sparrowRaw: String
        get() = sp.getString(k("sparrowScores"), "") ?: ""
        set(v) { sp.edit().putString(k("sparrowScores"), v).apply() }

    /** Loved / Liked / Disliked verdicts (see UserRatings). */
    var ratingsRaw: String
        get() = sp.getString(k("ratings"), "") ?: ""
        set(v) { sp.edit().putString(k("ratings"), v).apply() }

    /** The user's channel / group edits for one provider (see Customize). */
    fun custom(providerId: Long): String = sp.getString("cust_$providerId", "") ?: ""
    fun setCustom(providerId: Long, v: String) = sp.edit().putString("cust_$providerId", v).apply()

    /** Current theme, see ui/theme/Palette.encode(). Empty = default. */
    var theme: String
        get() = sp.getString("theme", "") ?: ""
        set(v) { sp.edit().putString("theme", v).apply() }

    /** Watch history (see History): one "uid<TAB>timestamp" per line, newest first. */
    fun history(): List<History.Entry> = History.parse(sp.getString(k("history"), ""))
    fun recordWatch(uid: String) {
        if (uid.isBlank()) return
        sp.edit().putString(k("history"), History.serialize(History.record(history(), uid, System.currentTimeMillis()))).apply()
    }

    /** Last episode id watched for a series (so Play continues the series). */
    fun lastEpisode(seriesUid: String): String = sp.getString(k("lastEp_$seriesUid"), "") ?: ""
    fun setLastEpisode(seriesUid: String, epId: String) = sp.edit().putString(k("lastEp_$seriesUid"), epId).apply()

    fun duration(key: String): Long = sp.getLong(k("dur_$key"), 0L)
    fun setDuration(key: String, v: Long) = sp.edit().putLong(k("dur_$key"), v).apply()
    fun percent(key: String): Int = Resume.percent(position(key), duration(key))

    fun position(key: String): Long = sp.getLong(k("pos_$key"), 0L)
    fun setPosition(key: String, v: Long) = sp.edit().putLong(k("pos_$key"), v).apply()

    /** Movie: its own progress. Series: progress of the episode being watched. */
    fun vodPercent(v: VodItem): Int {
        if (v.type == "movie") return percent(v.uid)
        val ep = lastEpisode(v.uid)
        return if (ep.isBlank()) 0 else percent("ep:$ep")
    }

    /** Started, not finished: shows up in "Continue watching". */
    fun inProgress(v: VodItem): Boolean = inProgress(v.type, v.uid)

    fun inProgress(type: String, uid: String): Boolean {
        val key = if (type == "movie") uid else lastEpisode(uid).let { if (it.isBlank()) return false else "ep:$it" }
        return Resume.hasProgress(position(key))
    }

    companion object {
        /** Some panels block unknown user agents; a VLC UA is the most widely accepted. */
        const val UA = "VLC/3.0.20 LibVLC/3.0.20"
    }
}
