package com.sparrow.player.data

import android.app.Application
import androidx.room.Room
import androidx.room.withTransaction
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import com.sparrow.player.util.TitleCase

/** A channel group as shown in the groups panel. [original] = the provider's name (for "reset"), [custom] = created by the user. */
data class GroupInfo(val id: String, val name: String, val original: String, val custom: Boolean, val hidden: Boolean)

class Repository(app: Application) {
    // Providers (with their logins) live in this database. There is deliberately NO fallbackToDestructiveMigration(): if a
    // schema change ever ships without a Migration, Room must refuse loudly instead of silently deleting the user's providers.
    // Rule: any change to an @Entity => bump AppDb.version AND add a Migration here (see docs/UPGRADE_SAFETY.md).
    val db: AppDb = Room.databaseBuilder(app, AppDb::class.java, "sparrow.db").addMigrations(*Migrations.ALL).build()
    val dao = db.dao()
    val prefs = Prefs(app)

    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .addInterceptor { it.proceed(it.request().newBuilder().header("User-Agent", Prefs.UA).build()) }
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val status = MutableStateFlow("")
    val dataVersion = MutableStateFlow(0)

    /** Bumped when only the TV guide was refreshed: the guide reloads its programmes in place, the selection stays where it is. */
    val epgVersion = MutableStateFlow(0)

    @Volatile var active: Provider? = null
        private set

    suspend fun activeProvider(): Provider? {
        val p = dao.provider(prefs.activeProvider) ?: dao.providers().firstOrNull()
        if (p != null) prefs.activeProvider = p.id
        active = p
        return p
    }

    // ---- URLs -------------------------------------------------------------------------------
    fun liveUrl(c: Channel): String =
        if (c.streamUrl.isNotBlank()) c.streamUrl else Urls.live(active!!, c.remoteId, prefs.liveFormat)

    fun movieUrl(v: VodItem): String =
        if (v.streamUrl.isNotBlank()) v.streamUrl else Urls.movie(active!!, v.remoteId, v.ext.ifBlank { "mp4" })

    fun episodeUrl(e: Episode): String = Urls.episode(active!!, e.id, e.ext)

    suspend fun seriesEpisodes(v: VodItem): List<Episode> = withContext(Dispatchers.IO) {
        synchronized(seriesCache) { seriesCache[v.uid] }?.let { hit -> return@withContext hit.list }
        val x = XtreamClient(http, active!!)
        val l = x.seriesEpisodes(v.remoteId)
        if (x.maturity.isNotEmpty()) remember(v.uid, -1, x.maturity, v.plot)       // lets Children & Family tell a cartoon for kids from one for adults
        if (l.isNotEmpty()) synchronized(seriesCache) { seriesCache[v.uid] = SeriesHit(l, x.director to x.cast) }
        l
    }

    // ---- posters the panel's list left empty: asked for once per title, when its card is on screen ----------------------------
    private val posterFound = java.util.concurrent.ConcurrentHashMap<String, String>()     // uid -> address ("" = the panel has none either)
    private val posterBusy = HashSet<String>()
    private val posterGate = kotlinx.coroutines.sync.Semaphore(3)

    /** A poster already found this session for [uid] (or null). */
    fun knownPoster(uid: String): String? = posterFound[uid]?.takeIf { it.isNotBlank() }

    /**
     * Many panels leave a film's / series' poster out of the bulk list and only give it in the per-title info call. Looked up here, three at a
     * time, remembered (also in the database for the next start), and handed to [done] on the main thread. Xtream playlists only.
     */
    fun fetchPoster(v: VodItem, done: (String) -> Unit) {
        posterFound[v.uid]?.let { if (it.isNotBlank()) done(it); return }
        val p = active ?: return
        if (p.type != "xtream") return
        synchronized(posterBusy) { if (posterBusy.size >= 60 || !posterBusy.add(v.uid)) return }
        scope.launch {
            val url = try {
                posterGate.withPermit { withContext(Dispatchers.IO) { XtreamClient(http, p).posterOf(v.type, v.remoteId) } }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { "" }
            posterFound[v.uid] = url
            synchronized(posterBusy) { posterBusy.remove(v.uid) }
            if (url.isNotBlank()) {
                try { withContext(Dispatchers.IO) { dao.updatePoster(v.uid, url) } } catch (e: Exception) { }
                done(url)
            }
        }
    }

    /** The last 200 information pages (plot, backdrop, cast ...): opening a title again, or going back to it, no longer waits on the provider. */
    private val infoCache = object : LinkedHashMap<String, Map<String, Any?>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Map<String, Any?>>): Boolean = size > 200
    }

    suspend fun vodInfo(v: VodItem): Map<String, Any?> = withContext(Dispatchers.IO) {
        synchronized(infoCache) { infoCache[v.uid] }?.let { return@withContext it }
        try {
            // a slow panel must not hold the page for the 2 minutes the big catalogue download is allowed
            val fast = http.newBuilder().readTimeout(20, TimeUnit.SECONDS).build()
            XtreamClient(fast, active!!).vodInfo(v.remoteId).also { m -> if (m.isNotEmpty()) synchronized(infoCache) { infoCache[v.uid] = m } }
        } catch (e: Exception) { emptyMap() }
    }

    // ---- series: the episode list + people are kept for the session too (opening a series again is instant) ------------------------
    private class SeriesHit(val list: List<Episode>, val people: Pair<String, String>)
    private val seriesCache = object : LinkedHashMap<String, SeriesHit>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, SeriesHit>): Boolean = size > 60
    }

    /** Director / cast the panel gave for a series opened through [seriesEpisodes] (director, cast). */
    fun seriesPeopleOf(uid: String): Pair<String, String> = synchronized(seriesCache) { seriesCache[uid]?.people } ?: ("" to "")

    // ---- TMDB details for the information page: genres, director, cast -----------------------------------------------------------
    private val tmdbInfoCache = object : LinkedHashMap<String, TmdbDetails>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, TmdbDetails>): Boolean = size > 300
    }

    /** null = no key, no certain match (exact title + year within 1), or no network. One search (skipped when the id is known) + one call. */
    suspend fun tmdbDetails(v: VodItem): TmdbDetails? = withContext(Dispatchers.IO) {
        val key = prefs.tmdbKey
        if (key.isBlank()) return@withContext null
        synchronized(tmdbInfoCache) { tmdbInfoCache[v.uid] }?.let { return@withContext it }
        try {
            val tv = v.type == "series"
            var id = synchronized(this@Repository) { tmdbStore.idOf(v.uid) }
            if (id <= 0) {
                val name = Tmdb.cleanTitle(v.name); val year = v.year.take(4).toIntOrNull() ?: 0
                val q = ArrayList<Pair<String, String>>()
                q += "query" to name
                q += "include_adult" to "false"
                if (year > 0) q += (if (tv) "first_air_date_year" else "year") to year.toString()
                val search = tmdbGet(tmdbUrl(if (tv) "3/search/tv" else "3/search/movie", key, q)) ?: return@withContext null
                id = Tmdb.pickId(search, name, year, tv)
                if (id <= 0) id = Tmdb.pickIdLoose(search, name, year, tv)
                if (id <= 0 && year > 0) {          // the year on the title may be off: once more without it
                    val q2 = q.filter { it.first != "year" && it.first != "first_air_date_year" }
                    val s2 = tmdbGet(tmdbUrl(if (tv) "3/search/tv" else "3/search/movie", key, q2))
                    if (s2 != null) id = Tmdb.pickId(s2, name, year, tv).let { if (it > 0) it else Tmdb.pickIdLoose(s2, name, year, tv) }
                }
            }
            if (id <= 0) return@withContext null
            val json = tmdbGet(tmdbUrl(if (tv) "3/tv/$id" else "3/movie/$id", key, listOf("append_to_response" to (if (tv) "credits,content_ratings" else "credits,release_dates")))) ?: return@withContext null
            Tmdb.detailsFrom(json, tv).also { d ->
                synchronized(tmdbInfoCache) { tmdbInfoCache[v.uid] = d }
                // the age rating found now is kept like one the background lookups found (Child profiles, search, the information page)
                if (d.cert.isNotEmpty()) { synchronized(this@Repository) { tmdbStore.put(v.uid, d.cert, id) }; tmdbSave() }
            }
        } catch (e: Exception) { null }
    }

    private var prefetchJob: Job? = null

    /** The selector rests on a poster: after a short pause its information page is fetched in the background, so opening it is instant. */
    fun prefetchInfo(v: VodItem) {
        prefetchJob?.cancel()
        prefetchJob = scope.launch(Dispatchers.IO) {
            delay(140)                                              // scrolling past does not fetch anything (v3.0.0: 350 -> 140 ms, so the page is ready when OK is pressed)
            if (v.type == "movie") vodInfo(v) else seriesEpisodes(v)
            tmdbDetails(v)
        }
    }

    // ---- profiles and My List -----------------------------------------------------------------
    @Synchronized fun profileStore(): ProfileStore = profilesCache ?: ProfileStore.parse(prefs.profilesRaw).also { profilesCache = it }
    @Synchronized fun saveProfiles() { prefs.profilesRaw = profileStore().serialize() }

    /** Set after the "Who's watching?" choice (or when there is only one profile), so the picker shows once per launch. */
    @Volatile var profileConfirmed = false

    @Synchronized fun activeProfile(): Profile {
        val st = profileStore()
        return st.get(prefs.profile) ?: st.profiles.first().also { prefs.profile = it.id }
    }

    /** Switch profile: history, resume points, ratings and My List now come from the new one. */
    @Synchronized fun switchProfile(id: String) {
        prefs.profile = id
        ratingsCache = null; sparrowCache = null; myListCache = null; holidayFavCache = null; vodHideCache = null
        dataVersion.value++
    }

    /** After a Restore changed the saved settings behind the app's back: forget everything read from them and reload the screens. */
    @Synchronized fun reloadAfterRestore() {
        profilesCache = null; ratingsCache = null; sparrowCache = null; myListCache = null; holidayFavCache = null; vodHideCache = null
        customCache.clear()
        dataVersion.value++
    }

    // ---- Hidden movies / series / episodes / groups / carousels (per profile, see VodHide) --------------------------------------------
    private var vodHideCache: VodHide? = null
    private fun vodHideObj(): VodHide = vodHideCache ?: VodHide.parse(prefs.vodHiddenRaw).also { vodHideCache = it }
    private fun vodHideSave() { prefs.vodHiddenRaw = vodHideObj().serialize(); dataVersion.value++ }

    @Synchronized fun hiddenVod(): Set<String> = HashSet(vodHideObj().items())
    @Synchronized fun isVodHidden(uid: String): Boolean = vodHideObj().hasItem(uid)
    @Synchronized fun hideVod(uids: Collection<String>) { vodHideObj().addItems(uids); vodHideSave() }
    @Synchronized fun unhideVod(uids: Collection<String>) { vodHideObj().removeItems(uids); vodHideSave() }
    @Synchronized fun hiddenVodGroups(): Set<String> = HashSet(vodHideObj().groups())
    @Synchronized fun hideVodGroup(id: String) { vodHideObj().addGroup(id); vodHideSave() }
    @Synchronized fun unhideVodGroup(id: String) { vodHideObj().removeGroup(id); vodHideSave() }
    @Synchronized fun hiddenVodRows(): Set<String> = HashSet(vodHideObj().rows())
    @Synchronized fun hideVodRow(key: String) { vodHideObj().addRow(key); vodHideSave() }
    @Synchronized fun unhideVodRow(key: String) { vodHideObj().removeRow(key); vodHideSave() }

    @Synchronized fun inMyList(uid: String) = myListObj().contains(uid)
    @Synchronized fun myListUids(): List<String> = ArrayList(myListObj().all())
    /** Add / remove a title; returns true if it is in My List afterwards. */
    @Synchronized fun toggleMyList(uid: String): Boolean { val r = myListObj().toggle(uid); prefs.myListRaw = myListObj().serialize(); return r }

    // ---- the catalogue of Movies / Series (kept in memory, see VodCatalog) -------------------------------------
    /** Bumped when the titles in the database change (sync, playlist deleted): the in-memory catalogues are then read again. */
    @Volatile private var catalogVersion = 0
    private val catalogs = LinkedHashMap<String, Deferred<VodCatalog>>()

    /**
     * The catalogue of [type] ("movie" / "series") of provider [pid]. Built once on a background thread and shared: callers that arrive
     * while it is being built wait for the same build. Cancelling a caller (leaving the screen) does not cancel the build.
     */
    suspend fun catalog(pid: Long, type: String): VodCatalog {
        val key = "$pid|$type|$catalogVersion"
        val d = synchronized(catalogs) {
            catalogs[key] ?: scope.async(Dispatchers.Default) { buildCatalog(pid, type) }.also { catalogs[key] = it
                while (catalogs.size > 4) catalogs.remove(catalogs.keys.first()) }
        }
        try { return d.await() } catch (e: CancellationException) { throw e } catch (e: Exception) { synchronized(catalogs) { catalogs.remove(key) }; throw e }
    }

    private suspend fun buildCatalog(pid: Long, type: String): VodCatalog {
        val names = dao.categories(pid, if (type == "movie") "vod" else "series").associate { it.remoteId to TitleCase.of(it.name) }
        val items = dao.vodLite(pid, type)
        val plots = ArrayList(dao.vodPlots(pid, type))
        for ((uid, m) in metaAll()) if (m.plot.isNotBlank() && uid.startsWith("$pid:")) plots += UidPlot(uid, m.plot)     // movies: plots remembered from details pages
        return VodCatalog.build(pid, type, items, names, plots)
    }

    // ---- age limit of the active profile (Content Preferences) ---------------------------------------------------------------
    private val blockedCache = LinkedHashMap<String, Set<String>>()

    /**
     * The uids of [cat] the ACTIVE profile may not see because of its age limit (see [Profile.ageLimit]); null = no limit. Worked out once per catalogue, limit and
     * number of known ratings, then shared. Call from a background thread (a first call reads every title).
     */
    fun blockedFor(cat: VodCatalog): Set<String>? {
        val age = ageBlocked(cat)
        val hid = hiddenVod()                     // what the profile hid by hand is kept out of every row, search and the random pick the same way
        if (hid.isEmpty()) return age
        if (age == null) return hid
        return HashSet(age).also { it.addAll(hid) }
    }

    private fun ageBlocked(cat: VodCatalog): Set<String>? {
        val who = activeProfile()
        val limit = who.ageLimit
        if (Maturity.ratingsFor(limit) == null) return null
        val strict = who.child && who.strict
        val known = maturities()
        val key = "${cat.providerId}|${cat.type}|$catalogVersion|$limit|$strict|${known.size}"
        synchronized(blockedCache) { blockedCache[key] }?.let { return it }
        val series = cat.type == "series"
        val out = HashSet<String>()
        for (t in cat.titles) if (!Maturity.allowed(limit, t, known[t.uid] ?: "", series, strict)) out += t.uid
        synchronized(blockedCache) {
            blockedCache[key] = out
            while (blockedCache.size > 6) blockedCache.remove(blockedCache.keys.first())
        }
        return out
    }

    // ---- the search list (see SearchIndex): built once per catalogue, shared by every visit to the search window ---------------
    private val searchIndexes = LinkedHashMap<String, Deferred<SearchIndex>>()

    /** The search list of [cat], with the profile's own state (my ratings, watched, Sparrow ratings, remembered length / plot) applied. */
    suspend fun searchIndex(cat: VodCatalog): SearchIndex {
        val key = "${cat.providerId}|${cat.type}|$catalogVersion"
        val d = synchronized(searchIndexes) {
            searchIndexes[key] ?: scope.async(Dispatchers.Default) { SearchIndex.build(cat) }.also {
                searchIndexes[key] = it
                while (searchIndexes.size > 4) searchIndexes.remove(searchIndexes.keys.first())
            }
        }
        val idx = try { d.await() } catch (e: CancellationException) { throw e } catch (e: Exception) { synchronized(searchIndexes) { searchIndexes.remove(key) }; throw e }
        withContext(Dispatchers.Default) { refreshSearchState(idx) }
        return idx
    }

    private fun refreshSearchState(idx: SearchIndex) {
        val mine = synchronized(this) { myRatings() }
        val metas = synchronized(this) { metaSnapshot() }
        val sp = synchronized(this) { sparrowScores().all() }
        val seen = prefs.history().map { it.uid }.toHashSet()
        idx.applyState(mine, seen, metas, { uid -> sp[uid] ?: -1.0 }, sp.keys)
    }

    /** Read the catalogues of the active playlist ahead of time (app start, after a sync) so Movies / Series / search open at once. */
    fun warmCatalogs() {
        startYears()
        scope.launch {
            delay(2500)                                         // the first screen and the guide come first
            val p = (try { activeProvider() } catch (e: Exception) { null }) ?: return@launch
            for (t in listOf("movie", "series")) {
                try { val c = catalog(p.id, t); searchIndex(c); withContext(Dispatchers.Default) { genreIndex(p.id, t) }; namedRows(c).await() } catch (e: CancellationException) { throw e } catch (e: Exception) { }
            }
        }
    }

    // ---- genre tabs of Movies / Series --------------------------------------------------------
    private val genreCache = HashMap<String, Genres.Index>()

    /** The main genres that have at least one title and, for each, its sub-genres that have titles. Cached until the next sync. */
    suspend fun genreIndex(pid: Long, type: String): Genres.Index {
        val key = "$pid|$type|$catalogVersion"
        synchronized(genreCache) { genreCache[key] }?.let { return it }
        val names = dao.categories(pid, if (type == "movie") "vod" else "series").associate { it.remoteId to it.name }
        val combos = dao.catGenres(pid, type)
        val found = withContext(Dispatchers.Default) {
            Genres.index(combos.map { TextNorm.prepare(it.genre + " " + (names[it.categoryId] ?: "")) }.distinct())
        }
        synchronized(genreCache) { genreCache.clear(); genreCache[key] = found }
        return found
    }

    // ---- the named carousels of the Movies / Series home (Top 10, My List, platforms ...): the heavy part, cached --------
    private val namedCache = HashMap<String, Deferred<List<RowSpec>>>()

    /** What the panel told us about ratings (titles whose details were opened): uid -> "PG-13", "TV-MA" ... */
    /** Ratings the panel gave (remembered from details pages) with the certifications TMDB gave ([startTmdb]) on top: TMDB is the more reliable of the two. */
    @Synchronized fun maturities(): Map<String, String> {
        val m = HashMap(metaCache.maturities())
        m.putAll(tmdbStore.maturities())
        return m
    }

    // ---- TMDB age certifications (Stage 1 of the online database cross-reference) -----------------------------------
    private val TMDB_RETRY_VERSION = 3          // bump to make every title without a usable rating be tried again once
    private val tmdbFile = java.io.File(app.filesDir, "tmdb.tsv")
    private val tmdbStore: TmdbStore by lazy { TmdbStore.parse(try { if (tmdbFile.exists()) tmdbFile.readText() else "" } catch (e: Exception) { "" }) }
    @Volatile private var tmdbJob: Job? = null
    // v3.4.0: the Kids / Family screen reads the genres TMDB gave (the panel's movie list carries none)
    init {
        Maturity.genreLookup = { uid -> synchronized(this@Repository) { tmdbStore.genreOf(uid) } }
        Maturity.yearLookup = { uid -> synchronized(this@Repository) { tmdbStore.yearOf(uid) } }
    }

    /** What the TMDB lookups are doing, for the settings page. */
    val tmdbState = MutableStateFlow("")

    @Synchronized fun tmdbCounts(): Pair<Int, Int> = tmdbStore.size() to tmdbStore.withCode()

    fun stopTmdb() { tmdbJob?.cancel(); tmdbJob = null }

    /** Looks up the age certification of every title of the active playlist that has no rating, slowly in the background (kids' titles first), and keeps the answers. Needs [Prefs.tmdbKey]. */
    fun startTmdb() {
        val key = prefs.tmdbKey.trim()
        if (key.isEmpty() || tmdbJob?.isActive == true) return
        tmdbJob = scope.launch(Dispatchers.IO) {
            try { tmdbLoop(key) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { tmdbState.value = "TMDB lookups stopped: " + (e.message ?: "error") }
        }
    }

    private fun tmdbSave() {
        val text = synchronized(this) { tmdbStore.serialize() }
        try {
            val tmp = java.io.File(tmdbFile.parentFile, "tmdb.tsv.tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(tmdbFile)) { tmdbFile.writeText(text); tmp.delete() }
        } catch (e: Exception) { }
    }

    private fun tmdbGet(url: okhttp3.HttpUrl): Map<String, Any?>? {
        return http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (r.code == 401) throw IllegalStateException("TMDB rejected the key (use the v3 API Key)")
            if (!r.isSuccessful) null else r.body?.let { b -> Json.readObject(b.byteStream()) }
        }
    }

    private fun tmdbUrl(path: String, key: String, q: List<Pair<String, String>>): okhttp3.HttpUrl {
        val b = okhttp3.HttpUrl.Builder().scheme("https").host("api.themoviedb.org").addPathSegments(path).addQueryParameter("api_key", key)
        for ((k, v) in q) b.addQueryParameter(k, v)
        return b.build()
    }

    /** (tmdb id, code, genres) - (0, "", "") when TMDB has no certain match, null when the network failed (try again later). */
    private class TmdbHit(val id: Int, val code: String, val genres: String)

    private fun tmdbLookup(key: String, name: String, year: Int, tv: Boolean): TmdbHit? {
        val q = ArrayList<Pair<String, String>>()
        q += "query" to name
        q += "include_adult" to "false"
        if (year > 0) q += (if (tv) "first_air_date_year" else "year") to year.toString()
        val search = tmdbGet(tmdbUrl(if (tv) "3/search/tv" else "3/search/movie", key, q)) ?: return null
        var id = Tmdb.pickId(search, name, year, tv)
        if (id == 0) id = Tmdb.pickIdLoose(search, name, year, tv)
        if (id == 0) return TmdbHit(0, "", "")
        // v3.4.0: one call gives the genres AND the certifications (it used to ask for the certifications only)
        val rk = if (tv) "content_ratings" else "release_dates"
        val full = tmdbGet(tmdbUrl(if (tv) "3/tv/$id" else "3/movie/$id", key, listOf("append_to_response" to rk))) ?: return null
        @Suppress("UNCHECKED_CAST") val certJson = full[rk] as? Map<String, Any?>
        val code = if (certJson == null) "" else if (tv) Tmdb.tvCertFrom(certJson) else Tmdb.movieCertFrom(certJson)
        return TmdbHit(id, code, Tmdb.genresFrom(full))
    }

    /** A title the year rows could want: no year in the panel's list, added in the last ~2 years or filed in a category that names a recent year. */
    private fun yearCandidate(cat: VodCatalog, t: RowTitle): Boolean {
        val now = System.currentTimeMillis()
        val addedMs = if (t.added in 1..99_999_999_999L) t.added * 1000 else t.added
        if (addedMs > 0 && now - addedMs < 800L * 86_400_000L) return true
        val y = Recommender.yearOf(t.category)
        return y >= java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) - 2
    }

    @Volatile private var yearJob: Job? = null

    /** v3.6.15: finds the release year of recent movies on its own (no TMDB key needed), newest additions first, a few hundred a session. */
    fun startYears() {
        if (yearJob?.isActive == true) return
        yearJob = scope.launch(Dispatchers.IO) { try { yearLoop() } catch (e: CancellationException) { throw e } catch (e: Exception) { } }
    }

    private suspend fun yearLoop() {
        var waited = 0
        while (active == null && waited < 60) { delay(3000); waited++ }
        val pid = active?.id ?: return
        val cat = try { catalog(pid, "movie") } catch (e: Exception) { return }
        val floor = java.util.GregorianCalendar(2024, 0, 1).timeInMillis
        fun addedMs(t: RowTitle) = if (t.added in 1..99_999_999_999L) t.added * 1000 else t.added
        val open = cat.titles.filter { it.year == 0 && !tmdbStore.yearAsked(it.uid) }
        // titles with a known date: only those added since 2024 can be a 2025 / 2026 release; titles with no date: the highest stream ids (the newest) first
        val dated = open.filter { addedMs(it) >= floor }.sortedByDescending { addedMs(it) }
        val undated = open.filter { addedMs(it) <= 0 }.sortedByDescending { it.uid.substringAfterLast(':').toLongOrNull() ?: 0L }
        var asked = 0; var learned = 0; var failures = 0; var rebuiltOnce = false
        for (t in (dated + undated).take(1500)) {
            val item = dao.vod(t.uid) ?: continue
            val info = vodInfo(item)
            if (info.isEmpty()) { failures++; if (failures >= 10) break; delay(1500); continue }
            failures = 0
            val y = Recommender.yearOf(info.str("releasedate").ifBlank { info.str("release_date") }.ifBlank { info.str("year") })
            synchronized(this) { tmdbStore.putYear(t.uid, y) }
            if (y > 0) learned++
            if (++asked % 25 == 0) tmdbSave()
            if (!rebuiltOnce && learned >= 150) { rebuiltOnce = true; tmdbSave(); catalogVersion++; dataVersion.value++ }
            delay(250)
        }
        tmdbSave()
        if (learned > 0) { catalogVersion++; dataVersion.value++ }                     // rebuilt with the new years
    }

    private suspend fun tmdbLoop(key: String) {
        var waited = 0
        while (active == null && waited < 60) { delay(3000); waited++ }
        val pid = active?.id ?: return
        var done = 0; var failures = 0
        for (type in listOf("movie", "series")) {
            val cat = try { catalog(pid, type) } catch (e: Exception) { continue }
            val tv = type == "series"
            val known = maturities()
            // one lookup per distinct film (cleaned name + year); the answer goes to every copy of it
            val todo = LinkedHashMap<String, ArrayList<RowTitle>>()
            val retry = prefs.tmdbRetryDone < TMDB_RETRY_VERSION
            for (t in cat.titles.indices.sortedByDescending { cat.kidsOnly[it] || Maturity.kidsCandidate(cat.titles[it]) }.map { cat.titles[it] }) {
                // v3.4.0: a title is skipped once TMDB gave its genres; titles looked up before genres were kept get one more try (retry version 3)
                if (tmdbStore.has(t.uid) && (tmdbStore.genreOf(t.uid).isNotEmpty() || !retry)) continue
                val name = Tmdb.cleanTitle(t.name)
                if (name.length < 2) continue
                todo.getOrPut(name.lowercase() + "|" + t.year) { ArrayList() }.add(t)
            }
            for ((_, list) in todo) {
                val first = list[0]
                val r = tmdbLookup(key, Tmdb.cleanTitle(first.name), first.year, tv)
                if (r == null) {
                    failures++
                    if (failures >= 20) { tmdbState.value = "TMDB lookups paused: no connection (they continue next time the app starts)"; tmdbSave(); return }
                    delay(2000); continue
                }
                failures = 0
                synchronized(this) { for (x in list) tmdbStore.put(x.uid, r.code, r.id, r.genres) }
                done++
                if (done % 50 == 0) { tmdbSave(); tmdbState.value = "TMDB: $done titles checked this session" }
                delay(150)
            }
            tmdbSave()
        }
        if (prefs.tmdbRetryDone < TMDB_RETRY_VERSION) prefs.tmdbRetryDone = TMDB_RETRY_VERSION
        tmdbState.value = "TMDB: finished ($done titles checked this session)"
    }
    @Synchronized private fun metaAll(): Map<String, MetaCache.Meta> = metaCache.all()

    /**
     * The named carousels for [cat], worked out in the background once per catalogue, day and state of the profile and then shared:
     * whoever asks while it is being worked out waits for the same result (the screen shows its other rows meanwhile).
     */
    fun namedRows(cat: VodCatalog): Deferred<List<RowSpec>> {
        val movies = cat.type == "movie"
        val hist = prefs.history()
        val finished = hist.mapNotNull { cat.lite(it.uid) }.filter { !prefs.inProgress(cat.type, it.uid) }.map { it.uid }
        val mine = myListUids(); val verdicts = myRatings(); val known = maturities()
        val now = System.currentTimeMillis()
        val key = "${cat.providerId}|${cat.type}|$catalogVersion|${now / 86_400_000L}|${prefs.profile}|${mine.hashCode()}|${finished.hashCode()}|${verdicts.hashCode()}|${known.size}"
        val prefix = "${cat.providerId}|${cat.type}|"
        return synchronized(namedCache) {
            namedCache[key] ?: scope.async(Dispatchers.Default) {
                val country = java.util.Locale.getDefault().displayCountry.ifBlank { "Your Country" }
                HomeRows.build(cat.titles, RowCtx(now, movies, country, activeProfile().name, finished, mine, verdicts, known))
            }.also {
                namedCache.keys.removeAll { k -> k.startsWith(prefix) }
                namedCache[key] = it
            }
        }
    }

    // ---- My Holiday Favourites: titles saved by hand (per profile) --------------------------------------------
    private var holidayFavCache: MyList? = null
    private fun holidayFavObj(): MyList = holidayFavCache ?: MyList.parse(prefs.holidayFavsRaw).also { holidayFavCache = it }
    @Synchronized fun holidayFavUids(): List<String> = ArrayList(holidayFavObj().all())
    @Synchronized fun inHolidayFavs(uid: String) = holidayFavObj().contains(uid)
    /** Add / remove a title; returns true if it is saved afterwards. */
    @Synchronized fun toggleHolidayFav(uid: String): Boolean { val r = holidayFavObj().toggle(uid); prefs.holidayFavsRaw = holidayFavObj().serialize(); return r }

    // ---- the user's own ratings and what search remembers about titles ------------------------
    private val metaPrefs = app.getSharedPreferences("sparrow_meta", android.content.Context.MODE_PRIVATE)     // separate file: the big one loads lazily

    private var ratingsCache: UserRatings? = null
    private var sparrowCache: SparrowScores? = null
    private var myListCache: MyList? = null
    private var profilesCache: ProfileStore? = null
    private fun userRatings(): UserRatings = ratingsCache ?: UserRatings.parse(prefs.ratingsRaw).also { ratingsCache = it }
    private fun sparrowScores(): SparrowScores = sparrowCache ?: SparrowScores.parse(prefs.sparrowRaw).also { sparrowCache = it }
    private fun myListObj(): MyList = myListCache ?: MyList.parse(prefs.myListRaw).also { myListCache = it }
    private val metaCache: MetaCache by lazy { MetaCache.parse(metaPrefs.getString("meta", "")) }

    @Synchronized fun myRating(uid: String): String = userRatings().get(uid)
    @Synchronized fun myRatings(): Map<String, String> = LinkedHashMap(userRatings().all())

    /** Loved / Liked / Disliked; pressing the same one again removes it. Returns the rating now stored ("" = none). */
    @Synchronized fun rate(uid: String, code: String): String {
        userRatings().toggle(uid, code); prefs.ratingsRaw = userRatings().serialize()
        return userRatings().get(uid)
    }

    // ---- the two star ratings on every poster ------------------------------------------------

    /** The provider's own rating (0 - 10, one decimal; -1 = none). */
    fun providerRatingOf(v: VodItem): Double = SparrowRating.providerOf(v.rating)

    /** The user's own Sparrow Rating of a title (0.5 - 10 in half steps; -1 = not rated). Independent of Loved / Liked / Disliked. */
    @Synchronized fun sparrowOf(v: VodItem): Double = sparrowScores().get(v.uid)
    @Synchronized fun sparrowOf(uid: String): Double = sparrowScores().get(uid)

    /** Everything search remembers about titles (length, rating, plot), copied once so 100 000 titles do not each take the lock. */
    @Synchronized fun metaSnapshot(): Map<String, MetaCache.Meta> = metaCache.all()

    /** Set (0.5 - 10) or clear (0 or less) the user's Sparrow Rating. */
    @Synchronized fun setSparrow(uid: String, value: Double) {
        sparrowScores().set(uid, value); prefs.sparrowRaw = sparrowScores().serialize()
    }

    @Synchronized fun meta(uid: String): MetaCache.Meta? = metaCache.get(uid)

    /** Remember length / maturity / plot from a details page, for search. */
    @Synchronized fun remember(uid: String, lengthMin: Int, maturity: String, plot: String) {
        metaCache.put(uid, lengthMin, maturity, plot)
        metaPrefs.edit().putString("meta", metaCache.serialize()).apply()
    }

    // ---- Channel helpers --------------------------------------------------------------------
    private val customCache = HashMap<Long, Customize>()

    /** The user's edits (hidden / renamed channels, own groups ...) for one provider. Edit it, then call [saveCustom]. */
    @Synchronized
    fun custom(pid: Long): Customize = customCache.getOrPut(pid) { Customize.parse(prefs.custom(pid)) }

    fun saveCustom(pid: Long) {
        prefs.setCustom(pid, custom(pid).serialize())
        dataTick.value++
    }

    /** Bumped whenever the user's channel / group edits change (separate from [dataVersion], which reloads everything). */
    val dataTick = MutableStateFlow(0)

    /** Channels of a group with the user's edits applied: hidden ones left out (unless [includeHidden]), renamed ones renamed. */
    suspend fun channelsFor(pid: Long, scope: String, includeHidden: Boolean = false): List<Channel> {
        val cu = custom(pid)
        var list = when (scope) {
            SCOPE_ALL -> dao.channels(pid)
            SCOPE_FAV -> dao.favorites(pid)
            else -> groupChannels(pid, scope, cu)
        }
        if (!includeHidden && cu.hidden.isNotEmpty()) list = list.filter { it.uid !in cu.hidden }
        return named(list, cu)
    }

    private suspend fun groupChannels(pid: Long, gid: String, cu: Customize): List<Channel> {
        val out: Set<String> = cu.removed[gid] ?: emptySet()
        val base = if (cu.isCustom(gid)) emptyList() else dao.channelsIn(pid, gid).let { l -> if (out.isEmpty()) l else l.filter { it.uid !in out } }
        val extra = cu.added[gid]?.toList().orEmpty()
        if (extra.isEmpty()) return base
        val have = base.mapTo(HashSet()) { it.uid }
        val more = ArrayList<Channel>()
        extra.chunked(500).forEach { more += dao.channelsByUids(it) }
        return (base + more.filter { it.uid !in have && it.providerId == pid }).sortedWith(compareBy({ it.number }, { it.name }))
    }

    private fun named(list: List<Channel>, cu: Customize): List<Channel> =
        if (cu.renamed.isEmpty()) list else list.map { c -> cu.renamed[c.uid]?.let { n -> c.copy(name = n) } ?: c }

    /**
     * The channel groups after the user's edits, in the order they are shown (the two built-in ones, All Channels and Favourites,
     * are not part of this list). Hidden groups are included and flagged.
     */
    suspend fun groups(pid: Long): List<GroupInfo> {
        val cu = custom(pid)
        val cats = dao.categories(pid, "live")
        val original = cats.associate { it.remoteId to TitleCase.of(it.name) }
        val natural = cu.customGroups.keys.toList() + cats.map { it.remoteId }
        return cu.arrange(natural.distinct()).map { id ->
            val orig = original[id] ?: cu.customGroups[id] ?: id
            GroupInfo(id, cu.groupName(id, orig), orig, cu.isCustom(id), cu.isGroupHidden(id))
        }
    }

    /** One channel with the user's name applied (null if it no longer exists). */
    suspend fun channel(uid: String): Channel? {
        val c = dao.channel(uid) ?: return null
        return named(listOf(c), custom(c.providerId)).first()
    }

    /** The channels this provider shows by default (hidden ones left out). */
    suspend fun firstChannel(pid: Long): Channel? = channelsFor(pid, SCOPE_ALL).firstOrNull()

    /** Channels the user hid (for Settings -> General -> Hidden). */
    suspend fun hiddenChannels(pid: Long): List<Channel> {
        val cu = custom(pid)
        if (cu.hidden.isEmpty()) return emptyList()
        val out = ArrayList<Channel>()
        cu.hidden.toList().chunked(500).forEach { out += dao.channelsByUids(it) }
        return named(out.filter { it.providerId == pid }, cu)
    }

    /** Currently airing programme per epgId. */
    suspend fun nowMap(pid: Long, channels: List<Channel>): Map<String, Programme> {
        val now = System.currentTimeMillis()
        val ids = channels.map { it.epgId }.filter { it.isNotBlank() }.distinct()
        val out = HashMap<String, Programme>()
        ids.chunked(500).forEach { chunk ->
            dao.programmes(pid, chunk, now, now + 1).forEach { out[it.epgId] = it }
        }
        return out
    }

    suspend fun deleteProvider(p: Provider) {
        withContext(Dispatchers.IO) { dao.deleteProgrammes(p.id) }
        db.withTransaction {
            dao.deleteChannels(p.id); dao.deleteVod(p.id); dao.deleteCategories(p.id)
            dao.deleteProvider(p.id)
        }
        // Deleting a playlist that is not the active one must not switch the user away from the one they are watching.
        if (prefs.activeProvider == p.id) { prefs.activeProvider = -1; active = null }
        forgetCustom(p.id)
        catalogVersion++
        dataVersion.value++
    }

    @Synchronized
    private fun forgetCustom(pid: Long) { customCache.remove(pid); prefs.setCustom(pid, ""); prefs.setLastEpgSync(pid, 0L) }

    // ---- Sync -------------------------------------------------------------------------------
    private val syncing = AtomicBoolean(false)

    /** Run [block] unless another sync is already running; failures show in the status line and never crash the app. */
    private suspend fun guarded(block: suspend () -> Unit) {
        if (!syncing.compareAndSet(false, true)) {
            status.value = "A sync is already running"; delay(2500)
            if (status.value == "A sync is already running") status.value = ""
            return
        }
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            status.value = "Sync failed: ${e.message}"
            delay(8000)
            status.value = ""
        } finally {
            syncing.set(false)
        }
    }

    /** Full sync: channels, movies, series and the guide ("Sync Now", a new playlist). */
    fun syncAsync(p: Provider) {
        scope.launch { guarded { sync(p) } }
    }

    /** Guide only (automatic EPG sync). */
    fun syncEpgAsync(p: Provider) {
        scope.launch { guarded { syncEpgOnly(p) } }
    }

    private var scheduler: Job? = null

    /**
     * Automatic guide sync: once when the app starts (if "Sync EPG On App Start" is on and the last sync is older than ten minutes),
     * then whenever the chosen interval (24 / 12 / 6 / 3 / 2 hours) has passed. Checked every five minutes while the app is running.
     */
    fun startScheduler() {
        if (scheduler != null) return
        scheduler = scope.launch {
            delay(4_000)                                          // let the screen come up first
            var first = true
            while (true) {
                val p = try { activeProvider() } catch (e: Exception) { null }
                if (p != null) {
                    val age = System.currentTimeMillis() - prefs.lastEpgSync(p.id)
                    val due = age >= prefs.epgHours * 3_600_000L
                    val atStart = first && prefs.epgOnStart && age >= START_GAP_MS
                    if (due || atStart) guarded { syncEpgOnly(p) }
                }
                first = false
                delay(5 * 60_000L)
            }
        }
    }

    private suspend fun syncEpgOnly(p: Provider) = withContext(Dispatchers.IO) {
        val st = { s: String -> status.value = s }
        try {
            if (syncEpg(p, st)) {
                prefs.setLastEpgSync(p.id, System.currentTimeMillis())
                epgVersion.value++
                st("Guide updated"); delay(2000); st("")
            } else st("")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            st("TV guide failed: ${e.message}"); delay(5000); st("")
        }
    }

    private suspend fun sync(p0: Provider) = withContext(Dispatchers.IO) {
        var p = p0
        val st = { s: String -> status.value = s }
        if (p.type == "xtream") syncXtream(p, st) else p = syncM3u(p, st)
        try {
            if (syncEpg(p, st)) prefs.setLastEpgSync(p.id, System.currentTimeMillis())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            st("TV guide failed: ${e.message}"); delay(5000)
        }
        dao.updateProvider(p.copy(lastSync = System.currentTimeMillis()))
        dataVersion.value++
        st("Ready"); delay(2000); st("")
    }

    private suspend fun syncXtream(p: Provider, st: (String) -> Unit) {
        val x = XtreamClient(http, p)
        st("Signing in…")
        if (!x.authenticate()) error("Login failed – check server, username and password")
        val favs = dao.favoriteKeys(p.id)

        st("Loading categories…")
        val cats = ArrayList<Category>()
        for ((action, type) in listOf("get_live_categories" to "live", "get_vod_categories" to "vod", "get_series_categories" to "series")) {
            x.list(action) { m -> cats += Category(providerId = p.id, remoteId = m.str("category_id"), name = m.str("category_name"), type = type) }
        }

        st("Loading live channels…")
        val ch = ArrayList<Channel>(); var n = 0
        x.list("get_live_streams") { m ->
            n++
            val id = m.str("stream_id")
            ch += Channel("${p.id}:$id", p.id, id, m.str("num").toIntOrNull() ?: n, m.str("name"),
                m.str("stream_icon"), "", m.str("category_id"), m.str("epg_channel_id"), false)
        }

        st("Loading movies…")
        val vod = ArrayList<VodItem>()
        val vodCatName = HashMap<String, String>()
        cats.filter { it.type == "vod" }.forEach { vodCatName[it.remoteId] = it.name }
        x.list("get_vod_streams") { m ->
            val id = m.str("stream_id")
            val primary = m.str("category_id")
            // Movies carry no genre in the panel's list. Newer panels do list every category a film belongs to ("category_ids"): the OTHER categories'
            // names stand in for its genre, so a film filed under Action AND Comedy shows up in both.
            val others = (m["category_ids"] as? List<*>)?.mapNotNull { c -> vodCatName[c?.toString() ?: ""] }
                ?.filter { n -> n != vodCatName[primary] }?.distinct()?.joinToString(", ") ?: ""
            vod += VodItem("${p.id}:m:$id", p.id, id, "movie", m.str("name"), m.str("stream_icon"), m.str("stream_icon"),
                primary, m.str("rating"), m.str("year"), "", m.str("added").toLongOrNull() ?: 0,
                m.str("container_extension"), m.str("genre").ifBlank { others }, "", TmdbId.clean(m.str("tmdb")))
        }

        st("Loading series…")
        x.list("get_series") { m ->
            val id = m.str("series_id")
            val bd = (m["backdrop_path"] as? List<*>)?.firstOrNull()?.toString() ?: ""
            vod += VodItem("${p.id}:s:$id", p.id, id, "series", m.str("name"), m.str("cover"), bd.ifBlank { m.str("cover") },
                m.str("category_id"), m.str("rating"), m.str("year").ifBlank { m.str("releaseDate").take(4) },
                m.str("plot"), m.str("last_modified").toLongOrNull() ?: 0, "", m.str("genre"), "", TmdbId.clean(m.str("tmdb")))
        }
        st("Saving…")
        store(p, cats, ch, vod, favs)
    }

    private suspend fun syncM3u(p: Provider, st: (String) -> Unit): Provider {
        st("Downloading playlist…")
        val favs = dao.favoriteKeys(p.id)
        val ch = ArrayList<Channel>(); val vod = ArrayList<VodItem>()
        val liveGroups = LinkedHashSet<String>(); val vodGroups = LinkedHashSet<String>()
        var n = 0
        var epg = ""
        http.newCall(Request.Builder().url(p.m3uUrl).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            epg = M3uParser.parse(r.body!!.byteStream()) { e ->
                n++
                val id = Integer.toHexString(e.url.hashCode())
                if (e.url.contains("/movie/")) {
                    vodGroups += e.group
                    vod += VodItem("${p.id}:m:$id", p.id, id, "movie", e.name, e.logo, e.logo, e.group, "", "", "",
                        n.toLong(), "", "", e.url)
                } else {
                    liveGroups += e.group
                    ch += Channel("${p.id}:$id", p.id, id, e.chno ?: n, e.name, e.logo, e.url, e.group, e.tvgId, false)
                }
            }
        }
        val cats = liveGroups.map { Category(providerId = p.id, remoteId = it, name = it, type = "live") } +
            vodGroups.map { Category(providerId = p.id, remoteId = it, name = it, type = "vod") }
        st("Saving…")
        store(p, cats, ch, vod, favs)
        return if (p.epgUrl.isBlank() && epg.isNotBlank()) p.copy(epgUrl = epg) else p
    }

    private suspend fun store(p: Provider, cats: List<Category>, ch: List<Channel>, vod: List<VodItem>, favs: List<String>) {
        db.withTransaction {
            dao.deleteCategories(p.id); dao.deleteChannels(p.id); dao.deleteVod(p.id)
            dao.insertCategories(cats)
            ch.chunked(2000).forEach { dao.insertChannels(it) }
            vod.chunked(2000).forEach { dao.insertVod(it) }
            favs.chunked(500).forEach { dao.restoreFavorites(it) }
        }
        // what the panel sent, for Settings -> General -> Library Counts (compare with the provider's own numbers)
        prefs.setSyncCounts(p.id, SyncCounts.of(vod, ch.size, cats.count { it.type == "vod" }, cats.count { it.type == "series" }, System.currentTimeMillis()).serialize())
        catalogVersion++
        dataVersion.value++
        warmCatalogs()
    }

    /** The library report of one kind of title for the Library Counts window (worked out on a background thread). */
    suspend fun libraryReport(pid: Long, type: String): LibraryReport {
        val cat = catalog(pid, type)
        val known = maturities()
        return withContext(Dispatchers.Default) { LibraryStats.of(cat, known) }
    }

    /** @return true if a guide was downloaded and imported (false = nothing to do: no EPG source / no channel with a guide id). */
    private suspend fun syncEpg(p: Provider, st: (String) -> Unit): Boolean {
        val url = when {
            p.epgUrl.isNotBlank() -> p.epgUrl
            p.type == "xtream" -> Urls.xmltv(p)
            else -> return false
        }
        val ids = dao.channels(p.id).map { it.epgId }.filter { it.isNotBlank() }.toHashSet()
        if (ids.isEmpty()) return false
        st("Downloading TV guide…")
        val now = System.currentTimeMillis()
        val from = now - 3 * 3600_000L; val to = now + 36 * 3600_000L
        http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("EPG HTTP ${r.code}")      // old guide data is only replaced once the server answered OK
            dao.deleteProgrammes(p.id)
            val input = XmltvParser.maybeGunzip(r.body!!.byteStream())
            val buf = ArrayList<Programme>(); var count = 0
            XmltvParser.parse(input, ids, from, to) { pr ->
                buf += pr.copy(providerId = p.id); count++
                if (buf.size >= 1500) {
                    dao.insertProgrammes(ArrayList(buf)); buf.clear(); st("Importing TV guide… $count")
                }
            }
            if (buf.isNotEmpty()) dao.insertProgrammes(buf)
        }
        return true
    }

    companion object {
        const val START_GAP_MS = 10 * 60_000L          // "sync on app start" is skipped if the guide was updated less than 10 minutes ago
        const val SCOPE_HOLIDAY_FAVS = "__holidayfavs"
        const val SCOPE_YEAR = "year:"                       // v3.6.18: "year:2026" = the 2026 Releases page
        const val SCOPE_HOLIDAYS = "__holidays"
        const val SCOPE_ALL = "__all"
        const val SCOPE_FAV = "__fav"
    }
}
