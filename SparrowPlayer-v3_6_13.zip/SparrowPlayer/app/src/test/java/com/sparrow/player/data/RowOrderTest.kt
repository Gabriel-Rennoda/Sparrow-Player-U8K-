package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class RowOrderTest {
    private val me = "Gabriel"
    private val shuffled = listOf(
        "Hidden Gems", "Watch It Again", "Top Rated", "Because You Watched Heat", "Top 10 Kids Titles Today", "Recently Added", "2026 Releases",
        "My List", "Because You Added Up to Your List", "Continue Watching for Gabriel", "Trending Now", "Top 10 Movies Today in Canada",
        "New in Thrillers", "Top Picks for Gabriel", "Because You Liked Alien", "Classic Movies", "Action"
    )

    @Test fun firstTenAreLockedThenBecauseRowsThenTheRest() {
        val r = RowOrder.arrange(shuffled, me, 2026) { it }
        assertEquals(listOf("Top Picks for Gabriel", "Top 10 Movies Today in Canada", "Trending Now", "Continue Watching for Gabriel", "My List",
            "2026 Releases", "Recently Added", "Top Rated", "Top 10 Kids Titles Today", "Watch It Again"), r.take(10))
        assertEquals(listOf("Because You Watched Heat", "Because You Added Up to Your List", "Because You Liked Alien"), r.subList(10, 13))
        assertEquals(listOf("Hidden Gems", "New in Thrillers", "Classic Movies", "Action"), r.drop(13))      // build order kept
    }

    @Test fun missingRowsLeaveNoGap() {
        val r = RowOrder.arrange(listOf("Top Rated", "Trending Now", "Top Picks for Gabriel"), me, 2026) { it }
        assertEquals(listOf("Top Picks for Gabriel", "Trending Now", "Top Rated"), r)
    }

    @Test fun yearRowFollowsTheYearAndKidsTopTenIsNotTheCountryRow() {
        assertEquals(6, RowOrder.rank("2027 Releases", me, 2027))
        assertEquals(6, RowOrder.rank("2026 Releases", me, 2027))                                         // the year before sits right behind it
        assertEquals(RowOrder.OTHER, RowOrder.rank("2025 Releases", me, 2027))
        assertEquals(2, RowOrder.rank("Top 10 TV Shows Today in United States", me, 2026))
        assertEquals(9, RowOrder.rank("Top 10 Kids Titles Today", me, 2026))
        assertEquals(RowOrder.OTHER, RowOrder.rank("Top Picks for Someone Else", me, 2026))
    }

    @Test fun lateRowsSlotIntoTheirPlace() {
        val onScreen = listOf("Top Picks for Gabriel", "Continue Watching for Gabriel", "Top Rated", "Because You Watched Heat", "New in Thrillers")
        val end = onScreen.size
        assertEquals(1, RowOrder.insertIndex(onScreen, end, "Top 10 Movies Today in Canada", me, 2026))   // after Top Picks
        assertEquals(1, RowOrder.insertIndex(onScreen, end, "Trending Now", me, 2026))
        assertEquals(2, RowOrder.insertIndex(onScreen, end, "My List", me, 2026))                          // after Continue Watching
        assertEquals(2, RowOrder.insertIndex(onScreen, end, "2026 Releases", me, 2026))                    // before Top Rated
        assertEquals(4, RowOrder.insertIndex(onScreen, end, "Because You Liked Alien", me, 2026))          // after the other Because row
        assertEquals(3, RowOrder.insertIndex(onScreen, end, "Top 10 Kids Titles Today", me, 2026))         // after Top Rated
        assertEquals(end, RowOrder.insertIndex(onScreen, end, "Hidden Gems", me, 2026))
    }

    @Test fun yearIsReadFromAnyDateShape() {
        assertEquals(2026, Recommender.yearOf("2026-03-01")); assertEquals(2026, Recommender.yearOf("2026"))
        assertEquals(2026, Recommender.yearOf("01-03-2026")); assertEquals(2026, Recommender.yearOf("March 3, 2026"))
        assertEquals(0, Recommender.yearOf("")); assertEquals(0, Recommender.yearOf("TV Movie")); assertEquals(0, Recommender.yearOf("12345"))
    }

    @Test fun tmdbStoreKeepsTheReleaseYearAndReadsOldFiles() {
        val st = TmdbStore(); st.put("1:m:5", "PG", 77, "Drama", 2026)
        st.put("1:m:5", "PG", 77, "", 0)                                              // a later put without a year keeps it
        assertEquals(2026, st.yearOf("1:m:5"))
        val back = TmdbStore.parse(st.serialize()); assertEquals(2026, back.yearOf("1:m:5")); assertEquals("Drama", back.genreOf("1:m:5"))
        val old = TmdbStore.parse("1:m:9\tG\t12\tAnimation, Family\n"); assertEquals(0, old.yearOf("1:m:9")); assertEquals("Animation, Family", old.genreOf("1:m:9"))
    }
}
