package com.sparrow.player.sports

import org.junit.Assert.*
import org.junit.Test

class SportsChannelMatcherTest {
    private val game = SportsGame("1", "NHL", 0L, GameState.LIVE, SportsTeam("Maple Leafs", "TOR", 3), SportsTeam("Canadiens", "MTL", 2))
    private fun ch(vararg names: String) = names.mapIndexed { i, n -> ChannelRef("1:$i", n) }

    @Test fun teamNamesAndBroadcastersRankChannels() {
        val m = SportsChannelMatcher.match(game, ch("CA: SPORTSNET ONTARIO HD", "NHL: Toronto Maple Leafs vs Montreal Canadiens", "Cartoon Network", "TSN 1"))
        assertEquals("NHL: Toronto Maple Leafs vs Montreal Canadiens", m[0].channel.name); assertEquals("Likely", m[0].label)
        assertEquals(setOf("CA: SPORTSNET ONTARIO HD", "TSN 1"), m.drop(1).map { it.channel.name }.toSet())        // broadcaster only: "Possible"
        assertTrue(m.drop(1).all { it.label == "Possible" })
        assertTrue(m.none { it.channel.name == "Cartoon Network" })                                                   // no evidence, not offered
    }

    @Test fun replaysHighlightsAndTalkAreNeverTheLiveGame() {
        val m = SportsChannelMatcher.match(game, ch("Leafs Highlights HD", "Leafs Lunch Talk Show", "TOR Maple Leafs Live"))
        assertEquals(MatchKind.REPLAY, m.first { it.channel.name.contains("Highlights") }.kind)
        assertEquals(MatchKind.SHOW, m.first { it.channel.name.contains("Talk") }.kind)
        assertEquals(MatchKind.LIVE, m.first { it.channel.name.contains("Live") }.kind)
    }

    @Test fun codesMatchOnlyAsWholeWordsAndAccentsAreIgnored() {
        val m = SportsChannelMatcher.match(game, ch("Stormtrooper TV", "Canadiens de Montréal", "TOR 04"))
        assertTrue(m.none { it.channel.name == "Stormtrooper TV" })                                                  // "tor" inside a word is not TOR
        assertTrue(m.any { it.channel.name == "TOR 04" })
        assertTrue(m.any { it.channel.name == "Canadiens de Montréal" })
    }
}
