package com.sparrow.player.ui.sports

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.sparrow.player.R
import com.sparrow.player.data.Json
import com.sparrow.player.sports.*
import com.sparrow.player.ui.TabContent
import com.sparrow.player.ui.menus.Popup
import com.sparrow.player.util.repo
import com.sparrow.player.data.Repository
import com.sparrow.player.ui.player.PlayerActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v4.0.0 Sports, stage 2: the tab. Favourite clubs first (live, next, last games), then today's NHL scoreboard, then the options.
 * A section with nothing to show is not drawn. Offline it shows the last saved copy and says when it was saved. Channels, news and more leagues come later.
 */
class SportsFragment : Fragment(), TabContent {
    private var scroll: ScrollView? = null
    private var root: LinearLayout? = null
    private var firstFocus: View? = null
    private var job: Job? = null
    private lateinit var service: SportsService

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx = requireContext()
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(28), dp(20), dp(28), dp(48)) }
        root = col
        return ScrollView(ctx).apply { isFillViewport = true; clipToPadding = false; addView(col) }.also { scroll = it }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val ctx = requireContext().applicationContext
        service = SportsService(OkSportsHttp(ctx.repo.http), SportsCache(File(ctx.cacheDir, "sports")), RateLimiter(30), { Json.readObject(it.byteInputStream()) })
        start()
    }

    override fun onDestroyView() { job?.cancel(); root = null; scroll = null; firstFocus = null; super.onDestroyView() }

    private fun start() {
        job?.cancel()
        job = viewLifecycleOwner.lifecycleScope.launch {
            while (isActive) {
                val live = try { render() } catch (e: Exception) { SportsDiagnostics.add("RENDER FAILED: ${e.message}"); false }
                delay(if (live) 30_000L else 300_000L)           // 30 s while a game is on, otherwise every 5 minutes
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private suspend fun render(): Boolean {
        val prefs = requireContext().applicationContext.repo.prefs
        val teams = prefs.sportsTeams.split(',').map { it.trim().uppercase() }.filter { it.isNotEmpty() }
        val seasons = teams.map { it to service.nhlSeason(it) }
        val board = service.nhlScores()
        val col = root ?: return false
        val focusedAt = (0 until col.childCount).firstOrNull { col.getChildAt(it).hasFocus() }          // the same spot is selected again after the refresh
        col.removeAllViews(); firstFocus = null
        val now = System.currentTimeMillis()
        var anyLive = false
        val results = seasons.map { it.second } + board

        heading(col, "Sports")
        val offline = results.filter { it.fromCache && it.updatedMs > 0 }
        if (offline.isNotEmpty()) dim(col, "Offline: showing the last copy from " + fmt("EEE MMM d, h:mm a", offline.minOf { it.updatedMs }))
        else if (results.any { it.updatedMs > 0 }) dim(col, "Updated " + fmt("h:mm a", results.maxOf { it.updatedMs }))

        // the hero: the first favourite club's live game, else its next game, else its last result
        val heroGame = seasons.firstOrNull()?.second?.games?.let { g ->
            g.firstOrNull { it.state == GameState.LIVE } ?: g.firstOrNull { it.state == GameState.UPCOMING && it.startMs >= now - 3 * 3_600_000L } ?: g.lastOrNull { it.state == GameState.FINAL }
        }
        if (heroGame != null) {
            if (heroGame.state == GameState.LIVE) anyLive = true
            section(col, if (heroGame.state == GameState.LIVE) "Live now" else if (heroGame.state == GameState.UPCOMING) "Next game" else "Last game")
            card(col, heroText(heroGame, now), heroGame.state == GameState.LIVE, 34f) { watch(heroGame) }
            card(col, "▶  Watch: channels that carry this game", false) { watch(heroGame) }
        }
        var shownAny = false
        for ((abbrev, res) in seasons) {
            val games = res.games
            val live = games.filter { it.state == GameState.LIVE }
            val next = games.filter { it.state == GameState.UPCOMING && it.startMs >= now - 3 * 3_600_000L }.take(3)
            val last = games.filter { it.state == GameState.FINAL }.takeLast(2).reversed()
            val shown = live + next + last
            if (shown.isEmpty()) continue                                      // nothing to show: the section is not drawn
            if (live.isNotEmpty()) anyLive = true
            section(col, NhlTeams.nameOf(abbrev)); shown.forEach { g -> card(col, line(g), g.state == GameState.LIVE) { watch(g) } }; shownAny = true
        }
        val todays = board.games.filter { it.state == GameState.LIVE || sameDay(it.startMs, now) }
        if (todays.isNotEmpty()) {
            if (todays.any { it.state == GameState.LIVE }) anyLive = true
            section(col, "Today in the NHL"); todays.forEach { g -> card(col, line(g), g.state == GameState.LIVE) { watch(g) } }; shownAny = true
        }
        if (!shownAny) {
            section(col, "Nothing to show yet")
            dim(col, "No games found for your favourite clubs right now.")
            val last = SportsDiagnostics.all().lastOrNull()
            if (last != null) dim(col, "Last answer: " + last.take(160))
        }

        section(col, "Options")
        card(col, "Favourite clubs: " + (teams.joinToString(", ") { NhlTeams.nameOf(it) }.ifEmpty { "none" }) + "   (OK to change)", false) { pickClubs() }
        card(col, "Sports tab sits " + (if (prefs.sportsAfterLive) "under Live TV" else "under Series") + "   (OK to change)", false) {
            prefs.sportsAfterLive = !prefs.sportsAfterLive
            Toast.makeText(requireContext(), "Takes effect when the app restarts", Toast.LENGTH_LONG).show()
            start()
        }
        if (focusedAt != null && focusedAt < col.childCount && col.getChildAt(focusedAt).isFocusable) col.getChildAt(focusedAt).requestFocus()
        return anyLive
    }

    private fun pickClubs() {
        val prefs = requireContext().applicationContext.repo.prefs
        val p = Popup(requireActivity(), "Favourite Clubs")
        for ((ab, name) in NhlTeams.CANADIAN) {
            val on = prefs.sportsTeams.split(',').any { it.trim().equals(ab, true) }
            p.row((if (on) "✓  " else "     ") + name) { prefs.sportsTeams = NhlTeams.toggle(prefs.sportsTeams, ab); start(); view?.postDelayed({ if (isAdded) pickClubs() }, 200) }
        }
        p.row("Done") { }
        p.show()
    }

    private fun heroText(g: SportsGame, now: Long): String {
        fun sc(t: SportsTeam) = t.score?.toString() ?: "-"
        val teams = "${g.away.name} ${sc(g.away)}  –  ${g.home.name} ${sc(g.home)}"
        return when (g.state) {
            GameState.LIVE -> "LIVE  ·  ${g.status}\n$teams"
            GameState.FINAL -> "Final  ·  ${fmt("EEE MMM d", g.startMs)}\n$teams"
            GameState.UPCOMING -> {
                val mins = ((g.startMs - now) / 60_000L).coerceAtLeast(0)
                val left = if (mins >= 1440) "in ${mins / 1440} d ${mins % 1440 / 60} h" else if (mins >= 60) "in ${mins / 60} h ${mins % 60} min" else "in $mins min"
                "${fmt("EEE MMM d, h:mm a", g.startMs)}  ·  starts $left\n${g.away.name}  @  ${g.home.name}"
            }
        }
    }

    /** The channels of the active playlist that may carry this game (see [SportsChannelMatcher]); OK on one plays it. */
    private fun watch(g: SportsGame) {
        viewLifecycleOwner.lifecycleScope.launch {
            val repo = requireContext().applicationContext.repo
            val p = repo.activeProvider()
            val chans = if (p == null) emptyList() else withContext(Dispatchers.IO) { repo.dao.channels(p.id) }
            val matches = SportsChannelMatcher.match(g, chans.map { ChannelRef(it.uid, it.name) })
            val pop = Popup(requireActivity(), "Watch: ${g.away.name} @ ${g.home.name}")
            val live = matches.filter { it.kind == MatchKind.LIVE }.take(12)
            if (live.isEmpty()) pop.note("No channel in your playlist matches this game yet.")
            for (m in live) pop.row(m.channel.name, m.label) { startActivity(PlayerActivity.live(requireContext(), m.channel.uid, Repository.SCOPE_ALL)) }
            val other = matches.filter { it.kind != MatchKind.LIVE }.take(6)
            if (other.isNotEmpty()) {
                pop.note("Replays, highlights and shows")
                for (m in other) pop.row(m.channel.name, if (m.kind == MatchKind.REPLAY) "Replay" else "Show") { startActivity(PlayerActivity.live(requireContext(), m.channel.uid, Repository.SCOPE_ALL)) }
            }
            pop.row("Close") { }
            pop.show()
        }
    }

    private fun line(g: SportsGame): String {
        fun sc(t: SportsTeam) = t.score?.toString() ?: "-"
        return when (g.state) {
            GameState.LIVE -> "LIVE  ${g.status}     ${g.away.name} ${sc(g.away)}  –  ${g.home.name} ${sc(g.home)}"
            GameState.FINAL -> "Final  ${fmt("MMM d", g.startMs)}     ${g.away.name} ${sc(g.away)}  –  ${g.home.name} ${sc(g.home)}"
            GameState.UPCOMING -> "${fmt("EEE MMM d, h:mm a", g.startMs)}     ${g.away.name}  @  ${g.home.name}"
        }
    }

    private fun fmt(pattern: String, ms: Long) = SimpleDateFormat(pattern, Locale.getDefault()).format(Date(ms))
    private fun sameDay(a: Long, b: Long) = fmt("yyyyMMdd", a) == fmt("yyyyMMdd", b)

    // ---- little views ---------------------------------------------------------------------------
    private fun heading(col: LinearLayout, t: String) = col.addView(TextView(requireContext()).apply {
        text = t; textSize = 32f; setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(ContextCompat.getColor(context, R.color.text)); setPadding(0, 0, 0, dp(4))
    })

    private fun section(col: LinearLayout, t: String) = col.addView(TextView(requireContext()).apply {
        text = t; textSize = 22f; setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(ContextCompat.getColor(context, R.color.accent)); setPadding(dp(4), dp(22), 0, dp(8))
    })

    private fun dim(col: LinearLayout, t: String) = col.addView(TextView(requireContext()).apply {
        text = t; textSize = 16f; setTextColor(ContextCompat.getColor(context, R.color.textDim)); setPadding(dp(4), 0, 0, dp(4))
    })

    private fun card(col: LinearLayout, t: String, live: Boolean, size: Float = 22f, onClick: (() -> Unit)? = null) {
        val ctx = requireContext()
        val accent = ContextCompat.getColor(ctx, R.color.accent)
        fun bg(focused: Boolean) = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (focused) Color.argb(70, 255, 255, 255) else Color.argb(28, 255, 255, 255))
            setStroke(dp(if (focused) 3 else 1), if (focused) accent else if (live) accent else Color.argb(60, 255, 255, 255))
        }
        val v = TextView(ctx).apply {
            text = t; textSize = size; setTextColor(ContextCompat.getColor(ctx, R.color.text)); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14)); isFocusable = true; isClickable = true; background = bg(false)
            setOnFocusChangeListener { _, f -> background = bg(f) }
            setOnClickListener { onClick?.invoke() }
        }
        col.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        if (firstFocus == null) firstFocus = v
    }

    // ---- TabContent -----------------------------------------------------------------------------
    override fun focusContent(): Boolean = firstFocus?.requestFocus() ?: false
    override fun isAtLeftEdge() = true
    override fun isAtTop(): Boolean = false
    override fun scrollView(): View? = scroll
}
