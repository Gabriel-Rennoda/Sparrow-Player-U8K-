package com.sparrow.player.sports

data class ChannelRef(val uid: String, val name: String)

enum class MatchKind { LIVE, REPLAY, SHOW }

data class ChannelMatch(val channel: ChannelRef, val score: Int, val kind: MatchKind, val reasons: List<String>) {
    /** "Likely" / "Good" / "Possible": shown next to the channel so a weak match is never presented as a sure one. */
    val label: String get() = when { score >= 70 -> "Likely"; score >= 40 -> "Good"; else -> "Possible" }
}

/**
 * Which channels of the playlist may carry a game. Evidence only: a team's name, city or 3-letter code as a whole word in the channel name (+40 each,
 * +30 when both teams are named), a league word (+10) or a broadcaster that carries the sport (+20). Channels that say replay / highlights / recap are
 * REPLAY, news and talk are SHOW: never offered as the live game. Below 20 points a channel is not offered at all (no guessing).
 */
object SportsChannelMatcher {
    private val REPLAY = Regex("\\b(replay|replays|re air|rerun|highlights?|recap|condensed|classic|archive|encore)\\b")
    private val SHOW = Regex("\\b(news|talk|show|tonight|insider|analysis|podcast|radio)\\b")
    private val LEAGUE = listOf("nhl", "hockey")
    private val BROADCASTERS = listOf("sportsnet", "sn1", "sn360", "tsn", "cbc", "hockey night", "rds", "tva sports", "nhl network", "center ice", "espn")

    fun normalize(s: String): String {
        val d = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return " " + d.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim() + " "
    }

    private fun has(text: String, word: String): Boolean = word.isNotBlank() && text.contains(" " + word.trim() + " ")

    private fun aliases(t: SportsTeam): List<String> {
        if (t.name.isBlank() && t.abbrev.isBlank()) return emptyList()
        val full = NhlTeams.nameOf(t.abbrev).takeIf { t.abbrev.isNotBlank() && it != t.abbrev.uppercase() } ?: ""
        val common = normalize(t.name).trim()
        val city = if (full.isNotBlank() && common.isNotBlank()) normalize(full).trim().removeSuffix(common).trim() else ""
        val last = common.substringAfterLast(' ').takeIf { it.length >= 5 } ?: ""          // "leafs" for "maple leafs"
        return listOf(common, last, normalize(full).trim(), city, t.abbrev.lowercase()).filter { it.length >= 3 }.distinct()
    }

    fun match(game: SportsGame, channels: List<ChannelRef>): List<ChannelMatch> {
        val home = aliases(game.home); val away = aliases(game.away)
        return channels.mapNotNull { c ->
            val n = normalize(c.name)
            val reasons = ArrayList<String>(); var score = 0
            val h = home.any { has(n, it) }; val a = away.any { has(n, it) }
            if (h) { score += 40; reasons += "names ${game.home.name.ifBlank { game.home.abbrev }}" }
            if (a) { score += 40; reasons += "names ${game.away.name.ifBlank { game.away.abbrev }}" }
            if (h && a) { score += 30; reasons += "both teams" }
            if (LEAGUE.any { has(n, it) }) { score += 10; reasons += "league" }
            if (BROADCASTERS.any { has(n, it) }) { score += 20; reasons += "broadcaster" }
            if (score < 20) null else {
                val kind = when { REPLAY.containsMatchIn(n) -> MatchKind.REPLAY; SHOW.containsMatchIn(n) -> MatchKind.SHOW; else -> MatchKind.LIVE }
                ChannelMatch(c, score, kind, reasons)
            }
        }.sortedWith(compareByDescending<ChannelMatch> { it.score }.thenBy { it.channel.name })
    }
}
