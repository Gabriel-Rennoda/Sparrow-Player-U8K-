Next update (v3.4.0) - copy / paste this into the next chat
Same rules: investigate and test each item before changing code, apply in stages, test for the 75" U8K remote, then give me the updated zip. If anything is not completed, write a new copy-paste document.
Version 3.3.0 is the base (written WITHOUT a compiler). FIRST check the GitHub build log for the 3.3.0 run (versionCode 43) and fix compile errors before anything else. Check docs/TV_TEST_CHECKLIST_3_3.md (my results are pasted below).
Done in 3.3.0: Sparrow's own keyboard (Settings -> General -> Sparrow Keyboard; Up never leaves the letters, hold Up = number row, hold OK on a top letter = its number); sync starts by itself after "Yes, Restart"; Add Playlist arrow re-checks more often; Kids guard against grown-up TV films (channel words in category / genre, murder-affair style words in the title); My List carousel hides the Sparrow rating; details title moved up + two lines.
NEEDS MY ANSWER BEFORE CODING (not guessed in 3.3.0):
- Navigation, "still showing": I wrote "still showing" under the icon-list item. What is still showing, and where? (The Search icon in the icon list? The Search entry at the top of the Groups panel? Which tab?)
- Add Playlist arrow: if still missing, tell me whether any part of the page is cut off at the bottom.
- Kids: send the exact title + category of any grown-up TV film still in Kids / Family / Child profiles.
- "My list hide sparrow rating": I hid it in the My List carousel. Also in its See All grid? On the details page?
- "Move title up / bigger text box": I did this on the details page. Tell me if you meant another screen.
NOT done (each needs its own build + TV test):
Group loading is still computed per page; if a group is still slow, send which group and how long (a cache of finished genre pages is the next step).
S2 TMDB genres + animation + family tags (tmdbId is stored). S3 TMDB keywords for holiday carousels + holiday pre-menu (23). S0 TMDB logo on Settings / About (send the logo file).
19 / 20 multiple custom Favourites sections; Copy To for Movies / Series. 12 live sync. 3 / 6 four-channel split screen.
"Bigger watched badges on posters": tell me what you want on the poster (a tick on finished titles?).
