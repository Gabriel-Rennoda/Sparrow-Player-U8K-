package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class MaturityTest {
    private fun ok(name: String, cat: String = "", genre: String = "", known: String = "", series: Boolean = false) =
        Maturity.familyOk(known, name, cat, TextNorm.prepare(name), TextNorm.prepare("$genre $cat"), series)

    @Test fun knownRatingsDecide() {
        for (r in listOf("TV-Y", "TV-G", "G", "TV-PG", "PG", "PG-13")) assertTrue(r, ok("X", known = r))
        for (r in listOf("TV-14", "TV-MA", "R", "NC-17")) assertFalse(r, ok("X", "Kids", "Kids", known = r))
    }

    @Test fun ageNumbersAndTextNormalise() {
        assertEquals("TV-MA", Maturity.normalize("18+")); assertEquals("R", Maturity.normalize("16")); assertEquals("TV-14", Maturity.normalize("14"))
        assertEquals("PG-13", Maturity.normalize("13")); assertEquals("TV-PG", Maturity.normalize("10")); assertEquals("", Maturity.normalize("0"))
        assertEquals("PG-13", Maturity.normalize("Rated PG-13")); assertEquals("", Maturity.normalize("Not Rated")); assertEquals("", Maturity.normalize(""))
    }

    @Test fun adultCartoonsAreOutKidsShowsAreIn() {
        assertFalse(ok("Rick And Morty", "Animation", "Animation, Comedy", series = true))
        assertFalse(ok("Rick & Morty (2013)", "Kids", "Kids"))                                      // listed even when misfiled under Kids
        assertFalse(ok("BoJack Horseman", "Animation", "Animation, Drama", series = true))
        assertFalse(ok("Beavis And Butt-Head", "Animation", "Animation", series = true))
        assertFalse(ok("Anything [TV-MA]", "Kids", "Kids"))
        assertFalse(ok("Scary Toons", "Kids", "Animation, Horror"))
        assertTrue(ok("Bluey", "Kids", "Animation, Kids", series = true))
        assertTrue(ok("Paw Patrol", "Children", "", series = true))
        assertTrue(ok("Frozen", "Animation Movies", ""))                                            // film, only "animation": allowed
        assertFalse(ok("Unknown Cartoon", "Animation", "Animation, Comedy", series = true))         // series, only "animation": waits for a rating
    }

    @Test fun crimeNextToFamilyIsFineCrimeAloneIsNot() {
        assertTrue(ok("Despicable Me", "Kids", "Animation, Family, Comedy, Crime"))
        assertFalse(ok("Heat Wave", "Animation", "Animation, Crime"))
        assertFalse(ok("Dark Toon", "Kids", "Kids, Horror"))                                          // horror never
    }

    @Test fun knownChildrensTitlesPassEvenAsASeriesWithNoGenre() {
        assertTrue(ok("Bluey", "Animation", "", series = true)); assertTrue(ok("Peppa Pig (2004)", "Cartoons", "", series = true))
        assertFalse(ok("Rick And Morty", "Animation", "", series = true))
        assertTrue(Maturity.isKidsTitle(TextNorm.prepare("PAW Patrol: The Movie"))); assertFalse(Maturity.isKidsTitle(TextNorm.prepare("Up In Smoke")))
    }

    @Test fun ageLimitsUseKnownRatingsFirst() {
        fun ok(limit: String, known: String, name: String = "A Film", cat: String = "Movies") =
            Maturity.allowed(limit, known, name, cat, TextNorm.prepare(name), TextNorm.prepare(cat), false)
        assertTrue(ok("", "NC-17"))                                  // no limit
        assertTrue(ok("PG-13", "PG-13")); assertFalse(ok("PG-13", "TV-14")); assertFalse(ok("PG-13", "R"))
        assertTrue(ok("TV-14", "TV-14")); assertFalse(ok("TV-14", "TV-MA"))
        assertTrue(ok("R", "R")); assertTrue(ok("R", "TV-MA")); assertFalse(ok("R", "NC-17"))
        assertTrue(ok("PG", "PG")); assertFalse(ok("PG", "PG-13")); assertFalse(ok("G", "PG"))
    }

    @Test fun ageLimitWithoutRatingUsesKidsEvidence() {
        fun ok(limit: String, name: String, cat: String) = Maturity.allowed(limit, "", name, cat, TextNorm.prepare(name), TextNorm.prepare(cat), false)
        assertFalse(ok("PG-13", "Some Film", "Adult Movies"))
        assertFalse(ok("PG-13", "Some Film [TV-MA]", "Movies"))
        assertTrue(ok("PG-13", "Paw Patrol The Movie", "Kids"))
        assertTrue(ok("R", "Some Film", "Action"))
        assertFalse(ok("R", "Some Film", "XXX"))
    }

    @Test fun strictHidesUnratedUnlessKids() {
        fun ok(name: String, cat: String, strict: Boolean) = Maturity.allowed("PG-13", "", name, cat, TextNorm.prepare(name), TextNorm.prepare(cat), false, strict)
        assertTrue(ok("Some Drama", "Drama", false))
        assertFalse(ok("Some Drama", "Drama", true))
        assertTrue(ok("Some Cartoon", "Kids", true))
        assertFalse(ok("Cinderella Man", "Kids", true))
        assertFalse(ok("Madagascar Skin", "Family", false))
    }

    // v3.1.0: the title's own genres outvote a kids-looking provider category
    @Test fun ownGenresKeepGrownUpTitlesOutOfKids() {
        assertFalse(Maturity.genreKidsOk("TV Movie, Crime, Drama"))              // She Said No
        assertFalse(Maturity.genreKidsOk("TV Movie, Romance"))                   // Flowers & Honey
        assertFalse(Maturity.genreKidsOk("TV Movie, Family, Romance"))           // Every Other Holiday: romance needs animation
        assertFalse(Maturity.genreKidsOk("TV Movie"))                            // Sinatra / Lucille Ball / Liszt: nothing says family
        assertFalse(Maturity.genreKidsOk("TV Movie, Documentary"))
        assertFalse(Maturity.genreKidsOk("Thriller"))
        assertFalse(Maturity.genreKidsOk("Horror, Animation"))
        assertTrue(Maturity.genreKidsOk("Animation, Family, Comedy, Crime"))     // Despicable Me
        assertTrue(Maturity.genreKidsOk("Animation, Family, Fantasy, Romance"))  // a Disney princess film
        assertTrue(Maturity.genreKidsOk("Family, Drama"))
        assertTrue(Maturity.genreKidsOk("Comedy"))
        assertTrue(Maturity.genreKidsOk(""))                                     // no evidence = decided by the rest of the screen
    }

    @Test fun childProfileUsesOwnGenresToo() {
        val bad = RowTitle("u1", "She Said No", "Kids", "TV Movie, Crime, Drama", 1990, 7.7, 0L)
        val fine = RowTitle("u2", "Bluey", "Kids", "Animation, Family", 2018, 8.0, 0L)
        assertFalse(Maturity.allowed("PG", bad, "", false, strict = true))
        assertTrue(Maturity.allowed("PG", fine, "", true, strict = true))
        assertFalse(Maturity.familyOk(bad, "", false))
    }

    // v3.2.0
    @Test fun moreWellKnownChildrensTitlesAreKidsTitles() {
        for (n in listOf("Frozen II (2019)", "Frozen", "Mulan", "Cars 2", "The Wild Robot", "Sing 2", "Home Alone 2"))
            assertTrue(n, Maturity.isKidsTitle(TextNorm.prepare(n)))
        for (n in listOf("Up In Smoke", "Sing Sing", "Wish Upon", "Soul Plane", "Brave New World", "The Wild Bunch", "Home Invasion"))
            assertFalse(n, Maturity.isKidsTitle(TextNorm.prepare(n)))
    }

    @Test fun descriptionsThatNameChildrenAreAKidsClue() {
        assertTrue(Maturity.plotKidsSign(TextNorm.prepare("A fun show for preschoolers about colours.")))
        assertTrue(Maturity.plotKidsSign(TextNorm.prepare("Songs and stories for kids of all ages.")))
        assertFalse(Maturity.plotKidsSign(TextNorm.prepare("A detective hunts a killer who targets children's charities.")))
    }

    @Test fun grownUpTvFilmsStayOutOfKids() {                                                          // v3.3.0
        assertFalse(ok("Murder On The Lake", "Family Movies"))
        assertFalse(ok("Secrets Of A Deadly Affair", "Family"))
        assertFalse(ok("Christmas At The Inn", "Hallmark Movies"))
        assertTrue(ok("Frozen", "Kids Movies"))                                                         // a well-known children's title is never touched
        assertTrue(ok("The Lion King", "Family", "Animation, Family, Romance"))
    }
}
