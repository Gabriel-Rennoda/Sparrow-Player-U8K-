package com.sparrow.player.ui.epg

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.TextPaint
import android.text.TextUtils
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import com.sparrow.player.R
import com.sparrow.player.data.Channel
import com.sparrow.player.data.Programme
import com.sparrow.player.util.fmtTime

/**
 * Canvas-drawn EPG grid (channels x time) with D-pad navigation.
 * Left/Right move between programmes, Up/Down between channels, OK plays the channel.
 * Drawing only touches visible rows/cells, so lists of several hundred channels stay smooth on TV SoCs.
 */
class EpgView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    data class Row(val channel: Channel, val programmes: List<Programme>)

    var onSelect: ((Row, Programme?) -> Unit)? = null
    var onPlay: ((Channel) -> Unit)? = null

    private var rows: List<Row> = emptyList()
    private var windowStart = 0L
    private var windowEnd = 0L
    private var selRow = 0
    private var selTime = 0L
    private var sx = 0f
    private var sy = 0f

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private val chanW = dp(220f)
    private val headerH = dp(38f)
    private val rowH = dp(54f)
    private val pxPerMin = dp(4.6f)
    private val radius = dp(6f)

    private fun col(id: Int) = context.getColor(id)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(15f) }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(13f); color = col(R.color.textDim) }
    private val line = Paint().apply { color = col(R.color.surface2); strokeWidth = 1f }
    private val nowPaint = Paint().apply { color = 0xFFE5484D.toInt() }

    init { isFocusable = true; isFocusableInTouchMode = false }

    fun setData(r: List<Row>, ws: Long, we: Long) {
        rows = r; windowStart = ws; windowEnd = we
        selRow = 0; selTime = System.currentTimeMillis(); sy = 0f
        post {
            sx = (timeToX(selTime) - dp(90f)).coerceIn(0f, maxScrollX())
            invalidate(); notifySel()
        }
    }

    private fun timeToX(t: Long) = (t - windowStart) / 60000f * pxPerMin
    private fun maxScrollX() = maxOf(0f, timeToX(windowEnd) - (width - chanW))
    private fun progAt(r: Int, t: Long): Programme? = rows[r].programmes.firstOrNull { t >= it.start && t < it.stop }
    private fun notifySel() { if (rows.isNotEmpty()) onSelect?.invoke(rows[selRow], progAt(selRow, selTime)) }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect); invalidate()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (rows.isEmpty()) return super.onKeyDown(keyCode, event)
        val progs = rows[selRow].programmes
        val cur = progAt(selRow, selTime)
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                val next = if (cur != null) progs.firstOrNull { it.start >= cur.stop } else progs.firstOrNull { it.start > selTime }
                if (next != null) { selTime = next.start + 1; changed() }
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                val prev = if (cur != null) progs.lastOrNull { it.stop <= cur.start } else progs.lastOrNull { it.stop <= selTime }
                if (prev != null) { selTime = maxOf(prev.start + 1, windowStart); changed() }
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> { if (selRow < rows.size - 1) { selRow++; changed() }; return true }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (selRow > 0) { selRow--; changed(); return true }
                return super.onKeyDown(keyCode, event)           // let focus leave to the category button
            }
            KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { selRow = minOf(rows.size - 1, selRow + 8); changed(); return true }
            KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { selRow = maxOf(0, selRow - 8); changed(); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                onPlay?.invoke(rows[selRow].channel); return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun changed() { ensureVisible(); invalidate(); notifySel() }

    private fun ensureVisible() {
        val vw = width - chanW; val vh = height - headerH
        val p = progAt(selRow, selTime)
        val x1 = timeToX(p?.start ?: selTime); val x2 = timeToX(p?.stop ?: (selTime + 1))
        if (x1 < sx) sx = x1 - dp(6f)
        else if (x2 > sx + vw) sx = if (x2 - x1 > vw) x1 - dp(6f) else x2 - vw + dp(6f)
        sx = sx.coerceIn(0f, maxScrollX())
        val y1 = selRow * rowH; val y2 = y1 + rowH
        if (y1 < sy) sy = y1 else if (y2 > sy + vh) sy = y2 - vh
        sy = sy.coerceIn(0f, maxOf(0f, rows.size * rowH - vh))
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (rows.isEmpty()) {
            text.color = col(R.color.textDim)
            c.drawText("No channels or guide data – add a provider / refresh in Settings.", dp(8f), h / 2, text); return
        }
        val gl = chanW; val gt = headerH
        val now = System.currentTimeMillis()
        val first = (sy / rowH).toInt().coerceAtLeast(0)
        val last = minOf(rows.size - 1, ((sy + h - gt) / rowH).toInt())
        val focused = isFocused

        // --- programme cells
        c.save(); c.clipRect(gl, gt, w, h)
        for (r in first..last) {
            val y = gt + r * rowH - sy
            val row = rows[r]
            if (row.programmes.isEmpty()) {
                fill.color = col(R.color.surface)
                c.drawRoundRect(gl + 2, y + 2, w - 2, y + rowH - 2, radius, radius, fill)
                c.drawText("No information", gl + dp(12f), y + rowH / 2 + dp(5f), small)
                continue
            }
            for (p in row.programmes) {
                val x1 = gl + timeToX(p.start) - sx; val x2 = gl + timeToX(p.stop) - sx
                if (x2 < gl || x1 > w) continue
                val selected = r == selRow && selTime >= p.start && selTime < p.stop
                val airing = p.start <= now && p.stop > now
                fill.color = when {
                    selected && focused -> col(R.color.accent)
                    selected -> col(R.color.surface2)
                    airing -> 0xFF2A1E15.toInt()
                    else -> col(R.color.surface)
                }
                c.drawRoundRect(x1 + 2, y + 2, x2 - 2, y + rowH - 2, radius, radius, fill)
                val tx = maxOf(x1, gl) + dp(10f)
                val avail = x2 - tx - dp(8f)
                if (avail > dp(28f)) {
                    text.color = if (selected && focused) col(R.color.onAccent) else col(R.color.text)
                    val t = TextUtils.ellipsize(p.title, text, avail, TextUtils.TruncateAt.END)
                    c.drawText(t, 0, t.length, tx, y + rowH / 2 + dp(5f), text)
                }
            }
        }
        val nx = gl + timeToX(now) - sx
        if (nx > gl && nx < w) c.drawRect(nx - 1.5f, gt, nx + 1.5f, h, nowPaint)
        c.restore()

        // --- time header
        c.save(); c.clipRect(gl, 0f, w, gt)
        fill.color = col(R.color.bg); c.drawRect(gl, 0f, w, gt, fill)
        var t = windowStart
        while (t <= windowEnd) {
            val x = gl + timeToX(t) - sx
            if (x > gl - dp(70f) && x < w) {
                c.drawLine(x, gt - dp(10f), x, gt, line)
                c.drawText(fmtTime(t), x + dp(6f), gt - dp(12f), small)
            }
            t += 30 * 60_000L
        }
        c.restore()

        // --- channel column
        c.save(); c.clipRect(0f, gt, gl, h)
        for (r in first..last) {
            val y = gt + r * rowH - sy
            val sel = r == selRow
            fill.color = if (sel) col(R.color.surface2) else col(R.color.bg)
            c.drawRect(0f, y, gl, y + rowH, fill)
            val ch = rows[r].channel
            small.color = col(R.color.textDim)
            c.drawText(ch.number.toString(), dp(6f), y + rowH / 2 + dp(5f), small)
            text.color = col(R.color.text)
            val name = TextUtils.ellipsize((if (ch.isFavorite) "★ " else "") + ch.name, text, gl - dp(56f), TextUtils.TruncateAt.END)
            c.drawText(name, 0, name.length, dp(46f), y + rowH / 2 + dp(5f), text)
        }
        c.restore()
        c.drawLine(gl, 0f, gl, h, line)
    }
}
