Next update (v3.6.0) - copy / paste this into the next chat
Same rules: investigate and test each item before changing code, apply in stages, test for the 75" U8K remote, then give me the updated zip. If anything is not completed, write a new copy-paste document.
Version 3.5.0 (versionCode 46) is the base (written WITHOUT a compiler). FIRST check the GitHub build log for the 3.5.0 run and fix compile errors before anything else. Check docs/TV_TEST_CHECKLIST_3_5.md (my results are pasted below).
Done in 3.5.0 (untested on the TV): Rename keeps the capital after backspacing to the start; Enter key = Done on the Sparrow keyboard (OK button still types); "more below" arrow ignores layout flicker (the end must hold 300 ms).
STILL OPEN: any Kids / Family title still wrong after the TMDB lookups (send title + page + details-page genre line).
NOT done: group loading cache; S2 animation + family tags beyond TMDB genres; S3 TMDB keywords for holiday carousels; S0 TMDB logo on About; 19 / 20 multiple custom Favourites sections; Copy To for Movies / Series; 12 live sync; 3 / 6 four-channel split screen; bigger watched badges (tell me what you want on the poster).
Each of these is large: pick ONE per chat so it can be done in stages and tested.
[paste checklist results here]
