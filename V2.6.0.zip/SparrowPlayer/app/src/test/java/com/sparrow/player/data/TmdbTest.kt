package com.sparrow.player.data

import org.junit.Assert.*
import org.junit.Test

class TmdbTest {
    @Test fun certificationCodes() {
        assertEquals("PG-13", Tmdb.movieCode("PG-13", "US")); assertEquals("R", Tmdb.movieCode("18A", "CA")); assertEquals("PG-13", Tmdb.movieCode("14A", "CA"))
        assertEquals("", Tmdb.movieCode("NR", "US")); assertEquals("TV-Y", Tmdb.tvCode("TV-Y7", "US")); assertEquals("TV-MA", Tmdb.tvCode("18+", "CA"))
    }

    @Test fun builtInKeyIsAV3Key() {
        assertTrue(Regex("[0-9a-f]{32}").matches(Tmdb.BUILT_IN_KEY))             // a v3 key is 32 hex digits (a v4 token is a long "eyJ..." text)
    }

    @Test fun strictestWins() {
        assertEquals("R", Tmdb.strictest(listOf("PG-13", "R", "PG"))); assertEquals("TV-14", Tmdb.strictest(listOf("TV-G", "TV-14"))); assertEquals("", Tmdb.strictest(emptyList()))
    }

    @Test fun movieCertificationFromTmdbAnswer() {
        val json = mapOf<String, Any?>("results" to listOf<Any?>(
            mapOf("iso_3166_1" to "FR", "release_dates" to listOf<Any?>(mapOf("certification" to "18"))),
            mapOf("iso_3166_1" to "US", "release_dates" to listOf<Any?>(mapOf("certification" to ""), mapOf("certification" to "R"))),
            mapOf("iso_3166_1" to "CA", "release_dates" to listOf<Any?>(mapOf("certification" to "14A")))))
        assertEquals("R", Tmdb.movieCertFrom(json))
        assertEquals("", Tmdb.movieCertFrom(emptyMap()))
    }

    @Test fun tvCertificationFromTmdbAnswer() {
        val json = mapOf<String, Any?>("results" to listOf<Any?>(mapOf("iso_3166_1" to "US", "rating" to "TV-MA"), mapOf("iso_3166_1" to "CA", "rating" to "14+")))
        assertEquals("TV-MA", Tmdb.tvCertFrom(json))
    }

    @Test fun onlyCertainMatchesAreAccepted() {
        val json = mapOf<String, Any?>("results" to listOf<Any?>(
            mapOf("id" to "1", "title" to "Cinderella", "original_title" to "Cinderella", "release_date" to "1950-02-15"),
            mapOf("id" to "2", "title" to "Cinderella Man", "original_title" to "Cinderella Man", "release_date" to "2005-06-03")))
        assertEquals(2, Tmdb.pickId(json, "Cinderella Man", 2005, false))
        assertEquals(1, Tmdb.pickId(json, "Cinderella", 1950, false))
        assertEquals(0, Tmdb.pickId(json, "Cinderella", 2015, false))       // wrong year: no guess
        assertEquals(0, Tmdb.pickId(json, "Cinder", 0, false))
    }

    @Test fun providerTitlesAreCleaned() {
        assertEquals("The Movie", Tmdb.cleanTitle("EN - The Movie (2019) 4K"))
        assertEquals("Heat", Tmdb.cleanTitle("Heat [MULTI] 1995"))
        assertEquals("Mission: Impossible", Tmdb.cleanTitle("Mission: Impossible"))
    }

    @Test fun storeRoundTrip() {
        val s = TmdbStore(); s.put("a", "PG", 5); s.put("b", "", 0)
        val back = TmdbStore.parse(s.serialize())
        assertTrue(back.has("a") && back.has("b")); assertEquals(mapOf("a" to "PG"), back.maturities()); assertEquals(2, back.size())
    }
}
